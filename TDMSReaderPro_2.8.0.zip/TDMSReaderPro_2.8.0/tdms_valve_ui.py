"""Valve events workspace with an auditable manual review; independent of main plot Fs."""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from html import escape
import statistics
from PyQt6.QtCore import Qt, QSignalBlocker, QTimer
from PyQt6.QtGui import QBrush, QColor, QFont
import numpy as np
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QDoubleSpinBox, QTreeWidget, QTreeWidgetItem, QHeaderView, QSplitter,
    QLineEdit, QFileDialog, QScrollArea, QSizePolicy, QFrame, QGroupBox)
import pyqtgraph as pg
from tdms_export import export_snapshot
from tdms_workspace import FunctionWorker, disable_native_menus, show_plot_menu
from tdms_valve import analyze_valve, manual_measurement, write_valve_report
from tdms_valve_auto import auto_analyze
from tdms_valve_controls import ValveSettingsMixin
from tdms_valve_rules import MODES


STATUS = {'complete':'Tamamlandı', 'unpaired':'Başlangıç uyumsuz', 'invalid':'Veri boşluğu',
          'cancelled':'Başlatan sinyal geri döndü', 'timeout':'Süre aşıldı', 'incomplete':'Bitiş eksik',
          'ambiguous':'Eşzamanlı kenarlar / belirsiz'}
REVIEWS = {'pending':'Bekliyor', 'approved':'Onaylandı', 'adjusted':'Elle doğrulandı', 'rejected':'Reddedildi'}
DIRECTIONS = {'opening': 'Açılma', 'closing': 'Kapanma'}
ISSUE_COLOR = '#D9822B'


def effective_duration(event):
    """Duration that counts in the summary: reviewed manual value, else a complete automatic one."""
    if event['review'] == 'rejected':
        return None
    if event['manual'] is not None and event['review'] in ('approved', 'adjusted'):
        return event['manual']['duration']
    return event['duration'] if event['status'] == 'complete' else None


def needs_review(event):
    return event['status'] != 'complete' and event['review'] == 'pending'


def ms_text(seconds):
    return f'{round(seconds*1000, 3):.10g} ms'


def duration_summary(events, direction):
    values = [d for d in map(effective_duration, (e for e in events if e['direction'] == direction)) if d is not None]
    if not values:
        return None
    return {'n': len(values), 'mean': statistics.fmean(values), 'min': min(values), 'max': max(values),
            'std': statistics.stdev(values) if len(values) > 2 else None,
            'manual': sum(e['manual'] is not None and e['review'] in ('approved', 'adjusted')
                          for e in events if e['direction'] == direction)}


class ValveMixin(ValveSettingsMixin):
    def _init_valve(self):
        self._valve_result = None
        self._valve_signature = None
        self._valve_busy = False
        self._valve_draft = None
        self._valve_hint = None
        self._valve_origin = 0.
        self._valve_token = 0
        self._valve_manual_token = 0
        self._valve_updating = False
        self._valve_timer = QTimer(self)
        self._valve_timer.setSingleShot(True)
        self._valve_timer.setInterval(200)
        self._valve_timer.timeout.connect(self._valve_request_manual)
        self.valve_tab = QScrollArea()
        self.valve_tab.setWidgetResizable(True)
        self.valve_tab.setFrameShape(QScrollArea.Shape.NoFrame)
        content = QWidget()
        self.valve_tab.setWidget(content)
        root = QVBoxLayout(content); root.setContentsMargins(10,8,10,8); root.setSpacing(6)
        title = QLabel('Vana açılma ve kapanma süreleri')
        title.setStyleSheet('font-weight: 700; font-size: 14px;')
        root.addWidget(title)
        hint = QLabel('İki kanalı ana grafikte çizin, bağlantı türünü ve kanalları seçip <b>Süreleri Hesapla</b>’ya basın. '
                      'Analiz özgün örnekleri kullanır; ana grafik filtresi ve X/Y kaydırmaları uygulanmaz.')
        hint.setWordWrap(True); hint.setProperty('valveHint', True); root.addWidget(hint)
        self._valve_build_controls(root)
        actions = QHBoxLayout()
        self.valve_run = QPushButton('Süreleri Hesapla'); self.valve_run.setProperty('primary',True)
        self.valve_run.setMinimumWidth(150)
        self.valve_stop = QPushButton('Durdur'); self.valve_stop.setEnabled(False)
        self.valve_csv = QPushButton('CSV’ye Aktar'); self.valve_csv.setEnabled(False)
        self.valve_csv.setToolTip('Tüm olayları, otomatik ve elle doğrulanan süreleri ve kullanılan ayarları CSV olarak kaydeder.')
        self.valve_run.clicked.connect(self._valve_analyze)
        self.valve_stop.clicked.connect(self._valve_cancel)
        self.valve_csv.clicked.connect(self._valve_export)
        for b in (self.valve_run,self.valve_stop,self.valve_csv): actions.addWidget(b)
        self.valve_summary = QLabel('İki kanal seçin.'); self.valve_summary.setWordWrap(True)
        actions.addWidget(self.valve_summary,1); root.addLayout(actions)
        results = QGroupBox('2 · Sonuç')
        rl = QVBoxLayout(results); rl.setContentsMargins(12,18,12,10); rl.setSpacing(6)
        cards = QHBoxLayout(); cards.setSpacing(8)
        self.valve_cards = {}
        for key, caption in (('opening','Açılma süresi'),('closing','Kapanma süresi'),('issues','Kontrol edilecek olay')):
            frame, value, detail = self._valve_card(caption)
            self.valve_cards[key] = (frame, value, detail); cards.addWidget(frame, 1)
        self.valve_next_issue = QPushButton('Sonrakini göster ›'); self.valve_next_issue.setFlat(True)
        self.valve_next_issue.clicked.connect(self._valve_show_next_issue); self.valve_next_issue.hide()
        self.valve_cards['issues'][0].layout().addWidget(self.valve_next_issue, 0, Qt.AlignmentFlag.AlignLeft)
        rl.addLayout(cards)
        self.valve_used = QLabel(); self.valve_used.setWordWrap(True); self.valve_used.setProperty('valveHint', True)
        self.valve_used.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        rl.addWidget(self.valve_used)
        self.valve_notice = QFrame(); self.valve_notice.setObjectName('valveNotice')
        nl = QHBoxLayout(self.valve_notice); nl.setContentsMargins(10,6,10,6)
        self.valve_notice_text = QLabel(); self.valve_notice_text.setWordWrap(True)
        self.valve_hint_button = QPushButton('Öneriyi uygula ve yeniden hesapla')
        self.valve_hint_button.clicked.connect(self._valve_apply_hint)
        nl.addWidget(self.valve_notice_text,1); nl.addWidget(self.valve_hint_button)
        rl.addWidget(self.valve_notice); self.valve_notice.hide()
        root.addWidget(results)
        events = QGroupBox('3 · Olaylar ve elle doğrulama')
        el = QVBoxLayout(events); el.setContentsMargins(8,18,8,8)
        split = QSplitter(Qt.Orientation.Vertical)
        self.valve_tree = QTreeWidget()
        self.valve_tree.setRootIsDecorated(False); self.valve_tree.setAlternatingRowColors(True)
        self.valve_tree.setHeaderLabels(['Olay','Başlangıç [s]','Bitiş [s]','Oto. süre [ms]', 'Ölçüm durumu','Elle süre [ms]','Doğrulama'])
        self.valve_tree.setMinimumHeight(105)
        self.valve_tree.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)
        self.valve_tree.setSortingEnabled(False)
        self.valve_tree.header().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.valve_tree.header().setStretchLastSection(True)
        self.valve_tree.currentItemChanged.connect(self._valve_event_selected)
        split.addWidget(self.valve_tree)
        preview = QWidget(); pl = QVBoxLayout(preview); pl.setContentsMargins(0,0,0,0); pl.setSpacing(4)
        self.valve_canvas = pg.GraphicsLayoutWidget()
        self.valve_canvas.setMinimumHeight(350)
        self.valve_canvas.ci.layout.setContentsMargins(10,10,10,18)
        self.valve_canvas.ci.layout.setVerticalSpacing(14)
        self.valve_canvas.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)
        self.valve_plot_open = self.valve_canvas.addPlot(row=0,col=0)
        self.valve_plot_closed = self.valve_canvas.addPlot(row=1,col=0)
        self.valve_plot_open.setXLink(self.valve_plot_closed)
        self.valve_plot_open.hideAxis('bottom')
        self.valve_plots = [self.valve_plot_open,self.valve_plot_closed]
        for plot,caption in zip(self.valve_plots,('A','B')):
            plot.setLabel('left',caption); plot.setYRange(-.15,1.15,padding=0)
            plot.getAxis('left').setTicks([[(0,'0'),(1,'1')]])
            plot.setMouseEnabled(x=True,y=False); plot.showGrid(x=True,y=True,alpha=.12)
            plot.setMenuEnabled(False); plot.hideButtons()
        disable_native_menus(self.valve_canvas)
        self.valve_canvas.customContextMenuRequested.connect(lambda p: show_plot_menu(self,self.valve_canvas,p,[
            ('Seçili Olaya Sığdır',self._valve_zoom_event),('Tüm Kaydı Göster',self._valve_zoom_all)]))
        self._valve_lines = []
        for plot in self.valve_plots:
            for endpoint,color in enumerate(('#0899aa','#d8770b')):
                line=pg.InfiniteLine(angle=90,movable=True,pen=pg.mkPen(color,width=2),label='Baş.' if endpoint==0 else 'Bit.')
                line.sigPositionChangeFinished.connect(lambda line, i=endpoint:self._valve_line_changed(i,line.value()))
                plot.addItem(line); line.hide(); self._valve_lines.append(line)
        legend = QLabel('Sol: ham sinyal. Sağ: aktif seviyeye çevrilmiş 0/1 durum; renkli = kabul edilen, kesikli = filtre öncesi, '
                        '× = elenen kısa durum. Baş./Bit. çizgilerini sürükleyerek olayı elle düzeltebilirsiniz.')
        legend.setWordWrap(True); legend.setProperty('valveHint', True); pl.addWidget(legend)
        pl.addWidget(self.valve_canvas,1)
        pl.addSpacing(18)
        self.valve_detail = QLabel('Bir olay seçin. Başlangıç/bitiş çizgilerini sürükleyerek özgün örnekleri kontrol edin.')
        self.valve_detail.setWordWrap(True); pl.addWidget(self.valve_detail)
        row=QHBoxLayout(); self.valve_a=QDoubleSpinBox(); self.valve_b=QDoubleSpinBox()
        for label,box in (('Başlangıç [s]:',self.valve_a),('Bitiş [s]:',self.valve_b)):
            box.setRange(-1e15,1e15); box.setDecimals(9); box.setKeyboardTracking(False)
            box.setEnabled(False); row.addWidget(QLabel(label)); row.addWidget(box,1)
            box.valueChanged.connect(self._valve_boxes_changed)
        self.valve_restore=QPushButton('Otomatiğe Dön'); self.valve_restore.clicked.connect(self._valve_restore_auto)
        row.addWidget(self.valve_restore); pl.addLayout(row)
        row=QHBoxLayout()
        self.valve_review_note=QLineEdit(); self.valve_review_note.setPlaceholderText('Doğrulama notu (isteğe bağlı)')
        self.valve_review_note.textEdited.connect(self._valve_note_edited)
        self.valve_accept=QPushButton('Doğrulamayı Kaydet'); self.valve_accept.setProperty('primary',True)
        self.valve_reject=QPushButton('Reddet')
        self.valve_accept.clicked.connect(self._valve_approve)
        self.valve_reject.clicked.connect(self._valve_reject_event)
        row.addWidget(self.valve_review_note,1); row.addWidget(self.valve_accept); row.addWidget(self.valve_reject)
        pl.addLayout(row)
        split.addWidget(preview); split.setStretchFactor(0,1); split.setStretchFactor(1,2); split.setSizes([160,350])
        el.addWidget(split,1)
        root.addWidget(events,1)
        footer=QLabel('Otomatik sonuç korunur; elle doğrulama ayrı kaydedilir ve özet kartlarına yansır. '
                      'Vana sonuçları .tdmsproj içinde saklanmaz; CSV’ye aktarın.')
        footer.setWordWrap(True); footer.setProperty('valveHint', True); root.addWidget(footer)
        self.tabs.addTab(self.valve_tab,'Vana Analizi')
        self._valve_curves=[]
        self._valve_logic_plots=[]
        self._valve_set_review_enabled(False)
        self._valve_theme()
        self._valve_refresh()

    @staticmethod
    def _valve_card(caption):
        frame = QFrame(); frame.setObjectName('valveCard')
        layout = QVBoxLayout(frame); layout.setContentsMargins(12,8,12,8); layout.setSpacing(1)
        title = QLabel(caption); title.setProperty('valveCardTitle', True)
        value = QLabel('—'); value.setProperty('valveCardValue', True)
        value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        detail = QLabel(''); detail.setProperty('valveCardDetail', True); detail.setWordWrap(True)
        for widget in (title, value, detail):
            layout.addWidget(widget)
        return frame, value, detail

    def _valve_theme(self):
        if not hasattr(self,'valve_canvas'): return
        dark=self._theme=='dark'
        self.valve_canvas.setBackground('#101624' if dark else '#ffffff')
        for line in self._valve_lines:
            line.label.setColor('#d5e0ee' if dark else '#203248')
        for plot in self.valve_plots+getattr(self,'_valve_logic_plots',[]):
            for key in ('left','bottom'):
                plot.getAxis(key).setPen('#b6c5d5' if dark else '#526475')
                plot.getAxis(key).setTextPen('#d5e0ee' if dark else '#203248')

    def _valve_set_review_enabled(self,enabled):
        for widget in (self.valve_a,self.valve_b,self.valve_restore,self.valve_review_note,self.valve_reject): widget.setEnabled(enabled)
        self.valve_accept.setEnabled(enabled and self._valve_draft is not None)

    def _valve_refresh(self):
        if not hasattr(self,'valve_open'): return
        candidates=[s for s in self.current_series or [] if not s.get('is_virtual')]
        signature=tuple((s['style_key'],s.get('fs_est'),s.get('x_mode'),s.get('effective_x_base'),s.get('sample_count'),
                         s.get('source_path'),repr(s.get('source_fingerprint')),None if s.get('lazy') else id(s['y'])) for s in candidates)
        if signature==self._valve_signature: return
        self._valve_signature=signature
        old=[self.valve_open.currentData(),self.valve_closed.currentData()]
        for combo,selected in zip((self.valve_open,self.valve_closed),old):
            with QSignalBlocker(combo):
                combo.clear();combo.addItem('Kanal seçin…',None)
                for s in candidates:
                    fs,origin=self._effective_fs_source(s)
                    label=' / '.join([s.get('file_label',''),s.get('group',''),s['name']])
                    combo.addItem(f"{label} · {fs:g} Hz ({origin})" if fs else f'{label} · Fs bilinmiyor',s['style_key'])
                ix=combo.findData(selected); combo.setCurrentIndex(max(0,ix))
        self._valve_reset('Kanal veya zaman değişti. Kanalları seçip Süreleri Hesapla’ya basın.' if candidates
                          else 'Önce ana grafikte iki kanal çizin.')

    def _valve_reset(self,message):
        if not hasattr(self,'valve_tree'): return
        self._cancel_jobs(['valve','valve_manual']); self._valve_timer.stop()
        self._valve_token+=1;self._valve_manual_token+=1
        self._valve_result=None;self._valve_draft=None;self._valve_busy=False;self._valve_hint=None
        self.valve_tree.clear(); self.valve_csv.setEnabled(False);self.valve_run.setEnabled(True);self.valve_stop.setEnabled(False)
        self.valve_summary.setText(message);self.valve_detail.setText('Bir olay seçerek özgün örnekleri kontrol edin.')
        for curve,plot in self._valve_curves: plot.removeItem(curve)
        self._valve_curves=[]
        for plot in self._valve_logic_plots: self.valve_canvas.removeItem(plot)
        self._valve_logic_plots=[]
        self._valve_lines=self._valve_lines[:4]
        for line in self._valve_lines: line.hide()
        self._valve_set_review_enabled(False)
        self._valve_update_cards()
        self.valve_notice.hide()
        self._valve_show_settings_state()

    def _valve_show_settings_state(self):
        if not hasattr(self,'valve_used') or self._valve_result is not None: return
        if self.valve_auto.isChecked():
            self.valve_used.setText('Giriş türü, eşikler ve parazit filtresi hesaplama sırasında veriden belirlenecek.')
        else:
            self.valve_used.setText('Otomatik ayar kapalı; Gelişmiş ayarlar’daki değerler kullanılacak.')

    def _valve_selection_changed(self,*args):
        self._valve_reset('Seçim/ayar değişti. Süreleri Hesapla’ya basın.')

    def _valve_cancel(self):
        self._valve_reset('Analiz durduruldu; tamamlanmış sonuç gösterilmiyor.')

    def _valve_sources(self):
        by_key={s['style_key']:s for s in self.current_series or []}
        keys=[self.valve_open.currentData(),self.valve_closed.currentData()]
        if any(k not in by_key for k in keys): raise ValueError('A ve B kanallarını seçin.')
        sources=[]
        for k in keys:
            s=by_key[k]; snap=export_snapshot(s)
            snap.update(source_path=s.get('source_path'),source_fingerprint=s.get('source_fingerprint'))
            sources.append(snap)
        return sources

    def _valve_analyze(self):
        self._valve_reset('Tam kayıt taranıyor…')
        auto=self.valve_auto.isChecked()
        try:
            sources=self._valve_sources()
            options=self._valve_options(auto=auto)
        except Exception as exc:
            self.valve_summary.setText(str(exc));return
        token=self._valve_token; self._valve_busy=True
        self.valve_run.setEnabled(False); self.valve_stop.setEnabled(True)
        if auto: self.valve_summary.setText('Seviyeler, eşikler ve parazit filtresi belirleniyor; tam kayıt taranıyor…')
        analyze=auto_analyze if auto else analyze_valve
        worker=FunctionWorker(lambda cancel: analyze(sources,options,cancel))
        self._start_job(worker,lambda p:self._valve_ready(token,p),lambda msg:self._valve_failed(token,msg),tag='valve')

    def _valve_failed(self,token,message):
        if token==self._valve_token: self._valve_reset(message)

    def _valve_ready(self,token,result):
        if token!=self._valve_token or result.get('cancelled'):return
        self._valve_result=result;self._valve_busy=False
        self.valve_run.setEnabled(True);self.valve_stop.setEnabled(False)
        if 'auto' in result: self._valve_apply_detected(result['options'])
        # Relative axis keeps UTC spin boxes readable and preserves sub-second display precision.
        self._valve_origin=result['bounds'][0]
        self.valve_plot_closed.setLabel('bottom','Zaman',units='s')
        self.valve_plot_closed.getAxis('bottom').enableAutoSIPrefix(False)
        self.valve_plot_closed.getAxis('bottom').setHeight(48)
        self._valve_draw_diagnostics(result)
        rows=result['events'];complete=sum(e['status']=='complete' for e in rows)
        skipped=[r['observed_s'] for runs in result['rejected_runs'] for r in runs]
        longest=f" (en uzun {ms_text(max(skipped))})" if skipped else ''
        self.valve_summary.setText(f"{complete} / {len(rows)} olay tamamlandı · elenen kısa durum: {len(skipped)}{longest} "
                                   f"· NaN/Inf örnek: {sum(result['invalid_samples'])}")
        numbers=Counter()
        self.valve_tree.blockSignals(True)
        for i,e in enumerate(rows):
            numbers[e['direction']]+=1
            item=QTreeWidgetItem();item.setData(0,Qt.ItemDataRole.UserRole,i);item.setData(0,Qt.ItemDataRole.UserRole+1,numbers[e['direction']])
            self.valve_tree.addTopLevelItem(item);self._valve_render_row(item,e)
        self.valve_tree.blockSignals(False)
        self.valve_csv.setEnabled(bool(rows))
        self._valve_update_cards()
        self._valve_describe(result)
        if rows:self.valve_tree.setCurrentItem(self.valve_tree.topLevelItem(0))
        else:self._valve_zoom_all();self.valve_detail.setText('Seçili kurala uygun başlangıç kenarı bulunamadı. İlk örnekteki seviye geçiş sayılmaz; bağlantı türünü, kanal rollerini ve aktif seviyeyi kontrol edin.')

    def _valve_describe(self,result):
        options,auto=result['options'],result.get('auto')
        parts=[]
        for j,(signal,source) in enumerate(zip(options.signals,result['sources'])):
            unit=f" {source['unit']}" if source.get('unit') else ''
            if signal.input_mode=='binary':
                kind='0/1 dijital'
            else:
                level=auto['levels'][j] if auto else None
                kind=(f"analog {level['low']:.4g}/{level['high']:.4g}{unit}, " if level else 'analog, ')+\
                     f"eşik {signal.low_threshold:.4g}/{signal.high_threshold:.4g}{unit}"
            polarity='ters (0 = aktif)' if signal.active_low else 'normal'
            parts.append(f"<b>{'AB'[j]}</b>: {escape(kind)} · {polarity} · filtre {ms_text(options.hold(j))}")
        wait=f" · azami bekleme {options.max_wait_s:g} s" if options.max_wait_s else ''
        rise=f" · 0→1 doğrulama {ms_text(options.rise_hold_s)}"
        head='Otomatik belirlenen ayarlar' if auto else 'Elle ayarlar'
        self.valve_used.setText(f"{head}: "+'  |  '.join(parts)+rise+wait)
        notes=[f"{'AB'[j]}: {level['warning']}." for j,level in enumerate(auto['levels']) if level['warning']] if auto else []
        self._valve_hint=auto.get('hint') if auto else None
        if self._valve_hint:
            notes.append(self._valve_hint_text(self._valve_hint,result))
        self.valve_notice_text.setText(' '.join(notes))
        self.valve_hint_button.setVisible(self._valve_hint is not None)
        self.valve_notice.setVisible(bool(notes))

    def _valve_hint_text(self,hint,result):
        options=result['options'];order=(1,0) if hint['swap'] else (0,1)
        changes=[]
        if hint['mode']!=options.mode: changes.append(f"bağlantı türü “{MODES[hint['mode']][0]}”")
        if hint['swap']: changes.append('A ve B kanalları yer değiştirilmiş')
        for i,low in enumerate(hint['active_low']):
            if low!=options.signals[order[i]].active_low:
                changes.append(f"{'AB'[i]} {'ters (0 = aktif)' if low else 'normal (1 = aktif)'}")
        complete=sum(e['status']=='complete' for e in result['events'])
        start=f" Bu ayarla ilk olay {DIRECTIONS[hint['first']].lower()}; yani vana kayıt başında " \
              f"{'kapalı' if hint['first']=='opening' else 'açık'} olmalı." if hint.get('first') else ''
        return (f"Öneri: {', '.join(changes)} seçilirse {hint['complete']}/{hint['events']} olay tamamlanıyor "
                f"(şu an {complete}/{len(result['events'])}).{start} Öneri yalnız kenar eşleşmesine dayanır; "
                f"kanal rollerini ve kayıt başındaki vana konumunu gerçek bağlantıya göre doğrulayın.")

    def _valve_apply_hint(self):
        hint=self._valve_hint
        if not hint:return
        if hint['swap']:self._valve_swap_channels()
        with QSignalBlocker(self.valve_mode):
            self.valve_mode.setCurrentIndex(self.valve_mode.findData(hint['mode']))
        self._valve_store('valve/mode',hint['mode'])
        for j,low in enumerate(hint['active_low']):
            polarity=self.valve_signal_controls[j][1]
            with QSignalBlocker(polarity):polarity.setCurrentIndex(polarity.findData(low))
        self._valve_update_rule()
        self._valve_analyze()

    def _valve_update_cards(self):
        if not hasattr(self,'valve_cards'):return
        events=self._valve_result['events'] if self._valve_result else []
        for direction in ('opening','closing'):
            _,value,detail=self.valve_cards[direction]
            stats=duration_summary(events,direction)
            if stats is None:
                value.setText('—');detail.setText('Tamamlanan olay yok' if self._valve_result else '')
                continue
            value.setText(('ort. ' if stats['n']>1 else '')+ms_text(stats['mean']))
            text=f"n = {stats['n']}"
            if stats['n']>1:text=f"min {ms_text(stats['min'])} · maks {ms_text(stats['max'])} · "+text
            if stats['std'] is not None:text+=f" · σ {ms_text(stats['std'])}"
            if stats['manual']:text+=f" · {stats['manual']} elle doğrulandı"
            detail.setText(text)
        frame,value,detail=self.valve_cards['issues']
        issues=[e for e in events if needs_review(e)]
        rejected=sum(e['review']=='rejected' for e in events)
        value.setText(str(len(issues)) if self._valve_result else '—')
        counts=Counter(STATUS[e['status']] for e in issues)
        text=' · '.join(f'{n} {name.lower()}' for name,n in counts.most_common())
        if rejected:text=(text+' · ' if text else '')+f'{rejected} reddedildi'
        detail.setText(text or ('Tüm olaylar tamamlandı' if events else ''))
        frame.setProperty('issue',bool(issues))
        frame.style().unpolish(frame);frame.style().polish(frame)
        self.valve_next_issue.setVisible(bool(issues))
        for key in ('opening','closing'):
            self.valve_cards[key][0].setToolTip('Elle doğrulanan olaylarda elle süre, diğer tamamlanan olaylarda otomatik süre kullanılır; '
                                                 'reddedilen olaylar hariçtir.')

    def _valve_show_next_issue(self):
        if not self._valve_result:return
        events=self._valve_result['events'];count=self.valve_tree.topLevelItemCount()
        item=self.valve_tree.currentItem()
        start=item.data(0,Qt.ItemDataRole.UserRole) if item else -1
        for step in range(1,count+1):
            candidate=self.valve_tree.topLevelItem((start+step)%count)
            if needs_review(events[candidate.data(0,Qt.ItemDataRole.UserRole)]):
                self.valve_tree.setCurrentItem(candidate);self.valve_tree.scrollToItem(candidate);return

    def _valve_draw_diagnostics(self, result):
        options = result['options']
        origin = self._valve_origin
        # Raw signals retain physical units and polarity on the left.
        for j, (trace, plot) in enumerate(zip(result['traces'], self.valve_plots)):
            analog = options.signals[j].input_mode == 'hysteresis'
            plot.setTitle(escape(f"{'AB'[j]} · Ham · {result['sources'][j]['name']}"), size='10pt')
            plot.setLabel('left', 'Ham değer')
            plot.getAxis('left').setTicks(None if analog else [[(0,'0'),(1,'1')]])
            plot.enableAutoRange(axis='y', enable=analog)
            plot.setMouseEnabled(x=True, y=analog)
            if not analog: plot.setYRange(-.15,1.15,padding=0)
            curve = plot.plot(trace['x']-origin, trace['y'], stepMode=None if analog else 'right',
                              pen=pg.mkPen('#8b97a8',width=1.4), connect='finite')
            self._valve_curves.append((curve,plot))
        # Separate axes prevent analog voltage and logical levels being confused.
        for j, color in enumerate(('#029da8','#d58019')):
            plot = self.valve_canvas.addPlot(row=j,col=1)
            self._valve_logic_plots.append(plot)
            plot.setTitle(f"{'AB'[j]} · Kabul edilen durum",size='10pt')
            plot.setLabel('left','Aktif')
            plot.getAxis('left').setTicks([[(0,'0'),(1,'1')]])
            plot.setYRange(-.15,1.15,padding=0); plot.setMouseEnabled(x=True,y=False)
            plot.setXLink(self.valve_plot_closed); plot.showGrid(x=True,y=True,alpha=.12)
            plot.setMenuEnabled(False); plot.hideButtons()
            if j == 0: plot.hideAxis('bottom')
            else:
                plot.setLabel('bottom','Zaman',units='s')
                plot.getAxis('bottom').enableAutoSIPrefix(False)
                plot.getAxis('bottom').setHeight(48)
            for key, pen in (('logical_traces',pg.mkPen('#8b97a8',width=1,style=Qt.PenStyle.DashLine)),
                             ('accepted_traces',pg.mkPen(color,width=2))):
                trace = result[key][j]
                curve = plot.plot(trace['x']-origin,trace['y'],stepMode='right',pen=pen,connect='finite')
                self._valve_curves.append((curve,plot))
            skipped = result['rejected_runs'][j]
            if skipped:
                curve = plot.plot(np.array([r['t'] for r in skipped])-origin,[r['state'] for r in skipped],
                                  pen=None,symbol='x',symbolSize=8,symbolPen=pg.mkPen('#d55169',width=2))
                self._valve_curves.append((curve,plot))
            sig = options.signals[j]
            if sig.input_mode == 'hysteresis':
                for threshold in (sig.low_threshold,sig.high_threshold):
                    line = pg.InfiniteLine(pos=threshold,angle=0,movable=False,
                                           pen=pg.mkPen(color,width=1,style=Qt.PenStyle.DashLine))
                    self.valve_plots[j].addItem(line); self._valve_curves.append((line,self.valve_plots[j]))
            for endpoint, cursor_color in enumerate(('#0899aa','#d8770b')):
                line = pg.InfiniteLine(angle=90,movable=True,pen=pg.mkPen(cursor_color,width=2),
                                       label='Baş.' if endpoint == 0 else 'Bit.')
                line.sigPositionChangeFinished.connect(lambda line,i=endpoint:self._valve_line_changed(i,line.value()))
                plot.addItem(line); line.hide(); self._valve_lines.append(line)
        disable_native_menus(self.valve_canvas)
        self._valve_theme()

    @staticmethod
    def _valve_fmt(value):return '—' if value is None else f'{value:.9g}'

    def _valve_render_row(self,item,e):
        fmt=self._valve_fmt; manual=e['manual']
        number=item.data(0,Qt.ItemDataRole.UserRole+1)
        values=[f"{DIRECTIONS[e['direction']]} {number or ''}".strip(),fmt(e['start']-self._valve_origin),
                fmt(None if e['end'] is None else e['end']-self._valve_origin),fmt(None if e['duration'] is None else 1000*e['duration']),
                STATUS[e['status']],fmt(None if manual is None else 1000*manual['duration']),REVIEWS[e['review']]]
        for col,value in enumerate(values):item.setText(col,value);item.setToolTip(col,e['note']+'\n'+e['review_note'])
        issue=needs_review(e)
        font=QFont(item.font(4));font.setBold(issue);item.setFont(4,font)
        item.setData(4,Qt.ItemDataRole.ForegroundRole,QBrush(QColor(ISSUE_COLOR)) if e['status']!='complete' else None)

    def _valve_row_changed(self,item,e):
        self._valve_render_row(item,e);self._valve_update_cards()

    def _valve_selected(self):
        item=self.valve_tree.currentItem()
        if not item or not self._valve_result:return None,None
        return item,self._valve_result['events'][item.data(0,Qt.ItemDataRole.UserRole)]

    def _valve_event_selected(self,*args):
        self._valve_timer.stop();self._cancel_jobs(['valve_manual']);self._valve_manual_token+=1
        item,e=self._valve_selected()
        if e is None:self._valve_set_review_enabled(False);return
        for line in self._valve_lines:line.show()
        m=e['manual'];bounds=self._valve_result['bounds']
        a=m['start'] if m else e['start']
        b=m['end'] if m else (e['end'] if e['end'] is not None else min(bounds[1],a+1))
        for box in (self.valve_a,self.valve_b):
            with QSignalBlocker(box):box.setRange(0,bounds[1]-self._valve_origin)
        self._valve_set_positions(a,b)
        self.valve_review_note.setText(e['review_note']); self._valve_draft=m
        self._valve_set_review_enabled(True);self._valve_zoom_event();self._valve_request_manual()

    def _valve_set_positions(self,a,b):
        self._valve_updating=True
        try:
            for box,value in ((self.valve_a,a),(self.valve_b,b)):
                with QSignalBlocker(box):box.setValue(value-self._valve_origin)
            for i,line in enumerate(self._valve_lines):
                with QSignalBlocker(line):line.setValue((a if i%2==0 else b)-self._valve_origin)
        finally:self._valve_updating=False

    def _valve_line_changed(self,endpoint,value):
        if not self._valve_result or self._valve_updating:return
        (self.valve_a if endpoint==0 else self.valve_b).setValue(value)

    def _valve_boxes_changed(self,*args):
        if self._valve_updating:return
        self._valve_set_positions(self.valve_a.value()+self._valve_origin,self.valve_b.value()+self._valve_origin)
        self._valve_draft=None; self.valve_accept.setEnabled(False)
        self._valve_manual_token+=1;self._cancel_jobs(['valve_manual'])
        item,e=self._valve_selected()
        if e is not None:
            e.update(review='pending',manual=None);self._valve_row_changed(item,e)
        self._valve_timer.start()

    def _valve_request_manual(self):
        item,e=self._valve_selected()
        if e is None:return
        self._valve_manual_token+=1;token=self._valve_manual_token
        self._valve_draft=None;self.valve_accept.setEnabled(False)
        sources=self._valve_result['sources'];direction=e['direction']
        a,b=self.valve_a.value()+self._valve_origin,self.valve_b.value()+self._valve_origin
        options=self._valve_result['options']
        worker=FunctionWorker(lambda cancel: manual_measurement(sources,direction,a,b,options))
        self._start_job(worker,lambda p:self._valve_manual_ready(token,p),lambda msg:self._valve_manual_failed(token,msg),tag='valve_manual',cancel_tags=['valve_manual'])

    def _valve_manual_ready(self,token,p):
        if token!=self._valve_manual_token:return
        item,e=self._valve_selected()
        if e is None:return
        self._valve_draft=p;self._valve_set_positions(p['start'],p['end']);self.valve_accept.setEnabled(True)
        sources=self._valve_result['sources']
        dt=' / '.join(f"{1000/float(s['fs_hz']):.6g} ms" for s in sources)
        bounds=f"Örnekleme kaynaklı süre sınırları: {1000*e['lower']:.6g}–{1000*e['upper']:.6g} ms. " if e['lower'] is not None else ''
        origin=self._valve_origin
        origin_text=datetime.fromtimestamp(origin,tz=timezone.utc).isoformat() if sources[0]['x_mode']=='datetime' else f'{origin:.9g} s'
        self.valve_detail.setText(f"Elle Δt = {1000*p['duration']:.9g} ms ({p['duration']:.9g} s). "
            f"Başlangıç ({'AB'[e['start_channel']]}): i={p['start_index']}, ham={p['start_value']:g}; "
            f"Bitiş ({'AB'[e['end_channel']]}): i={p['end_index']}, ham={p['end_value']:g}. "
            f"Örnek aralıkları (A/B): {dt}. {bounds}Grafikte 0 = {origin_text}. "
            f"{e['note']} Onay, örnekleme çözünürlüğünü artırmaz.")

    def _valve_manual_failed(self,token,message):
        if token==self._valve_manual_token:
            self._valve_draft=None;self.valve_accept.setEnabled(False);self.valve_detail.setText(message)

    def _valve_note_edited(self,text):
        item,e=self._valve_selected()
        if e is not None:e['review_note']=text;self._valve_render_row(item,e)

    def _valve_approve(self):
        item,e=self._valve_selected()
        if e is None or self._valve_draft is None or self._valve_timer.isActive():return
        p=dict(self._valve_draft)
        same=p['start_index']==e['start_index'] and p['end_index']==e['end_index'] and e['status']=='complete'
        e.update(manual=p,review='approved' if same else 'adjusted',review_note=self.valve_review_note.text())
        self._valve_row_changed(item,e)

    def _valve_reject_event(self):
        item,e=self._valve_selected()
        if e is not None:
            e.update(review='rejected',review_note=self.valve_review_note.text());self._valve_row_changed(item,e)

    def _valve_restore_auto(self):
        item,e=self._valve_selected()
        if e is None:return
        e.update(manual=None,review='pending');self._valve_row_changed(item,e);self._valve_event_selected()

    def _valve_zoom_event(self):
        item,e=self._valve_selected()
        if e is None:return
        a=self.valve_a.value();b=self.valve_b.value()
        step=max(1/float(s['fs_hz']) for s in self._valve_result['sources'])
        pad=max(abs(b-a)*.6,3*step)
        self.valve_plot_closed.setXRange(min(a,b)-pad,max(a,b)+pad,padding=0)

    def _valve_zoom_all(self):
        if self._valve_result:
            lo,hi=self._valve_result['bounds'];self.valve_plot_closed.setXRange(lo-self._valve_origin,hi-self._valve_origin,padding=.02)

    def _valve_export(self):
        if not self._valve_result:return
        path,_=QFileDialog.getSaveFileName(self,'Vana Olaylarını Kaydet','vana_olaylari.csv','CSV (*.csv)')
        if not path:return
        if not path.lower().endswith('.csv'):path+='.csv'
        try:
            write_valve_report(path,self._valve_result)
            self.status.showMessage('Otomatik sonuçlar ve kaydedilen doğrulamalar CSV’ye aktarıldı.',5000)
        except Exception as exc:self.valve_summary.setText(f'CSV kaydedilemedi: {exc}')
