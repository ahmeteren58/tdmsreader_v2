# 2.7.0 — Zaman kanalı bağlama

- `tdms_time_channels.py`: metadata ile RIO/modül önerileri; açık eşlemelerde
  otomatik bağlama, karışık model sırası/örnek sayısı adaylarında kullanıcı onayı.
  Birim dönüşümü, tüm zaman örneklerinde blok doğrulama ve skaler LRU önbellek.
- `tdms_time_channels_ui.py`: dosya/modül seçimi, arama, zaman kanalı dropdown'ları,
  Hz/başlangıç/durum, denetleme, uygulama ve dosya bazlı geri alma. Proje durum
  köprüleri ve değişmiş zamana göre mevcut yüklü sinyalleri yeniden okumadan güncelleme.
- `tdmsreader.py`: metadata kataloğu, loader zaman girdisi, yeni sekme, temel zaman
  kaynağı etiketi ve kısa grafik bilgileri için sınırlı entegrasyon.
- `tdms_project.py`: dosya bazlı isteğe bağlı zaman eşlemesini yüklemeye aktarır.
  Eski projelerde özellik varsayılan olarak kapalıdır.
- `tests/test_time_channels.py`: karışık hız, kayıpsızlık, bozuk zaman, geri alma,
  CSV/proje, lazy veri, değişmemiş vana motoruna doğru zaman iletimi ve hata akışı.
- `examples/create_time_channels_demo.py` ve `time_channels_mixed_rates.tdms`:
  waveform metadata olmadan 500/5000 Hz örnek. `ZAMAN_KANALLARI_TR.md`: kullanım.

Vana Analizi, timing, fake pulse filtering ve Basınç Kaybı algoritmaları aynı.
`tdms_io.py`, `tdms_viewport.py`, `tdms_numeric.py`, `tdms_jobs.py`,
`tdms_export.py`, `tdms_workspace.py`, `tdms_steady*.py`, `tdms_valve*.py`
2.6.0 ile bayt bayt aynı. Yeni resampling veya signal shift yoktur.

Times bağlama, temel kayıt zamanını tüm mevcut veri tüketicilerine iletir.
Channel Alignment ayrı kullanıcı ofseti olarak korunur; Vana Analizi'ne ek
alignment ofseti uygulanmaz. Times doğruluğu acquisition donanım senkronizasyonu
kanıtı değildir. Fiziksel proses gecikmesi silinmez.
