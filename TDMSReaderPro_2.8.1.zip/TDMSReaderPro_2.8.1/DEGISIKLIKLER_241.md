# 2.4.1 — Kapanma ölçümü düzeltmesi

Temel sorun, 2.4.0'ın kapanmada yalnız **Kapalı yükselir → Açık düşer** sırasını aramasıydı. Aktif yüksek iki konum anahtarında beklenen sıra genellikle **Açık düşer → Kapalı yükselir** olur. Buna ek olarak tek örneklik parazitler başlangıcı iptal ediyor veya erken bitiş üretiyordu.

## Yapılan değişiklikler

- Açılma ve kapanma için seçilebilir ölçüm modları: iki konum anahtarı, komut + kapalı konum, komut + açık konum, özel kenarlar. Eski kural geriye uyum için varsayılan olarak korunur.
- Kanal bazında ayrı kararlılık süresi ve aktif yüksek/düşük polarite.
- İsteğe bağlı analog histerezis: ham birimde iki eşik, bant içinde durum koruma, boşluk sonrasında yeniden durum belirleme.
- Ham sinyal ile analizde kabul edilen durumun ayrı eksenlerde gösterimi. Elenen kısa darbeler × ile işaretlenir.
- Eşzamanlı bitiş ve geri dönüş için ayrı “belirsiz” durumu; otomatik süre uydurulmaz.
- “Başlangıç uyumsuz” uyarısında beklenen/görülen seviye ve kural açıklanır. “Tetik geri çekildi” daha açık olan “Başlatan sinyal geri döndü” adıyla gösterilir.
- Manuel ölçüm, seçilen modun doğru başlangıç ve bitiş kanalının özgün örneklerine oturur; farklı Fs'lerde indeksler karıştırılmaz.
- Olay CSV'sine mod, kanal rolleri, kenarlar, kanal bazlı kararlılık ve tüm koşullandırma ayarları eklendi. Eski otomatik/manuel sütunlar korundu.
- Büyük analog kayıtların yalnız önizlemesi min/max ile küçültülür; analiz her örneği bloklar halinde işler. Kaynak dosyanın analiz sırasında değişmesi denetlenir.
- Türkçe kullanım/tanı belgesi, gürültülü sentetik TDMS örneği ve regresyon testleri eklendi.

## Hızlı başlangıç

İki sinyal de vana konum anahtarıysa **İki konum anahtarı** modunu seçin: A = açık konum, B = kapalı konum. A açma komutu, B kapalı konum geri bildirimiyse **Komut + kapalı konum** kullanın. Aktif seviyeyi sinyallerinizin gerçek bağlantısına göre seçin.

Kararlılık süresi için evrensel bir değer yoktur. Paketteki 1 kHz sentetik örnekte 3 ms, eklenen 1–2 ms parazitleri eler. Gerçek kaydınızda kısa parazit ile gerçek hareketi ham/kabul edilen grafiklerinden ayırt edin. Çok yüksek kararlılık kısa gerçek olayları da eleyecektir.

ZIP'i yeni klasöre tamamen çıkarın; yalnız `tdmsreader.py` dosyasını değiştirmeyin. Yeni `tdms_valve_rules.py` ve `tdms_valve_controls.py` modülleri gereklidir. Windows'ta `kurulum_windows.bat`, ardından `baslat_windows.bat` kullanılır. Mevcut EXE kaynak dosyalarla kendiliğinden güncellenmez; `TDMSReaderPro.spec` ile yeniden derlenir.

## Sınırlar

Doğrulama sentetik kayıtlar ve Linux/offscreen Qt ile yapıldı. Kullanıcının sorunlu gerçek TDMS kaydı sağlanmadığından o kayıt özelinde fiziksel süre doğruluğu doğrulanamadı. Windows EXE derlenmedi. Vana analizi/ayarları `.tdmsproj` içine kaydedilmez; sonuç ve ayarları Olay CSV ile saklayın.
