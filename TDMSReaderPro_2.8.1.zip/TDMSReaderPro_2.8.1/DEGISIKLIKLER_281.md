# 2.8.1 — Arayüz düzenlemesi

Yalnız görünüm ve yerleşim. Hesap, zaman eşleme, okuma ve dışa aktarma kodu
2.8.0 ile aynıdır.

## Tema

- `tdms_theme.py` (yeni): açık ve koyu tema tek bir renk paletinden üretilir.
  Önceki dört ayrı stil katmanı ile `presentation_qss` kaldırıldı; yeşil, mavi
  ve camgöbeği karışık vurgular yerine tek bir mühendislik mavisi kullanılır.
- Nötr gri pencere zemini, beyaz paneller, 3–4 px köşe, ince 1 px çizgiler.
  Butonlar, giriş alanları, sekmeler, tablo başlıkları, menüler, kaydırma
  çubukları ve durum çubuğu aynı ölçü ve renk kurallarını izler.
- Onay kutuları ve radyo düğmeleri iki temada da belirgin; kanal ağacında
  kısmi seçim (–) ayrı gösterilir. Ağaç dalları ok ikonlarıyla açılır.
- Uyarı bildirimleri (eski ofsetler, vana uyarıları) aynı sarı tonla,
  sonuç kartları sol vurgu çizgisiyle gösterilir.
- Grafik eksenleri saf siyah/beyaz yerine yumuşak gri çizgi ve okunur
  etiketlerle çizilir. Koyu temada grafik zemini siyah yerine koyu antrasittir.
  Vana Analizi ve Basınç Kaybı grafikleri aynı renkleri kullanır.

## Şerit (ribbon)

- **Proje** artık **Dosya** grubunda, **Kalite** (Veri Kalitesi) **Ölçüm**
  grubunda; grupsuz buton kalmadı.
- İki satıra bölünüp kırpılan etiketler tek satır: **Görüntü** (grafiği
  PNG/SVG kaydet), **Kalite**. Overlay/Stacked seçimi **Düzen** adını aldı;
  son grup **Pencere** oldu (iki ayrı "Görünüm" karışıklığı giderildi).
- Bütün şerit butonları aynı boyutta; açıklamalar araç ipuçlarında.

## Küçük düzeltmeler

- Detay Ayarları çekmecesindeki kapatma işareti bazı fontlarda nokta olarak
  görünüyordu; ikonla değiştirildi. Çekmece sekmelerinde gri zemin taşması
  giderildi.
- Dosya sekmesi kapatma düğmesi kırmızı kare yerine sade × ikonu.
- İmleç okuması ve Arka Plan Rengi düğmesi diğer kontrollerle aynı biçimde.

Yeni ikonlar: `close.svg`, `dash_white.svg` (açık/koyu).
