"""Versioned project archives. No pickle, script execution, or source mutation."""
from __future__ import annotations
import copy
import json
import os
import math
import tempfile
import zipfile
from pathlib import Path
import numpy as np
from tdms_io import open_tdms
from tdms_export import ExportCancelled

FORMAT = "TDMSReaderProject"
VERSION = 2
TIMING_POLICY = "manual_or_metadata_v1"


def file_reference(path, project_path):
    path = Path(path).resolve()
    stat = path.stat()
    try:
        relative = os.path.relpath(path, Path(project_path).resolve().parent)
    except ValueError:  # different Windows drives
        relative = None
    return {"path": str(path), "relative_path": relative,
            "size": stat.st_size, "mtime_ns": stat.st_mtime_ns}


def resolve_source(record, project_path):
    parent = Path(project_path).resolve().parent
    candidates = []
    if record.get("relative_path"):
        candidates.append(parent / record["relative_path"])
    candidates.append(Path(record["path"]))
    # Moving the project together with its sources keeps the relative paths valid.
    for candidate in candidates:
        if candidate.is_file():
            stat = candidate.stat()
            if stat.st_size != record["size"] or stat.st_mtime_ns != record["mtime_ns"]:
                raise ValueError(f"Kaynak dosya değişmiş: {candidate.name}. TDMS'yi yeniden açıp yeni proje kaydedin.")
            return str(candidate.resolve())
    raise FileNotFoundError(f"Kaynak bulunamadı: {record['path']}. Projeyi ve TDMS dosyalarını kayıt sırasındaki göreli klasör düzeniyle taşıyın.")


def save_project_archive(path, manifest, virtual_series, cancelled=lambda: False):
    destination = Path(path).resolve()
    for record in manifest["files"]:
        if os.path.normcase(str(Path(record["path"]).resolve())) == os.path.normcase(str(destination)):
            raise ValueError("Proje hedefi kaynak TDMS dosyası olamaz.")
    data = copy.deepcopy(manifest)
    data.update(format=FORMAT, version=VERSION, timing_policy=TIMING_POLICY, time_display="relative_seconds_v1")
    for record in data["files"]:
        original = (record["size"], record["mtime_ns"])
        updated = file_reference(record["path"], path)
        if original != (updated["size"], updated["mtime_ns"]):
            raise ValueError(f"Kaynak kayıt sırasında değişti: {record['path']}")
        record.update(updated)
    encoded = json.dumps(data, ensure_ascii=False, allow_nan=False).encode("utf-8")
    fd, temporary = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent)
    try:
        with os.fdopen(fd, "w+b") as stream:
            with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as archive:
                archive.writestr("project.json", encoded)
                for i, series in enumerate(virtual_series):
                    for name in ("x", "y", "source_x"):
                        if cancelled():
                            raise ExportCancelled()
                        values = np.asarray(series.get(name, series["x"]))
                        if values.ndim != 1 or values.dtype.kind not in "biuf":
                            raise ValueError("Hesaplanan kanal dizisi gerçek sayısal ve tek boyutlu olmalı.")
                        with archive.open(f"virtual/{i}/{name}.npy", "w", force_zip64=True) as item:
                            np.lib.format.write_array(item, values, allow_pickle=False)
            stream.flush()
            os.fsync(stream.fileno())
        if cancelled():
            raise ExportCancelled()
        os.replace(temporary, destination)
        temporary = None
        return {"path": str(destination)}
    finally:
        if temporary is not None:
            os.unlink(temporary)


def read_project_archive(path, cancelled=lambda: False):
    with zipfile.ZipFile(path) as archive:
        if archive.getinfo("project.json").file_size > 8 * 1024**2:
            raise ValueError("Proje metadata'sı desteklenen sınırı aşıyor.")
        data = json.loads(archive.read("project.json"), parse_constant=lambda v: (_ for _ in ()).throw(ValueError(f"Geçersiz sayı: {v}")))
        if not isinstance(data, dict) or data.get("format") != FORMAT or data.get("version") not in (1, VERSION):
            raise ValueError("Proje biçimi veya sürümü desteklenmiyor.")
        if data["version"] == VERSION and data.get("timing_policy") != TIMING_POLICY:
            raise ValueError("Projenin zaman politikası desteklenmiyor.")
        for name in ("files", "channels", "virtual"):
            if not isinstance(data.get(name), list) or len(data[name]) > 10000:
                raise ValueError(f"Geçersiz proje alanı: {name}")
        if not isinstance(data.get("ui"), dict) or not isinstance(data.get("styles"), dict):
            raise ValueError("Proje ayarları geçersiz.")
        ids = [r["id"] for r in data["files"]]
        if len(ids) != len(set(ids)) or not all(isinstance(i, str) for i in ids):
            raise ValueError("Yinelenen veya geçersiz kaynak kimliği.")
        for record in data["files"]:
            for checked in record.get("checked", []):
                if not isinstance(checked, dict) or not all(isinstance(checked.get(k), str) for k in ("group", "channel", "name")) or not isinstance(checked.get("checked"), bool):
                    raise ValueError("Geçersiz proje kanal seçimi.")
            if cancelled():
                raise ExportCancelled()
            record["resolved_path"] = resolve_source(record, path)
        virtual = []
        for i, record in enumerate(data["virtual"]):
            series = dict(record)
            if not series.get("is_virtual") or not all(isinstance(series.get(k), str) for k in ("style_key", "name", "unit", "virtual_expression")):
                raise ValueError("Geçersiz hesaplanan kanal metadata'sı.")
            if series.get("x_mode") not in ("index", "seconds", "datetime") or series.get("source_x_mode") not in ("index", "seconds", "datetime"):
                raise ValueError("Geçersiz hesaplanan kanal zaman türü.")
            for name in ("source_x_base", "source_x_inc"):
                if not isinstance(series.get(name), (float, int)) or not math.isfinite(series[name]):
                    raise ValueError("Geçersiz hesaplanan kanal zaman adımı.")
            for name in ("x", "y", "source_x"):
                if cancelled():
                    raise ExportCancelled()
                entry = archive.getinfo(f"virtual/{i}/{name}.npy")
                # Validate the header before allocating. NPY object payloads and
                # a forged shape cannot cause arbitrary unpickling/allocation.
                with archive.open(entry) as item:
                    version = np.lib.format.read_magic(item)
                    if version == (1, 0):
                        shape, _, dtype = np.lib.format.read_array_header_1_0(item)
                    elif version == (2, 0):
                        shape, _, dtype = np.lib.format.read_array_header_2_0(item)
                    else:
                        raise ValueError("Desteklenmeyen dizi sürümü.")
                    if len(shape) != 1 or dtype.kind not in "biuf" or shape[0]*dtype.itemsize != entry.file_size-item.tell():
                        raise ValueError("Geçersiz proje dizisi.")
                with archive.open(entry) as item:
                    series[name] = np.lib.format.read_array(item, allow_pickle=False)
            if len(series["x"]) != len(series["y"]) or len(series["source_x"]) != len(series["y"]):
                raise ValueError("Projedeki hesaplanan kanal uzunlukları uyuşmuyor.")
            virtual.append(series)
        # Removed timing fields are never evaluated, even in an old project.
        for record in data["channels"]:
            record.pop("automatic", None)
        ui = data["ui"]
        for section, keys in (("checks", ("chk_manual_fs_plot", "chk_auto_sync")),
                              ("numbers", ("sp_manual_fs_plot", "fs_fft"))):
            if isinstance(ui.get(section), dict):
                for key in keys:
                    ui[section].pop(key, None)
        ui.pop("fs_unit", None)
        if data["version"] == 1:
            data["timing_migrated"] = True
            # Old coordinates can have been based on inferred rates. Preserve
            # data/manual assignments, but never reuse those measurements.
            ui.update(x_range=None, ab_positions=None, ab_enabled=False, markers=[])
            if isinstance(ui.get("axis"), dict):
                ui["axis"]["x_title"] = ""
            for s in virtual:
                x = np.arange(len(s["y"]), dtype=np.float64)
                s.update(x=x, source_x=x, x_mode="index", source_x_mode="index",
                         source_x_base=0., source_x_inc=1., source_fs_est=None,
                         fs_est=None, source_timing_origin=None)
        for s in virtual:
            for key in list(s):
                if key.startswith(("auto_fs", "auto_x_", "auto_duration")):
                    s.pop(key)
        return data, virtual


def load_project_archive(path, loader_factory, request_type, key_type, cancelled=lambda: False):
    """Validate and load into temporary state before touching the current GUI."""
    data, virtual = read_project_archive(path, cancelled)
    files = {r["id"]: {"path": r["resolved_path"], "label": Path(r["resolved_path"]).name,
                         "time_binding": r.get("time_binding", {"enabled": False})} for r in data["files"]}
    indexes = {}
    for fid, source in files.items():
        if cancelled():
            raise ExportCancelled()
        with open_tdms(source["path"]) as tdms:
            indexes[fid] = [(g.name, c.name, len(c)) for g in tdms.groups() for c in g.channels()]
    requests = []
    for record in data["channels"]:
        if record["file_id"] not in files:
            raise ValueError("Kanalın kaynak dosyası projede yok.")
        ref = (record["group"], record["channel"], record["length"])
        if ref not in indexes[record["file_id"]]:
            raise ValueError(f"Kanal veya örnek sayısı değişmiş: {record['channel']}")
        requests.append(request_type(key_type(record["file_id"], *ref), record["name"]))
    result, errors = [], []
    worker = loader_factory(files, requests)
    # The worker runs synchronously in this background task. Sharing only a
    # cancellation event avoids cross-thread TDMS/Qt object access.
    if hasattr(cancelled, "event"):
        worker._cancel_event = cancelled.event
    worker.finished.connect(result.append)
    worker.failed.connect(errors.append)
    worker.run()
    if cancelled():
        raise ExportCancelled()
    if errors or not result or result[0].get("errors"):
        raise ValueError("\n".join(errors or (result[0].get("errors", []) if result else ["Proje verisi okunamadı."])))
    series = result[0]["series"]
    by_key = {(r["file_id"], r["group"], r["channel"]): r for r in data["channels"]}
    if len(by_key) != len(data["channels"]) or len(series) != len(data["channels"]):
        raise ValueError("Proje kanal listesi yineleniyor veya eksik.")
    if data.get("time_display") != "relative_seconds_v1":
        origins = {s["style_key"]: s.get("time_origin_epoch") for s in series}
        had_utc = any(v is not None for v in origins.values())
        for s in virtual:
            if s.get("source_x_mode") != "datetime":
                continue
            had_utc = True
            refs = s.get("virtual_sources") or {}
            origin = next((origins.get(refs[a]) for a in sorted(refs)
                           if origins.get(refs[a]) is not None), float(s["source_x_base"]))
            for name in ("x", "source_x"):
                s[name] = np.asarray(s[name], dtype=float) - origin
            s.update(source_x_base=float(s["source_x_base"]) - origin,
                     source_x_mode="seconds", x_mode="seconds")
            s.pop("effective_x_base", None)
            origins[s["style_key"]] = origin
        if had_utc:
            data["relative_time_migrated"] = True
            ui = data["ui"]
            ui.update(x_range=None, ab_positions=None, ab_enabled=False, markers=[])
            if isinstance(ui.get("axis"), dict):
                ui["axis"]["x_title"] = ""
    keys = [s["style_key"] for s in series + virtual]
    if len(keys) != len(set(keys)):
        raise ValueError("Proje kanal kimlikleri yineleniyor.")
    return {"path": str(Path(path).resolve()), "manifest": data, "series": series + virtual,
            "files": files, "indexes": indexes, "time_bindings":result[0].get("time_bindings", {})}
