"""Non-destructive time offsets and explicit, reviewable alignment estimates.

No Valve Analysis dependency. No source array/file writes. Edge scans use exact
samples; correlation uses a bounded temporary grid and bounded sparse reads.
"""
from __future__ import annotations
from contextlib import ExitStack
import math
import os

import numpy as np

from tdms_export import _Channel, ExportOptions, ExportCancelled
from tdms_io import open_tdms


class ChannelAlignmentManager:
    def __init__(self):
        self._offsets = {}
        self.generation = 0

    def offset(self, key):
        return self._offsets.get(key, 0.)

    @staticmethod
    def validate(state):
        if not isinstance(state, dict) or len(state) > 10000:
            raise ValueError('Geçersiz kanal alignment ayarları.')
        for key, value in state.items():
            if not isinstance(key, str) or isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError('Alignment ofsetleri sonlu saniye değerleri olmalı.')

    def set_offsets(self, offsets):
        self.validate(offsets)
        updated = dict(self._offsets)
        for key, value in offsets.items():
            if value:
                updated[key] = float(value)
            else:
                updated.pop(key, None)
        if updated != self._offsets:
            self._offsets = updated
            self.generation += 1

    def snapshot(self):
        return dict(self._offsets)

    def restore(self, state):
        self.validate(state)
        updated = {key: float(value) for key, value in state.items() if value}
        if updated != self._offsets:
            self._offsets = updated
            self.generation += 1

    def reset_all(self):
        self.restore({})

    def drop_prefix(self, prefix):
        self.restore({k: v for k, v in self._offsets.items() if not k.startswith(prefix)})

    def display_styles(self, styles, series):
        """O(channels) metadata overlay only; source/style dicts are untouched."""
        if not self._offsets:
            return styles
        result = dict(styles)
        for s in series or []:
            key = s.get('style_key')
            offset = self.offset(key) if s.get('x_mode') in ('seconds', 'datetime') else 0.
            if offset:
                result[key] = dict(styles.get(key, {}), alignment_offset=offset)
        return result


def display_time_shift(style):
    return float(style.get('x_shift', 0.) or 0.) + float(style.get('alignment_offset', 0.) or 0.)


def _check(cancelled):
    if cancelled():
        raise ExportCancelled()


def source_bounds(source):
    offset = float(source.get('alignment_offset', 0.))
    if source.get('path'):
        a = float(source['x_base'])
        b = a+(source['n']-1)*float(source['x_inc'])
    else:
        x = source['x']
        if not len(x):
            raise ValueError(f"{source['name']}: kanal boş.")
        a, b = float(x[0]), float(x[-1])
    if not math.isfinite(a) or not math.isfinite(b) or b <= a:
        raise ValueError(f"{source['name']}: geçersiz zaman sınırları.")
    return a+offset, b+offset


def _validate(sources, bounds):
    if len(sources) != 2 or sources[0]['key'] == sources[1]['key']:
        raise ValueError('Referans ve hedef için iki farklı kanal seçin.')
    if len({s['x_mode'] for s in sources}) != 1 or sources[0]['x_mode'] not in ('seconds', 'datetime'):
        raise ValueError('İki kanal aynı zaman türünde olmalı (saniye veya UTC). İndeks kanallarına önce Manuel Fs atayın.')
    for s in sources:
        fs = s.get('fs_hz')
        if fs is None or not math.isfinite(float(fs)) or fs <= 0 or s['n'] < 2:
            raise ValueError(f"{s['name']}: geçerli Fs ve en az iki örnek gerekli.")
        if not math.isfinite(float(s.get('alignment_offset', 0.))):
            raise ValueError('Alignment ofseti sonlu olmalı.')
        path, fingerprint = s.get('source_path') or s.get('path'), s.get('source_fingerprint')
        if path and fingerprint:
            stat = os.stat(path)
            if stat.st_size != fingerprint['size'] or stat.st_mtime_ns != fingerprint['mtime_ns']:
                raise ValueError(f"{s['name']}: kaynak değişti; kanalı yeniden yükleyin.")
        source_bounds(s)
    a, b = bounds
    if not math.isfinite(a) or not math.isfinite(b) or b <= a:
        raise ValueError('Analiz başlangıcı bitişten küçük olmalı.')


def _channels(stack, sources, bounds=None):
    handles = {p: stack.enter_context(open_tdms(p)) for p in dict.fromkeys(s['path'] for s in sources if s.get('path'))}
    channels = []
    for s in sources:
        # Display X/Y shifts are intentionally excluded from acquisition estimates.
        raw = dict(s, x_shift=0., y_shift=0.)
        raw.pop('alignment_offset', None)
        offset = s.get('alignment_offset', 0.)
        raw_bounds = (bounds[0]-offset, bounds[1]-offset) if bounds else None
        channels.append(_Channel(raw, handles.get(s.get('path')), ExportOptions(x_range=raw_bounds)))
    return channels


def _edge(ch, source, bounds, direction, cancelled):
    offset = float(source.get('alignment_offset', 0.))
    state = None
    last_time = None
    first, count = None, 0
    step = 1/float(source['fs_hz'])
    precision = max(1e-12, 4*abs(float(np.spacing(bounds[0]))))
    for start in range(0, ch.count, 262144):
        _check(cancelled)
        _, x, y = ch.block(start, start+262144)
        x = np.asarray(x, dtype=float) + offset
        y = np.asarray(y)
        if not len(x):
            continue
        if not np.all(np.isfinite(x)) or np.any(np.diff(x) <= 0) or (last_time is not None and x[0] <= last_time):
            raise ValueError(f"{source['name']}: zamanlar sonlu ve kesin artan olmalı.")
        finite = np.isfinite(y)
        if np.any(finite & (y != 0) & (y != 1)):
            raise ValueError(f"{source['name']}: Edge Alignment yalnız 0/1 dijital kanallar içindir.")
        previous_y = np.r_[np.nan if state is None else state, y[:-1]]
        previous_x = np.r_[x[0] if last_time is None else last_time, x[:-1]]
        continuous = (x-previous_x <= 2.5*step+precision) & np.isfinite(previous_y) & finite
        transition = (previous_y == 0) & (y == 1) if direction == 'rising' else (previous_y == 1) & (y == 0)
        ids = np.flatnonzero(continuous & transition & (x >= bounds[0]) & (x <= bounds[1]))
        if first is None and len(ids):
            j = int(ids[0])
            first = {'time': float(x[j]), 'previous': float(previous_x[j])}
        count += len(ids)
        state, last_time = (y[-1] if finite[-1] else None), float(x[-1])
    if first is None:
        raise ValueError(f"{source['name']}: No valid rising/falling edge found in selected channel.")
    return dict(first, count=int(count))


def estimate_edges(sources, bounds, direction='rising', cancelled=lambda: False):
    _validate(sources, bounds)
    if direction not in ('rising', 'falling'):
        raise ValueError('Rising / Falling edge seçin.')
    with ExitStack() as stack:
        padded = (bounds[0]-max(1/s['fs_hz'] for s in sources), bounds[1])
        channels = _channels(stack, sources, padded)
        events = [_edge(ch, s, bounds, direction, cancelled) for ch, s in zip(channels, sources)]
    _validate(sources, bounds); _check(cancelled)
    ref, target = events
    residual = ref['time']-target['time']
    warnings = []
    if any(e['count'] > 1 for e in events):
        warnings.append('Birden fazla kenar bulundu; aralıktaki ilk kenarlar kullanıldı. Aynı olayı eşleştirdiğinizi kontrol edin.')
    return {'method': 'edge', 'offset_s': sources[1].get('alignment_offset', 0.)+residual,
            'residual_s': residual, 'score': None, 'events': events, 'bounds': bounds,
            'resolution_s': max(1/s['fs_hz'] for s in sources), 'warnings': warnings}


def _read_at_indices(ch, indices, cancelled):
    """Bound I/O even when a years-long source is sampled on a small grid."""
    indices, inverse = np.unique(indices, return_inverse=True)
    values = np.empty(len(indices), dtype=float)
    times = np.empty(len(indices), dtype=float)
    i = 0
    while i < len(indices):
        _check(cancelled)
        j = i+1
        a = int(indices[i])
        while j < len(indices) and indices[j]-a < 65536 and indices[j]-indices[j-1] <= 32:
            j += 1
        b = int(indices[j-1])+1
        _, xx, yy = ch.block(a, b)
        pos = indices[i:j]-a
        times[i:j], values[i:j] = xx[pos], yy[pos]
        i = j
    return times[inverse], values[inverse]


def _sample_grid(ch, source, grid, cancelled):
    """Temporary linear interpolation for analog, ZOH for digital, no gap bridge."""
    offset = float(source.get('alignment_offset', 0.))
    raw_grid = grid-offset
    if ch.ch is not None:
        left = np.floor((raw_grid-source['x_base'])/source['x_inc']).astype(np.int64)
    else:
        left = np.searchsorted(source['x'], raw_grid, side='right')-1
    left = np.clip(left, 0, ch.n-2)
    right = left+1
    indices = np.r_[left, right]
    times, values = _read_at_indices(ch, indices, cancelled)
    n = len(grid)
    t0, t1, y0, y1 = times[:n], times[n:], values[:n], values[n:]
    if not np.all(np.isfinite(times)) or not np.all(np.isfinite(values)):
        raise ValueError(f"{source['name']}: örneklenen aralıkta NaN/Inf var; temiz bir analiz aralığı seçin.")
    precision = max(1e-10, 4*abs(float(np.spacing(grid[0]))))
    if np.any(t1 <= t0) or np.any(t1-t0 > 2.5/source['fs_hz']+precision):
        raise ValueError(f"{source['name']}: zaman boşluğu var; interpolasyon yapılmadı.")
    if np.any(raw_grid < t0-precision) or np.any(raw_grid > t1+precision):
        raise ValueError('Analiz grid’i kaynak sınırları dışında.')
    digital = bool(source.get('is_digital')) or bool(np.all((values==0)|(values==1)))
    if digital:
        # Exact sample times use that sample; a digital edge is never ramped.
        return np.where(raw_grid >= t1, y1, y0), True
    fraction = np.clip((raw_grid-t0)/(t1-t0), 0., 1.)
    return y0+(y1-y0)*fraction, False


def estimate_correlation(sources, bounds, search_s=.05, cancelled=lambda: False, max_points=32768):
    _validate(sources, bounds)
    if not math.isfinite(search_s) or search_s <= 0 or max_points < 32:
        raise ValueError('Pozitif arama aralığı ve en az 32 analiz noktası gerekli.')
    a = max(bounds[0], *(source_bounds(s)[0] for s in sources))
    b = min(bounds[1], *(source_bounds(s)[1] for s in sources))
    if b <= a or search_s >= (b-a)/2:
        raise ValueError('Ortak analiz aralığı arama aralığının iki katından uzun olmalı.')
    native_step = max(1/s['fs_hz'] for s in sources)
    step = max(native_step, (b-a)/(max_points-1), 4*abs(float(np.spacing(a))))
    n = min(max_points, int(math.floor((b-a)/step))+1)
    if n < 32:
        raise ValueError('Korelasyon için ortak aralıkta en az 32 örnek gerekli; analiz aralığını genişletin.')
    maxlag = min(int(math.floor(search_s/step+1e-9)), n//2-1)
    if maxlag < 1:
        raise ValueError(f'Arama aralığı analiz çözünürlüğünden küçük ({step*1000:.6g} ms); analiz aralığını daraltın veya Fs’yi kontrol edin.')
    grid = a+np.arange(n)*step
    with ExitStack() as stack:
        channels = _channels(stack, sources)
        sampled = [_sample_grid(ch, s, grid, cancelled) for ch, s in zip(channels, sources)]
    _check(cancelled)
    r, t = [v[0] for v in sampled]
    r, t = r-r.mean(), t-t.mean()
    if np.std(r) <= 1e-14 or np.std(t) <= 1e-14:
        raise ValueError('Sabit/çok düşük değişimli kanalda korelasyonla ofset bulunamaz.')
    # FFT is loaded on demand; application startup / main plot stays unchanged.
    from scipy.signal import correlate, find_peaks
    raw = correlate(r, t, mode='full', method='fft')
    _check(cancelled)
    lags = np.arange(-maxlag, maxlag+1)
    ra, rb = np.maximum(lags, 0), n+np.minimum(lags, 0)
    ta, tb = np.maximum(-lags, 0), n-np.maximum(lags, 0)
    count = n-np.abs(lags)
    def sums(x, left, right):
        prefix = np.r_[0., np.cumsum(x)]
        return prefix[right]-prefix[left]
    sr, st = sums(r, ra, rb), sums(t, ta, tb)
    vr = np.maximum(0., sums(r*r, ra, rb)-sr*sr/count)
    vt = np.maximum(0., sums(t*t, ta, tb)-st*st/count)
    denom = np.sqrt(vr*vt)
    scores = np.divide(raw[n-1+lags]-sr*st/count, denom,
                       out=np.full(len(lags), -np.inf), where=denom>1e-20)
    if not np.any(np.isfinite(scores)):
        raise ValueError('Geçerli korelasyon bulunamadı; değişken sinyalli bir aralık seçin.')
    if np.ptp(scores[np.isfinite(scores)]) < 1e-6:
        raise ValueError('Korelasyon tepesi ayırt edilemiyor; düz rampa yerine belirgin ortak olaylar içeren bir aralık seçin.')
    scores = np.minimum(1., np.maximum(-1., scores))
    peak = int(np.argmax(scores)); lag = float(lags[peak])
    # Parabolic refinement is an estimate, not extra sampling precision.
    if 0 < peak < len(scores)-1:
        denominator = scores[peak-1]-2*scores[peak]+scores[peak+1]
        if denominator < -1e-12:
            lag += float(np.clip(.5*(scores[peak-1]-scores[peak+1])/denominator, -.5, .5))
    residual = float(np.clip(lag*step, -search_s, search_s))
    score = float(scores[peak])
    warnings = []
    if score < .6:
        warnings.append('Korelasyon zayıf; bu öneri güvenilir bir acquisition kayması kanıtı değildir.')
    if peak in (0, len(scores)-1):
        warnings.append('Tepe arama sınırında; arama aralığını genişletip tekrar inceleyin.')
    peaks, _ = find_peaks(scores)
    if any(abs(int(p)-peak)>2 and scores[p] >= score-.02 for p in peaks):
        warnings.append('Birden fazla benzer korelasyon tepesi var; periyodik sinyallerde ofset belirsiz olabilir.')
    if step > native_step*1.01:
        warnings.append('Hız için azaltılmış analiz grid’i kullanıldı; aliasing ve ince olaylar için daha dar bir aralıkla kontrol edin.')
    warnings.append('Korelasyon acquisition kayması ile gerçek fiziksel gecikmeyi ayırt edemez; aynı fiziksel olayı ölçen kanalları karşılaştırın.')
    _validate(sources, bounds); _check(cancelled)
    return {'method': 'correlation', 'offset_s': sources[1].get('alignment_offset', 0.)+residual,
            'residual_s': residual, 'score': score, 'bounds': (a, b), 'resolution_s': step,
            'points': n, 'digital': [v[1] for v in sampled], 'warnings': warnings}
