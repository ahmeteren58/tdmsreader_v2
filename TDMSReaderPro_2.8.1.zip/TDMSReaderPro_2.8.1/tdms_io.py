"""Pooled TDMS metadata and bounded byte-range channel reads.

npTDMS ``read_data(offset, length)`` reads a complete native data chunk and
then trims it. A defragmented or single-write file stores each channel as one
chunk, so reading such a channel in 64k-sample blocks re-read the whole
channel for every block. ``open_tdms`` reads only the requested bytes for
plain little/big-endian numeric layouts and falls back to npTDMS (under a
per-file lock) for DAQmx, strings, timestamps and truncated interleaved data.

Parsed metadata is reused while the file size/mtime/inode stay unchanged.
Operating-system handles are closed as soon as the last reader finishes, so
files can still be moved or replaced on Windows while the app is open.
"""
from __future__ import annotations

import os
import threading
from collections import OrderedDict
from contextlib import contextmanager
from typing import Iterator, Optional

import numpy as np
from nptdms import TdmsFile

try:  # Private npTDMS helpers; the fast path is disabled if they move.
    from nptdms.base_segment import RawChannelDataChunk
    from nptdms.common import toc_properties
except Exception:  # pragma: no cover - depends on npTDMS internals
    RawChannelDataChunk = None
    toc_properties = None

MAX_POOLED_FILES = 6
_INTERLEAVED_ROWS = 262_144


def fingerprint(path: str) -> tuple:
    st = os.stat(path)
    return st.st_size, st.st_mtime_ns, getattr(st, "st_ino", 0)


class ChannelPlan:
    """Byte layout of one channel: groups of equally spaced value runs.

    Group ``g`` holds ``nruns[g]`` runs of ``count[g]`` values. Run ``j`` starts
    at ``base[g] + j*step[g]``; consecutive values are ``stride[g]`` bytes apart.
    """

    __slots__ = ("dtype", "start", "base", "nruns", "step", "count", "stride", "n")

    def __init__(self, dtype, groups):
        self.dtype = dtype
        arr = np.array(groups, dtype=np.int64).reshape(-1, 5)
        self.base, self.nruns, self.step, self.count, self.stride = arr.T.copy()
        sizes = self.nruns * self.count
        self.start = np.r_[0, np.cumsum(sizes)].astype(np.int64)
        self.n = int(self.start[-1])

    def read(self, f, offset: int, length: int) -> np.ndarray:
        stop = min(self.n, offset + max(0, length))
        out = np.empty(max(0, stop - offset), dtype=self.dtype)
        if not len(out):
            return out
        item = self.dtype.itemsize
        g = int(np.searchsorted(self.start, offset, side="right")) - 1
        pos = offset
        while pos < stop:
            local = pos - int(self.start[g])
            count, stride = int(self.count[g]), int(self.stride[g])
            run, k = divmod(local, count)
            if run >= int(self.nruns[g]):
                g += 1
                continue
            m = min(count - k, stop - pos)
            at = int(self.base[g]) + run * int(self.step[g]) + k * stride
            dest = out[pos - offset:pos - offset + m]
            if stride == item:
                f.seek(at)
                view = memoryview(dest).cast("B")
                got = 0
                while got < len(view):
                    part = f.readinto(view[got:])
                    if not part:
                        raise IOError("TDMS kanalının istenen veri aralığı eksik okundu.")
                    got += part
            else:
                for r in range(0, m, _INTERLEAVED_ROWS):
                    rows = min(_INTERLEAVED_ROWS, m - r)
                    span = (rows - 1) * stride + item
                    f.seek(at + r * stride)
                    buf = f.read(span)
                    if len(buf) != span:
                        raise IOError("TDMS kanalının istenen veri aralığı eksik okundu.")
                    dest[r:r + rows] = np.ndarray((rows,), dtype=self.dtype, buffer=buf, strides=(stride,))
            pos += m
        return out


def build_plan(tdms: TdmsFile, channel) -> Optional[ChannelPlan]:
    """Return the channel byte layout, or None when npTDMS must read it."""
    if toc_properties is None or RawChannelDataChunk is None:
        return None
    reader = getattr(tdms, "_reader", None)
    segments = getattr(reader, "_segments", None)
    if reader is None or segments is None or getattr(reader, "_file_path", None) is None:
        return None
    dtype_cls = getattr(channel, "data_type", None)
    nptype = getattr(dtype_cls, "nptype", None)
    size = getattr(dtype_cls, "size", None)
    if nptype is None or size is None or nptype.kind not in "biuf" or nptype.itemsize != size:
        return None
    path = channel.path
    raw_flag = toc_properties["kTocRawData"]
    big_flag = toc_properties["kTocBigEndian"]
    layout_cache = {}
    groups, order = [], None
    for seg in segments:
        index = seg.object_index.get(path) if seg.object_index is not None else None
        if index is None:
            continue
        obj = seg.ordered_objects[index]
        if not obj.has_data or not obj.number_values or not seg.num_chunks:
            continue
        if not seg.toc_mask & raw_flag or seg._have_daqmx_objects():
            return None
        seg_order = ">" if seg.toc_mask & big_flag else "<"
        if order is None:
            order = seg_order
        elif order != seg_order:
            return None
        override = seg.final_chunk_lengths_override
        key = (id(seg.ordered_objects), obj.number_values, seg.toc_mask)
        layout = layout_cache.get(key)
        if layout is None:
            data_objects = seg._get_data_objects()
            interleaved = seg._have_interleaved_data()
            offset = 0
            for other in data_objects:
                if other is obj:
                    break
                if interleaved:
                    offset += other.data_type.size
                elif other.data_size is None:
                    return None
                else:
                    offset += other.data_size
            else:
                return None
            width = sum(o.data_type.size for o in data_objects) if interleaved else size
            layout = (interleaved, offset, width, seg._get_chunk_size(), data_objects)
            layout_cache[key] = layout
        interleaved, offset, width, chunk_size, data_objects = layout
        nv = int(obj.number_values)
        full = seg.num_chunks - (1 if override is not None else 0)
        start = int(seg.data_position)
        if interleaved:
            if override is not None or len({o.number_values for o in data_objects}) != 1:
                return None
            groups.append((start + offset, 1, 0, nv * full, width))
            continue
        if full > 0:
            if full > 1 and chunk_size == nv * size:
                groups.append((start + offset, 1, 0, nv * full, size))
            else:
                groups.append((start + offset, full, chunk_size, nv, size))
        if override is not None:
            position = 0
            for other in data_objects:
                values = override.get(other.path, 0)
                if other is obj:
                    if values:
                        groups.append((start + (seg.num_chunks - 1) * chunk_size + position, 1, 0, values, size))
                    break
                if values == other.number_values:
                    position += other.data_size
                elif other.data_type.size is not None:
                    position += other.data_type.size * values
                else:
                    return None
    plan = ChannelPlan(nptype.newbyteorder(order or "<"), groups) if groups else ChannelPlan(nptype, [])
    return plan if plan.n == len(channel) else None


class _Entry:
    def __init__(self, path: str, stamp: tuple, tdms: TdmsFile):
        self.path, self.stamp, self.tdms = path, stamp, tdms
        self.lock = threading.RLock()
        self.users = 0
        self.plans: dict = {}
        self.retired = False

    def plan(self, channel) -> Optional[ChannelPlan]:
        key = channel.path
        with self.lock:
            if key not in self.plans:
                try:
                    self.plans[key] = build_plan(self.tdms, channel)
                except Exception:
                    self.plans[key] = None
            return self.plans[key]

    def ensure_nptdms_handle(self) -> None:
        reader = self.tdms._reader
        if reader._file is None and reader._file_path is not None:
            reader._file = open(reader._file_path, "rb")

    def release_handles(self) -> None:
        reader = getattr(self.tdms, "_reader", None)
        f = getattr(reader, "_file", None)
        if f is not None:
            try:
                f.close()
            finally:
                reader._file = None
        index = getattr(reader, "_index_file", None)
        if index is not None:
            # npTDMS keeps the closed index object; is_index_file_only() relies on it.
            index.close()


_POOL: "OrderedDict[str, _Entry]" = OrderedDict()
_POOL_LOCK = threading.Lock()


def _pool_key(path: str) -> str:
    return os.path.normcase(os.path.abspath(path))


def forget(path: str) -> None:
    """Drop cached metadata for a file (e.g. when its tab is closed)."""
    with _POOL_LOCK:
        entry = _POOL.pop(_pool_key(path), None)
        if entry is not None:
            entry.retired = True
    if entry is not None:
        with entry.lock:
            if entry.users == 0:
                entry.release_handles()


def clear_pool() -> None:
    with _POOL_LOCK:
        paths = list(_POOL)
    for p in paths:
        forget(p)


def pooled_paths() -> list:
    with _POOL_LOCK:
        return list(_POOL)


def _acquire(path: str) -> _Entry:
    key = _pool_key(path)
    stamp = fingerprint(path)
    with _POOL_LOCK:
        entry = _POOL.get(key)
        if entry is not None and entry.stamp == stamp:
            _POOL.move_to_end(key)
            with entry.lock:
                entry.users += 1
            return entry
    tdms = TdmsFile.open(path)
    fresh = _Entry(path, stamp, tdms)
    fresh.users = 1
    retired = []
    with _POOL_LOCK:
        old = _POOL.pop(key, None)
        if old is not None:
            retired.append(old)
        _POOL[key] = fresh
        while len(_POOL) > MAX_POOLED_FILES:
            retired.append(_POOL.popitem(last=False)[1])
    for old in retired:
        old.retired = True
        with old.lock:
            if old.users == 0:
                old.release_handles()
    return fresh


def _release(entry: _Entry) -> None:
    with entry.lock:
        entry.users -= 1
        if entry.users <= 0:
            entry.users = 0
            entry.release_handles()


class PooledChannel:
    """npTDMS channel facade whose reads touch only the requested bytes."""

    def __init__(self, session: "TdmsSession", channel):
        self._session, self._channel = session, channel

    def __getattr__(self, name):
        return getattr(self._channel, name)

    def __len__(self):
        return len(self._channel)

    def __iter__(self):
        return iter(self.read_data())

    @property
    def properties(self):
        return self._channel.properties

    @property
    def name(self):
        return self._channel.name

    @property
    def path(self):
        return self._channel.path

    @property
    def data_type(self):
        return self._channel.data_type

    @property
    def fast(self) -> bool:
        return self._session.plan(self._channel) is not None

    def read_data(self, offset=0, length=None, scaled=True):
        n = len(self._channel)
        offset = max(0, int(offset))
        length = n - offset if length is None else max(0, min(int(length), n - offset))
        plan = self._session.plan(self._channel) if scaled else None
        if plan is None:
            return self._session.nptdms_read(self._channel, offset, length, scaled)
        raw = plan.read(self._session.data_file(), offset, length)
        scaling = self._channel._scaling
        if scaling is None:
            return raw
        return self._channel._scale_data(RawChannelDataChunk.channel_data(raw))

    def __getitem__(self, index):
        n = len(self._channel)
        if isinstance(index, slice):
            start, stop, step = index.indices(n)
            if step == 1:
                return self.read_data(start, max(0, stop - start))
            return self.read_data()[index]
        i = int(index)
        if i < 0:
            i += n
        if not 0 <= i < n:
            raise IndexError("Index out of range")
        return self.read_data(i, 1)[0]


class PooledGroup:
    def __init__(self, session: "TdmsSession", group):
        self._session, self._group = session, group

    def __getattr__(self, name):
        return getattr(self._group, name)

    @property
    def name(self):
        return self._group.name

    @property
    def properties(self):
        return self._group.properties

    def channels(self):
        return [PooledChannel(self._session, c) for c in self._group.channels()]

    def __getitem__(self, name):
        return PooledChannel(self._session, self._group[name])

    def __contains__(self, name):
        return name in self._group

    def __iter__(self):
        return iter(self._group)


class TdmsSession:
    """One reader's view of a pooled file; owns a private data handle."""

    def __init__(self, entry: _Entry):
        self._entry = entry
        self._file = None

    def __getattr__(self, name):
        return getattr(self._entry.tdms, name)

    @property
    def tdms(self) -> TdmsFile:
        return self._entry.tdms

    @property
    def properties(self):
        return self._entry.tdms.properties

    def groups(self):
        return [PooledGroup(self, g) for g in self._entry.tdms.groups()]

    def __getitem__(self, name):
        return PooledGroup(self, self._entry.tdms[name])

    def __contains__(self, name):
        return name in self._entry.tdms

    def __iter__(self):
        return iter(self._entry.tdms)

    def plan(self, channel) -> Optional[ChannelPlan]:
        return self._entry.plan(channel)

    def data_file(self):
        if self._file is None:
            self._file = open(self._entry.tdms._reader._file_path, "rb", buffering=0)
        return self._file

    def nptdms_read(self, channel, offset, length, scaled=True):
        with self._entry.lock:
            self._entry.ensure_nptdms_handle()
            return channel.read_data(offset=offset, length=length, scaled=scaled)

    def close(self) -> None:
        if self._file is not None:
            try:
                self._file.close()
            finally:
                self._file = None


@contextmanager
def open_tdms(path) -> Iterator[TdmsSession]:
    """Context manager yielding a pooled, thread-safe TDMS reader session."""
    entry = _acquire(os.fspath(path))
    session = TdmsSession(entry)
    try:
        yield session
    finally:
        session.close()
        _release(entry)
