# TDMSReader Pro 2.8.1

## 2.8.1: Arayüz düzenlemesi

- Açık ve koyu tema tek palette toplandı (`tdms_theme.py`); tek vurgu rengi,
  sade çizgiler, belirgin onay kutuları ve yumuşak grafik eksenleri.
- Şeritte bütün komutlar gruplu ve tek satır etiketli. Ayrıntı:
  `DEGISIKLIKLER_281.md`. Hesaplama ve zaman eşleme davranışı değişmedi.

## 2.8.0: Sade çalışma alanı

- Manuel Fs ve Channel Alignment sekmeleri kaldırıldı. Fs, **Kanallar**
  ekranındaki **Elle** kutusu ve **Fs [Hz]** alanından düzenlenir.
- Sekmeler iş akışına göre sıralandı. Açık/koyu tema, yerel SVG ikonları,
  tablolar ve dosya/kanal seçimine göre başlangıç ekranı yenilendi.
- Uzun açıklamalar **ⓘ** ile açılır. Sonuçlar ve önemli uyarılar görünür kalır.
- Eski projelerdeki elle ofsetler korunur, bildirilir ve Zaman Kanalları'ndan sıfırlanabilir.
- TDMS, Times, hızlı çizim/downsampling ve analiz motorları korunur.

Kullanım: **UI_UX_280_TR.md**. Değişiklikler: **DEGISIKLIKLER_280.md**.
Doğrulama: **TEST_280.txt**. Ekranlar: `preview/ui_280_*.png`.

## 2.7.0: Ayrı Times kanallarıyla doğru zaman ekseni

**Zaman Kanalları** sekmesi eklendi. Açık `RIO / Mod N-Time` eşleşmeleri
otomatik bulunur; farklı model/grup sırası veya örnek sayısı adayları kullanıcı
onayına sunulur. 500 Hz ve 5000 Hz kanallar kendi doğrulanmış zamanlarını ve
ortak dosya başlangıcını kullanır. Geçersiz/sabit/düzensiz zaman bağlanmaz.

Birim etiketi olmayan Times için paneldeki birim kullanılır (varsayılan s).
Manuel Fs / Ortak Süre önceliği korunur; Times hızını kullanmak için bu
atamaları kaldırın. Önceden kayıt başlangıcı için eklenen alignment ofsetlerini
iki kez uygulamayın. Times eşlemesi grafik, CSV ve mevcut analizlerin temel
zamanına ulaşır; Vana Analizi algoritmaları aynıdır.

Dosya açılışı metadata ile sınırlı; zaman denetimi arka planda, bloklarla ve
önbellekle yapılır. Ham TDMS değiştirilmez. Eşlemeler `.tdmsproj` ile saklanır.
Kullanım: **ZAMAN_KANALLARI_TR.md**. Demo: `examples/time_channels_mixed_rates.tdms`.
Değişiklikler: **DEGISIKLIKLER_270.md**, doğrulama: **TEST_270.txt**.

## 2.6.0: Channel Alignment / Synchronization

Yeni **Channel Alignment** sekmesinde kanal başına manuel ms/s ofseti,
0/1 rising/falling edge eşleştirmesi ve sınırlı grid üzerinden cross-correlation
bulunur. Tahminler **Apply Alignment** yapılana kadar uygulanmaz. Ham TDMS,
zaman/sinyal dizileri ve örnek sayıları değişmez. Ofsetler ayrı state’te tutulur,
Reset ile sıfırlanır ve `.tdmsproj` ile kaydedilebilir.

CSV’de **Export aligned timestamps** seçeneği varsayılan olarak kapalıdır.
Vana Analizi/timing/fake pulse filtresi değişmedi; mevcut optimizasyon motorları korundu.
Kullanım: **CHANNEL_ALIGNMENT_TR.md**. Değişiklikler: **DEGISIKLIKLER_260.md**.
Demo: `examples/channel_alignment_demo.tdms`. Ek bağımlılık gerekmez.

## 2.5.5: Otomatik kararlı akış ve basınç kaybı

**Basınç Kaybı** sekmesinde giriş basıncı, çıkış basıncı ve isteğe bağlı debi
kanallarını seçin. Ortak kararlı aralıklar bulunur; her aralık için ortalama,
σ, min–maks ve örnek sayısı ile **Δp = ort(Pgiriş) − ort(Pçıkış)** hesaplanır.
Aralığı grafikte inceleyip elle düzeltebilir, sonuçları CSV’ye aktarabilirsiniz.
Başlangıç ayarı: **Standart, 1 s pencere, 3 s asgari süre**.

Ayrıntılı kullanım: **BASINC_KAYBI_TR.md**. Örnek veri:
`examples/basinc_kaybi_demo.tdms`. Değişiklikler: **DEGISIKLIKLER_255.md**.
Mevcut bağımlılıklar yeterlidir; ZIP’i çıkarıp PyCharm’da `tdmsreader.py` çalıştırın.

PyQt6 tabanlı TDMS görüntüleyici. Varsayılan zaman hesabı kanal bazlıdır. İsteğe bağlı **Testlerin ortak sürede yapıldığını varsay** seçeneği, belirlediğiniz referans kanalın kayıt süresini diğer kaynak kanallara uygular.

## 2.5.3: Büyük veride hız, donma düzeltmesi ve kolay vana analizi

**Donma giderildi.** Yakınlaştırma/kaydırma sırasında arka plan işi biterken yenisi başlarsa uygulama kalıcı olarak donabiliyordu (Qt iş parçacığı ile Python arasında kilitlenme). Arka plan işleri artık Python iş parçacıklarında çalışır; sonuçlar arayüz iş parçacığına iletilir.

**Büyük dosyalar hızlı açılır.** npTDMS blok okumalarında tüm veri parçasını okuyup kırpıyordu; tek seferde yazılmış büyük kayıtlarda her önizleme bloğu bütün kanalı yeniden okuyordu. Yeni `tdms_io.py` yalnız istenen bayt aralığını okur. Bitişik, iç içe (interleaved), çok parçalı ve ölçekli düzenler desteklenir; diğer düzenlerde npTDMS'ye dönülür. Metadata dosya değişene kadar tekrar kullanılır. Dosya tutamacı okuma bitince kapanır, dosya Windows'ta taşınabilir.

**Çizim hafifledi.** Eğri başına nokta bütçesi grafik genişliğine göre belirlenir: piksel başına 4 nokta, en az 4.000. Önizleme pikleri ve kenarları yine korur. Yeni eğrilerin varsayılan kalınlığı 1 px'tir; kullanıcının seçtiği kalınlık korunur. SciPy ilk SG filtresinde yüklenir.

| 2 × 20 milyon örnek, tek segment (Linux ölçümü) | 2.5.2 | 2.5.3 |
| --- | --- | --- |
| Seçili kanalları çiz | 29,7 s | 0,46 s |
| Aralığın %50'sine yakınlaş | 6,0 s | 0,22 s |
| Tam yeniden çizim | 46,8 ms | 10,3 ms |
| `import tdmsreader` | 0,62 s | 0,17 s |

**Vana Analizi sadeleşti.** Sekme üç adımdan oluşur:

1. Bağlantı türü ve kanallar.
2. Sonuç kartları.
3. Olaylar ve elle doğrulama.

Bağlantı türleri sade adlarla ve kanal rolleriyle gösterilir. Aktif seviye her kanalın yanındadır; **⇅ A ↔ B** kanalları değiştirir. Otomatik ayar varsayılan olarak açıktır: giriş türünü (0/1 veya analog), histerezis eşiklerini ve kontak sıçramasını eleyen parazit filtresini özgün örneklerden belirler. Bağlantı türünü, kanal rollerini ve aktif seviyeyi değiştirmez. Daha iyi eşleşen bir bağlantı varsa bunu tek tıkla uygulanabilir **öneri** olarak gösterir; kayıt başındaki vana konumunu da yazar.

Kartlar açılma/kapanma için ortalama, min/maks, σ ve n; sorunlu olay sayısını ve **Sonrakini göster** düğmesini içerir. Parazit filtresi artık ms olarak girilir. Varsayılan bağlantı türü **İki konum sensörü**'dür. Eski sonuçlarla karşılaştırma ve `examples/vana_5hz.tdms` için **Eski kural (2.4.0 uyumlu)** seçin.

Ayrıntılar: **DEGISIKLIKLER_253.md**, kullanım: **VANA_ANALIZI_TR.md**, doğrulama: **TEST_253.txt**. Ekran örnekleri: `preview/vana_253_sonuc.png`, `preview/vana_253_oneri_koyu.png`, `preview/vana_253_gelismis.png`.

## 2.5.2: Akıcı yakınlaştırma ve sağ tuş

Görünüm güncellenirken eğriler yerinde yenilenir; eksenler ve lejant yeniden kurulmaz. RAM kanallarında da yakınlaştırılan aralığın ayrıntısı gelir. Disk önizlemeleri tek okuyucu sırasına alınır, 32 MiB sınırlı önbellekle yinelenen okumalar azaltılır. İlk çizim indirgemesi arka planda yapılır; çok kanalda çizim noktası bütçesi paylaşılır. Toplam Süre zoomla değişmez.

**Sağ tuşla sürükleyerek eksen ölçekleme devam eder. Menü için Ctrl + sağ tık kullanın.** İlk yükleme, zoom ve ölçümlerin davranışı ile geri bildirimin madde madde değerlendirmesi **DEGISIKLIKLER_252.md** içindedir.

## 2.5.1: Saniye ekseni, Y2 zoomu ve manuel eksen aralıkları

- `wf_start_time` bulunan TDMS kayıtları artık tarih/UTC yerine **Zaman (s)** ekseninde açılır. Örnekleme hızı ve özgün Y değerleri değişmez. Fs yoksa saniye uydurulmaz; **İndeks** gösterilir ve Manuel Fs girilebilir.
- **Y2**, tekerlekle ve dikdörtgenle yakınlaştırma/uzaklaştırmada Y1 ile aynı görüntü oranında değişir. Birimler ve sayısal sınırlar bağımsızdır. Y2 kilidi açıksa bilinçli olarak sabit kalır; grafikte Ctrl + sağ tık → **Sağ Y Ekseni Kilidi** ile kapatılabilir. Y1 kilidi Y2'yi kilitlemez.
- Üst çubukta **Aralık**, **Görünüm → Eksen Aralıkları…** veya grafikte Ctrl + sağ tık → **Eksen Aralıkları…**: değiştirmek istediğiniz X1/Y1/Y2 eksenlerini seçin, minimum–maksimum girin, **Uygula**'ya basın. Örnek: X1=4–8 s, Y1=0–50, Y2=1–4. Diğer eksenler korunur; ardından fareyle zooma devam edebilirsiniz. Açık bir eksen kilidi varsa yeni sınırlar kilidin yeni değeri olur.
- Y2 seçeneği, sağ eksene en az bir görünür kanal atanmışsa sunulur. Stacked görünümde X1 ortaktır; her kanalın Y aralığı ayrı girilir. Virgüllü ondalıklar ve `1e-3` gösterimi kabul edilir. Ters, eşit veya sonlu olmayan sınırlar uygulanmaz.
- Büyük dosyanın görünür bölümü yeniden okunurken X/Y1/Y2 görünümü korunur. **Y Sığdır**, seçili X aralığı için her iki Y eksenini ayrı hesaplar. **Sığdır**, kilitli eksenler dışında tüm veriye geri döner.
- Yeni projeler saniye eksenini ve manuel aralıkları kaydeder. Eski UTC projeleri açılabilir; geçersiz kalacak UTC görünümü ve ölçüm noktaları temizlenip kullanıcı bilgilendirilir. Eski çok dosyalı hesaplanan kanalları yeni zaman referansıyla yeniden kontrol edin.

Ayrıntılı inceleme ve test kapsamı: **DEGISIKLIKLER_251.md**. Ekran örnekleri `preview/eksen_251.png` ve `preview/eksen_araliklari_251.png`.

## 2.5.0: Ortak süre ve büyük veri

Kanalları çizdikten sonra soldaki **Testlerin ortak sürede yapıldığını varsay** kutusunu işaretleyin ve **Referans kanal** seçin. Referansın Fs değeri TDMS zaman metadatasından veya **Manuel Fs** sekmesinden bilinmelidir. Referansın özgün örnek sayısı `Nref` ise `T=(Nref-1)/Fsref` hesaplanır. Her kaynak kanalın özgün örneği için `t[i]=t0+i*T/(N-1)` kullanılır. Referansın başlangıç zamanı/ofseti `t0` bütün kaynak kanallara uygulanır. Bu bir **kullanıcı varsayımıdır**: farklı kayıtlara eşzamanlılık kanıtı oluşturmaz.

Kutuyu kapatınca kanalın kendi manuel Fs/TDMS zamanına veya indeks eksenine dönülür. Atanan manuel Fs değerleri ve kaynak dosya değişmez. Ortak süre açıkken diğer kanalların etkin Fs'si kendi metadata/manual Fs değerinden farklı olabilir. FFT, A/B, vana analizi ve CSV, grafikteki etkin zaman eksenini kullanır. Daha önce oluşturulmuş hesaplanan kanalların dizileri değiştirilmez; yeni zamanla yeniden hesaplayın. İşaretler, A/B ve FFT zaman değişince temizlenir. Ayar `.tdmsproj` ile kaydedilir; eski projelerde varsayılan olarak kapalıdır.

**250 bin örneği aşan kanallar** ilk grafikte tüm diziyi tutmak yerine blok blok okunur; yaklaşık 60 bin noktalık, pikleri/boşlukları koruyan önizleme gösterilir. Yakınlaştırınca görünen aralık yeniden okunur. CSV, FFT ve analiz gerektiğinde özgün örnekleri kaynaktan okur. Bu nedenle 5/10 örnekte bir kalıcı import seçeneği yoktur; kısa anahtarlama olayları kaybolmaz. Çok geniş aralıkta ekran çizgisi önizlemedir, sayısal analiz sonucu değildir.

## 2.4.1: Vana Analizi düzeltmeleri

Kapanma hesabı artık tek bir sinyal sırasına bağlı değil. **İki konum anahtarı**, **Komut + kapalı konum**, **Komut + açık konum** ve **Özel kenar eşleştirme** modları eklendi; **Eski kural (2.4.0)** varsayılan olarak korunuyordu (2.5.3'ten itibaren varsayılan **İki konum sensörü**). Gerçek bağlantınıza uygun modu seçin.

A/B kanalları için ayrı kararlılık süreleri, düşük/yüksek aktif polarite ve isteğe bağlı analog histerezis eşikleri var. Tanı görünümü ham sinyali, kararlılık öncesi durumu, kabul edilen geçişleri ve elenen kısa darbeleri yan yana gösterir. Aynı anda bitiş ve geri dönüş görülen olaylar belirsiz olarak işaretlenir; süre uydurulmaz.

Elle ölçüm seçili modun doğru başlangıç/bitiş kanalına oturur. Olay CSV bütün olayları ve analiz ayarlarını içerir. Bu analiz/ayarlar `.tdmsproj` içinde saklanmaz; CSV ile saklayın.

Kullanım, uyarıların açıklaması ve ölçüm tanımları: **VANA_ANALIZI_TR.md**. Önceki değişiklik özeti: **DEGISIKLIKLER_241.md**. Yeni gürültülü sentetik örnek: `examples/vana_gurultulu_1khz.tdms`. Eski `examples/vana_5hz.tdms` korunmuştur.

## Güncelleme

Uygulamayı kapatın, ZIP'i **yeni bir klasöre tamamen çıkartın**. Bütün `tdms_*.py` modülleri ve `icons` klasörü birlikte bulunmalıdır; yalnız ana Python dosyasını değiştirmeyin. `baslat_windows.bat` ile kaynak sürümü açın; pencere başlığında **2.8.1** yazmalıdır. Eski EXE, kaynak dosyaları değiştirmekle güncellenmez; aşağıdaki komutla yeniden oluşturulmalıdır.

## Zaman hesabı

| Öncelik | Koşul | Sonuç |
| --- | --- | --- |
| 1 | Kanala pozitif, sonlu manuel Fs atanmış | `t[i] = t0 + i / Fs` |
| 2 | Manuel atama yok, kanalın geçerli `wf_increment` metadatası var | `Fs = 1 / wf_increment`; kanalın kendi zaman adımı kullanılır |
| 3 | İkisi de yok | `x[i] = i`; eksen örnek indeksidir, saniye değildir. FFT için manuel Fs gerekir. |

`i`, dosyadaki **özgün, sıfırdan başlayan örnek indeksidir**. Büyük kayıtların seyreltilmiş önizlemeleri yeniden 0, 1, 2… diye numaralandırılmaz. Manuel Fs, Y değerlerini veya örnek sayısını değiştirmez. Zaman ekseni saniye olarak gösterilir. UTC başlangıcı bulunan dosyalarda, dosyadaki geçerli waveform başlangıçlarının en erkeni takvim referansı olarak çıkarılır; kanalların birbirine göre başlangıç farkları ve `wf_start_offset` korunur. Dolayısıyla ilk örneğin mutlaka 0 olması gerekmez. Her dosya kendi zaman referansını kullanır; farklı dosyaların takvim tarihine göre otomatik hizalanması yapılmaz.

Ortak süre **kapalıyken** her kanal bağımsızdır. Başka kanalın örnek sayısı, Fs değeri, eklenmesi veya çıkarılması bu kanalın Fs'sini değiştirmez. Başka bir Time kanalından, kayıt süresinden veya X dizisinden otomatik Fs çıkarılmaz. Metadata burada standart TDMS waveform zaman alanlarını ifade eder; adı rastgele `Fs` olan özel bir özellik otomatik yorumlanmaz.

**5 kHz atamak için:** Kanalları çizin → **Manuel Fs** sekmesi → ilgili kanal satırında **5 / kHz** veya **5000 / Hz** → **Uygula**. Aynı hız birden çok kanal için isteniyorsa her satıra atayın. Atamayı temizleyince kanal kendi metadatasına döner; metadata yoksa indeks gösterir. Kanal Yöneticisi ve Veri Kalitesi, etkin Fs ile kaynağını gösterir.

| Kontrol | 5 kHz | 500 Hz |
| --- | --- | --- |
| Bir örnek aralığı | 0,2 ms | 2 ms |
| 200 örnek aralığı süren olay | 40 ms | 400 ms |
| 5001 örnekte ilk-son örnek arası | 1 s | 10 s |

Bu fark matematiksel olarak zorunludur. 500 Hz seçince beklenen süreyi elde etmek, gerçek kayıt hızının 500 Hz olduğunu tek başına kanıtlamaz. Cihazın hızı ile TDMS'ye gerçekten yazılan kanal hızı farklı olabilir; uygulama kaydedilmemiş örnekleri yeniden üretemez. Bilinen olay için dosyadaki iki özgün örnek indeksinin farkını kontrol edin.

**Fs değiştiğinde** eski işaretler, A/B konumları ve FFT sonucu temizlenir. Yeni eksende ölçüm noktalarını yeniden yerleştirin. FFT, grafikle aynı kanal Fs'sini kullanır; ayrı FFT Fs girişi yoktur.

## Eski projeler

2.2.x projeleri açılabilir. Kaynak kanallar yeniden okunur; kanal bazlı manuel Fs atamaları korunur. Eski referans/ortak süre ve ayrı FFT Fs ayarları yok sayılır. Eski zaman aralığı, X başlığı, işaretler ve A/B konumları sıfırlanır; geçiş bilgisi gösterilir.

Eski projedeki **hesaplanan kanalların** Y değerleri ve formülleri korunur. Eski zaman ölçeği güvenilir biçimde ayırt edilemediğinden indeks eksenine alınır; varsa kendilerine ait manuel Fs uygulanır. Bu kanalları yeni kaynak ayarlarıyla yeniden hesaplayın veya bilinen Fs'lerini kendilerine atayın. Yeni hesaplanan kanal, açıkça seçilmiş hesap kaynağının o andaki zaman eksenini saklar; diğer kaynakların Fs'sini değiştirmez.

Yeni kayıtlarda proje biçimi sürüm 2'dir. 2.3.0 ile kaydedilen projeler önceki uygulama sürümleriyle açılamaz. Eski proje kopyasını saklamak için **Farklı Kaydet** kullanın.

## Kurulum

Sabitlenmiş bağımlılıklar Python **3.12 veya üzeri, 64 bit** içindir. Windows'ta önce `kurulum_windows.bat`, sonraki açılışlarda `baslat_windows.bat` kullanılabilir. Kurulum internet gerektirir.

```powershell
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe tdmsreader.py
```

Linux/macOS'ta `.venv/bin/python` kullanın. SciPy olmadan uygulama açılır, SG filtresi devre dışı kalır. Bağımlılıklar `requirements.txt` içindedir.

## Windows EXE ve çevrimdışı kullanım

**Windows'ta**, PyCharm terminalinde proje klasöründe ve doğru sanal ortam etkin durumdayken:

```powershell
python -m pip install -r requirements.txt
python -m pip install pyinstaller pillow
python -m PyInstaller --clean --noconfirm TDMSReaderPro.spec
```

Sanal ortam etkin değilse `python` yerine `.venv\Scripts\python.exe` yazın. Oluşan **`dist\TDMSReaderPro` klasörünün tamamını**, `_internal` ve diğer dosyalarla birlikte çevrimdışı Windows bilgisayara taşıyın. `TDMSReaderPro.exe` ile açılır; hedefte Python kurulumu ve internet gerekmez. Tek başına EXE dosyasını taşımayın.

Bu teslimat kaynak paketidir. Windows EXE derlemesi ve hedef Windows bilgisayar testi bu ortamda yapılmadı. Derlemeyi kullanacağınız Windows mimarisinde yapın ve taşınan klasörde örnek dosya açma/çizme/CSV kontrolü yapın.

## CSV aktarımı

Kanalları onay kutularıyla seçin → **Seçili Kanalları Çiz** → **CSV Aktar** / **Ctrl+E**. Açılan listede tüm yüklenmiş kanallar varsayılan seçilidir; yalnız satırı vurgulamak kanal seçimi değildir.

| Seçenek | Davranış |
| --- | --- |
| Yan yana | Her kanalın kendi X/Y sütunları vardır. Kısa kanalların devamındaki hücreler boştur. |
| Uzun tablo | Kanal kimliği, dosya/grup/kanal, birim, özgün örnek indeksi, X türü, X ve Y içerir. |
| Tüm kayıt | Seyreltilmiş önizleme yerine bütün örnekleri aktarır. |
| Görünen X aralığı | Görünen koordinatlar kullanılır; sınır örnekleri dahildir. |
| Excel Türkçe | Noktalı virgül ayırıcı, virgül ondalık ve UTF-8 BOM kullanır. |
| Kaydırmaları uygula | Görüntü X/Y ofsetlerini uygular; varsayılan kapalıdır. |

Aynı CSV satırı farklı kanallarda aynı anı temsil etmek zorunda değildir. Her kanalın kendi X sütununu kullanın; ortak süre seçildiyse X sütunları bu varsayıma göre hesaplanır, CSV için interpolasyon yapılmaz. FFT, A/B ve CSV aynı etkin kanal zamanını kullanır.

CSV, SG filtresinden bağımsız ölçüm değerlerini aktarır; npTDMS'nin TDMS/DAQmx ölçeklendirmesi korunur. Zamanlı kanallarda X, grafiktekiyle aynı saniye koordinatıdır; Fs bilinmeyen kanallarda örnek indeksidir. NaN/Inf açıkça yazılır; boş hücre o kanalda örnek bulunmayan satırı belirtir. Kayıt geçici dosya üzerinden yapılır; iptal veya hatada eski hedef korunur.

## Ölçüm ve veri kalitesi

**A/B Ölçüm** / **Ctrl+M**, iki imleç arasında kanal değerlerini ve farklarını gösterir. Değerler en yakın özgün örnekten alınır; aralık dışında değer üretilmez. Tablodaki ΔX, o kanalın seçilen özgün örnekleri arasındaki farktır. **Aralık İstatistiği**, A/B sınırlarında sonlu örnek sayısını, ortalamayı ve RMS'yi hesaplar. İndeks ekseninde ΔX saniye değildir.

**Veri Kalitesi → Tüm Örnekleri Denetle**, kaynak veri türünü, birimi, etkin Fs/kaynağını, örnek sayısını, NaN/Inf ve geçersiz örnek oranını gösterir. Büyük kanallar bloklarla taranır. Bu özellik fiziksel sensör doğruluğunu veya cihazın gerçek örnekleme hızını kanıtlamaz; kaydedilen verinin sayısal durumunu denetler, veriyi değiştirmez.

Grafik menüsü Ctrl + sağ tık ile açılır; sıradan sağ tık menü açmaz ve sağ tuşla sürükleme ölçekleme için kullanılabilir. Overlay/Stacked, ayrı grafik penceresi, kanal renkleri, eksen kilitleri ve açık/koyu tema korunmuştur. Stacked görünüm en fazla 24 kanal gösterir; CSV bu sınıra bağlı değildir.

## Proje ve hesaplanan kanallar

**Ctrl+S** kaydeder, **Ctrl+Shift+O** proje açar, **Ctrl+Alt+S** farklı kaydeder. `.tdmsproj`; kaynak yollarını, kanal seçimi/stillerini, manuel Fs atamalarını, görünümü, ölçüm noktalarını ve hesaplanmış sonuç dizilerini saklar. Kaynak TDMS dosyaları gömülmez; ayrıca taşınmalıdır. Kaynak boyutu/değişiklik zamanı uyuşmazsa veya dosya eksikse açılmaz. Otomatik kaydetme yoktur.

Hesaplanan kanallar anlık sonuçtur. Kaynağın Fs'sini/değerlerini değiştirirseniz yeniden oluşturun. Bir formülde birden çok kaynak kullanıldığında yalnız bu açık hesap için zaman noktalarına interpolasyon yapılabilir; hiçbir kaynak kanalın Fs'si değiştirilmez. `gradient(C1)` örnek indeksine göre türevdir; `cumsum(C1)` tek başına zaman integrali değildir.

Sayısal metin kanalları desteklenir (`1.25`, `1,25`, `-2.5e-3`). Tek virgül ondalıktır; binlik ayırıcı kullanmayın. Boş/None örnekleri NaN olarak kalır. Sayısal olmayan metinlerde sorunlu örnek belirtilir.

## Testler ve sınırlar

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

Güncel test kapsamı ve sonuçlar `TEST_253.txt` içindedir; önceki sürümlerinki `TEST_2xx.txt` dosyalarındadır. `examples/demo.tdms` sentetik 1000/500/100 Hz kanallar içerir; gerçek cihaz kaydı değildir. Önizlemeler `preview` klasöründedir.

`fs_teshis.py`, TDMS örnek sayısını ve zaman metadatasını değiştirmeden raporlayan bağımsız yardımcıdır:

```powershell
python fs_teshis.py "C:\Veri\test.tdms" --report fs_raporu.txt
```

FFT ve hesaplanan kanallar tam veri dizilerine ihtiyaç duyar; RAM kullanımı kayıt boyutuyla artar. Min/maks önizleme tüm dijital geçişlerin kesin zamanını göstermez; yakınlaştırma ve tam çözünürlüklü A/B kullanın. Float64 Unix saniyesi çok yüksek hızlarda mutlak zaman ayrımını sınırlar. Gerçek cihazınızın TDMS kaydı paylaşılmadığı için cihaza özgü kayıt/ölçekleme davranışı ayrıca doğrulanmalıdır.
