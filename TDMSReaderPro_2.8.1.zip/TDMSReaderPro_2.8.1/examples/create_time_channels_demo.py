"""Small mixed-rate RIO record; signals have no waveform time metadata."""
from pathlib import Path
import numpy as np
from nptdms import TdmsWriter,ChannelObject

def main():
    destination=Path(__file__).with_name('time_channels_mixed_rates.tdms')
    slow=np.arange(2001)/500
    fast=np.arange(20001)/5000
    status=((slow>=1.08)&(slow<2.52)).astype(float)
    closed=((slow<1.0)|(slow>=2.60)).astype(float)
    pulse=((fast>=1.0)&(fast<2.0)).astype(float)
    pressure=1.+39.*((slow>=1.09)&(slow<2.58))
    objects=[
        ChannelObject('RIO1-9205-1','PT Inlet',40.+.02*np.sin(2*np.pi*slow)),
        ChannelObject('RIO1-9205-1','PT Outlet',pressure),
        ChannelObject('RIO1-9253-1','Flow',((fast>=1.1)&(fast<2.55)).astype(float)),
        ChannelObject('RIO1-Times','Mod 1-Time',100.+slow),
        ChannelObject('RIO1-Times','Mod 2-Time',100.0004+fast),
        ChannelObject('RIO3-9425-3','Open',status),
        ChannelObject('RIO3-9425-3','Closed',closed),
        ChannelObject('RIO3-9425-4','Fast Digital',pulse),
        ChannelObject('RIO3-9425-6','RIO3 Synch',np.zeros(len(fast))),
        ChannelObject('RIO3-Times','Mod 3-Time',100.006+slow),
        ChannelObject('RIO3-Times','Mod 4-Time',100.0064+fast),
        ChannelObject('RIO3-Times','Mod 6-Time',100.0072+fast),
    ]
    with TdmsWriter(destination) as writer:writer.write_segment(objects)
    print(destination)

if __name__=='__main__':main()
