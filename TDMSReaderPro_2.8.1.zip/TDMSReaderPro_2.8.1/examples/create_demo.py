"""Create synthetic multirate TDMS channels; no real measurement data included."""
from pathlib import Path
import numpy as np
from nptdms import TdmsWriter, ChannelObject


def create_demo(path=None):
    path = Path(path) if path else Path(__file__).with_name("demo.tdms")
    t = np.arange(24_000) / 1000
    envelope = np.clip(t/2, 0, 1) * np.clip((24-t)/3, 0, 1)
    inlet = envelope * (42 + 2.6*np.sin(2*np.pi*.36*t) + .5*np.sin(2*np.pi*8*t))
    inlet[13_327] += 12
    t2 = np.arange(12_000) / 500
    outlet = np.interp(t2,t,inlet) - np.clip(t2/2,0,1) * np.clip((24-t2)/3,0,1) * 6
    td = np.arange(2400) / 100
    valve = ((td>=2) & (td<21)).astype(np.uint8)
    with TdmsWriter(path) as writer:
        writer.write_segment([
            ChannelObject("Basınç", "Giriş basıncı", inlet, {"wf_increment":.001, "unit_string":"bar"}),
            ChannelObject("Basınç", "Çıkış basıncı", outlet, {"wf_increment":.002, "unit_string":"bar"}),
            ChannelObject("Kontrol", "Vana komutu", valve, {"wf_increment":.01, "unit_string":"0/1"}),
        ])
    return path


if __name__ == "__main__":
    print(create_demo())
