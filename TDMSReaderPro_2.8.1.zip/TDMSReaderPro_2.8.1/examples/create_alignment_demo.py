"""Synthetic acquisition offsets; no physical system delay is modelled."""
from pathlib import Path
import numpy as np
from nptdms import ChannelObject, TdmsWriter


def make_demo(path=None):
    path=Path(path) if path else Path(__file__).with_name('channel_alignment_demo.tdms')
    channels=[]
    for name,fs,delay,digital in [('AnalogReference',5000.,0.,False),('AnalogDelayed',7000.,.0022,False),
                                  ('Sync',10000.,0.,True),('DigitalDelayed',10000.,.0014,True),('SyncZero',10000.,0.,True)]:
        t=np.arange(int(4*fs)+1)/fs;u=t-delay
        if name=='SyncZero':y=np.zeros(len(t))
        elif digital:y=(((u>=1.)&(u<1.5))|((u>=2.2)&(u<2.35))).astype(float)
        else:y=np.exp(-((u-.7)/.07)**2)+.6*np.exp(-((u-1.4)/.12)**2)-.3*np.exp(-((u-2.1)/.03)**2)
        channels.append(ChannelObject('AlignmentDemo',name,y,{'wf_increment':1/fs,'wf_start_offset':0.,
            'unit_string':'','description':'Sentetik acquisition offset örneği; fiziksel gecikme değildir.'}))
    with TdmsWriter(path) as writer:writer.write_segment(channels)
    return path


if __name__=='__main__':print(make_demo())
