"""Reproducible synthetic noisy signals, not a measurement from a real valve."""
from pathlib import Path
import numpy as np
from nptdms import TdmsWriter, ChannelObject


def create(path):
    n = 1000
    opened = np.zeros(n, dtype=np.int16); opened[180:600] = 1
    closed = np.ones(n, dtype=np.int16); closed[100:700] = 0
    # End-stop travel: B falling -> A rising (80 ms), A falling -> B rising (100 ms).
    opened[650] = 1; closed[130:132] = 1
    command = np.zeros(n); command[100:600] = 1
    feedback = np.ones(n); feedback[180:700] = 0
    command[630] = 1; feedback[650:652] = 1
    rng = np.random.default_rng(241)
    command_v = .1 + 4.8*command + rng.normal(0, .08, n)
    feedback_v = .1 + 4.8*feedback + rng.normal(0, .08, n)
    digital = {'wf_increment': .001, 'unit_string': '0/1'}
    analog = {'wf_increment': .001, 'unit_string': 'V'}
    channels = [ChannelObject('KonumAnahtarlari', 'Acik', opened, properties=digital),
                ChannelObject('KonumAnahtarlari', 'Kapali', closed, properties=digital),
                ChannelObject('TersPolarite', 'Acik', 1-opened, properties=digital),
                ChannelObject('TersPolarite', 'Kapali', 1-closed, properties=digital),
                ChannelObject('GurultuluKomut', 'AcmaKomutu_V', command_v, properties=analog),
                ChannelObject('GurultuluKomut', 'KapaliKonum_V', feedback_v, properties=analog)]
    with TdmsWriter(path) as writer:
        writer.write_segment(channels)


if __name__ == '__main__':
    target = Path(__file__).with_name('vana_gurultulu_1khz.tdms')
    create(target)
    print(target)
