"""Reproducible synthetic flow test: two plateaus, different native sample rates.

This is a demonstration, not experimental valve data. Run from any directory.
"""
from pathlib import Path
import numpy as np
from nptdms import ChannelObject, TdmsWriter


def make_demo(path=None):
    path = Path(path) if path else Path(__file__).with_name('basinc_kaybi_demo.tdms')
    rng = np.random.default_rng(255)
    channels = []
    for name, fs, unit in (('Pin', 1000., 'bar'), ('Pout', 1000., 'kPa'), ('Debi', 100., 'kg/s')):
        t = np.arange(round(26*fs)+1)/fs
        plateau1 = np.clip((t-1.)/1.2, 0, 1)*np.clip((10.6-t)/.6, 0, 1)
        plateau2 = np.clip((t-13.)/1.2, 0, 1)*np.clip((23.6-t)/.6, 0, 1)
        if name=='Pin':
            y = 1.+15.908*plateau1+11.1*plateau2+rng.normal(0, .001, len(t))
        elif name=='Pout':
            y = 1.+15.846*plateau1+11.072*plateau2+rng.normal(0, .001, len(t))
            y *= 100.  # kPa
        else:
            y = 59.63*plateau1+35.*plateau2+rng.normal(0, .02, len(t))
        channels.append(ChannelObject('AkisTesti', name, y, properties={
            'wf_increment':1/fs, 'wf_start_offset':0., 'unit_string':unit,
            'description':'Sentetik kararlı akış / basınç kaybı örneği'}))
    with TdmsWriter(path) as writer:
        writer.write_segment(channels)
    return path


if __name__ == '__main__':
    print(make_demo())
