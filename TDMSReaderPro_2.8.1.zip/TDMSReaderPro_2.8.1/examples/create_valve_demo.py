"""Create a reproducible 5 Hz binary valve example (not a physical test record)."""
from pathlib import Path
import numpy as np
from nptdms import TdmsWriter, ChannelObject


def create(path):
    n=200
    opened=np.zeros(n,dtype=np.int16)
    closed=np.ones(n,dtype=np.int16)
    opened[10:44]=1; closed[14:40]=0       # opening 0.8 s; closing 0.8 s
    opened[75:120]=1; closed[81:113]=0     # opening 1.2 s; closing 1.4 s
    opened[155:158]=1                      # cancelled opening; no matching fall
    opened[185:]=1                         # incomplete opening at EOF
    props={'wf_increment':.2, 'unit_string':'0/1'}
    with TdmsWriter(path) as writer:
        writer.write_segment([ChannelObject('Vana','Acik',opened,properties=props),
                              ChannelObject('Vana','Kapali',closed,properties=props)])


if __name__=='__main__':
    path=Path(__file__).with_name('vana_5hz.tdms');create(path);print(path)
