"""Explicit, validated time-channel binding; independent of signal processing.

Only regular numeric clocks are projected onto the existing uniform-time
pipeline. Validation streams every timestamp once and caches scalar results,
never signal arrays. No resampling, correlation, or TDMS mutation is performed.
"""
from __future__ import annotations
from collections import OrderedDict
import math
import re
import threading
import numpy as np
from tdms_io import fingerprint
from tdms_export import ExportCancelled

_RIO = re.compile(r'^(RIO\d+)-(\d+)-(\d+)$', re.I)
_TIME = re.compile(r'^Mod\s*(\d+)\s*-\s*Time$', re.I)
_UNITS = {'s':1., 'sec':1., 'second':1., 'seconds':1., 'ms':1e-3,
          'millisecond':1e-3, 'milliseconds':1e-3, 'us':1e-6,
          'µs':1e-6, 'μs':1e-6, 'ns':1e-9}
_CACHE = OrderedDict()
_LOCK = threading.RLock()
_BLOCK = 131_072


def clean_settings(settings=None):
    s = settings if isinstance(settings, dict) else {}
    bindings = s.get('bindings', {})
    if not isinstance(bindings, dict):
        raise ValueError('Geçersiz zaman kanalı eşlemesi.')
    out = {'enabled':bool(s.get('enabled', True)), 'unit':str(s.get('unit', 's')), 'bindings':{}}
    if out['unit'] not in ('s','ms','us','ns'):
        raise ValueError('Zaman kanalı birimi s, ms, us veya ns olmalı.')
    for group, item in bindings.items():
        if not isinstance(group, str):raise ValueError('Geçersiz modül adı.')
        if item is None:
            out['bindings'][group] = None
        elif isinstance(item, dict) and all(isinstance(item.get(k), str) for k in ('group','channel')):
            out['bindings'][group] = {'group':item['group'], 'channel':item['channel']}
        else:raise ValueError('Geçersiz zaman kanalı seçimi.')
    return out


def discover(tdms):
    """Metadata-only proposals. Sample count alone never identifies a clock."""
    groups = tdms.groups()
    clocks = {}
    for g in groups:
        if re.fullmatch(r'RIO\d+-Times', g.name, re.I):
            for ch in g.channels():
                if _TIME.fullmatch(ch.name):clocks[(g.name, ch.name)] = ch
        else:
            for ch in g.channels():
                if ch.name.strip().lower() in ('time','times','timestamp','timestamps','zaman'):
                    clocks[(g.name,ch.name)]=ch
    rows = []
    for g in groups:
        match = _RIO.fullmatch(g.name)
        if not match:
            if not g.name.lower().endswith('-times'):
                rows.append({'group':g.name,'lengths':sorted({len(c) for c in g.channels() if len(c)}),
                             'target':None,'method':'Elle zaman kanalı seçilebilir','automatic':False})
            continue
        rio, model, number = match.groups()
        peers = [x for x in groups if (m:=_RIO.fullmatch(x.name)) and m[1].lower()==rio.lower()]
        families = { _RIO.fullmatch(x.name)[2] for x in peers }
        slots = {int(_TIME.fullmatch(c)[1]):(gn,c) for gn,c in clocks if gn.lower()==(rio+'-Times').lower() and _TIME.fullmatch(c)}
        target = None; method = ''; automatic = False
        # An explicit slot property takes priority over naming conventions.
        slot_props = [v for k,v in g.properties.items() if re.sub('[^a-z0-9]', '', str(k).lower()) in
                      ('slot','slotnumber','moduleslot','nimoduleslot')]
        try:
            slot = int(slot_props[0]) if len(slot_props)==1 else None
        except (ValueError, TypeError, OverflowError):slot = None
        if slot in slots:
            target=slots[slot]; method='Slot metadata'; automatic=True
        elif len(families)==1 and int(number) in slots:
            target=slots[int(number)]; method='RIO / modül adı'; automatic=True
        elif len(peers)==len(slots) and set(slots)==set(range(1,len(peers)+1)):
            # Mixed-model suffixes restart at 1. Group order is only a proposal,
            # never proof of physical slot identity: require explicit Apply.
            family_positions = {}
            for peer in peers:
                pm = _RIO.fullmatch(peer.name)
                family_positions.setdefault(pm[2],[]).append(int(pm[3]))
            if all(v==list(range(1,len(v)+1)) for v in family_positions.values()):
                target=slots[peers.index(g)+1]; method='Grup sırası önerisi — onay gerekli'
        lengths = sorted({len(c) for c in g.channels() if len(c)})
        if target and len(clocks[target]) not in lengths:
            alternatives=[pair for pair in slots.values() if len(clocks[pair]) in lengths]
            if method.startswith('Grup sırası') and len(alternatives)==1:
                target=alternatives[0];method='Örnek sayısı adayı — onay gerekli'
            else:method += ' / örnek sayısı uyuşmuyor'
            automatic=False
        rows.append({'group':g.name, 'lengths':lengths, 'target':target,
                     'method':method or 'Zaman kanalı seçin', 'automatic':automatic})
    return rows, clocks


def _validate(channel, scale, cancelled):
    n = len(channel)
    if n<2:return {'valid':False,'n':n,'reason':'En az iki zaman örneği gerekli.'}
    if np.dtype(channel.dtype).kind not in 'iuf':
        return {'valid':False,'n':n,'reason':'Sayısal bir zaman kanalı gerekli.'}
    first=float(channel.read_data(offset=0,length=1)[0])*scale
    last=float(channel.read_data(offset=n-1,length=1)[0])*scale
    inc=(last-first)/(n-1)
    if not (math.isfinite(first) and math.isfinite(last) and math.isfinite(inc) and inc>0):
        return {'valid':False,'n':n,'reason':'Zaman sabit, geri gidiyor veya sonlu değil.'}
    # Allow representational roundoff, not real clock jitter or missing samples.
    tol=max(2e-9,8*abs(float(np.spacing(max(abs(first),abs(last))))),abs(inc)*1e-7)
    prev=None
    for start in range(0,n,_BLOCK):
        if cancelled():raise ExportCancelled()
        a=np.asarray(channel.read_data(offset=start,length=min(_BLOCK,n-start)),dtype=float)*scale
        if len(a)!=min(_BLOCK,n-start):raise IOError('Zaman kanalı eksik okundu.')
        if not np.all(np.isfinite(a)) or np.any(np.diff(a)<=0) or (prev is not None and a[0]<=prev):
            return {'valid':False,'n':n,'reason':'Zaman artmıyor, tekrarlı veya sonlu olmayan örnek var.'}
        expected=first+(start+np.arange(len(a),dtype=float))*inc
        if np.any(np.abs(a-expected)>tol):
            return {'valid':False,'n':n,'reason':'Düzensiz zaman: bu sürümde sabit Fs ile bağlanmaz.'}
        prev=float(a[-1])
    return {'valid':True,'n':n,'first':first,'last':last,'inc':inc,'fs':1/inc,'tolerance':tol}


class TimeChannelResolver:
    def __init__(self, tdms, path, settings=None, cancelled=lambda:False):
        self.tdms,self.path,self.settings,self.cancelled=tdms,path,clean_settings(settings),cancelled
        self.rows,self.clocks=discover(tdms)
        # Manual selections may point to a time channel outside RIO-Times.
        for b in self.settings['bindings'].values():
            if b is not None:
                try:self.clocks[(b['group'],b['channel'])]=tdms[b['group']][b['channel']]
                except KeyError:pass
        self._validated=None
        self._fingerprint=fingerprint(path)

    def validate(self):
        if self._validated is not None:return self._validated
        result={}
        for key,ch in self.clocks.items():
            if self.cancelled():raise ExportCancelled()
            unit=str(ch.properties.get('unit_string',ch.properties.get('unit','')) or '').strip().lower()
            assumed=not bool(unit)
            chosen=unit or self.settings['unit']
            scale=_UNITS.get(chosen)
            if scale is None:
                result[key]={'valid':False,'n':len(ch),'reason':'Desteklenmeyen zaman birimi: '+chosen}
                continue
            cache_key=(self.path,self._fingerprint,*key,scale)
            with _LOCK:
                checked=_CACHE.get(cache_key)
                if checked is not None:_CACHE.move_to_end(cache_key)
            if checked is None:
                checked=_validate(ch,scale,self.cancelled)
                if fingerprint(self.path)!=self._fingerprint:
                    raise IOError('TDMS zaman doğrulaması sırasında değişti; dosyayı yeniden açın.')
                with _LOCK:
                    _CACHE[cache_key]=checked
                    while len(_CACHE)>256:_CACHE.popitem(last=False)
            result[key]=dict(checked,unit=chosen,assumed_unit=assumed)
        self._validated=result
        return result

    def reports(self):
        checked=self.validate()
        valid=[x['first'] for x in checked.values() if x['valid']]
        origin=min(valid) if valid else 0.
        report=[]
        for row in self.rows:
            r=dict(row); b=self.settings['bindings'].get(r['group'],'auto')
            target=r['target'] if b=='auto' else ((b['group'],b['channel']) if b else None)
            explicit=b!='auto' and b is not None
            r.update(target=target,active=self.settings['enabled'] and (explicit or (b=='auto' and r['automatic'])),explicit=explicit)
            health=dict(checked.get(target,{'valid':False,'reason':'Zaman kanalı seçilmedi veya bulunamadı.'}))
            if health['valid']:
                health['base']=health['first']-origin
                if health['n'] not in r['lengths']:
                    health.update(valid=False,reason='Veri / zaman örnek sayıları uyuşmuyor.')
            r.update(health=health,origin=origin)
            report.append(r)
        # Manual non-RIO groups are supported without guessing generic names.
        for group,b in self.settings['bindings'].items():
            if any(r['group']==group for r in report) or b is None:continue
            target=(b['group'],b['channel']);health=dict(checked.get(target,{'valid':False,'reason':'Zaman kanalı bulunamadı.'}))
            if health['valid']:health['base']=health['first']-origin
            report.append({'group':group,'target':target,'method':'Kullanıcı seçimi','automatic':False,'explicit':True,'active':self.settings['enabled'],'health':health,'origin':origin})
        return report

    def bind(self, group, channel, props):
        if not self.settings['enabled']:return props,None
        # Native waveform timing retains its previous behavior.
        if 'wf_increment' in props:return props,None
        row=next((r for r in self.rows if r['group']==group),None)
        choice=self.settings['bindings'].get(group,'auto')
        if choice is None or (choice=='auto' and (row is None or not row['automatic'])):return props,None
        r=next((r for r in self.reports() if r['group']==group),None)
        if r is None:return props,None
        health=r['health']
        if not health['valid'] or health['n']!=len(self.tdms[group][channel]):
            return props,dict(r,applied=False,reason=health.get('reason','Veri / zaman örnek sayıları uyuşmuyor.'))
        result=dict(props,wf_increment=health['inc'],wf_start_offset=health['base'])
        return result,dict(r,applied=True)
