# 2.8.0 — Kullanım

ZIP'i yeni bir klasöre çıkarın. Mevcut Python ortamınızla `tdmsreader.py`
çalıştırın; `icons` klasörü birlikte kalmalıdır. Ek bağımlılık yoktur.

1. Dosyayı açın veya pencereye sürükleyin.
2. Soldan kanalları işaretleyip **Grafiğe Ekle** deyin.
3. **Kanallar** ekranından ad, birim, renk ve ekseni düzenleyin. Fs için
   **Elle** kutusunu işaretleyip değeri **Hz** olarak girin. Kutuyu kaldırınca
   Times / özgün TDMS zamanı kullanılır. **Ayrıntılar** ek sütunları açar.
4. **Zaman Kanalları** eşlemesi aynıdır. **Denetle** mevcut eşlemeyi inceler;
   **Uygula** seçimleri kabul eder. **Bağlamayı Kapat** seçili dosyada
   özgün TDMS / indeks yöntemine döner.
5. Vana Analizi, Basınç Kaybı, Aralık Analizi ve FFT aynı hesapları kullanır.
   İfade ile yeni kanal oluşturmak için **Hesaplanan** sekmesini kullanın.

Başlığın yanındaki **ⓘ** açıklamayı açar/kapatır. Canlı sonuçlar ve uyarılar
görünür kalır. Zaman durumu sütununun üzerine gelince tam açıklama görünür.

## Eski projeler

Manuel Fs ve Channel Alignment için ayrı ekranlar kaldırıldı. Kayıtlı Fs
atamaları ve eski elle ofsetler silinmez. Etkin ofsetler grafikte ve Zaman
Kanalları ekranında bildirilir. **Ofsetleri Sıfırla**, yalnız eski alignment
ofsetlerini kaldırır; Times bağını, ham veriyi ve görsel X/Y kaydırmalarını
değiştirmez. CSV'deki eski ofset seçeneği yalnız böyle bir ofset varsa görünür;
varsayılanı önceki gibi kapalıdır.

İkonlar yerel SVG'dir; internet gerekmez. Eski EXE kaynak dosyaları değiştirmekle
güncellenmez; bu paket Python kaynak projesidir.
