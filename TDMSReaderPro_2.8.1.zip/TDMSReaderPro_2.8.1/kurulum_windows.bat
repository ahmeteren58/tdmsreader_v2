@echo off
setlocal
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo Kurulum tamamlandi. baslat_windows.bat dosyasini acabilirsiniz.
pause
exit /b 0
:failed
echo Kurulum tamamlanamadi. Python 3.12 veya daha yeni 64-bit Python kurulumunu kontrol edin.
pause
exit /b 1
