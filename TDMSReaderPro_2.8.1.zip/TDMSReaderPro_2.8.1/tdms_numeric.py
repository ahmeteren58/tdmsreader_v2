"""Bounded-block overview reads which retain narrow extrema and missing data."""
import math
import re
from decimal import Decimal
from numbers import Real
import numpy as np


_NUMBER_TEXT = re.compile(r"[+-]?(?:[0-9]+(?:[.,][0-9]*)?|[.,][0-9]+)(?:[eE][+-]?[0-9]+)?\Z")
_NONFINITE_TEXT = {"nan", "+nan", "-nan", "inf", "+inf", "-inf",
                   "infinity", "+infinity", "-infinity"}


def numeric_1d(values, *, sample_offset=0):
    """Normalize real samples, including npTDMS string channels (dtype object).

    Native numeric arrays retain their dtype. Text uses float64; a single comma
    is a decimal separator, never a thousands separator. Blank/None samples
    become NaN without deleting a sample or changing its time index. Complex,
    timestamp and nonnumeric values are rejected with their sample position.
    """
    a = np.asarray(values).reshape(-1)
    if a.dtype.kind in "biuf":
        return np.ascontiguousarray(a)
    if a.dtype.kind not in "OSU":
        raise ValueError(f"Çizim için gerçek sayısal kanal gerekli; veri türü: {a.dtype}.")
    if not a.size:
        return np.array([], dtype=np.float64)

    # Object arrays may also contain actual integers; do not round 64-bit
    # counters through float64 just because their container is dtype object.
    if a.dtype.kind == "O" and all(isinstance(v, (int, np.integer, bool, np.bool_)) for v in a):
        lo, hi = int(min(a)), int(max(a))
        if -(2**63) <= lo and hi < 2**63:
            return a.astype(np.int64)
        if 0 <= lo and hi < 2**64:
            return a.astype(np.uint64)
        raise ValueError("Object kanalındaki tamsayılar tek bir 64 bit sayısal türe sığmıyor.")

    out = np.empty(a.size, dtype=np.float64)
    for i, value in enumerate(a):
        try:
            if value is None:
                number = math.nan
            elif isinstance(value, (str, bytes)):
                token = (value.decode("utf-8-sig") if isinstance(value, bytes) else value).strip()
                if not token:
                    number = math.nan
                elif token.lower() in _NONFINITE_TEXT:
                    number = float(token)
                else:
                    if _NUMBER_TEXT.fullmatch(token) is None:
                        raise ValueError("Sayı biçimi geçersiz; binlik ayırıcı desteklenmiyor.")
                    number = float(token.replace(",", "."))
                    if not math.isfinite(number):
                        raise ValueError("Değer float64 aralığını aşıyor.")
            elif isinstance(value, (Real, Decimal, np.bool_)):
                number = float(value)
                if isinstance(value, (int, np.integer)) and int(number) != int(value):
                    raise ValueError("Karma object kanalındaki tamsayı float64 ile tam temsil edilemiyor.")
                finite = value.is_finite() if isinstance(value, Decimal) else math.isfinite(value)
                if finite and not math.isfinite(number):
                    raise ValueError("Değer float64 aralığını aşıyor.")
            else:
                raise ValueError("Değer gerçek bir sayı veya sayısal metin değil.")
            out[i] = number
        except (ValueError, TypeError, OverflowError, UnicodeError) as exc:
            shown = repr(value)
            if len(shown) > 80:
                shown = shown[:77] + "..."
            raise ValueError(
                f"Sayısal dönüşüm başarısız: {sample_offset+i+1}. örnek, değer {shown}. {exc}"
            ) from exc
    return out


def read_envelope(channel, start, stop, max_points, cancelled=lambda: False):
    """Return original sample indices and values, never interpolated samples.

    Each bucket contributes its minimum, maximum and (when present) one missing
    sample. Reading stepped npTDMS slices would load the entire range first.
    Here reads are explicitly bounded to about 65536 samples or one bucket;
    the underlying reader may still buffer a whole TDMS data chunk.
    """
    n = max(0, stop-start)
    if n == 0:
        return np.array([], dtype=np.int64), np.array([], dtype=np.float64)
    bucket = max(1, math.ceil(n / max(1, (max_points-2)//3))) if n > max_points else 1
    block = max(bucket, (65_536//bucket)*bucket)
    indices, values = [], []
    for a in range(start, stop, block):
        if cancelled():
            return np.array([], dtype=np.int64), np.array([], dtype=np.float64)
        b = min(stop, a+block)
        y = numeric_1d(channel.read_data(offset=a, length=b-a), sample_offset=a)
        if len(y) != b-a:
            raise IOError("TDMS kanalının istenen veri aralığı eksik okundu.")
        if bucket == 1:
            pick = np.arange(len(y), dtype=np.int64)
        else:
            full = len(y)//bucket*bucket
            picks = []
            if full:
                yy = y[:full].reshape(-1, bucket)
                finite = np.isfinite(yy)
                # Preserve integer precision: argmin/argmax use original dtype
                # for integer arrays (which cannot contain NaN/Inf).
                small = np.where(finite, yy, np.inf) if y.dtype.kind == "f" else yy
                large = np.where(finite, yy, -np.inf) if y.dtype.kind == "f" else yy
                base = np.arange(len(yy))*bucket
                picks += [base+np.argmin(small, axis=1), base+np.argmax(large, axis=1)]
                bad = ~np.all(finite, axis=1)
                if np.any(bad):
                    picks.append((base+np.argmax(~finite, axis=1))[bad])
            if full < len(y):
                tail = y[full:]
                finite = np.isfinite(tail)
                if np.any(finite):
                    ids = np.flatnonzero(finite)
                    picks.append(full + ids[[np.argmin(tail[finite]), np.argmax(tail[finite])]])
                if np.any(~finite):
                    picks.append(np.array([full + np.flatnonzero(~finite)[0]]))
            if a == start:
                picks.append(np.array([0]))
            if b == stop:
                picks.append(np.array([len(y)-1]))
            pick = np.unique(np.concatenate(picks))
        indices.append(a+pick)
        values.append(y[pick])
    return np.concatenate(indices), np.concatenate(values)
