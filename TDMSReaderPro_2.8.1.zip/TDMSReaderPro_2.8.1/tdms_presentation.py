"""Presentation only: navigation, help, empty states and theme-aware actions."""
from __future__ import annotations
from PyQt6.QtCore import Qt,QEvent,QSize,QLocale
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (QFrame,QWidget,QLabel,QToolButton,QPushButton,
                            QHBoxLayout,QVBoxLayout,QCheckBox,QHeaderView,QDoubleSpinBox)


class FrequencyEditor(QDoubleSpinBox):
    def textFromValue(self,value):
        locale=self.locale();locale.setNumberOptions(locale.numberOptions()|QLocale.NumberOption.OmitGroupSeparator)
        text=locale.toString(value,'f',self.decimals())
        return text.rstrip('0').rstrip(locale.decimalPoint()) if locale.decimalPoint() in text else text


def page_header(layout,title,help_text):
    row=QHBoxLayout();row.setSpacing(8)
    heading=QLabel(title);heading.setProperty('pageTitle',True)
    row.addWidget(heading);row.addStretch()
    button=QToolButton();button.setText('?');button.setCheckable(True)
    button.setProperty('helpButton',True);button.setProperty('ui_icon','info.svg')
    button.setToolTip('Kısa yardım');button.setAccessibleName(title+' — yardım')
    button.setFixedSize(28,28);row.addWidget(button);layout.addLayout(row)
    detail=QLabel(help_text);detail.setWordWrap(True);detail.setProperty('pageHelp',True)
    detail.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    detail.hide();layout.addWidget(detail);button.toggled.connect(detail.setVisible)
    return heading,button,detail


class EmptyPlotState(QFrame):
    def __init__(self,parent,open_file):
        super().__init__(parent);self.setObjectName('plotEmptyState')
        outer=QVBoxLayout(self);outer.setSpacing(12);outer.addStretch()
        self.mark=QLabel();self.mark.setObjectName('emptyMark');self.mark.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title=QLabel('Test verisini açın');self.title.setObjectName('emptyTitle');self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.detail=QLabel('Kanalları seçin, grafiğe ekleyin.');self.detail.setObjectName('emptySubtitle');self.detail.setAlignment(Qt.AlignmentFlag.AlignCenter)
        for w in (self.mark,self.title,self.detail):outer.addWidget(w)
        row=QHBoxLayout();row.addStretch();self.open=QPushButton('TDMS Aç');self.open.setProperty('primary',True)
        self.open.setProperty('ui_icon','folder_white.svg');self.open.setMinimumWidth(140);self.open.clicked.connect(open_file)
        row.addWidget(self.open);row.addStretch();outer.addLayout(row)
        self.hint=QLabel('Dosyayı buraya sürükleyebilir veya Ctrl+O kullanabilirsiniz.')
        self.hint.setObjectName('emptySubtitle');self.hint.setAlignment(Qt.AlignmentFlag.AlignCenter);outer.addWidget(self.hint);outer.addStretch()
        parent.installEventFilter(self);self.setGeometry(parent.rect())

    def eventFilter(self,watched,event):
        if watched is self.parent() and event.type()==QEvent.Type.Resize:
            self.setGeometry(watched.rect())
            if self.isVisible():self.raise_()
        return super().eventFilter(watched,event)


class PresentationMixin:
    def _init_presentation(self,icon_loader):
        self._presentation_icons=icon_loader
        self.tabs.setObjectName('workspaceTabs');self.tabs.tabBar().setObjectName('workspaceTabBar')
        self.tabs.setIconSize(QSize(16,16));self.tabs.setUsesScrollButtons(True)
        self._presentation_pages=[
            (self.plot_tab,'Grafik','Grafik','chart.svg'),
            (self.channel_manager_tab,'Kanallar','Kanal Yöneticisi','channels.svg'),
            (self.time_channels_tab,'Zaman Kanalları','Zaman Kanalları','clock.svg'),
            (self.valve_tab,'Vana Analizi','Vana Analizi','valve.svg'),
            (self.steady_tab,'Basınç Kaybı','Basınç Kaybı','gauge.svg'),
            (self.range_stats_tab,'Aralık Analizi','Aralık Analizi','statistics.svg'),
            (self.fft_tab,'FFT','Frekans Analizi (FFT)','wave.svg'),
            (self.calculated_channel_tab,'Hesaplanan','Hesaplanan Kanal','formula.svg')]
        active=self.tabs.currentWidget()
        for index,(page,label,full,icon) in enumerate(self._presentation_pages):
            old=self.tabs.indexOf(page)
            if old!=index:self.tabs.tabBar().moveTab(old,index)
            self.tabs.setTabText(index,label);self.tabs.setTabToolTip(index,full)
        self.tabs.setCurrentWidget(active)
        # Reuse existing actions and signals; no plot implementation changes.
        self._polish_ribbon()
        # QScrollArea owns the ribbon through its viewport.
        parent=self.ribbon.parentWidget()
        while parent and not hasattr(parent,'setWidgetResizable'):parent=parent.parentWidget()
        if parent:parent.setFixedHeight(88)
        self.lbl_hint.setText('TDMS dosyalarını açın veya buraya sürükleyin.\nKanalları işaretleyip grafiğe ekleyin.')
        self.btn_plot_checked.setText('Grafiğe Ekle');self.btn_plot_checked.setAccessibleName('Seçili kanalları çiz')
        self.btn_uncheck_all.setText('Seçimi Kaldır');self.btn_clear_plot.setText('Grafiği Temizle')
        self.btn_open_manual_fs_tab.setText('Kanal Yöneticisi');self.btn_open_manual_fs_tab.setToolTip('Örnekleme hızı ve kanal ayarları')
        self._empty_plot=EmptyPlotState(self.plot_container,self._empty_plot_action)
        self._create_legacy_offsets_notice()
        self._simplify_analysis_copy()
        for attr,icon in {
            'btn_open':'folder_white','btn_plot_checked':'play_white','btn_uncheck_all':'deselect',
            'btn_clear_plot':'clear','btn_channel_manager_apply':'check_white','btn_channel_manager_refresh':'refresh',
            'btn_channel_manager_back':'chart','btn_calc_create':'plus_white',
            'btn_range_stats_calc':'play_white','btn_range_stats_visible':'region_rect','btn_range_stats_full':'move_pan',
            'btn_range_stats_clear':'clear','btn_range_stats_export':'export_csv',
            'time_check':'check','time_apply':'check_white','time_reset':'reset',
            'valve_run':'play_white','valve_stop':'stop','valve_csv':'export_csv',
            'steady_run':'play_white','steady_stop':'stop','steady_csv':'export_csv',
            'btn_details_close':'close',
        }.items():
            button=getattr(self,attr,None)
            if button is not None:button.setProperty('ui_icon',icon+'.svg')
        for widget in (self.tabs,self.tabs.tabBar()):
            widget.style().unpolish(widget);widget.style().polish(widget);widget.update()
        self._presentation_theme();self._presentation_sync()

    def _polish_ribbon(self):
        direct=Qt.FindChildOption.FindDirectChildrenOnly
        groups={}
        for group in self.ribbon.findChildren(QFrame,options=direct):
            caption=group.findChild(QLabel)
            if group.objectName()=='ribbonGroup' and caption is not None:groups[caption.text()]=(group,caption)
        loose={b.accessibleName():b for b in self.ribbon.findChildren(QToolButton,options=direct) if b.property('ribbon')=='1'}
        for name,title,index in (('Proje','Dosya',0),('Veri Kalitesi','İşaretleme & Ölçüm',-1)):
            button,entry=loose.get(name),groups.get(title)
            if button is None or entry is None:continue
            self.ribbon.layout().removeWidget(button)
            entry[0].layout().itemAt(0).layout().insertWidget(index,button)
        captions={'İşaretleme & Ölçüm':'Ölçüm','Görünüm':'Pencere'}
        for title,(_,caption) in groups.items():caption.setText(captions.get(title,title))
        labels={'Kaydet':('Görüntü','Grafiği görüntü olarak kaydet (PNG / SVG)'),
                'Veri Kalitesi':('Kalite','Veri kalitesi: veri türleri, Fs kaynağı ve eksik örnekler'),
                'Görünüm':('Düzen','Grafik düzeni: Overlay / Stacked'),
                'Marker':('İşaret','Tıklayarak grafik üzerine işaret ekle'),
                'Ölçüm':('A/B Ölçüm','A/B imleçleri ile aralık ölçümü'),
                'Ayır':('Ayır','Grafiği ayrı pencerede aç'),
                'Ayarlar':('Ayarlar','Grafik detay ayarları çekmecesini aç / kapat')}
        for b in self.ribbon.findChildren(QToolButton):
            if b.property('ribbon')!='1':continue
            text,tip=labels.get(b.accessibleName(),(None,None))
            if text:b.setText(text);b.setToolTip(tip)
            b.setFixedSize(66,54)

    def _presentation_theme(self):
        if not hasattr(self,'_presentation_icons'):return
        for i,(_,_,_,name) in enumerate(self._presentation_pages):self.tabs.setTabIcon(i,self._presentation_icons(name))
        for kind in (QToolButton,QPushButton):
            for b in self.findChildren(kind):
                name=b.property('ui_icon')
                if name:b.setIcon(self._presentation_icons(name));b.setIconSize(QSize(16,16))
        self._empty_plot.mark.setPixmap(self._presentation_icons('chart.svg').pixmap(48,48))
        self._time_status_theme()
        for bar in (self.tabs.tabBar(),self.file_tabs.tabBar()):
            for button in bar.findChildren(QToolButton):
                if button.arrowType() in (Qt.ArrowType.LeftArrow,Qt.ArrowType.RightArrow):
                    side='left' if button.arrowType()==Qt.ArrowType.LeftArrow else 'right'
                    button.setProperty('ui_icon','chevron_'+side+'.svg')
                    button.setIcon(self._presentation_icons('chevron_'+side+'.svg'))
                    button.setArrowType(Qt.ArrowType.NoArrow);button.setIconSize(QSize(12,12))

    def _time_status_theme(self):
        if not hasattr(self,'_presentation_icons'):return
        dark=self._theme=='dark'
        colors={'linked':'#75cfb5' if dark else '#26765b','pending':'#edc278' if dark else '#916017',
                'invalid':'#f0a3a3' if dark else '#ad4444','off':'#97a6b8' if dark else '#65768a'}
        for i in range(self.time_tree.topLevelItemCount()):
            row=self.time_tree.topLevelItem(i);status=row.data(5,Qt.ItemDataRole.UserRole) or 'off'
            row.setForeground(5,QColor(colors.get(status,colors['off'])))
            name='check.svg' if status=='linked' else 'warning.svg' if status in ('pending','invalid') else 'clock.svg'
            row.setIcon(5,self._presentation_icons(name))

    def _presentation_sync(self):
        if not hasattr(self,'_empty_plot'):return
        empty=not bool(self.current_series)
        self._empty_plot.setVisible(empty)
        if empty:
            loaded=bool(self.files)
            self._empty_plot.title.setText('Kanalları grafiğe ekleyin' if loaded else 'Test verisini açın')
            self._empty_plot.detail.setText('Soldaki listeden incelemek istediğiniz kanalları seçin.' if loaded else 'Kanalları seçin, grafiğe ekleyin.')
            self._empty_plot.open.setText('Grafiğe Ekle' if loaded else 'TDMS Aç')
            self._empty_plot.open.setEnabled(self.btn_plot_checked.isEnabled() if loaded else True)
            self._empty_plot.hint.setText('Kanal adlarının yanındaki kutuları işaretleyin.' if loaded else 'Dosyayı buraya sürükleyebilir veya Ctrl+O kullanabilirsiniz.')
            self._empty_plot.raise_()
        self._legacy_offsets_refresh()

    def _empty_plot_action(self):
        if self.files:self.plot_checked_channels()
        else:self.open_tdms()

    def _workspace_data_changed(self):
        super()._workspace_data_changed()
        self._presentation_sync()

    def _create_legacy_offsets_notice(self):
        self.legacy_offsets=QFrame();self.legacy_offsets.setObjectName('legacyOffsets')
        row=QHBoxLayout(self.legacy_offsets);row.setContentsMargins(10,6,10,6)
        self.legacy_offsets_text=QLabel();self.legacy_offsets_text.setWordWrap(True)
        row.addWidget(self.legacy_offsets_text,1)
        button=QPushButton('Ofsetleri Sıfırla');button.setProperty('ui_icon','reset.svg')
        button.clicked.connect(self._clear_legacy_offsets);row.addWidget(button)
        self.time_channels_tab.layout().insertWidget(self.time_channels_tab.layout().count()-1,self.legacy_offsets)
        self.legacy_offsets.hide()

    def _legacy_offsets_refresh(self):
        if not hasattr(self,'legacy_offsets'):return
        offsets=self.alignment_manager.snapshot();self.legacy_offsets.setVisible(bool(offsets))
        self.legacy_offsets_text.setText(f'Eski projeden {len(offsets)} elle zaman ofseti etkin. Zaman eşlemesinden sonra kontrol edin.')
        self.legacy_offsets_text.setToolTip('\n'.join(f'{key}: {value*1000:+.6g} ms' for key,value in offsets.items()))

    def _clear_legacy_offsets(self):
        self.alignment_manager.reset_all();self._alignment_redraw();self._legacy_offsets_refresh()

    def _simplify_analysis_copy(self):
        # Only static guidance is collapsed. Live errors/results remain visible.
        rules={self.valve_tab:[('İki kanalı ana grafikte','İki kanalı seçin ve süreleri hesaplayın.')],
               self.steady_tab:[('1. Kanalları ve birimleri','Basınç kanallarını seçip kararlı aralıkları bulun.'),
                                ('Basınçlar aynı referansta','Basınç kanalları aynı referansta olmalı.'),
                                ('Tolerans = büyük olanı',None),('Δp = ort(Pgiriş)',None)]}
        for page,items in rules.items():
            help_parts=[]
            for label in page.findChildren(QLabel):
                if label.text() in ('Vana açılma ve kapanma süreleri','Kararlı akış ve basınç kaybı'):
                    label.setText('Vana Analizi' if page is self.valve_tab else 'Basınç Kaybı')
                    label.setStyleSheet('');label.setProperty('pageTitle',True)
                for prefix,replacement in items:
                    if label.text().startswith(prefix):
                        help_parts.append(label.text())
                        label.setToolTip(label.text())
                        if replacement:label.setText(replacement)
                        else:label.hide()
            content=page.widget();layout=content.layout();old_title=layout.itemAt(0).widget()
            layout.removeWidget(old_title);old_title.hide()
            heading=QWidget();heading_layout=QVBoxLayout(heading);heading_layout.setContentsMargins(0,0,0,0)
            page_header(heading_layout,'Vana Analizi' if page is self.valve_tab else 'Basınç Kaybı','\n\n'.join(help_parts))
            layout.insertWidget(0,heading)
        self.steady_detail.setText('Aralığı grafikten veya başlangıç–bitiş alanlarından değiştirebilirsiniz.')
        self.steady_csv.setText('CSV Aktar');self.steady_manual_run.setText('Aralığı Hesapla')
        self.steady_restore.setText('Otomatik Aralığa Dön')
        self.valve_csv.setText('CSV Aktar')
