"""UI-independent, lossless multi-channel CSV export.

No pandas dependency, interpolation, decimation, or implicit float64 conversion
of integer samples. Each worker uses its own pooled TDMS session. The destination
is replaced atomically only after every selected channel has been written.
"""
from __future__ import annotations

import csv
import math
import os
import tempfile
from contextlib import ExitStack
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
from tdms_io import open_tdms
from tdms_numeric import numeric_1d


class ExportCancelled(Exception):
    """Cooperative cancellation; an existing destination remains untouched."""


@dataclass(frozen=True)
class ExportOptions:
    layout: str = "wide"
    delimiter: str = ";"
    decimal: str = "."
    x_range: tuple[float, float] | None = None
    apply_shifts: bool = False
    chunk_size: int = 16_384
    export_aligned: bool = False

    def __post_init__(self):
        if self.layout not in ("wide", "long"):
            raise ValueError("CSV düzeni wide veya long olmalıdır.")
        if self.delimiter not in (";", ",", "\t") or self.decimal not in (".", ","):
            raise ValueError("Geçersiz ayırıcı veya ondalık işareti.")
        if self.delimiter == self.decimal:
            raise ValueError("Sütun ayırıcı ve ondalık işareti aynı olamaz.")
        if self.chunk_size < 1:
            raise ValueError("Blok boyutu pozitif olmalıdır.")
        if self.x_range is not None:
            lo, hi = self.x_range
            if not (math.isfinite(lo) and math.isfinite(hi) and hi > lo):
                raise ValueError("Geçerli bir dışa aktarma aralığı seçin.")


def export_snapshot(series: dict, style: dict | None = None) -> dict:
    """Freeze metadata; array references are read-only throughout the export."""
    s = dict(series)
    st = style or {}
    meta = dict(s.get("lazy_meta") or {})
    return {
        "key": str(s.get("style_key", "")),
        "name": str(st.get("display_name") or s.get("name") or "Kanal"),
        "file_label": str(s.get("file_label") or ""),
        "unit": str(st.get("unit_override") or s.get("unit") or ""),
        "group": str(s.get("group", meta.get("group", ""))),
        "channel": str(s.get("channel", meta.get("channel", s.get("name", "")))),
        "x_mode": str(s.get("x_mode", "index")),
        "x_base": float(meta.get("x_base", s.get("effective_x_base", s.get("source_x_base", 0.0))) or 0.0),
        "x_inc": float(meta.get("x_inc", s.get("effective_x_inc", s.get("source_x_inc", 1.0))) or 1.0),
        "fs_hz": s.get("fs_est"),
        "fs_source": s.get("effective_fs_source"),
        "n": int(meta.get("n", len(s.get("y", [])))),
        "path": str(meta.get("path") or ""),
        "x": np.asarray(s.get("x", [])),
        "y": np.asarray(s.get("y", [])),
        "x_shift": float(st.get("x_shift", 0.0) or 0.0),
        "y_shift": float(st.get("y_shift", 0.0) or 0.0),
    }


def _numeric(values: np.ndarray, *, sample_offset: int = 0) -> np.ndarray:
    a = np.asarray(values)
    if a.ndim != 1:
        raise ValueError("Kanal verisi tek boyutlu olmalıdır.")
    return numeric_1d(a, sample_offset=sample_offset)


def _cell(value, decimal: str = ".") -> str:
    # str(np.integer) is exact even for uint64 values above 2**53.
    if isinstance(value, (bool, np.bool_)):
        return "1" if value else "0"
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    number = float(value)
    if math.isnan(number):
        return "NaN"
    if math.isinf(number):
        return "Inf" if number > 0 else "-Inf"
    return repr(number).replace(".", decimal)


def _text(value: str) -> str:
    """Protect user-supplied names from spreadsheet formula interpretation."""
    value = str(value)
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value


class _Channel:
    def __init__(self, source: dict, tdms, options: ExportOptions):
        self.s, self.options = dict(source), options
        self.ch = tdms[source["group"]][source["channel"]] if tdms is not None else None
        self.n = int(source["n"])
        if self.n < 0:
            raise ValueError("Geçersiz örnek sayısı.")
        if self.ch is not None:
            if len(self.ch) != self.n:
                raise ValueError(f"{source['name']}: kaynak dosyanın örnek sayısı değişmiş; yeniden açın.")
        else:
            self.s["y"] = _numeric(source["y"])
            if len(source["x"]) != self.n or len(source["y"]) != self.n:
                raise ValueError(f"{source['name']}: X/Y uzunlukları uyuşmuyor.")
        self.start, self.stop = 0, self.n
        # Range selection always uses displayed coordinates, even when output
        # values themselves are requested without display offsets.
        if options.x_range is not None:
            lo, hi = options.x_range
            # Range selection follows displayed coordinates, regardless of the
            # independent choice of original/aligned output timestamps.
            range_shift = source['x_shift'] + float(source.get('alignment_offset', 0.) or 0.)
            if self.ch is not None:
                base = source["x_base"] if source["x_mode"] != "index" else 0.0
                inc = source["x_inc"] if source["x_mode"] != "index" else 1.0
                if not (math.isfinite(base) and math.isfinite(inc) and inc > 0):
                    raise ValueError("Geçersiz zaman metadata'sı.")
                # Binary search uses the very same float operations as x output,
                # so inclusive endpoints agree for large UTC epoch timestamps.
                def search(bound, right):
                    a, b = 0, self.n
                    while a < b:
                        mid = (a + b) // 2
                        x = (base + mid * inc) + range_shift
                        if x < bound or (right and x == bound):
                            a = mid + 1
                        else:
                            b = mid
                    return a
                self.start, self.stop = search(lo, False), search(hi, True)
            else:
                x = np.asarray(source["x"], dtype=np.float64) + range_shift
                if not np.all(np.isfinite(x)) or np.any(np.diff(x) < 0):
                    raise ValueError("Aralık aktarımı için artan, sonlu bir X ekseni gerekli.")
                self.start = int(np.searchsorted(x, lo, side="left"))
                self.stop = int(np.searchsorted(x, hi, side="right"))
        self.count = max(0, self.stop - self.start)

    def block(self, start, stop):
        a, b = self.start + start, min(self.stop, self.start + stop)
        if a >= b:
            return np.array([], dtype=np.int64), np.array([]), np.array([])
        idx = np.arange(a, b, dtype=np.int64)
        if self.ch is not None:
            y = _numeric(self.ch.read_data(offset=a, length=b-a), sample_offset=a)
            if len(y) != b-a:
                raise IOError(f"{self.s['name']}: istenen örnekler okunamadı.")
            x = idx if self.s["x_mode"] == "index" else self.s["x_base"] + idx * self.s["x_inc"]
        else:
            x, y = self.s["x"][a:b], self.s["y"][a:b]
        if self.options.apply_shifts:
            if self.s["x_shift"]:
                x = x + self.s["x_shift"]
            if self.s["y_shift"]:
                y = y + self.s["y_shift"]
        if self.options.export_aligned and self.s.get('alignment_offset'):
            x = x + self.s['alignment_offset']
        return idx, x, y


def read_source_xy(source: dict, cancelled: Callable[[], bool] = lambda: False):
    """Read full-resolution analysis arrays; propagate I/O errors explicitly."""
    if not source["path"]:
        y = _numeric(source["y"])
        if len(source["x"]) != len(source["y"]):
            raise ValueError("X/Y uzunlukları uyuşmuyor.")
        return source["x"], y
    with open_tdms(source["path"]) as tdms:
        channel = _Channel(source, tdms, ExportOptions())
        x_all = np.empty(channel.count, dtype=np.float64)
        y_all = None
        for start in range(0, channel.count, 262_144):
            if cancelled():
                raise ExportCancelled()
            _, x, y = channel.block(start, start+262_144)
            if y_all is None:
                y_all = np.empty(channel.count, dtype=y.dtype)
            x_all[start:start+len(x)] = x
            y_all[start:start+len(y)] = y
        return x_all, y_all if y_all is not None else np.array([])


def write_csv(path: str, sources: list[dict], options: ExportOptions = ExportOptions(),
              cancelled: Callable[[], bool] = lambda: False,
              progress: Callable[[int], None] = lambda percent: None) -> dict:
    if not sources:
        raise ValueError("En az bir kanal seçin.")
    destination = Path(path).expanduser().absolute()
    if any(s.get("path") and os.path.normcase(os.path.realpath(s["path"])) ==
           os.path.normcase(os.path.realpath(destination)) for s in sources):
        raise ValueError("CSV hedefi kaynak TDMS dosyası olamaz.")
    tmp = None
    def check():
        if cancelled():
            raise ExportCancelled()
    try:
        check()
        with ExitStack() as stack:
            handles = {p: stack.enter_context(open_tdms(p)) for p in dict.fromkeys(s["path"] for s in sources if s["path"])}
            channels = [_Channel(s, handles.get(s["path"]), options) for s in sources]
            total = sum(c.count for c in channels)
            if not total:
                raise ValueError("Seçilen aralıkta aktarılacak örnek yok.")
            counts = [c.count for c in channels]
            fd, tmp = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent)
            with os.fdopen(fd, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f, delimiter=options.delimiter)
                labels = []
                for i, s in enumerate(sources, 1):
                    # A stable ordinal guarantees unique headers for identical
                    # basenames/group names/display aliases across open files.
                    label = f"C{i} | " + " / ".join(v for v in [s["file_label"], s["group"], s["name"]] if v)
                    labels.append(_text(label))
                units = {"index": "index", "seconds": "s", "datetime": "Unix s UTC"}
                if options.layout == "wide":
                    header = []
                    for label, s in zip(labels, sources):
                        header += [f"{label} | X [{units.get(s['x_mode'], s['x_mode'])}]",
                                   f"{label} | Y" + (f" [{s['unit']}]" if s["unit"] else "")]
                    writer.writerow(header)
                    rows = max(counts)
                    for start in range(0, rows, options.chunk_size):
                        check()
                        stop = min(rows, start + options.chunk_size)
                        blocks = [c.block(start, stop) for c in channels]
                        for j in range(stop-start):
                            if j % 1024 == 0:
                                check()
                            row = []
                            for _, x, y in blocks:
                                row.extend((_cell(x[j], options.decimal), _cell(y[j], options.decimal)) if j < len(y) else ("", ""))
                            writer.writerow(row)
                        progress(min(99, int(100 * stop / rows)))
                else:
                    writer.writerow(["channel_id", "file", "group", "channel", "unit", "sample_index", "x_mode", "x", "y"])
                    done = 0
                    rows = total
                    for i, c in enumerate(channels, 1):
                        s = c.s
                        prefix = [f"C{i}", _text(s["file_label"]), _text(s["group"]), _text(s["name"]), _text(s["unit"])]
                        for start in range(0, c.count, options.chunk_size):
                            check()
                            idx, x, y = c.block(start, start+options.chunk_size)
                            for j in range(len(y)):
                                if j % 1024 == 0:
                                    check()
                                writer.writerow(prefix + [str(idx[j]), s["x_mode"], _cell(x[j], options.decimal), _cell(y[j], options.decimal)])
                            done += len(y)
                            progress(min(99, int(100 * done / total)))
                f.flush()
                os.fsync(f.fileno())
            check()
        os.replace(tmp, destination)
        tmp = None
        progress(100)
        return {"path": str(destination), "channels": len(channels), "samples": total,
                "rows": rows, "counts": counts, "layout": options.layout}
    finally:
        if tmp is not None:
            try:
                os.unlink(tmp)
            except FileNotFoundError:
                pass
