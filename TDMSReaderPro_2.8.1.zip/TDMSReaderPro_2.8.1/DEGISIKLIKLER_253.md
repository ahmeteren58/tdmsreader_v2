# TDMSReader Pro 2.5.3 — Büyük veri, donma düzeltmesi ve vana analizi

## İncelemede bulunan sorunlar

| Sorun | Neden | Düzeltme |
| --- | --- | --- |
| Grafik alanında zaman zaman **kalıcı donma** | Arka plan işleri `QThread` + `moveToThread` + `deleteLater` ile çalışıyordu. Python'a ait worker, biten QThread içinde yok ediliyordu. Orada sip GIL'i isterken Qt bağlantı kilidini tutuyordu. Arayüz tam o anda yeni iş başlatırsa (yakınlaştırma/kaydırmada sık olur) iki iş parçacığı birbirini sonsuza kadar bekliyordu. 2.5.2 test paketinde ve küçük bir örnekte gdb ile doğrulandı. | Yeni `tdms_jobs.JobThread`: işler Python iş parçacığında çalışır. Worker arayüz iş parçacığında kalır ve orada yok edilir; bitiş sinyali kuyrukla iletilir. Regresyon testi `tests/test_jobs_253.py`, 2.5.2 kodunda 8 çalıştırmanın 1'inde donmayı yakaladı; 2.5.3'te 30/30 geçti. |
| Büyük dosyaların **geç açılması** ve yavaş yakınlaştırma | npTDMS `read_data(offset, length)` isteneni değil bütün veri parçasını okuyup kırpıyordu. Tek seferde yazılmış kayıtlarda her önizleme bloğu tüm kanalı yeniden okuyordu. | Yeni `tdms_io.py`, düz sayısal düzenlerde yalnız istenen baytları okur: bitişik, iç içe, çok parçalı, ölçekli ve kesik bitişik düzenler. Diğer düzenlerde dosya başına kilitle npTDMS'ye döner. Metadata; boyut, değişiklik zamanı veya inode değişene kadar tekrar kullanılır. Son okuyucu çıkınca işletim sistemi tutamacı kapanır. Export, vana, veri kalitesi ve proje okumaları da aynı oturumları kullanır. |
| Çizimde takılma | Eğri başına 80.000 noktaya kadar çiziliyordu; her imleç hareketi, kaydırma ve yakınlaştırmada tümü yeniden çiziliyordu. Qt kalın kalemi yaklaşık 5 kat yavaş çizer. | Nokta bütçesi grafik genişliğine bağlandı: piksel başına 4 nokta, en az 4.000. Min/max önizleme pikleri ve kenarları korur. Yeni eğrilerde varsayılan kalem 1 px'tir; kullanıcı kalınlıkları korunur. Görünüm okuması artık milisaniyeler sürdüğü için yakınlaştırma sonrası bekleme 180 ms'den 110 ms'ye indi. |
| Açılışta gecikme | `scipy.signal` başlangıçta yükleniyordu (~0,45 s). | İlk SG filtresi isteğinde yüklenir. PyInstaller için `hiddenimports` listesine eklendi. |
| Kapatılan dosyanın metadata'sı bellekte kalıyordu | Havuz, dosyanın son sekmesi kapanınca temizlenmiyordu. | Son sekme kapanınca bırakılır. |
| Vana: kontak sıçraması kapanmayı **erken** bitirebiliyordu | Bitiş kanalındaki bir örneklik sıçrama olayı erken tamamlıyordu; kalan kenarlar hiçbir olaya ait olmuyordu. Durum "Tamamlandı" göründüğü için fark edilmesi zordu. | Otomatik parazit filtresi. Aday değerlendirmesinde hiçbir olayın açıklamadığı kenarlar da ceza olarak sayılır. |
| Vana: varsayılan eski kural iki konum sensöründe kapanmayı ters sırada arıyordu | 2.4.1'den beri doğru modlar vardı, ancak varsayılan hâlâ eski kuraldı. Filtre saniye biriminde ve 0'dı; eşikler 0,3/0,7 idi ve elle denenmesi gerekiyordu. | Varsayılan **İki konum sensörü**. Otomatik giriş ayarı, sade üç adımlı arayüz ve ms biriminde filtre. |
| Testlerde nadir "Background work did not finish" | Test yardımcısının son `processEvents()` çağrısı, gecikmeli görünüm okumasını başlatıp hemen boş kuyruk bekliyordu. Uygulamada hata yoktu; iş normal bitiyordu. | `wait_jobs`, işler bittikten sonra bir olay turunda yeni iş başlamadığını da kontrol eder. 25 tekrarda 5 hatadan 0 hataya indi. |

| 2 × 20 milyon örnek, tek segment | 2.5.2 | 2.5.3 |
| --- | --- | --- |
| Seçili kanalları çiz | 29,7 s | 0,46 s |
| Aralığın %50'sine yakınlaş | 6,0 s | 0,22 s |
| Tam yeniden çizim | 46,8 ms | 10,3 ms |
| `import tdmsreader` | 0,62 s | 0,17 s |

Ölçümler bu Linux ortamında, offscreen Qt ile alındı. Windows'ta sabit bir hızlanma oranı iddia edilmiyor; oran disk, CPU ve dosya düzenine bağlıdır.

## Vana Analizi: yeni akış

1. **Bağlantı ve kanallar:**
   - Bağlantı türü sade adla seçilir ("İki konum sensörü (açık + kapalı)", "Açma komutu + kapalı konum sensörü" vb.). Açılma/kapanma kuralı altında düz cümleyle yazılır.
   - Kanal satırları rolü söyler.
   - Aktif seviye (Normal / Ters) her kanalın yanındadır; **⇅ A ↔ B** kanalları ve kanal ayarlarını değiştirir.
   - Otomatik ayar kutusu varsayılan olarak açıktır.
2. **Sonuç:**
   - Açılma ve kapanma kartları: ortalama, min/maks, σ, n ve elle doğrulanan sayısı.
   - Kontrol edilecek olay kartı ve **Sonrakini göster ›** düğmesi.
   - Kullanılan ayarların tek satırlık özeti.
   - Uyarı/öneri kutusu ve **Öneriyi uygula ve yeniden hesapla** düğmesi.
3. **Olaylar ve elle doğrulama:** Tablo, tanı grafikleri ve onay/red akışı korunur. Olay adları "Açılma 1, Kapanma 1…" biçimindedir; sorunlu durumlar renklidir. Kartlar her doğrulamada güncellenir.

Giriş türü, eşikler, parazit filtresi (ms) ve azami bekleme **Gelişmiş ayarlar** altındadır. Otomatik ayar açıkken bulunan değerler bu alanlara yazılır. Değerlerden biri değiştirilirse otomatik ayar kapanır ve değerler girildiği gibi kullanılır. Bağlantı türü ve otomatik ayar tercihi uygulama ayarlarında saklanır.

## Otomatik ayar: kararlar

- **Belirlenenler:** giriş türü, seviyeler/eşikler (%30/%70) ve parazit filtresi. Seviyeler beşer örneklik blok medyanlarından bulunur; bir-iki örneklik sıçramalar seviyeyi kaydırmaz.
- **Belirlenmeyenler:** bağlantı türü, kanal rolleri ve aktif seviye. Ters polarite ile yanlış bir bağlantı türü, kenarları kusursuz eşleyip açılma ile kapanmayı yer değiştirebilir. Örneğin eski kural, ters bağlanmış iki konum sensörü kaydını temiz eşler ama kapanmayı açılma olarak etiketler. Bu yüzden alternatifler yalnız **öneri** olarak gösterilir. Önerinin ilk olayın yönünü ve kayıt başındaki vana konumunu yazması, kullanıcının öneriyi bilinen test düzeniyle karşılaştırmasını sağlar.
- **Filtre seçimi:**
  - Adaylar: 0 (filtresiz) ile 2–64 örnek arası.
  - Puan: tamamlanan − sorunlu − açıklanamayan kenar.
  - Eşit puanda en kısa filtre seçilir.
  - Filtre, ölçülen en kısa sürenin %20'sini aşamaz; 12 ms'lik gerçek bir komut darbesi elenmez, "Başlatan sinyal geri döndü" olarak raporlanır.
  - Filtre süresi 0,1 µs çözünürlüğe aşağı yuvarlanır, böylece arayüzde gösterilen değer aynı durumları seçer.
- **Tek tarama:** Her kanal bir kez okunur. Filtre ve polarite adayları bellekteki geçiş listesi üzerinde değerlendirilir. Öneri araması geçiş bütçesiyle sınırlıdır. Paketteki örnek dosyalarda otomatik ayar 20 ms'nin altında sürer.
- **Zaman hesabı değişmedi:** `analyze_valve` tarama/eşleştirme adımlarına ayrıldı, sonuçlar aynı. Otomatik ayarın sonucu, aynı ayarlarla yapılan elle analizle birebir aynıdır.

## Doğruluk kontrolü

`tests/test_valve_253.py` gerçek kenar zamanları bilinen sürekli bir vana modeli kullanır: komut, kapalıdan ayrılma, açığa varma… Model farklı örnekleme hızlarında örneklenir. Her raporlanan süre için şunlar kontrol edilir:

- `alt sınır ≤ gerçek süre ≤ üst sınır`,
- `|hesaplanan − gerçek| < bir örnek aralığı`.

Kapsam:

- üç bağlantı türü × üç Fs çifti (1000/1000, 5000/1000, 200/2000 Hz) × üç giriş (0/1, gürültülü 0–24 V, gürültülü 4–20),
- ters aktif seviye,
- yanlış bağlantı türü ve yer değişmiş kanallar için öneri,
- rastgele parazitler,
- kontak sıçramasında kararlı varış zamanı,
- gerçek kısa darbe,
- diskten okunan TDMS kaynağı,
- seviye bulma uç durumları (sıçrama, nadir seviye, sabit sinyal, yalnız sıçrama),
- filtre süresinin 5 Hz – 142,857 kHz aralığında ve Unix epoch zamanlarında k örneği kabul edip k−1'i elemesi,
- arayüz akışı.

## Uyumluluk

- `ValveOptions` API'si ve varsayılanları değişmedi; Python API'sinde varsayılan mod hâlâ `legacy`dir. Yalnız arayüzün varsayılanı değişti.
- CSV sütunları aynı.
- `.tdmsproj` biçimi değişmedi; vana sonuçları yine projede saklanmaz.
- `examples/vana_5hz.tdms` için **Eski kural (2.4.0 uyumlu)** seçin. Varsayılan türde iki kanalı ters çevirme önerisi çıkar ve bu öneri vanayı kayıt başında açık varsayar; bu örnekte uygulanmamalıdır.

Değişiklikler kaynak pakettir; ZIP'i tamamen yeni klasöre çıkarın. Windows EXE için `TDMSReaderPro.spec` ile yeniden derleyin (yeni modüller otomatik bulunur). Doğrulama: `TEST_253.txt`. Gerçek cihaz kaydı ve Windows EXE bu ortamda denenmedi.
