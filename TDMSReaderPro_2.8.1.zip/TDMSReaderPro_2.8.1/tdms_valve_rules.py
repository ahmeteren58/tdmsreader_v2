"""Explicit signal conditioning and valve measurement definitions."""
from dataclasses import dataclass, field
import math


@dataclass(frozen=True)
class SignalOptions:
    input_mode: str = 'binary'
    active_low: bool = False
    min_hold_s: float | None = None
    low_threshold: float = .3
    high_threshold: float = .7

    def __post_init__(self):
        if self.input_mode not in ('binary', 'hysteresis'):
            raise ValueError('Giriş türü 0/1 veya histerezis olmalı.')
        if self.min_hold_s is not None and (not math.isfinite(self.min_hold_s) or self.min_hold_s < 0):
            raise ValueError('Kararlılık süresi sonlu ve negatif olmayan bir sayı olmalı.')
        if self.input_mode == 'hysteresis' and not (
                math.isfinite(self.low_threshold) and math.isfinite(self.high_threshold)
                and self.low_threshold < self.high_threshold):
            raise ValueError('Histerezis için sonlu alt eşik < üst eşik olmalı.')


@dataclass(frozen=True)
class EdgeRule:
    direction: str
    start_channel: int
    start_edge: str
    end_channel: int
    end_edge: str

    @property
    def expected_end_state(self):
        return 0 if self.end_edge == 'rise' else 1

    @property
    def cancel_edge(self):
        return 'fall' if self.start_edge == 'rise' else 'rise'

    def description(self):
        arrow = {'rise': '0→1', 'fall': '1→0'}
        return f"{'AB'[self.start_channel]} {arrow[self.start_edge]} → {'AB'[self.end_channel]} {arrow[self.end_edge]}"


MODES = {
    'position': ('İki konum sensörü (açık + kapalı)',
                 'Açılma: kapalı sensörü bırakır (B 1→0) → açık sensörü algılar (A 0→1). '
                 'Kapanma: açık sensörü bırakır (A 1→0) → kapalı sensörü algılar (B 0→1). '
                 'Konumlar arası hareket süresidir; komut gecikmesini içermez.'),
    'command_closed': ('Açma komutu + kapalı konum sensörü',
                       'Açılma: komut verilir (A 0→1) → kapalı konumdan ayrılır (B 1→0); bu ayrılma gecikmesidir, tam açılma değildir. '
                       'Kapanma: komut kesilir (A 1→0) → kapalı konuma varır (B 0→1).'),
    'command_open': ('Açma komutu + açık konum sensörü',
                     'Açılma: komut verilir (A 0→1) → açık konuma varır (B 0→1). '
                     'Kapanma: komut kesilir (A 1→0) → açık konumdan ayrılır (B 1→0); bu ayrılma gecikmesidir, tam kapanma değildir.'),
    'legacy': ('Eski kural (2.4.0 uyumlu)',
               'A = Açık, B = Kapalı sinyali. Açılma: A 0→1 → B 1→0. Kapanma: B 0→1 → A 1→0. '
               'İki sinyalin 1 olduğu aralığı ölçer; yalnız eski sonuçlarla karşılaştırma için.'),
    'custom': ('Özel kenar eşleştirme',
               'Açılma ve kapanmanın başlangıç/bitiş kanallarını ve kenarlarını aşağıda seçin.'),
}

ROLES = {
    'position': ('Açık konum sensörü', 'Kapalı konum sensörü'),
    'command_closed': ('Açma komutu', 'Kapalı konum sensörü'),
    'command_open': ('Açma komutu', 'Açık konum sensörü'),
    'legacy': ('Açık sinyali', 'Kapalı sinyali'),
    'custom': ('A kanalı', 'B kanalı'),
}


@dataclass(frozen=True)
class ValveOptions:
    # First five fields retain the 2.4.0 positional API.
    min_hold_s: float = 0.0
    max_wait_s: float = 0.0
    chunk_size: int = 262144
    max_transitions: int = 200000
    max_events: int = 20000
    mode: str = 'legacy'
    signals: tuple[SignalOptions, SignalOptions] = field(default_factory=lambda: (SignalOptions(), SignalOptions()))
    opening_rule: tuple = (0, 'rise', 1, 'fall')
    closing_rule: tuple = (1, 'rise', 0, 'fall')
    rise_hold_s: float = 0.0

    def __post_init__(self):
        if not math.isfinite(self.rise_hold_s) or self.rise_hold_s < 0:
            raise ValueError('0→1 doğrulama süresi sonlu ve negatif olmayan bir sayı olmalı.')
        if any(not math.isfinite(v) or v < 0 for v in (self.min_hold_s, self.max_wait_s)):
            raise ValueError('Kararlılık ve azami bekleme süreleri sonlu ve negatif olmayan sayılar olmalı.')
        if any(type(v) is not int or v < 1 for v in (self.chunk_size, self.max_transitions, self.max_events)):
            raise ValueError('Analiz sınırları pozitif tamsayı olmalı.')
        if self.mode not in MODES:
            raise ValueError('Bilinmeyen vana ölçüm modu.')
        if len(self.signals) != 2 or not all(isinstance(s, SignalOptions) for s in self.signals):
            raise ValueError('İki kanalın giriş ayarları gerekli.')
        for r in ((self.opening_rule, self.closing_rule) if self.mode == 'custom' else ()):
            if (len(r) != 4 or r[0] not in (0, 1) or r[2] not in (0, 1)
                    or r[0] == r[2] or r[1] not in ('rise', 'fall') or r[3] not in ('rise', 'fall')):
                raise ValueError('Her kural iki farklı kanal ve geçerli kenarlar içermeli.')
        if self.mode == 'custom' and self.opening_rule == self.closing_rule:
            raise ValueError('Açılma ve kapanma kuralları aynı olamaz.')

    def hold(self, channel):
        value = self.signals[channel].min_hold_s
        return self.min_hold_s if value is None else value

    def rules(self):
        presets = {
            'legacy': ((0, 'rise', 1, 'fall'), (1, 'rise', 0, 'fall')),
            'position': ((1, 'fall', 0, 'rise'), (0, 'fall', 1, 'rise')),
            'command_closed': ((0, 'rise', 1, 'fall'), (0, 'fall', 1, 'rise')),
            'command_open': ((0, 'rise', 1, 'rise'), (0, 'fall', 1, 'fall')),
            'custom': (self.opening_rule, self.closing_rule),
        }
        return tuple(EdgeRule(d, *r) for d, r in zip(('opening', 'closing'), presets[self.mode]))
