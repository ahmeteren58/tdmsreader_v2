"""Reviewable steady-flow / pressure-loss tab, independent of main rendering."""
from __future__ import annotations

from datetime import datetime, timezone
from html import escape
import math
import re

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import Qt, QSignalBlocker
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QDoubleSpinBox, QTreeWidget, QTreeWidgetItem, QHeaderView, QComboBox,
    QScrollArea, QFrame, QGroupBox, QCheckBox, QToolButton, QFileDialog,
    QSizePolicy, QMessageBox,
)

from tdms_export import export_snapshot
from tdms_steady import (
    SteadyOptions, PRESSURE_FACTORS, ROLES, ROLE_NAMES, pressure_unit,
    analyze_steady, measure_steady, write_steady_report,
)
from tdms_workspace import FunctionWorker, disable_native_menus, show_plot_menu


def _num(value):
    return '—' if value is None else f'{value:.7g}'


def suggest_roles(sources):
    """Only unambiguous names are suggestions; never infer roles from values."""
    patterns = {
        'pin': r'\b(pin|p_in|p1|p_1|inlet|upstream|giris)\b',
        'pout': r'\b(pout|p_out|p2|p_2|outlet|downstream|cikis)\b',
        'flow': r'\b(flow|flowrate|debi|mdot|m_dot|massflow|q)\b',
    }
    found = {}
    for role, pattern in patterns.items():
        matches = []
        for s in sources:
            name = str(s.get('name', '')).lower().translate(str.maketrans('ışğüöç', 'isguoc'))
            name = re.sub(r'[^a-z0-9_]+', ' ', name)
            if re.search(pattern, name):
                matches.append(s['key'])
        if len(matches) == 1:
            found[role] = matches[0]
    # A label containing both inlet and outlet is not a usable mapping.
    return {r: k for r, k in found.items() if list(found.values()).count(k) == 1}


class SteadyFlowMixin:
    def _init_steady(self):
        self._steady_result = None
        self._steady_manual = None
        self._steady_selected = None
        self._steady_signature = None
        self._steady_unit_metadata = {}
        self._steady_token = 0
        self._steady_measure_token = 0
        self._steady_origin = 0.
        self._steady_updating = False
        self._steady_curves = []
        self.steady_tab = QScrollArea()
        self.steady_tab.setWidgetResizable(True)
        self.steady_tab.setFrameShape(QScrollArea.Shape.NoFrame)
        content = QWidget(); self.steady_tab.setWidget(content)
        root = QVBoxLayout(content); root.setContentsMargins(14, 12, 14, 12); root.setSpacing(9)
        title = QLabel('Kararlı akış ve basınç kaybı')
        title.setStyleSheet('font-size: 17px; font-weight: 700;'); root.addWidget(title)
        hint = QLabel('1. Kanalları ve birimleri seçin.  2. Ortak kararlı aralıkları bulun.  '
                      '3. Aralığı grafikte kontrol edin; gerekirse sınırları değiştirip yeniden hesaplayın.')
        hint.setWordWrap(True); hint.setProperty('valveHint', True); root.addWidget(hint)

        # Configure first, then give the plots and measurements the available
        # space. Settings stay one click away after an analysis succeeds.
        page = root
        self.steady_setup_toggle = QToolButton(); self.steady_setup_toggle.setCheckable(True)
        self.steady_setup_toggle.setChecked(True); self.steady_setup_toggle.setText('Kanallar ve analiz ayarları ▾')
        page.addWidget(self.steady_setup_toggle, 0, Qt.AlignmentFlag.AlignLeft)
        self.steady_setup = QWidget(); root = QVBoxLayout(self.steady_setup)
        root.setContentsMargins(0, 0, 0, 0); root.setSpacing(8); page.addWidget(self.steady_setup)
        self.steady_setup_toggle.toggled.connect(self._steady_toggle_setup)

        group = QGroupBox('Kanal eşleştirme'); grid = QGridLayout(group)
        self.steady_channels = {}; self.steady_units = {}
        for i, role in enumerate(ROLES):
            grid.addWidget(QLabel(ROLE_NAMES[role]+(' (isteğe bağlı)' if role=='flow' else '')), i, 0)
            combo = QComboBox(); combo.setMinimumWidth(240)
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            combo.setMinimumContentsLength(20); self.steady_channels[role] = combo
            grid.addWidget(combo, i, 1)
            if role != 'flow':
                units = QComboBox(); units.addItem('Birim seçin…', None)
                for unit in PRESSURE_FACTORS:
                    units.addItem(unit, unit)
                self.steady_units[role] = units
                units.setToolTip('Kanal değerlerinin mevcut fiziksel birimi. Sonuçlar bar olarak gösterilir. '
                                 'İki basınç aynı referansta olmalı (ikisi de mutlak veya ikisi de manometrik).')
                grid.addWidget(units, i, 2)
                units.currentIndexChanged.connect(self._steady_config_changed)
            else:
                self.steady_flow_unit = QLabel('Kaynak birimi'); grid.addWidget(self.steady_flow_unit, i, 2)
            combo.currentIndexChanged.connect(lambda _, role=role: self._steady_channel_changed(role))
        grid.setColumnStretch(1, 1)
        self.steady_suggest = QPushButton('Kanal adlarından öner')
        self.steady_suggest.setToolTip('Pin / Pout / Debi gibi belirgin ve tekil kanal adlarını eşleştirir. Rollerini kontrol edin.')
        self.steady_suggest.clicked.connect(self._steady_suggest_channels)
        grid.addWidget(self.steady_suggest, 3, 0)
        note = QLabel('Basınçlar aynı referansta olmalı. Debi seçimi, akış olmayan bekleme bölümlerini elemek için önerilir.')
        note.setWordWrap(True); note.setProperty('valveHint', True); grid.addWidget(note, 3, 1, 1, 2)
        root.addWidget(group)

        row = QHBoxLayout()
        self.steady_window = self._steady_spin(.01, 3600., 1., ' s', 3)
        self.steady_min = self._steady_spin(.01, 86400., 3., ' s', 3)
        self.steady_window.setToolTip('Her pencerenin tüm özgün örnekleri değerlendirilir. '
                                      'En az üç örnek/pencere gerekir; düşük Fs için pencereyi büyütün.')
        self.steady_min.setToolTip('Bir sonuç için tüm seçili kanalların birlikte kararlı kaldığı asgari süre.')
        self.steady_preset = QComboBox(); self.steady_preset.addItems(['Sıkı', 'Standart', 'Esnek', 'Özel']); self.steady_preset.setCurrentIndex(1)
        for label, widget in (('Pencere:', self.steady_window), ('Asgari süre:', self.steady_min), ('Tolerans:', self.steady_preset)):
            row.addWidget(QLabel(label)); row.addWidget(widget)
        self.steady_advanced_toggle = QToolButton(); self.steady_advanced_toggle.setText('Gelişmiş ayarlar ▸')
        self.steady_advanced_toggle.setCheckable(True); row.addWidget(self.steady_advanced_toggle); row.addStretch()
        root.addLayout(row)
        self.steady_advanced = QGroupBox('Kararlılık ölçütleri'); adv = QGridLayout(self.steady_advanced)
        self.steady_noise = self._steady_spin(.001, 100., .5, ' %', 3)
        self.steady_drift = self._steady_spin(.001, 100., 1., ' %', 3)
        self.steady_pfloor = self._steady_spin(0., 1e6, .005, ' bar', 6)
        self.steady_dpfloor = self._steady_spin(0., 1e6, .005, ' bar', 6)
        self.steady_qfloor = self._steady_spin(0., 1e12, 0., '', 6)
        self.steady_threshold = self._steady_spin(0., 1e12, 0., '', 6)
        self.steady_auto_flow = QCheckBox('Otomatik aktif debi eşiği'); self.steady_auto_flow.setChecked(True)
        self.steady_auto_flow.setToolTip('Eşik = pencere |debi ortalamaları| 95. yüzdeliğinin %5’i. '
                                       'Akışlı pencerede |ortalama debi| bu eşiğin üstünde olmalı.')
        self.steady_threshold.setEnabled(False)
        fields = [('Azami σ / seviye:', self.steady_noise), ('Azami sürüklenme:', self.steady_drift),
                  ('Basınç mutlak toleransı:', self.steady_pfloor), ('Δp mutlak toleransı:', self.steady_dpfloor),
                  ('Debi mutlak toleransı:', self.steady_qfloor), ('Asgari |debi|:', self.steady_threshold)]
        for i, (label, widget) in enumerate(fields):
            adv.addWidget(QLabel(label), i//2, (i%2)*2); adv.addWidget(widget, i//2, (i%2)*2+1)
        adv.addWidget(self.steady_auto_flow, 3, 0, 1, 4)
        explanation = QLabel('Tolerans = büyük olanı: mutlak değer veya ortalama seviyenin yüzdesi. '
                             'σ, pencere içindeki dalgalanmayı; sürüklenme, eğimi ve aralık boyunca pencere '
                             'ortalamalarının değişimini sınırlar. Δp değişimi ayrıca kontrol edilir.')
        explanation.setWordWrap(True); explanation.setProperty('valveHint', True); adv.addWidget(explanation, 4, 0, 1, 4)
        root.addWidget(self.steady_advanced); self.steady_advanced.hide()
        self.steady_advanced_toggle.toggled.connect(self._steady_toggle_advanced)
        self.steady_preset.currentIndexChanged.connect(self._steady_preset_changed)
        for box in (self.steady_window, self.steady_min, self.steady_noise, self.steady_drift,
                    self.steady_pfloor, self.steady_dpfloor, self.steady_qfloor, self.steady_threshold):
            box.valueChanged.connect(self._steady_config_changed)
        self.steady_auto_flow.toggled.connect(self._steady_flow_mode_changed)

        row = QHBoxLayout()
        self.steady_limit = QCheckBox('Aramayı zaman aralığıyla sınırla')
        self.steady_search_a = self._steady_spin(0., 1e12, 0., ' s', 6)
        self.steady_search_b = self._steady_spin(0., 1e12, 0., ' s', 6)
        for w in (self.steady_search_a, self.steady_search_b):
            w.setEnabled(False); w.valueChanged.connect(self._steady_config_changed)
        self.steady_limit.toggled.connect(self._steady_search_mode_changed)
        row.addWidget(self.steady_limit); row.addWidget(self.steady_search_a); row.addWidget(QLabel('—')); row.addWidget(self.steady_search_b)
        row.addStretch(); root.addLayout(row)
        root = page
        row = QHBoxLayout()
        self.steady_run = QPushButton('Kararlı Aralıkları Bul'); self.steady_run.setProperty('primary', True)
        self.steady_stop = QPushButton('Durdur'); self.steady_stop.setEnabled(False)
        self.steady_csv = QPushButton('Sonuçları CSV’ye Aktar'); self.steady_csv.setEnabled(False)
        self.steady_run.clicked.connect(self._steady_analyze)
        self.steady_stop.clicked.connect(lambda: self._steady_reset('Analiz durduruldu.'))
        self.steady_csv.clicked.connect(self._steady_export)
        for w in (self.steady_run, self.steady_stop, self.steady_csv):
            row.addWidget(w)
        self.steady_summary = QLabel('Önce basınç kanallarını ana grafikte çizin.'); self.steady_summary.setWordWrap(True)
        row.addWidget(self.steady_summary, 1); root.addLayout(row)
        self.steady_used = QLabel(); self.steady_used.setWordWrap(True); self.steady_used.setProperty('valveHint', True)
        self.steady_used.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); root.addWidget(self.steady_used)

        self.steady_cards = {}; row = QHBoxLayout()
        for role, caption in (('pin', 'Giriş basıncı · ortalama'), ('pout', 'Çıkış basıncı · ortalama'),
                              ('dp', 'Basınç kaybı · Δp'), ('flow', 'Debi · ortalama')):
            frame = QFrame(); frame.setObjectName('valveCard'); layout = QVBoxLayout(frame)
            label = QLabel(caption); label.setProperty('valveCardTitle', True)
            value = QLabel('—'); value.setProperty('valveCardValue', True)
            detail = QLabel(); detail.setWordWrap(True); detail.setProperty('valveCardDetail', True)
            for w in (label, value, detail):
                layout.addWidget(w)
            self.steady_cards[role] = (frame, value, detail); row.addWidget(frame, 1)
        root.addLayout(row)
        self.steady_tree = QTreeWidget(); self.steady_tree.setRootIsDecorated(False); self.steady_tree.setAlternatingRowColors(True)
        self.steady_tree.setHeaderLabels(['Aralık', 'Başlangıç [s]', 'Bitiş [s]', 'Süre [s]', 'Δp [bar]', 'Ort. debi'])
        self.steady_tree.setFixedHeight(105)
        self.steady_tree.header().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.steady_tree.header().setStretchLastSection(True)
        self.steady_tree.currentItemChanged.connect(self._steady_interval_selected); root.addWidget(self.steady_tree)

        self.steady_canvas = pg.GraphicsLayoutWidget(); self.steady_canvas.setMinimumHeight(280)
        self.steady_canvas.setMaximumHeight(360)
        self.steady_pressure_plot = self.steady_canvas.addPlot(row=0, col=0)
        self.steady_pressure_plot.addLegend(offset=(8, 8))
        self.steady_flow_plot = self.steady_canvas.addPlot(row=1, col=0)
        self.steady_flow_plot.setXLink(self.steady_pressure_plot)
        self.steady_plots = [self.steady_pressure_plot, self.steady_flow_plot]
        self._steady_regions = []
        for i, plot in enumerate(self.steady_plots):
            plot.showGrid(x=True, y=True, alpha=.12); plot.setLabel('bottom', 'Kayıt başlangıcından zaman', units='s')
            plot.getAxis('bottom').enableAutoSIPrefix(False)
            plot.getAxis('left').enableAutoSIPrefix(False)
            plot.setMenuEnabled(False); plot.hideButtons()
            region = pg.LinearRegionItem((0, 1), brush=pg.mkBrush(32, 170, 150, 40), pen=pg.mkPen('#199E8F', width=1.5))
            region.setZValue(-5); region.hide(); plot.addItem(region); self._steady_regions.append(region)
            region.sigRegionChanged.connect(lambda _, i=i: self._steady_region_changed(i))
        self.steady_pressure_plot.setLabel('left', 'Basınç', units='bar')
        disable_native_menus(self.steady_canvas)
        self.steady_canvas.customContextMenuRequested.connect(lambda p: show_plot_menu(self, self.steady_canvas, p, [
            ('Seçili Aralığa Sığdır', self._steady_zoom_selected), ('Tüm Aramayı Göster', self._steady_zoom_all)]))
        root.addWidget(self.steady_canvas)
        row = QHBoxLayout()
        self.steady_a = self._steady_spin(0., 1e12, 0., ' s', 6)
        self.steady_b = self._steady_spin(0., 1e12, 0., ' s', 6)
        for w in (self.steady_a, self.steady_b):
            w.setEnabled(False); w.valueChanged.connect(self._steady_manual_changed)
        self.steady_manual_run = QPushButton('Elle Aralığı Hesapla'); self.steady_manual_run.setEnabled(False)
        self.steady_manual_run.clicked.connect(self._steady_measure)
        self.steady_restore = QPushButton('Seçili Otomatik Aralığa Dön'); self.steady_restore.setEnabled(False)
        self.steady_restore.clicked.connect(self._steady_restore)
        for label, w in (('Başlangıç:', self.steady_a), ('Bitiş:', self.steady_b)):
            row.addWidget(QLabel(label)); row.addWidget(w)
        row.addWidget(self.steady_manual_run); row.addWidget(self.steady_restore); row.addStretch(); root.addLayout(row)
        self.steady_detail = QLabel('Yeşil aralık, hesabın yapıldığı zaman bölümünü gösterir.'); self.steady_detail.setWordWrap(True)
        root.addWidget(self.steady_detail)
        self.steady_stats = QTreeWidget(); self.steady_stats.setRootIsDecorated(False); self.steady_stats.setAlternatingRowColors(True)
        self.steady_stats.setHeaderLabels(['Kanal', 'Birim', 'Ortalama', 'σ', 'Minimum', 'Maksimum', 'Örnek sayısı'])
        self.steady_stats.setMinimumHeight(105); self.steady_stats.setMaximumHeight(140)
        self.steady_stats.header().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.steady_stats.header().setStretchLastSection(True); root.addWidget(self.steady_stats)
        footer = QLabel('Δp = ort(Pgiriş) − ort(Pçıkış). Her ortalama, aynı zaman aralığındaki özgün örneklerle hesaplanır. '
                        'σ veri dalgalanmasıdır; sensör belirsizliği değildir. Çizim kaydırma/yumuşatma uygulanmaz. '
                        'Kalibre edilmemiş voltaj/akım kanallarını önce fiziksel birime dönüştürün. '
                        'Bu sonuçlar projeye kaydedilmez; CSV’ye aktarın.')
        footer.setWordWrap(True); footer.setProperty('valveHint', True); root.addWidget(footer)
        root.addStretch()
        self.tabs.addTab(self.steady_tab, 'Basınç Kaybı')
        self._steady_theme(); self._steady_refresh()

    @staticmethod
    def _steady_spin(lo, hi, value, suffix, decimals):
        box = QDoubleSpinBox(); box.setDecimals(decimals); box.setRange(lo, hi); box.setValue(value)
        box.setSuffix(suffix); box.setKeyboardTracking(False); box.setMinimumWidth(100)
        return box

    def _steady_theme(self):
        if not hasattr(self, 'steady_canvas'):
            return
        dark = self._theme == 'dark'
        self.steady_canvas.setBackground('#181c21' if dark else '#ffffff')
        for plot in self.steady_plots:
            for key in ('left', 'bottom'):
                plot.getAxis(key).setPen('#78828c' if dark else '#6e7882')
                plot.getAxis(key).setTextPen('#d6dce2' if dark else '#262e36')

    def _steady_refresh(self):
        if not hasattr(self, 'steady_channels'):
            return
        candidates = list(self.current_series or [])
        signature = tuple((s['style_key'], s.get('fs_est'), s.get('x_mode'), s.get('effective_x_base'),
                           s.get('sample_count'), s.get('effective_fs_source'), s.get('source_path'), repr(s.get('source_fingerprint')),
                           None if s.get('lazy') else id(s.get('y')),
                           self.style_map.get(s['style_key'], {}).get('display_name'),
                           self.style_map.get(s['style_key'], {}).get('unit_override'), s.get('unit')) for s in candidates)
        if signature == self._steady_signature:
            return
        self._steady_signature = signature
        self._steady_updating = True
        for role, combo in self.steady_channels.items():
            selected = combo.currentData()
            with QSignalBlocker(combo):
                combo.clear(); combo.addItem('Kanal seçin…' if role != 'flow' else 'Debi kullanılmasın', None)
                for s in candidates:
                    style = self.style_map.get(s['style_key'], {})
                    name = style.get('display_name') or s['name']
                    label = ' / '.join(v for v in (s.get('file_label'), s.get('group'), name) if v)
                    unit = style.get('unit_override') or s.get('unit')
                    combo.addItem(label+(f' [{unit}]' if unit else ''), s['style_key'])
                combo.setCurrentIndex(max(0, combo.findData(selected)))
                combo.setToolTip(combo.currentText())
            if role != 'flow':
                self._steady_sync_unit(role)
        self._steady_updating = False
        self._steady_update_origin()
        self._steady_update_flow_unit()
        self._steady_reset('Veri/zaman değişti. Kanalları seçip Kararlı Aralıkları Bul’a basın.' if candidates
                           else 'Önce basınç kanallarını ana grafikte çizin.')

    def _steady_sources(self):
        by_key = {s['style_key']: s for s in self.current_series or []}
        sources = []
        for role in ROLES:
            key = self.steady_channels[role].currentData()
            if key is None and role == 'flow':
                continue
            if key not in by_key:
                raise ValueError('Giriş ve çıkış basıncı kanallarını seçin.')
            s = by_key[key]; style = self.style_map.get(key, {})
            snap = export_snapshot(s, {'display_name': style.get('display_name'), 'unit_override': style.get('unit_override')})
            snap.update(role=role, source_path=s.get('source_path'), source_fingerprint=s.get('source_fingerprint'))
            if role != 'flow':
                snap['pressure_unit'] = self.steady_units[role].currentData()
            sources.append(snap)
        return sources

    def _steady_update_origin(self):
        try:
            sources = self._steady_sources(); ends = []
            for s in sources:
                if s['x_mode'] not in ('seconds', 'datetime') or s['n'] < 2:
                    return
                ends.append((s['x_base'], s['x_base']+(s['n']-1)*s['x_inc']) if s['path']
                            else (float(s['x'][0]), float(s['x'][-1])))
            lo, hi = max(a for a, _ in ends), min(b for _, b in ends)
            if not math.isfinite(lo) or not math.isfinite(hi) or hi <= lo:
                return
        except (ValueError, KeyError, IndexError):
            return
        self._steady_origin = lo
        with QSignalBlocker(self.steady_search_a), QSignalBlocker(self.steady_search_b):
            self.steady_search_a.setValue(0.); self.steady_search_b.setValue(hi-lo)

    def _steady_channel_changed(self, role):
        if self._steady_updating:
            return
        if role != 'flow':
            self._steady_sync_unit(role)
        self.steady_channels[role].setToolTip(self.steady_channels[role].currentText())
        self._steady_update_origin(); self._steady_update_flow_unit()
        self._steady_reset('Seçim değişti. Birimleri kontrol edip Kararlı Aralıkları Bul’a basın.')

    def _steady_sync_unit(self, role):
        key = self.steady_channels[role].currentData()
        s = next((s for s in self.current_series or [] if s['style_key']==key), {})
        unit = self.style_map.get(key, {}).get('unit_override') or s.get('unit')
        signature = (key, unit)
        if signature != self._steady_unit_metadata.get(role):
            self._steady_unit_metadata[role] = signature
            with QSignalBlocker(self.steady_units[role]):
                self.steady_units[role].setCurrentIndex(max(0, self.steady_units[role].findData(pressure_unit(unit))))

    def _steady_update_flow_unit(self):
        key = self.steady_channels['flow'].currentData()
        s = next((s for s in self.current_series or [] if s['style_key']==key), {})
        unit = self.style_map.get(key, {}).get('unit_override') or s.get('unit') or 'kaynak birimi'
        self.steady_flow_unit.setText(unit)
        self.steady_threshold.setSuffix(' '+unit); self.steady_qfloor.setSuffix(' '+unit)
        enabled = key is not None
        for w in (self.steady_auto_flow, self.steady_qfloor):
            w.setEnabled(enabled)
        self.steady_threshold.setEnabled(enabled and not self.steady_auto_flow.isChecked())

    def _steady_suggest_channels(self):
        candidates = []
        for s in self.current_series or []:
            candidates.append(export_snapshot(s, self.style_map.get(s['style_key'], {})))
        suggestions = suggest_roles(candidates)
        for role, key in suggestions.items():
            self.steady_channels[role].setCurrentIndex(self.steady_channels[role].findData(key))
        self.steady_summary.setText('Önerilen kanal rollerini ve basınç birimlerini kontrol edin.' if suggestions
                                    else 'Kanal adları tekil bir eşleştirme vermedi; kanalları listeden seçin.')

    def _steady_toggle_advanced(self, checked):
        self.steady_advanced.setVisible(checked)
        self.steady_advanced_toggle.setText('Gelişmiş ayarlar ▾' if checked else 'Gelişmiş ayarlar ▸')

    def _steady_toggle_setup(self, checked):
        self.steady_setup.setVisible(checked)
        self.steady_setup_toggle.setText('Kanallar ve analiz ayarları ▾' if checked else 'Kanallar ve analiz ayarları ▸')

    def _steady_preset_changed(self, index):
        if index >= 3:
            return
        noise, drift, floor = ((.2, .5, .002), (.5, 1., .005), (1., 2., .01))[index]
        for box, value in ((self.steady_noise, noise), (self.steady_drift, drift),
                           (self.steady_pfloor, floor), (self.steady_dpfloor, floor)):
            with QSignalBlocker(box):
                box.setValue(value)
        self._steady_config_changed()

    def _steady_flow_mode_changed(self, *args):
        self._steady_update_flow_unit(); self._steady_config_changed()

    def _steady_search_mode_changed(self, checked):
        for box in (self.steady_search_a, self.steady_search_b):
            box.setEnabled(checked)
        self._steady_config_changed()

    def _steady_config_changed(self, *args):
        if not self._steady_updating:
            actual = (self.steady_noise.value(), self.steady_drift.value(),
                      self.steady_pfloor.value(), self.steady_dpfloor.value())
            choices = ((.2, .5, .002, .002), (.5, 1., .005, .005), (1., 2., .01, .01))
            index = choices.index(actual) if actual in choices else 3
            with QSignalBlocker(self.steady_preset):
                self.steady_preset.setCurrentIndex(index)
            self._steady_reset('Ayar değişti. Güncel sonuç için Kararlı Aralıkları Bul’a basın.')

    def _steady_clear_values(self):
        self.steady_stats.clear()
        for _, value, detail in self.steady_cards.values():
            value.setText('—'); detail.clear()

    def _steady_reset(self, message):
        self._cancel_jobs(['steady', 'steady_manual', 'steady_export'])
        self._steady_token += 1; self._steady_measure_token += 1
        self._steady_result = self._steady_manual = self._steady_selected = None
        self.steady_tree.clear(); self._steady_clear_values(); self.steady_used.clear()
        self.steady_run.setEnabled(True); self.steady_stop.setEnabled(False); self.steady_csv.setEnabled(False)
        self.steady_summary.setText(message); self.steady_detail.setText('Yeşil aralık, hesabın yapıldığı zaman bölümünü gösterir.')
        for curve, plot in self._steady_curves:
            plot.removeItem(curve)
        self._steady_curves = []
        for region in self._steady_regions:
            region.hide()
        for w in (self.steady_a, self.steady_b, self.steady_manual_run, self.steady_restore):
            w.setEnabled(False)

    def _steady_options(self):
        return SteadyOptions(window_s=self.steady_window.value(), min_duration_s=self.steady_min.value(),
                             noise_pct=self.steady_noise.value(), drift_pct=self.steady_drift.value(),
                             pressure_floor_bar=self.steady_pfloor.value(), dp_floor_bar=self.steady_dpfloor.value(),
                             flow_floor=self.steady_qfloor.value(),
                             flow_threshold=None if self.steady_auto_flow.isChecked() else self.steady_threshold.value())

    def _steady_analyze(self):
        self._steady_reset('Özgün örnekler taranıyor…')
        try:
            sources, options = self._steady_sources(), self._steady_options()
            bounds = (self._steady_origin+self.steady_search_a.value(), self._steady_origin+self.steady_search_b.value()) if self.steady_limit.isChecked() else None
        except Exception as exc:
            self.steady_summary.setText(str(exc)); return
        token = self._steady_token
        self.steady_run.setEnabled(False); self.steady_stop.setEnabled(True)
        worker = FunctionWorker(lambda cancel: analyze_steady(sources, options, cancel, bounds))
        self._start_job(worker, lambda r: self._steady_ready(token, r), lambda msg: self._steady_failed(token, msg), tag='steady')

    def _steady_failed(self, token, message):
        if token == self._steady_token:
            self._steady_reset(message)

    def _steady_ready(self, token, result):
        if token != self._steady_token or result.get('cancelled'):
            return
        self._steady_result = result
        self.steady_setup_toggle.setChecked(False)
        self.steady_run.setEnabled(True); self.steady_stop.setEnabled(False)
        # The origin remains the common record start even if the search is narrowed.
        self._steady_origin = result['common_bounds'][0]
        self._steady_draw(result)
        rows = result['intervals']
        self.steady_tree.blockSignals(True)
        for i, interval in enumerate(rows):
            q = interval['stats'].get('flow')
            item = QTreeWidgetItem([str(i+1), _num(interval['start']-self._steady_origin), _num(interval['end']-self._steady_origin),
                                   _num(interval['duration']), _num(interval['dp_bar']), _num(q['mean']) if q else '—'])
            item.setData(0, Qt.ItemDataRole.UserRole, i); self.steady_tree.addTopLevelItem(item)
        self.steady_tree.blockSignals(False)
        o = result['options']; source_parts = []
        for s in result['sources']:
            unit = s.get('pressure_unit') or s.get('unit') or 'kaynak birimi'
            source_parts.append(f"{ROLE_NAMES[s['role']]}: {s['name']} [{unit}], {s['fs_hz']:.6g} Hz")
        used = f"Pencere {o['window_s']:g} s · asgari süre {o['min_duration_s']:g} s · σ ≤ %{o['noise_pct']:g} · sürüklenme ≤ %{o['drift_pct']:g}"
        used += f" · mutlak P / Δp toleransı {o['pressure_floor_bar']:g} / {o['dp_floor_bar']:g} bar"
        if result['flow_threshold'] is not None:
            used += f" · |debi| > {result['flow_threshold']:.6g} {result['sources'][2].get('unit') or 'kaynak birimi'}"
        if result['time_mode'] == 'datetime':
            used += ' · 0 s = '+datetime.fromtimestamp(self._steady_origin, timezone.utc).isoformat(timespec='milliseconds')+' (UTC)'
        self.steady_used.setText(escape(' | '.join(source_parts))+'<br>'+escape(used))
        self.steady_cards['flow'][0].setVisible(len(result['sources']) == 3)
        self.steady_summary.setText(f'{len(rows)} ortak kararlı aralık bulundu. En uzun aralık seçildi.' if rows else
                                    'Ortak kararlı aralık bulunamadı. Grafiği ve toleransları kontrol edin; elle aralık seçebilirsiniz.')
        if not rows:
            reasons = '; '.join(f"{ROLE_NAMES[r]}: {v['coverage']} eksik/seyrek, {v['unsteady']} değişken pencere" for r, v in result['rejected'].items())
            self.steady_summary.setText(self.steady_summary.text()+' '+reasons)
        for w in (self.steady_a, self.steady_b, self.steady_manual_run):
            w.setEnabled(True)
        for region in self._steady_regions:
            region.setBounds((result['bounds'][0]-self._steady_origin, result['bounds'][1]-self._steady_origin))
        for box in (self.steady_a, self.steady_b):
            with QSignalBlocker(box):
                box.setRange(result['bounds'][0]-self._steady_origin, result['bounds'][1]-self._steady_origin)
        if rows:
            best = max(range(len(rows)), key=lambda i: rows[i]['duration'])
            self.steady_tree.setCurrentItem(self.steady_tree.topLevelItem(best))
        else:
            self._steady_set_range(*result['bounds']); self._steady_zoom_all()
            self.steady_detail.setText('Elle sınırları seçin ve Elle Aralığı Hesapla’ya basın. '+' '.join(result['warnings']))
        self.steady_csv.setEnabled(bool(rows))

    def _steady_draw(self, result):
        colors = ('#207FBF', '#E48331', '#198A73')
        for i, (s, trace) in enumerate(zip(result['sources'], result['traces'])):
            plot = self.steady_flow_plot if s['role']=='flow' else self.steady_pressure_plot
            curve = plot.plot(trace['x']-self._steady_origin, trace['y'], pen=pg.mkPen(colors[i], width=1.8),
                              name=escape(ROLE_NAMES[s['role']]+' · '+s['name']), connect='finite')
            self._steady_curves.append((curve, plot))
        self.steady_flow_plot.setVisible(len(result['sources']) == 3)
        if len(result['sources']) == 3:
            unit = result['sources'][2].get('unit') or ''
            self.steady_flow_plot.setLabel('left', 'Debi'+(f' [{unit}]' if unit else ' [kaynak birimi]'))
        self._steady_zoom_all()

    def _steady_set_range(self, start, end):
        self._steady_updating = True
        try:
            a, b = start-self._steady_origin, end-self._steady_origin
            for box, value in ((self.steady_a, a), (self.steady_b, b)):
                with QSignalBlocker(box):
                    box.setValue(value)
            for region in self._steady_regions:
                with QSignalBlocker(region):
                    region.setRegion((a, b)); region.show()
        finally:
            self._steady_updating = False

    def _steady_interval_selected(self, current, previous=None):
        if current is None or self._steady_result is None:
            return
        self._cancel_jobs(['steady_manual']); self._steady_measure_token += 1
        self._steady_manual = None
        i = current.data(0, Qt.ItemDataRole.UserRole)
        interval = self._steady_result['intervals'][i]
        self._steady_set_range(interval['start'], interval['end']); self._steady_show_values(interval)
        self.steady_summary.setText(f"{len(self._steady_result['intervals'])} ortak kararlı aralık · seçili aralık {i+1}")
        self.steady_restore.setEnabled(True); self.steady_manual_run.setEnabled(True); self._steady_zoom_selected()

    def _steady_show_values(self, interval):
        self._steady_selected = interval; self.steady_stats.clear()
        sources = {s['role']: s for s in self._steady_result['sources']}
        for role, stat in interval['stats'].items():
            unit = 'bar' if role != 'flow' else sources[role].get('unit') or 'kaynak birimi'
            _, value, detail = self.steady_cards[role]
            value.setText(_num(stat['mean'])+' '+unit); detail.setText('σ '+_num(stat['std'])+' · n = '+str(stat['n']))
            self.steady_stats.addTopLevelItem(QTreeWidgetItem([sources[role]['name'], unit,
                *[_num(stat[k]) for k in ('mean', 'std', 'min', 'max')], str(stat['n'])]))
        _, value, detail = self.steady_cards['dp']
        value.setText(_num(interval['dp_bar'])+' bar'); detail.setText(_num(interval['dp_bar']*1000)+' mbar · ort(Pin) − ort(Pout)')
        notes = list(self._steady_result['warnings'])
        if interval['mode'] == 'manual':
            notes.append(interval['note'])
        if interval['dp_bar'] < 0:
            notes.append('Δp negatif: kanal rollerini, birimleri, basınç referansını ve akış yönünü kontrol edin.')
        prefix = 'Otomatik kararlı aralık' if interval['mode']=='auto' else 'Elle seçilen aralık'
        self.steady_detail.setText(f"{prefix}: {interval['start']-self._steady_origin:.6f}–{interval['end']-self._steady_origin:.6f} s "
                                  f"({interval['duration']:.6g} s). Sınırlar [başlangıç, bitiş). "+' '.join(notes))
        self.steady_csv.setEnabled(True)

    def _steady_region_changed(self, index):
        if self._steady_updating or self._steady_result is None:
            return
        a, b = self._steady_regions[index].getRegion()
        self._steady_set_range(a+self._steady_origin, b+self._steady_origin)
        self._steady_manual_changed()

    def _steady_manual_changed(self, *args):
        if self._steady_updating or self._steady_result is None:
            return
        self._cancel_jobs(['steady_manual']); self._steady_measure_token += 1
        self._steady_manual = self._steady_selected = None
        self._steady_clear_values()
        a, b = self.steady_a.value(), self.steady_b.value()
        self._steady_updating = True
        for region in self._steady_regions:
            with QSignalBlocker(region):
                region.setRegion((a, b))
        self._steady_updating = False
        self.steady_manual_run.setEnabled(True)
        self.steady_csv.setEnabled(bool(self._steady_result['intervals']))
        self.steady_detail.setText('Sınırlar değişti. Güncel ortalama ve Δp için Elle Aralığı Hesapla’ya basın.')

    def _steady_measure(self):
        if self._steady_result is None:
            return
        self._steady_manual_changed()
        sources = self._steady_result['sources']
        a, b = self._steady_origin+self.steady_a.value(), self._steady_origin+self.steady_b.value()
        token = self._steady_measure_token
        self.steady_manual_run.setEnabled(False); self.steady_detail.setText('Seçili aralığın özgün örnekleri okunuyor…')
        worker = FunctionWorker(lambda cancel: measure_steady(sources, a, b, cancel))
        self._start_job(worker, lambda r: self._steady_manual_ready(token, r),
                        lambda msg: self._steady_manual_failed(token, msg), tag='steady_manual', cancel_tags=['steady_manual'])

    def _steady_manual_ready(self, token, result):
        if token != self._steady_measure_token or result.get('cancelled') or self._steady_result is None:
            return
        self._steady_manual = result['interval']; self.steady_manual_run.setEnabled(True)
        self._steady_show_values(self._steady_manual)

    def _steady_manual_failed(self, token, message):
        if token == self._steady_measure_token:
            self.steady_manual_run.setEnabled(True); self.steady_detail.setText(message)

    def _steady_restore(self):
        self._steady_interval_selected(self.steady_tree.currentItem())

    def _steady_zoom_all(self):
        if self._steady_result:
            lo, hi = self._steady_result['bounds']
            self.steady_pressure_plot.setXRange(lo-self._steady_origin, hi-self._steady_origin, padding=.02)
            for plot in self.steady_plots:
                plot.enableAutoRange(axis='y', enable=True)

    def _steady_zoom_selected(self):
        if self._steady_result:
            a, b = self.steady_a.value(), self.steady_b.value()
            pad = max(self._steady_result['options']['window_s'], (b-a)*.15)
            lo, hi = self._steady_result['bounds']
            self.steady_pressure_plot.setXRange(max(lo-self._steady_origin, a-pad), min(hi-self._steady_origin, b+pad), padding=0)

    def _steady_export(self):
        if self._steady_result is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Basınç kaybı sonuçları', 'basinc_kaybi.csv', 'CSV (*.csv)')
        if not path:
            return
        result, manual, token = self._steady_result, self._steady_manual, self._steady_token
        self.steady_csv.setEnabled(False)
        worker = FunctionWorker(lambda cancel: write_steady_report(path, result, manual, cancel))
        def ready(payload):
            if token == self._steady_token:
                self.steady_csv.setEnabled(True); self.status.showMessage('Basınç kaybı raporu kaydedildi: '+payload['path'], 6000)
        def failed(message):
            if token == self._steady_token:
                self.steady_csv.setEnabled(True); QMessageBox.warning(self, 'Rapor kaydedilemedi', message)
        self._start_job(worker, ready, failed, tag='steady_export', cancel_tags=['steady_export'])
