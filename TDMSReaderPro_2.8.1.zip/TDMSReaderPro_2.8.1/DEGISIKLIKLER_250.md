# TDMSReader Pro 2.5.0

## Zaman ekseni

- Soldaki kanal özelliklerine **Testlerin ortak sürede yapıldığını varsay** ve **Referans kanal** seçimleri eklendi. Başlangıçta kapalıdır.
- Referans kanalın özgün `Nref` örneği ve bilinen `Fsref` değeri için ortak süre `T=(Nref-1)/Fsref` olarak hesaplanır. Her kaynak kanala `Fs=(N-1)/T` uygulanır. Referansın başlangıç zamanı kullanılır. Diğer kaynak kanalların manuel ve TDMS Fs değerleri değiştirilmez; varsayım kapatılınca geri gelir.
- Referansın Fs değeri bilinmiyorsa seçenek etkinleşmez. Hesaplanmış kanalların önceki sonuçları otomatik olarak yeniden hesaplanmaz.
- Seçim yeni `.tdmsproj` dosyasına kaydedilir; eski projelerde kapalı kalır.

## Büyük kayıtlar

- İlk tam yükleme eşiği 2 milyon yerine **250 bin özgün örnek**. Daha büyük kanallar blok blok okunup ilk görünümde yaklaşık 60 bin örnekle temsil edilir; min/maks ve eksik değerler korunur. Görünen aralığa yakınlaşınca en fazla yaklaşık 80 bin noktalık yeni önizleme okunur.
- Zaman ekseni değişmiyorsa büyük X dizileri tekrar oluşturulmaz. Küçük kanalların ilk yüklenmesindeki yinelenen zaman metadata okuması kaldırıldı.
- CSV, FFT ve ölçümler kaynak TDMS örneklerini tam çözünürlükte kullanır. Sıradan `veri[::5]` seçeneği eklenmedi; dar pik ve kısa vana geçişlerini kaçırabilir.

## Doğrulama

- Ortak süre açma/kapatma, bilinmeyen Fs, kademeli kanalın özgün örnek sayısı, 1 milyon örnekte tek örneklik tepe, tam çözünürlüklü okuma ve proje açma/kaydetme testleri geçti.
- 183 testlik genel çalıştırmada 182 test geçti. Başarısız olan `test_export_cancel_button_preserves_existing_file` 1 ms'lik GUI zamanlayıcısının burada CSV aktarımı bittikten sonra çalışmasıyla ilgili; değiştirilmemiş 2.4.1 paketinde de aynı hata tekrarlandı. Gerçek Windows EXE ve kullanıcı TDMS dosyasıyla performans denemesi bu ortamda yapılmadı.
