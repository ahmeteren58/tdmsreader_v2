"""Isolated alignment tab and coordinate-only hooks into existing plot views."""
from __future__ import annotations
from datetime import datetime, timezone

from PyQt6.QtCore import Qt, QSignalBlocker
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QDoubleSpinBox, QComboBox, QTreeWidget, QTreeWidgetItem, QHeaderView,
    QScrollArea, QGroupBox, QAbstractItemView,
)

from tdms_alignment import source_bounds, estimate_edges, estimate_correlation
from tdms_export import export_snapshot
from tdms_workspace import FunctionWorker


class AlignmentMixin:
    def _alignment_display_styles(self):
        return self.alignment_manager.display_styles(self.style_map, self.current_series)

    def _alignment_total_shift(self, series):
        key = series.get('style_key')
        offset = self.alignment_manager.offset(key) if series.get('x_mode') in ('seconds', 'datetime') else 0.
        return float(self.style_map.get(key, {}).get('x_shift', 0.) or 0.)+offset

    def _init_alignment(self, build_ui=False):
        self._alignment_signature = None
        self._alignment_token = 0
        self._alignment_estimate = None
        self._alignment_origin = 0.
        self._alignment_updating = False
        self._alignment_unit_factor = .001
        if not build_ui:
            return
        self.alignment_tab = QScrollArea(); self.alignment_tab.setWidgetResizable(True)
        self.alignment_tab.setFrameShape(QScrollArea.Shape.NoFrame)
        content = QWidget(); self.alignment_tab.setWidget(content)
        root = QVBoxLayout(content); root.setContentsMargins(14, 12, 14, 12); root.setSpacing(10)
        title = QLabel('Channel Alignment / Synchronization')
        title.setStyleSheet('font-size:17px; font-weight:700;'); root.addWidget(title)
        note = QLabel('Zaman koordinatı: t_corrected = t_original + offset. Pozitif ofset sağa, negatif ofset sola kaydırır. '
                      'Ham veriler değişmez. Fiziksel gecikmeler acquisition kayması olmayabilir; önerileri uygulamadan önce kontrol edin.')
        note.setWordWrap(True); root.addWidget(note)

        group = QGroupBox('Manual Time Offset'); layout = QVBoxLayout(group)
        hint = QLabel('Bir veya birden fazla satır seçin (Ctrl / Shift). Seçili kanallara aynı ofseti uygulayabilir; '
                      'her kanala ayrı değer vermek için tek tek seçebilirsiniz.')
        hint.setWordWrap(True); hint.setProperty('valveHint', True); layout.addWidget(hint)
        self.alignment_tree = QTreeWidget(); self.alignment_tree.setRootIsDecorated(False)
        self.alignment_tree.setAlternatingRowColors(True)
        self.alignment_tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.alignment_tree.setHeaderLabels(['Kanal', 'Fs [Hz]', 'Alignment [ms]', 'Görsel X Δ [s]'])
        self.alignment_tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for i in range(1, 4):
            self.alignment_tree.header().setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        self.alignment_tree.setMinimumHeight(120); self.alignment_tree.setMaximumHeight(210)
        self.alignment_tree.itemSelectionChanged.connect(self._alignment_manual_selected); layout.addWidget(self.alignment_tree)
        row = QHBoxLayout(); self.alignment_value = self._alignment_spin(-1e9, 1e9, 6)
        self.alignment_value.setSingleStep(.1)
        self.alignment_unit = QComboBox(); self.alignment_unit.addItem('ms', .001); self.alignment_unit.addItem('s', 1.)
        self.alignment_unit.currentIndexChanged.connect(self._alignment_unit_changed)
        self.alignment_manual_apply = QPushButton('Seçililere Uygula')
        self.alignment_manual_apply.clicked.connect(self._alignment_apply_manual)
        self.alignment_reset = QPushButton('Reset Channel Alignment'); self.alignment_reset.clicked.connect(self._alignment_reset_selected)
        self.alignment_reset_all = QPushButton('Reset All Alignments'); self.alignment_reset_all.clicked.connect(self._alignment_reset_all)
        row.addWidget(QLabel('Ofset:')); row.addWidget(self.alignment_value); row.addWidget(self.alignment_unit)
        row.addWidget(self.alignment_manual_apply); row.addWidget(self.alignment_reset); row.addWidget(self.alignment_reset_all)
        row.addStretch(); layout.addLayout(row); root.addWidget(group)

        group = QGroupBox('Referans olaya göre ofset öner'); grid = QGridLayout(group)
        self.alignment_reference = QComboBox(); self.alignment_target = QComboBox()
        for combo in (self.alignment_reference, self.alignment_target):
            combo.setMinimumContentsLength(24)
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.alignment_method = QComboBox(); self.alignment_method.addItem('Edge Alignment · dijital 0/1', 'edge')
        self.alignment_method.addItem('Cross-Correlation · analog / dijital', 'correlation')
        self.alignment_edge = QComboBox(); self.alignment_edge.addItem('Rising Edge · 0 → 1', 'rising')
        self.alignment_edge.addItem('Falling Edge · 1 → 0', 'falling')
        self.alignment_search = self._alignment_spin(.000001, 1e9, 6); self.alignment_search.setValue(50.)
        self.alignment_search.setSuffix(' ms'); self.alignment_search_label = QLabel('Arama: ±')
        for i, (caption, combo) in enumerate((('Reference Channel:', self.alignment_reference), ('Target Channel:', self.alignment_target),
                                             ('Method:', self.alignment_method), ('Edge:', self.alignment_edge))):
            grid.addWidget(QLabel(caption), i, 0); grid.addWidget(combo, i, 1, 1, 3)
        self.alignment_edge_label = grid.itemAtPosition(3, 0).widget()
        grid.addWidget(self.alignment_search_label, 4, 0); grid.addWidget(self.alignment_search, 4, 1)
        self.alignment_a = self._alignment_spin(0., 1e12, 6); self.alignment_b = self._alignment_spin(0., 1e12, 6)
        for box in (self.alignment_a, self.alignment_b):
            box.setSuffix(' s'); box.valueChanged.connect(self._alignment_invalidate)
        self.alignment_visible = QPushButton('Görünen Aralığı Al'); self.alignment_visible.clicked.connect(self._alignment_use_visible)
        grid.addWidget(QLabel('Analiz aralığı:'), 5, 0); grid.addWidget(self.alignment_a, 5, 1)
        grid.addWidget(self.alignment_b, 5, 2); grid.addWidget(self.alignment_visible, 5, 3)
        self.alignment_origin_text = QLabel('Önce referans ve hedef kanalı seçin.'); self.alignment_origin_text.setWordWrap(True)
        self.alignment_origin_text.setProperty('valveHint', True); grid.addWidget(self.alignment_origin_text, 6, 0, 1, 4)
        grid.setColumnStretch(1, 1); grid.setColumnStretch(2, 1); root.addWidget(group)
        for combo in (self.alignment_reference, self.alignment_target):
            combo.currentIndexChanged.connect(self._alignment_pair_changed)
        self.alignment_method.currentIndexChanged.connect(self._alignment_method_changed)
        self.alignment_edge.currentIndexChanged.connect(self._alignment_invalidate)
        self.alignment_search.valueChanged.connect(self._alignment_invalidate)

        row = QHBoxLayout(); self.alignment_estimate_button = QPushButton('Estimate')
        self.alignment_estimate_button.setProperty('primary', True)
        self.alignment_estimate_button.clicked.connect(self._alignment_estimate_run)
        self.alignment_stop = QPushButton('Durdur'); self.alignment_stop.setEnabled(False)
        self.alignment_stop.clicked.connect(lambda: self._alignment_invalidate(message='Tahmin durduruldu.'))
        self.alignment_apply_button = QPushButton('Apply Alignment'); self.alignment_apply_button.setEnabled(False)
        self.alignment_apply_button.clicked.connect(self._alignment_apply_estimate)
        go = QPushButton('Grafiği Göster'); go.clicked.connect(self._show_plot_tab)
        for w in (self.alignment_estimate_button, self.alignment_stop, self.alignment_apply_button, go):
            row.addWidget(w)
        row.addStretch(); root.addLayout(row)
        self.alignment_estimated = QLabel('Estimated offset: —')
        self.alignment_estimated.setStyleSheet('font-size:18px; font-weight:700;'); root.addWidget(self.alignment_estimated)
        self.alignment_quality = QLabel('Quality / Correlation: —'); self.alignment_quality.setWordWrap(True); root.addWidget(self.alignment_quality)
        self.alignment_status = QLabel('Kanalları seçip Estimate düğmesine basın.'); self.alignment_status.setWordWrap(True)
        self.alignment_status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); root.addWidget(self.alignment_status)
        footer = QLabel('Öneri, hedef kanal için yeni toplam alignment ofsetidir; tekrar uygulamak ofseti biriktirmez. '
                        'Edge yöntemi seçili aralıktaki ilk gerçek örnek kenarını kullanır; filtre uygulanmaz. '
                        'Korelasyon için aynı fiziksel olayı temsil eden sinyalleri seçin. Sync/Synch/Trigger kanalları özel olarak seçilmez. '
                        'Görsel X Δ, alignment’dan ayrıdır. Vana Analizi ve Basınç Kaybı özgün zamanlarla çalışmaya devam eder. '
                        'Aralık Analizi ve A/B ölçümü grafikteki zaman koordinatlarını kullanır. Ofsetler .tdmsproj ile saklanır.')
        footer.setWordWrap(True); footer.setProperty('valveHint', True); root.addWidget(footer); root.addStretch()
        self.tabs.addTab(self.alignment_tab, 'Channel Alignment')
        self._alignment_method_changed(); self._alignment_refresh()

    @staticmethod
    def _alignment_spin(lo, hi, decimals):
        box = QDoubleSpinBox(); box.setDecimals(decimals); box.setRange(lo, hi)
        box.setKeyboardTracking(False); box.setMinimumWidth(110); return box

    def _alignment_sources(self):
        by_key = {s['style_key']: s for s in self.current_series or []}
        result = []
        for combo in (self.alignment_reference, self.alignment_target):
            key = combo.currentData()
            if key not in by_key:
                raise ValueError('Reference Channel ve Target Channel seçin.')
            s = by_key[key]; style = self.style_map.get(key, {})
            snap = export_snapshot(s, {'display_name': style.get('display_name'), 'unit_override': style.get('unit_override')})
            snap.update(alignment_offset=self.alignment_manager.offset(key), is_digital=bool(s.get('is_digital')),
                        source_path=s.get('source_path'), source_fingerprint=s.get('source_fingerprint'))
            result.append(snap)
        return result

    def _alignment_refresh(self):
        if not hasattr(self, 'alignment_tree'):
            if hasattr(self, '_legacy_offsets_refresh'):
                self._legacy_offsets_refresh()
            return
        series = self.current_series or []
        signature = (self.alignment_manager.generation, tuple((s['style_key'], s.get('fs_est'), s.get('x_mode'),
                    s.get('effective_x_base'), s.get('effective_fs_source'), s.get('sample_count'), s.get('source_path'),
                    repr(s.get('source_fingerprint')), None if s.get('lazy') else id(s.get('y')),
                    self.style_map.get(s['style_key'], {}).get('display_name'),
                    self.style_map.get(s['style_key'], {}).get('x_shift')) for s in series))
        if signature == self._alignment_signature:
            return
        self._alignment_signature = signature
        selected = {i.data(0, Qt.ItemDataRole.UserRole) for i in self.alignment_tree.selectedItems()}
        old = [c.currentData() for c in (self.alignment_reference, self.alignment_target)]
        self._alignment_updating = True
        self.alignment_tree.blockSignals(True); self.alignment_tree.clear()
        for s in series:
            key = s['style_key']; style = self.style_map.get(key, {})
            name = ' / '.join(str(v) for v in (s.get('file_label'), s.get('group'), style.get('display_name') or s['name']) if v)
            fs = s.get('fs_est')
            item = QTreeWidgetItem([name, f'{fs:.8g}' if fs else 'Bilinmiyor',
                                   f'{self.alignment_manager.offset(key)*1000:+.6f}', f"{style.get('x_shift', 0.):+.6g}"])
            item.setData(0, Qt.ItemDataRole.UserRole, key); self.alignment_tree.addTopLevelItem(item)
            item.setSelected(key in selected); item.setToolTip(0, name)
        self.alignment_tree.blockSignals(False)
        for combo, current in zip((self.alignment_reference, self.alignment_target), old):
            with QSignalBlocker(combo):
                combo.clear(); combo.addItem('Kanal seçin…', None)
                for s in series:
                    label = ' / '.join(str(v) for v in (s.get('file_label'), s.get('group'), self.style_map.get(s['style_key'], {}).get('display_name') or s['name']) if v)
                    combo.addItem(label, s['style_key'])
                combo.setCurrentIndex(max(0, combo.findData(current)))
        self._alignment_updating = False
        self._alignment_pair_changed()
        self._alignment_manual_selected()

    def _alignment_pair_changed(self, *args):
        if self._alignment_updating:
            return
        self._alignment_invalidate()
        try:
            sources = self._alignment_sources()
            ends = [source_bounds(s) for s in sources]
            lo, hi = min(a for a, b in ends), max(b for a, b in ends)
            self._alignment_origin = lo
            with QSignalBlocker(self.alignment_a), QSignalBlocker(self.alignment_b):
                self.alignment_a.setValue(0.); self.alignment_b.setValue(min(10., hi-lo))
            text = 'Başlangıç/bitiş bu ortak görünüm kökenine göre saniyedir. '
            if sources[0]['x_mode'] == 'datetime':
                text += '0 s = '+datetime.fromtimestamp(lo, timezone.utc).isoformat(timespec='milliseconds')+' UTC.'
            else:
                text += f'0 s = kaynak zamanında {lo:.9g} s.'
            self.alignment_origin_text.setText(text+' Görsel X Δ bu tahminde kullanılmaz.')
        except Exception:
            self.alignment_origin_text.setText('Önce referans ve hedef kanalı seçin. Bilinmeyen Fs için Manuel Fs sekmesini kullanın.')

    def _alignment_method_changed(self, *args):
        edge = self.alignment_method.currentData() == 'edge'
        for w in (self.alignment_edge, self.alignment_edge_label):
            w.setVisible(edge)
        for w in (self.alignment_search, self.alignment_search_label):
            w.setVisible(not edge)
        self._alignment_invalidate()

    def _alignment_invalidate(self, *args, message=None):
        if self._alignment_updating:
            return
        self._cancel_jobs(['alignment']); self._alignment_token += 1; self._alignment_estimate = None
        if not hasattr(self, 'alignment_apply_button'):
            return
        self.alignment_apply_button.setEnabled(False); self.alignment_stop.setEnabled(False)
        self.alignment_estimate_button.setEnabled(True)
        self.alignment_estimated.setText('Estimated offset: —'); self.alignment_quality.setText('Quality / Correlation: —')
        self.alignment_status.setText(message or 'Seçim veya zaman değişti. Yeni bir öneri için Estimate düğmesine basın.')

    def _alignment_use_visible(self):
        if self.current_series:
            a, b = self._current_xrange()
            self.alignment_a.setValue(max(0., a-self._alignment_origin)); self.alignment_b.setValue(max(0., b-self._alignment_origin))

    def _alignment_unit_changed(self, *args):
        old = self._alignment_unit_factor
        physical = self.alignment_value.value()*old
        self._alignment_unit_factor = float(self.alignment_unit.currentData())
        self.alignment_value.setDecimals(9 if self._alignment_unit_factor == 1. else 6)
        self.alignment_value.setValue(physical/self._alignment_unit_factor)

    def _alignment_manual_selected(self):
        if self._alignment_updating:
            return
        items = self.alignment_tree.selectedItems()
        if len(items) == 1:
            key = items[0].data(0, Qt.ItemDataRole.UserRole)
            self.alignment_value.setValue(self.alignment_manager.offset(key)/self._alignment_unit_factor)
        self.alignment_manual_apply.setEnabled(bool(items)); self.alignment_reset.setEnabled(bool(items))

    def _alignment_apply_manual(self):
        keys = [i.data(0, Qt.ItemDataRole.UserRole) for i in self.alignment_tree.selectedItems()]
        self._alignment_apply_offsets({key: self.alignment_value.value()*self._alignment_unit_factor for key in keys})

    def _alignment_apply_offsets(self, values):
        try:
            by_key = {s['style_key']: s for s in self.current_series or []}
            if not values:
                raise ValueError('Önce kanal satırlarını seçin.')
            if any(key not in by_key or by_key[key].get('x_mode') not in ('seconds', 'datetime') for key in values):
                raise ValueError('Zaman ofseti için saniye/UTC ekseni gerekli. İndeks kanallarına önce Manuel Fs atayın.')
            self.alignment_manager.set_offsets(values)
        except Exception as exc:
            if hasattr(self, 'alignment_status'):
                self.alignment_status.setText(str(exc))
            return
        self._alignment_refresh(); self._alignment_redraw()
        if hasattr(self, 'alignment_status'):
            self.alignment_status.setText(f'{len(values)} kanalın alignment ofseti uygulandı. Ham veri değişmedi; Grafiği Göster ile kontrol edin.')

    def _alignment_reset_selected(self):
        keys = [i.data(0, Qt.ItemDataRole.UserRole) for i in self.alignment_tree.selectedItems()]
        # Reset must also work if the user changed a channel back to index mode.
        self.alignment_manager.set_offsets({key: 0. for key in keys})
        self._alignment_refresh(); self._alignment_redraw()
        self.alignment_status.setText(f'{len(keys)} kanalın alignment ofseti sıfırlandı. Görsel X Δ korundu.')

    def _alignment_reset_all(self):
        self.alignment_manager.reset_all(); self._alignment_refresh(); self._alignment_redraw()
        if hasattr(self, 'alignment_status'):
            self.alignment_status.setText('Tüm alignment ofsetleri sıfırlandı. Ham zamanlara dönüldü; mevcut görsel X Δ korundu.')

    def _alignment_redraw(self):
        """Reuse curves/filter payload/cache; only bounded display X gets shifted."""
        self._alignment_invalidate()
        self._lazy_view_token += 1; self._cancel_jobs(['lazy_view', 'range_stats', 'marker_stats', 'ab', 'ab_stats'])
        self._lazy_view_timer.stop(); self._last_view_range = None; self._lazy_view_pending = None
        self._range_stats_token += 1; self._clear_range_stats_results(); self.btn_range_stats_calc.setEnabled(True)
        self._ab_token += 1; self.ab_tree.clear()
        styles = self._alignment_display_styles()
        if self._last_display_series:
            self._rendering_display = True
            try:
                pane = self.stacked_view if self._active_plot_mode == 'Stacked' else self.plot_pane
                pane.update_series_data(self._last_display_series, styles)
                if self.detached_win is not None:
                    self.detached_win.pane.update_series_data(self._last_display_series, styles)
            finally:
                self._rendering_display = False
            span = self._current_xrange()
            self._schedule_lazy_view_update(*span)
        if self._ab_enabled:
            self._ab_timer.start()

    def _alignment_estimate_run(self):
        self._alignment_invalidate()
        try:
            sources = self._alignment_sources()
            bounds = (self._alignment_origin+self.alignment_a.value(), self._alignment_origin+self.alignment_b.value())
            method, direction, search = self.alignment_method.currentData(), self.alignment_edge.currentData(), self.alignment_search.value()*.001
        except Exception as exc:
            self.alignment_status.setText(str(exc)); return
        token = self._alignment_token
        self.alignment_estimate_button.setEnabled(False); self.alignment_stop.setEnabled(True)
        self.alignment_status.setText('Seçili analiz aralığında ofset önerisi hesaplanıyor…')
        worker = FunctionWorker(lambda cancel: estimate_edges(sources, bounds, direction, cancel) if method=='edge'
                                else estimate_correlation(sources, bounds, search, cancel))
        self._start_job(worker, lambda r: self._alignment_estimate_ready(token, sources, r),
                        lambda msg: self._alignment_estimate_failed(token, msg), tag='alignment', cancel_tags=['alignment'])

    def _alignment_estimate_ready(self, token, sources, result):
        if token != self._alignment_token or result.get('cancelled'):
            return
        self._alignment_estimate = (sources[1]['key'], result)
        self.alignment_estimate_button.setEnabled(True); self.alignment_stop.setEnabled(False)
        self.alignment_apply_button.setEnabled(True)
        self.alignment_estimated.setText(f"Estimated offset: {result['offset_s']*1000:+.3f} ms")
        resolution = result['resolution_s']*1000
        if result['score'] is None:
            counts = ' / '.join(str(e['count']) for e in result['events'])
            quality = f'Edge · bulunan kenar sayısı (ref / hedef): {counts} · örnek çözünürlüğü ~{resolution:.6g} ms'
        else:
            quality = f"Correlation score: {result['score']:.4f} · analiz grid’i {result['points']} nokta · çözünürlük ~{resolution:.6g} ms"
        self.alignment_quality.setText(quality)
        text = f"Hedef: {sources[1]['name']} · mevcut ofset {sources[1]['alignment_offset']*1000:+.6g} ms · kalan kayma {result['residual_s']*1000:+.6g} ms. "
        text += 'Yeni toplam ofset henüz uygulanmadı. '+' '.join(result['warnings'])
        self.alignment_status.setText(text)
        self.alignment_tab.ensureWidgetVisible(self.alignment_estimated)

    def _alignment_estimate_failed(self, token, message):
        if token == self._alignment_token:
            self._alignment_invalidate(message=message)

    def _alignment_apply_estimate(self):
        if self._alignment_estimate:
            key, result = self._alignment_estimate
            self._alignment_apply_offsets({key: result['offset_s']})
