# 2.5.5 — Kararlı akış ve basınç kaybı

- Yeni **Basınç Kaybı** sekmesi: Pin, Pout, isteğe bağlı Debi eşleştirmesi.
- Tekil kanal adlarından öneri; açık basınç birimi seçimi ve bar dönüşümü.
- Aynı zamanda kararlı kalan bölgelerin özgün örneklerle, bloklar halinde bulunması.
- Gürültü, eğim, pikler, toplam sürüklenme, Δp değişimi ve aktif debi denetimi.
- Sıkı / Standart / Esnek önayarları; pencere ve asgari süre; gelişmiş toleranslar.
- Birden fazla test noktasını ayrı tutan aralık tablosu; en uzun aralığın seçilmesi.
- Ortalama, σ, min, maks, örnek sayısı ve Δp kartları.
- Zamanla bağlı basınç/debi grafikleri ve sürüklenebilir ortak aralık.
- Eski sonucu kaldıran elle sınır düzeltmesi ve özgün örneklerle yeniden hesap.
- Kanal, zaman, birim veya ayar değişikliğinde eski işlerin ve sonuçların iptali.
- Tüm otomatik aralıkları ve son elle aralığı ayarlarla birlikte aktaran atomik CSV.
- Farklı Fs ve farklı birimler içeren sentetik TDMS örneği ve Türkçe kullanım notları.

Yeni özellik mevcut arka plan iş yönetimini ve TDMS okuma havuzunu kullanır.
Ana grafiğin çizim, yakınlaştırma, downsample ve yumuşatma algoritmaları ile
vana zaman analizi ve kısa 0→1→0 darbe filtresi değiştirilmedi. Ek bağımlılık yoktur.

Kullanım ve hesap yöntemi: **BASINC_KAYBI_TR.md**. Doğrulama: **TEST_255.txt**.
