"""Application look & feel: one palette per theme, one stylesheet.

Only colours, spacing and borders live here. Object names and dynamic
properties are the contract with the widgets; no behaviour depends on this
module.
"""
from __future__ import annotations
from pathlib import Path

_ICON_ROOT = Path(__file__).resolve().parent / "icons"

PALETTES = {
    "light": dict(
        window="#E8EBEF", chrome="#F4F5F7", surface="#FFFFFF", raised="#F7F8FA",
        header="#EEF0F3", alt_row="#F6F8FA",
        border="#C3CAD2", border_soft="#DADFE5", border_strong="#9AA4AF",
        text="#1E2730", text_strong="#0F171F", muted="#5A6672", faint="#8A949E", disabled="#A3ACB5",
        accent="#0A5BAA", accent_hover="#084C8F", accent_pressed="#073E75",
        accent_soft="#E4EEF8", accent_soft_border="#A8C5E6", accent_text="#0A4F94",
        selection="#CFE1F5", selection_text="#0B2A4A",
        focus="#2F7CD0", input="#FFFFFF", hover="#ECEFF3", pressed="#E0E5EB",
        tooltip_bg="#1F2A36", tooltip_text="#F4F7FA",
        warn_bg="#FFF6E5", warn_border="#E7C27A", warn_text="#6A4705",
        danger="#B3261E", danger_soft="#FCECEB",
        scroll="#B9C1CA", scroll_hover="#9AA4AF",
    ),
    "dark": dict(
        window="#16191D", chrome="#1D2126", surface="#22272D", raised="#272C33",
        header="#2A3037", alt_row="#262B31",
        border="#3A4149", border_soft="#30363D", border_strong="#525B65",
        text="#DCE1E6", text_strong="#F2F4F6", muted="#99A3AD", faint="#76808A", disabled="#5F6872",
        accent="#3D8FDB", accent_hover="#4C9AE2", accent_pressed="#2F7DC6",
        accent_soft="#1F3348", accent_soft_border="#36638F", accent_text="#8EC1F2",
        selection="#284866", selection_text="#FFFFFF",
        focus="#5AA2E6", input="#1B1F24", hover="#2C3239", pressed="#343B43",
        tooltip_bg="#0F1317", tooltip_text="#EEF1F4",
        warn_bg="#33291A", warn_border="#7D6130", warn_text="#F0D9A8",
        danger="#E26D64", danger_soft="#3A2321",
        scroll="#47505A", scroll_hover="#5C6670",
    ),
}

QT_PALETTE_ROLES = {
    "Window": "window", "WindowText": "text", "Base": "input", "AlternateBase": "alt_row",
    "Text": "text", "Button": "surface", "ButtonText": "text", "Highlight": "selection",
    "HighlightedText": "selection_text", "ToolTipBase": "tooltip_bg", "ToolTipText": "tooltip_text",
    "PlaceholderText": "faint", "Link": "accent",
}

# Plot surfaces of the analysis pages follow the main plot defaults.
PLOT_BACKGROUND = {"light": (255, 255, 255), "dark": (24, 28, 33)}


def palette(theme: str) -> dict:
    return PALETTES["dark" if theme == "dark" else "light"]


def qt_palette_colors(theme: str) -> dict:
    p = palette(theme)
    return {role: p[key] for role, key in QT_PALETTE_ROLES.items()}


def axis_colors(bg_rgb) -> tuple:
    """Axis line and tick-label colours: softened, but readable on *bg_rgb*."""
    r, g, b = bg_rgb[:3]
    if 0.2126 * r + 0.7152 * g + 0.0722 * b > 140:
        return (110, 120, 130), (38, 46, 54)
    return (120, 130, 140), (214, 220, 226)


def build_qss(theme: str) -> str:
    p = dict(palette(theme))
    p["icons"] = (_ICON_ROOT / ("dark" if theme == "dark" else "light")).as_posix()
    return _QSS.format(**p)


# Order matters for equal specificity: generic widget rules first, named
# panels and property-tagged widgets afterwards.
_QSS = """
/* ---------- Base ---------- */
QMainWindow, QWidget#appRoot {{ background: {window}; }}
QDialog {{ background: {chrome}; }}
QLabel {{ color: {text}; background: transparent; }}
QLabel:disabled {{ color: {disabled}; }}
QLabel[muted="true"], QLabel#selection_label {{ color: {muted}; }}
QToolTip {{ color: {tooltip_text}; background: {tooltip_bg}; border: 1px solid {border_strong}; padding: 5px 7px; }}

/* ---------- Menus ---------- */
QMenuBar {{ background: {chrome}; border-bottom: 1px solid {border_soft}; padding: 1px 4px; }}
QMenuBar::item {{ padding: 4px 10px; border-radius: 3px; color: {text}; background: transparent; }}
QMenuBar::item:selected {{ background: {hover}; }}
QMenuBar::item:pressed {{ background: {accent_soft}; color: {accent_text}; }}
QMenu {{ background: {surface}; border: 1px solid {border}; padding: 4px 0; }}
QMenu::item {{ padding: 5px 28px 5px 24px; color: {text}; background: transparent; }}
QMenu::item:selected {{ background: {accent_soft}; color: {text_strong}; }}
QMenu::item:disabled {{ color: {disabled}; }}
QMenu::separator {{ height: 1px; background: {border_soft}; margin: 4px 8px; }}
QMenu::indicator {{ width: 13px; height: 13px; left: 6px; }}

/* ---------- Buttons ---------- */
QPushButton, QToolButton {{ border: 1px solid {border}; border-radius: 3px; padding: 4px 12px; background: {surface}; color: {text}; }}
QPushButton {{ min-height: 20px; }}
QPushButton:hover, QToolButton:hover {{ background: {hover}; border-color: {border_strong}; }}
QPushButton:pressed, QToolButton:pressed {{ background: {pressed}; }}
QPushButton:checked, QToolButton:checked {{ background: {accent_soft}; border-color: {accent_soft_border}; color: {accent_text}; }}
QPushButton:focus, QToolButton:focus {{ border-color: {focus}; }}
QPushButton:disabled, QToolButton:disabled {{ color: {disabled}; background: {raised}; border-color: {border_soft}; }}
QPushButton[primary="true"] {{ background: {accent}; border: 1px solid {accent}; color: #FFFFFF; font-weight: 600; }}
QPushButton[primary="true"]:hover {{ background: {accent_hover}; border-color: {accent_hover}; }}
QPushButton[primary="true"]:pressed {{ background: {accent_pressed}; border-color: {accent_pressed}; }}
QPushButton[primary="true"]:focus {{ border-color: {accent_pressed}; }}
QPushButton[primary="true"]:disabled {{ background: {raised}; border-color: {border_soft}; color: {disabled}; }}
QPushButton[danger="true"] {{ background: {surface}; border-color: {danger}; color: {danger}; font-weight: 600; }}
QPushButton[danger="true"]:hover {{ background: {danger_soft}; }}
QPushButton::menu-indicator {{ image: url("{icons}/chevron_down.svg"); width: 9px; height: 9px; subcontrol-position: right center; subcontrol-origin: padding; right: 4px; }}
QToolButton[helpButton="true"] {{ background: transparent; border: 1px solid transparent; border-radius: 3px; padding: 3px; }}
QToolButton[helpButton="true"]:hover {{ background: {hover}; border-color: {border_soft}; }}
QToolButton[helpButton="true"]:checked {{ background: {accent_soft}; border-color: {accent_soft_border}; }}

/* ---------- Inputs ---------- */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateTimeEdit, QPlainTextEdit, QTextEdit {{ border: 1px solid {border}; border-radius: 3px; padding: 2px 6px; background: {input}; color: {text}; selection-background-color: {selection}; selection-color: {selection_text}; }}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{ min-height: 20px; }}
QLineEdit:hover, QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover {{ border-color: {border_strong}; }}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QPlainTextEdit:focus, QTextEdit:focus {{ border: 1px solid {focus}; }}
QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled {{ color: {disabled}; background: {raised}; border-color: {border_soft}; }}
QLineEdit:read-only {{ background: {raised}; }}
QComboBox {{ padding-right: 22px; }}
QComboBox::drop-down {{ subcontrol-origin: padding; subcontrol-position: top right; width: 20px; border: none; background: transparent; }}
QComboBox::down-arrow {{ image: url("{icons}/chevron_down.svg"); width: 10px; height: 10px; }}
QComboBox QAbstractItemView {{ background: {surface}; border: 1px solid {border}; selection-background-color: {accent_soft}; selection-color: {text_strong}; outline: 0; padding: 2px; }}
QSpinBox, QDoubleSpinBox {{ padding-right: 18px; }}
QSpinBox::up-button, QDoubleSpinBox::up-button {{ subcontrol-origin: border; subcontrol-position: top right; width: 16px; border: none; border-left: 1px solid {border_soft}; background: transparent; }}
QSpinBox::down-button, QDoubleSpinBox::down-button {{ subcontrol-origin: border; subcontrol-position: bottom right; width: 16px; border: none; border-left: 1px solid {border_soft}; background: transparent; }}
QSpinBox::up-button:hover, QDoubleSpinBox::up-button:hover, QSpinBox::down-button:hover, QDoubleSpinBox::down-button:hover {{ background: {hover}; }}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow {{ image: url("{icons}/chevron_up.svg"); width: 8px; height: 8px; }}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow {{ image: url("{icons}/chevron_down.svg"); width: 8px; height: 8px; }}

QCheckBox, QRadioButton {{ spacing: 6px; color: {text}; background: transparent; }}
QCheckBox:disabled, QRadioButton:disabled {{ color: {disabled}; }}
QCheckBox::indicator, QTreeView::indicator, QListView::indicator, QTableView::indicator {{ width: 13px; height: 13px; border: 1px solid {border_strong}; border-radius: 2px; background: {input}; }}
QCheckBox::indicator:hover, QTreeView::indicator:hover, QListView::indicator:hover {{ border-color: {accent}; }}
QCheckBox::indicator:checked, QTreeView::indicator:checked, QListView::indicator:checked, QTableView::indicator:checked {{ background: {accent}; border-color: {accent}; image: url("{icons}/check_white.svg"); }}
QCheckBox::indicator:indeterminate, QTreeView::indicator:indeterminate, QListView::indicator:indeterminate {{ background: {accent}; border-color: {accent}; image: url("{icons}/dash_white.svg"); }}
QCheckBox::indicator:disabled, QTreeView::indicator:disabled {{ background: {raised}; border-color: {border_soft}; }}
QCheckBox::indicator:checked:disabled, QTreeView::indicator:checked:disabled {{ background: {border_strong}; border-color: {border_strong}; }}
QRadioButton::indicator {{ width: 13px; height: 13px; border: 1px solid {border_strong}; border-radius: 7px; background: {input}; }}
QRadioButton::indicator:hover {{ border-color: {accent}; }}
QRadioButton::indicator:checked {{ border: 1px solid {accent}; background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 {accent}, stop:0.45 {accent}, stop:0.55 {input}, stop:1 {input}); }}

/* ---------- Trees, tables, headers ---------- */
QTreeView, QTreeWidget, QTableView, QTableWidget, QListView, QListWidget {{ border: 1px solid {border_soft}; border-radius: 0; background: {input}; alternate-background-color: {alt_row}; selection-background-color: {selection}; selection-color: {selection_text}; outline: 0; }}
QTreeView::item, QListView::item {{ padding: 3px 4px; border: none; }}
QTreeView::item:hover, QListView::item:hover {{ background: {hover}; }}
QTreeView::item:selected, QListView::item:selected, QTableView::item:selected {{ background: {selection}; color: {selection_text}; }}
QTreeView::branch {{ background: transparent; }}
QTreeView::branch:selected {{ background: {selection}; }}
QTreeView::branch:has-children:!has-siblings:closed, QTreeView::branch:closed:has-children:has-siblings {{ image: url("{icons}/chevron_right.svg"); }}
QTreeView::branch:open:has-children:!has-siblings, QTreeView::branch:open:has-children:has-siblings {{ image: url("{icons}/chevron_down.svg"); }}
QTableView {{ gridline-color: {border_soft}; }}
QHeaderView {{ background: {header}; border: none; }}
QHeaderView::section {{ background: {header}; color: {muted}; font-weight: 600; padding: 5px 6px; border: none; border-right: 1px solid {border_soft}; border-bottom: 1px solid {border}; }}
QHeaderView::section:hover {{ color: {text}; }}
QHeaderView::section:last {{ border-right: none; }}
QTableCornerButton::section {{ background: {header}; border: none; border-bottom: 1px solid {border}; }}

/* ---------- Status, progress, splitters, scrollbars ---------- */
QStatusBar {{ background: {chrome}; border-top: 1px solid {border_soft}; color: {muted}; }}
QStatusBar::item {{ border: none; }}
QStatusBar QLabel {{ padding: 0 10px; color: {muted}; border-left: 1px solid {border_soft}; }}
QProgressBar {{ border: 1px solid {border}; border-radius: 3px; background: {raised}; color: {text}; text-align: center; min-height: 14px; }}
QProgressBar::chunk {{ background: {accent}; border-radius: 2px; }}
QScrollArea {{ background: transparent; }}
QScrollArea > QWidget#qt_scrollarea_viewport {{ background: transparent; }}
QSplitter::handle {{ background: transparent; }}
QSplitter::handle:hover {{ background: {accent_soft_border}; }}
QMainWindow::separator {{ background: {border_soft}; width: 4px; height: 4px; }}
QMainWindow::separator:hover {{ background: {accent_soft_border}; }}
QScrollBar:vertical {{ width: 10px; background: transparent; margin: 0; }}
QScrollBar::handle:vertical {{ background: {scroll}; border-radius: 3px; min-height: 28px; margin: 2px; }}
QScrollBar:horizontal {{ height: 10px; background: transparent; margin: 0; }}
QScrollBar::handle:horizontal {{ background: {scroll}; border-radius: 3px; min-width: 28px; margin: 2px; }}
QScrollBar::handle:hover {{ background: {scroll_hover}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; border: none; background: transparent; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

/* ---------- Tabs ---------- */
QTabWidget::pane {{ border: 1px solid {border_soft}; background: {surface}; top: -1px; }}
QTabBar::tab {{ color: {muted}; background: transparent; border: 1px solid transparent; border-bottom: 2px solid transparent; padding: 5px 12px; margin: 0; }}
QTabBar::tab:hover {{ color: {text}; background: {hover}; }}
QTabBar::tab:selected {{ color: {text_strong}; background: {surface}; border-color: {border_soft}; border-bottom: 2px solid {accent}; }}
QTabBar::tab:disabled {{ color: {disabled}; }}
QTabBar::close-button {{ image: url("{icons}/close.svg"); subcontrol-position: right; border-radius: 2px; margin: 2px; }}
QTabBar::close-button:hover {{ background: {pressed}; }}
QTabBar QToolButton {{ background: {chrome}; border: 1px solid {border_soft}; border-radius: 0; padding: 0; width: 18px; }}
QTabWidget#workspaceTabs::pane {{ border: none; border-top: 1px solid {border_soft}; background: {surface}; top: 0; }}
QTabBar#workspaceTabBar::tab {{ color: {muted}; background: transparent; border: none; border-bottom: 2px solid transparent; border-radius: 0; padding: 8px 10px 7px 10px; margin: 0; font-weight: 400; }}
QTabBar#workspaceTabBar::tab:hover {{ color: {text}; background: {hover}; }}
QTabBar#workspaceTabBar::tab:selected {{ color: {text_strong}; background: transparent; border-bottom: 2px solid {accent}; font-weight: 600; }}
QToolButton#workspaceDetailsButton {{ border: 1px solid {border}; border-radius: 3px; padding: 3px 10px; margin: 3px 4px; background: {surface}; color: {text}; font-weight: 400; }}
QToolButton#workspaceDetailsButton:hover {{ background: {hover}; }}

/* ---------- Command ribbon ---------- */
QFrame#ribbonBar {{ background: {surface}; border: 1px solid {border_soft}; border-radius: 4px; }}
QFrame#ribbonGroup {{ background: transparent; border: none; border-right: 1px solid {border_soft}; }}
QFrame#ribbonGroup[lastGroup="true"] {{ border-right: none; }}
QLabel[ribbonGroupTitle="true"] {{ color: {muted}; font-size: 10px; font-weight: 400; padding: 1px 0 0 0; }}
QToolButton[ribbon="1"] {{ border: 1px solid transparent; border-radius: 3px; padding: 4px 2px 3px 2px; background: transparent; color: {text}; font-size: 11px; font-weight: 400; }}
QToolButton[ribbon="1"]:hover {{ background: {hover}; border-color: {border_soft}; }}
QToolButton[ribbon="1"]:pressed {{ background: {pressed}; }}
QToolButton[ribbon="1"]:focus {{ border-color: {accent_soft_border}; }}
QToolButton[ribbon="1"]:checked {{ background: {accent_soft}; border-color: {accent_soft_border}; color: {accent_text}; }}
QToolButton[ribbon="1"]:disabled {{ background: transparent; border-color: transparent; color: {disabled}; }}
QToolButton[ribbon="1"]::menu-indicator {{ image: url("{icons}/chevron_down.svg"); width: 7px; height: 7px; subcontrol-origin: padding; subcontrol-position: bottom right; right: 4px; bottom: 4px; }}
QFrame#controlRibbon {{ background: {raised}; border: 1px solid {border_soft}; border-radius: 4px; }}
QFrame#controlRibbon QCheckBox {{ spacing: 5px; }}
QFrame#controlRibbon QLabel[compactLabel="true"] {{ color: {muted}; font-size: 10px; font-weight: 500; }}
QFrame#controlRibbon QDoubleSpinBox, QFrame#controlRibbon QSpinBox, QFrame#controlRibbon QComboBox {{ min-height: 22px; padding: 1px 6px; }}
QFrame#controlRibbon QPushButton {{ min-height: 22px; padding: 2px 8px; }}

/* ---------- Panels ---------- */
QFrame#sidePanel, QFrame#workspacePanel {{ background: {surface}; border: 1px solid {border_soft}; border-radius: 4px; }}
QFrame#workspaceTopBar {{ background: {raised}; border: 1px solid {border_soft}; border-radius: 3px; }}
QGroupBox {{ background: {surface}; border: 1px solid {border_soft}; border-radius: 4px; margin-top: 16px; padding: 10px 8px 8px 8px; }}
QGroupBox::title {{ subcontrol-origin: margin; subcontrol-position: top left; left: 8px; padding: 0 4px; color: {muted}; font-weight: 600; }}
QFrame#summaryStrip {{ background: {raised}; border: 1px solid {border_soft}; border-radius: 3px; }}
QFrame#summaryCell {{ border: none; border-right: 1px solid {border_soft}; }}
QLabel[summaryCaption="true"] {{ color: {faint}; font-size: 10px; font-weight: 500; }}
QLabel[summaryValue="true"] {{ color: {text_strong}; font-size: 12px; font-weight: 600; }}
QFrame#controlsDock {{ background: {surface}; border: 1px solid {border_soft}; border-radius: 4px; }}
QFrame#controlsHeader {{ background: {header}; border: none; border-bottom: 1px solid {border_soft}; border-top-left-radius: 4px; border-top-right-radius: 4px; }}
QFrame#controlsHeader QToolButton {{ border: 1px solid transparent; background: transparent; padding: 2px; }}
QFrame#controlsHeader QToolButton:hover {{ background: {hover}; border-color: {border_soft}; }}
QToolButton#btnCtrlCollapse {{ border: none; border-radius: 3px; padding: 4px 6px; background: transparent; color: {text_strong}; font-weight: 600; text-align: left; }}
QToolButton#btnCtrlCollapse:hover {{ background: {hover}; }}
QFrame#plotQuickbar {{ background: {surface}; border: 1px solid {border_soft}; border-radius: 4px; }}
QToolButton[qb="1"] {{ border: 1px solid {border}; border-radius: 3px; padding: 0px; background: {surface}; }}
QToolButton[qb="1"]:hover {{ background: {hover}; }}
QToolButton[qb="1"]:pressed {{ background: {pressed}; }}
QToolButton[qb="1"]:checked {{ background: {accent_soft}; border-color: {accent_soft_border}; }}
QToolButton[qb="1"]:disabled {{ background: {raised}; border-color: {border_soft}; }}
QDockWidget {{ color: {text_strong}; titlebar-close-icon: url("{icons}/close.svg"); titlebar-normal-icon: url("{icons}/detach.svg"); }}
QDockWidget::title {{ background: {header}; border: 1px solid {border_soft}; padding: 5px 8px; text-align: left; }}
QDockWidget::close-button, QDockWidget::float-button {{ border: none; background: transparent; padding: 1px; }}
QDockWidget::close-button:hover, QDockWidget::float-button:hover {{ background: {hover}; }}

/* ---------- Page chrome ---------- */
QLabel[pageTitle="true"] {{ color: {text_strong}; font-size: 15px; font-weight: 600; padding: 0; }}
QLabel[pageHelp="true"] {{ background: {raised}; color: {muted}; border: 1px solid {border_soft}; border-left: 3px solid {accent}; padding: 8px 12px; }}
QFrame#legacyOffsets {{ background: {warn_bg}; border: 1px solid {warn_border}; border-radius: 3px; }}
QFrame#legacyOffsets QLabel {{ color: {warn_text}; }}
QFrame#plotEmptyState {{ background: {surface}; border: none; }}
QLabel#emptyTitle {{ color: {text_strong}; font-size: 18px; font-weight: 600; }}
QLabel#emptySubtitle {{ color: {muted}; font-size: 12px; }}
QLabel#emptyMark {{ color: {accent}; }}

/* ---------- Analysis cards ---------- */
QFrame#valveCard {{ background: {raised}; border: 1px solid {border_soft}; border-left: 3px solid {accent}; border-radius: 3px; }}
QFrame#valveCard[issue="true"] {{ background: {warn_bg}; border-color: {warn_border}; border-left: 3px solid {warn_border}; }}
QLabel[valveCardTitle="true"] {{ color: {muted}; font-size: 11px; font-weight: 600; }}
QLabel[valveCardValue="true"] {{ color: {text_strong}; font-size: 19px; font-weight: 600; }}
QLabel[valveCardDetail="true"], QLabel[valveHint="true"] {{ color: {muted}; }}
QFrame#valveNotice {{ background: {warn_bg}; border: 1px solid {warn_border}; border-radius: 3px; }}
QFrame#valveNotice QLabel {{ color: {warn_text}; }}
"""
