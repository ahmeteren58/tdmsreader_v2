"""Known time shifts, bounded analysis, raw data integrity and GUI regressions."""
from dataclasses import replace
import csv
import time
from pathlib import Path

import numpy as np
import pytest
from nptdms import ChannelObject
from PyQt6.QtCore import Qt

import test_regressions as base
import tdmsreader as m
import tdms_alignment as a
from tdms_export import ExportOptions, _Channel, export_snapshot, write_csv, ExportCancelled
from tdms_project import save_project_archive, load_project_archive
from tdms_ui import CsvExportDialog

app = base.app
base_window = base.window


@pytest.fixture
def window(base_window):
    # Retired controls are tested as a compatibility component, not a main tab.
    from tdms_alignment_ui import AlignmentMixin
    AlignmentMixin._init_alignment(base_window, build_ui=True)
    return base_window


def wave(t):
    return np.exp(-((t-.7)/.07)**2)+.6*np.exp(-((t-1.4)/.12)**2)-.3*np.exp(-((t-2.1)/.03)**2)


def source(name, fs=5000., delay=0., digital=False, start=0., mode='seconds', offset=0.):
    t=np.arange(int(3*fs)+1)/fs
    y=((t>=1+delay)&(t<1.5+delay)).astype(float) if digital else wave(t-delay)
    s=base.memory_source(name,y,start+t,mode=mode)
    s.update(fs_hz=fs,x_base=start,x_inc=1/fs,alignment_offset=offset,is_digital=digital)
    return s


@pytest.mark.parametrize('direction',['rising','falling'])
@pytest.mark.parametrize('delay',[-.0014,.0014,.012])
@pytest.mark.parametrize('epoch,mode',[(0.,'seconds'),(1792051200.,'datetime')])
def test_edge_offset_sign_and_exact_sample_times(direction,delay,epoch,mode):
    s=[source('Ref',5000,digital=True,start=epoch,mode=mode),
       source('Target',10000,delay,True,epoch,mode)]
    r=a.estimate_edges(s,(epoch+.1,epoch+2.),direction)
    assert r['offset_s']==pytest.approx(-delay,abs=1/5000+1e-7)
    for event,channel in zip(r['events'],s):
        assert event['time'] in channel['x']


def test_existing_reference_and_target_offsets_are_not_double_applied():
    s=[source('Ref',digital=True,offset=.01),source('Target',delay=.0014,digital=True,offset=-.003)]
    r=a.estimate_edges(s,(.1,2.))
    assert r['offset_s']==pytest.approx(.01-.0014)
    s[1]['alignment_offset']=r['offset_s']
    r2=a.estimate_edges(s,(.1,2.))
    assert r2['offset_s']==pytest.approx(r['offset_s'])
    assert abs(r2['residual_s'])<1e-12


def test_edge_at_start_boundary_has_real_preceding_sample():
    s=[source('Ref',digital=True),source('Target',delay=.0014,digital=True)]
    assert a.estimate_edges(s,(1.,2.))['offset_s']==pytest.approx(-.0014)


@pytest.mark.parametrize('kind',['zero','one','nan','analog'])
def test_invalid_edge_data_are_clean_errors(kind):
    s=[source('Sync',digital=True),source('Target',digital=True)]
    if kind=='zero': s[0]['y'][:]=0
    if kind=='one': s[0]['y'][:]=1
    if kind=='nan': s[0]['y'][:]=np.nan
    if kind=='analog': s[0]['y'][20]=.7
    with pytest.raises(ValueError,match='No valid rising/falling|yalnız 0/1'):
        a.estimate_edges(s,(0.,3.))


def test_edge_does_not_bridge_a_nan_or_time_gap():
    s=[source('Ref',digital=True),source('Target',digital=True)]
    s[0]['y'][4999]=np.nan
    with pytest.raises(ValueError,match='No valid'):
        a.estimate_edges(s,(0.,1.3))
    s=[source('Ref',digital=True),source('Target',digital=True)]
    keep=(s[0]['x']<.999)|(s[0]['x']>=1.001)
    s[0].update(x=s[0]['x'][keep],y=s[0]['y'][keep],n=int(keep.sum()))
    with pytest.raises(ValueError,match='No valid'):
        a.estimate_edges(s,(0.,1.3))


@pytest.mark.parametrize('rates',[(5000,5000),(2000,7000),(1000,5000)])
@pytest.mark.parametrize('delay',[-.0123,.0022,.014])
def test_analog_correlation_recovers_known_offset_and_score(rates,delay):
    s=[source('Ref',rates[0]),source('Target',rates[1],delay)]
    x=[v['x'].copy() for v in s]; y=[v['y'].copy() for v in s]
    r=a.estimate_correlation(s,(.1,2.9),.05)
    assert r['offset_s']==pytest.approx(-delay,abs=r['resolution_s']*.1)
    assert r['score']>.99
    assert r['points']<=32768
    for i in range(2):
        np.testing.assert_array_equal(s[i]['x'],x[i]); np.testing.assert_array_equal(s[i]['y'],y[i])


def test_correlation_handles_utc_and_existing_offsets():
    epoch=1792051200.
    s=[source('Ref',5000,start=epoch,mode='datetime',offset=.01),
       source('Target',7000,.0022,start=epoch,mode='datetime',offset=-.002)]
    r=a.estimate_correlation(s,(epoch+.1,epoch+2.9),.05)
    assert r['offset_s']==pytest.approx(.01-.0022,abs=.00005)
    assert r['score']>.99


def test_digital_interpolation_is_zero_order_hold():
    s=source('Digital',fs=100,digital=True)
    ch=_Channel(s,None,ExportOptions())
    grid=np.array([.995,1.,1.005,1.495,1.5,1.505])
    y,digital=a._sample_grid(ch,s,grid,lambda:False)
    assert digital
    np.testing.assert_array_equal(y,[0,1,1,1,0,0])


@pytest.mark.parametrize('kind',['constant','nan','index','mixed','duplicate','range','resolution'])
def test_correlation_rejects_insufficient_or_invalid_data(kind):
    s=[source('Ref'),source('Target')]; bounds=(.1,2.9); search=.05
    if kind=='constant': s[0]['y'][:]=1.
    if kind=='nan': s[0]['y'][:]=np.nan
    if kind=='index': s[0]['x_mode']='index'
    if kind=='mixed': s[0]['x_mode']='datetime'
    if kind=='duplicate': s[1]['key']=s[0]['key']
    if kind=='range': bounds=(1.,.1)
    if kind=='resolution': search=.00001
    with pytest.raises(ValueError): a.estimate_correlation(s,bounds,search)


def test_correlation_read_volume_is_bounded_for_huge_source(monkeypatch):
    sources=[]; calls=[]
    class HugeChannel:
        ch=True
        n=100_000_001
        def __init__(self, s): self.s=s
        def block(self,start,stop):
            calls.append(stop-start)
            idx=np.arange(start,stop); x=idx*self.s['x_inc']
            return idx,x,wave(x-self.s['delay'])
    for name,delay in [('Ref',0.),('Target',.02)]:
        s=source(name)
        s.update(path='synthetic-large.tdms',n=100_000_001,fs_hz=2e6,x_inc=1/2e6,delay=delay,x=np.array([]),y=np.array([]))
        sources.append(s)
    monkeypatch.setattr(a,'_channels',lambda stack,sources,bounds=None:[HugeChannel(s) for s in sources])
    r=a.estimate_correlation(sources,(0.,3.),.05,max_points=2048)
    assert r['offset_s']==pytest.approx(-.02,abs=.0002)
    assert max(calls)<=65536
    assert sum(calls)<=4*2048
    assert r['points']<=2048


def test_manager_state_is_separate_and_reset_restores_original_style():
    manager=a.ChannelAlignmentManager(); styles={'a':{'x_shift':.3,'width':2.}}
    series=[{'style_key':'a','x_mode':'seconds'}]
    assert manager.display_styles(styles,series) is styles
    manager.set_offsets({'a':-.0012})
    view=manager.display_styles(styles,series)
    assert a.display_time_shift(view['a'])==pytest.approx(.2988)
    assert styles=={'a':{'x_shift':.3,'width':2.}}
    assert manager.snapshot()=={'a':-.0012}
    manager.set_offsets({'a':0.})
    assert manager.display_styles(styles,series) is styles
    with pytest.raises(ValueError): manager.restore({'a':float('nan')})


@pytest.mark.parametrize('layout',['wide','long'])
@pytest.mark.parametrize('aligned',[False,True])
@pytest.mark.parametrize('shifts',[False,True])
def test_csv_original_and_aligned_options_are_independent(tmp_path,layout,aligned,shifts):
    s=source('Pressure',fs=100.)
    s.update(alignment_offset=.0014,x_shift=.1,y_shift=3.)
    path=tmp_path/'output.csv'
    write_csv(path,[s],ExportOptions(layout=layout,export_aligned=aligned,apply_shifts=shifts))
    rows=list(csv.reader(path.read_text(encoding='utf-8-sig').splitlines(),delimiter=';'))
    xs=[float(r[0] if layout=='wide' else r[-2]) for r in rows[1:]]
    ys=[float(r[1] if layout=='wide' else r[-1]) for r in rows[1:]]
    np.testing.assert_allclose(xs,s['x']+(.0014 if aligned else 0.)+(.1 if shifts else 0.))
    np.testing.assert_allclose(ys,s['y']+(3 if shifts else 0.))


def test_csv_displayed_range_and_lazy_timestamps(tmp_path):
    n=1001; path=base.tdms_file(tmp_path,[ChannelObject('G','A',np.arange(n),{'wf_increment':.001})])
    s=source('A',1000.)
    s.update(path=str(path),group='G',channel='A',n=n,x=np.array([]),y=np.array([]),alignment_offset=.01)
    dest=tmp_path/'a.csv'
    write_csv(dest,[s],ExportOptions(export_aligned=True,x_range=(.02,.023)))
    rows=list(csv.reader(dest.read_text(encoding='utf-8-sig').splitlines(),delimiter=';'))
    np.testing.assert_allclose([float(r[0]) for r in rows[1:]],[.02,.021,.022,.023])
    assert [int(r[1]) for r in rows[1:]]==[10,11,12,13]


def populate(w,app,digital=False):
    sources=[source('Sync' if digital else 'Reference',digital=digital),
             source('Target',delay=.0014 if digital else .0022,digital=digital)]
    w.current_series=[]
    for s in sources:
        w.current_series.append(dict(style_key=s['key'],name=s['name'],unit='',file_label='Test',
            x=s['x'],y=s['y'],fs_est=s['fs_hz'],sample_count=s['n'],x_mode=s['x_mode'],is_digital=digital,
            source_x_mode=s['x_mode'],source_x_base=s['x_base'],source_x_inc=s['x_inc']))
    w._refresh_series_comboboxes();w.update_plot_data_with_filter();base.wait_jobs(w,app)
    return sources


def select_pair(w):
    w.alignment_reference.setCurrentIndex(1); w.alignment_target.setCurrentIndex(2)
    w.alignment_a.setValue(.1);w.alignment_b.setValue(2.9)


def test_gui_manual_multiple_offsets_apply_without_refilter_and_exact_reset(window,app,monkeypatch):
    sources=populate(window,app)
    raw=[(s['x'],s['y']) for s in window.current_series]
    curve=window.plot_pane._curve_items['Target']; old_x=curve.xData.copy(); old_y=curve.yData.copy()
    span=window._current_xrange()
    monkeypatch.setattr(window,'update_plot_data_with_filter',lambda:pytest.fail('Alignment must not recompute filters'))
    window._alignment_apply_offsets({'Target':.0014})
    np.testing.assert_allclose(curve.xData,old_x+.0014)
    assert window.plot_pane._curve_items['Target'] is curve
    np.testing.assert_array_equal(curve.yData,old_y)
    assert window._current_xrange()==pytest.approx(span)
    for s,(x,y) in zip(window.current_series,raw):
        assert s['x'] is x and s['y'] is y
    window._alignment_reset_all()
    np.testing.assert_array_equal(curve.xData,old_x)
    for i in range(window.alignment_tree.topLevelItemCount()): window.alignment_tree.topLevelItem(i).setSelected(True)
    window.alignment_value.setValue(-1.2);window._alignment_apply_manual()
    assert window.alignment_manager.snapshot()=={'Reference':-.0012,'Target':-.0012}
    window.alignment_unit.setCurrentIndex(1)
    assert window.alignment_value.value()==pytest.approx(-.0012)
    window.alignment_unit.setCurrentIndex(0)
    assert window.alignment_value.value()==pytest.approx(-1.2)
    window.alignment_value.setValue(.000001)
    window.alignment_unit.setCurrentIndex(1)
    assert window.alignment_value.value()==pytest.approx(1e-9)


def test_gui_estimate_never_applies_until_click_and_sync_is_not_auto_selected(window,app):
    populate(window,app,digital=True)
    assert window.alignment_reference.currentData() is None
    select_pair(window);window._alignment_estimate_run();base.wait_jobs(window,app)
    assert window.alignment_manager.snapshot()=={}
    assert window._alignment_estimate[1]['offset_s']==pytest.approx(-.0014)
    assert window.alignment_apply_button.isEnabled()
    window._alignment_apply_estimate()
    assert window.alignment_manager.offset('Target')==pytest.approx(-.0014)
    assert not window.alignment_apply_button.isEnabled()
    window._alignment_estimate_run();base.wait_jobs(window,app)
    assert abs(window._alignment_estimate[1]['residual_s'])<1e-12


def test_gui_constant_sync_fails_without_crash_or_offset(window,app):
    populate(window,app,digital=True);window.current_series[0]['y'][:]=0
    select_pair(window);window._alignment_estimate_run();base.wait_jobs(window,app)
    assert 'No valid rising/falling' in window.alignment_status.text()
    assert not window.alignment_apply_button.isEnabled() and not window.alignment_manager.snapshot()


def test_gui_correlation_and_estimate_invalidation(window,app):
    populate(window,app);select_pair(window)
    window.alignment_method.setCurrentIndex(1)
    window._alignment_estimate_run();base.wait_jobs(window,app)
    assert window._alignment_estimate[1]['offset_s']==pytest.approx(-.0022,abs=.00002)
    assert 'Correlation score:' in window.alignment_quality.text()
    window.alignment_search.setValue(70.)
    assert window._alignment_estimate is None and not window.alignment_apply_button.isEnabled()


def test_alignment_does_not_change_valve_sources_or_algorithm(window,app):
    populate(window,app,digital=True)
    window.valve_open.setCurrentIndex(1);window.valve_closed.setCurrentIndex(2)
    before=window._valve_sources()
    window._alignment_apply_offsets({'Sync':.1,'Target':-.05})
    after=window._valve_sources()
    for b,c in zip(before,after):
        assert b['x'] is c['x'] and b['y'] is c['y']
        assert b['x_shift']==c['x_shift']==0.
        assert 'alignment_offset' not in c


def test_ab_and_range_measurements_match_aligned_plot(window,app):
    populate(window,app)
    window._alignment_apply_offsets({'Target':.1})
    requests=window._range_stats_requests()
    assert requests[1]['x_shift']==.1
    sources=window._inspection_sources()
    assert sources[1]['x_shift']==.1
    assert window._series_full_x_bounds(window.current_series[1])==pytest.approx((.1,3.1))
    # Style reset is independent of the alignment state.
    window.reset_all_styles();base.wait_jobs(window,app)
    assert window.alignment_manager.offset('Target')==.1


def test_csv_option_is_off_by_default(app):
    dialog=CsvExportDialog([source('a')],{'a'},None)
    assert not dialog.options().export_aligned
    dialog.aligned.setChecked(True);assert dialog.options().export_aligned
    dialog.deleteLater()


def test_estimate_cancellation_and_time_edit_reject_stale_result(window,app,monkeypatch):
    import tdms_alignment_ui as ui
    populate(window,app);select_pair(window)
    def delayed(sources,bounds,direction,cancel):
        while not cancel(): time.sleep(.002)
        raise ExportCancelled()
    monkeypatch.setattr(ui,'estimate_edges',delayed)
    window._alignment_estimate_run()
    window.channel_fs_overrides['Target']=4000.
    window._apply_channel_timing();base.wait_jobs(window,app)
    assert window._alignment_estimate is None and not window.alignment_apply_button.isEnabled()


def test_lazy_zoom_alignment_uses_shifted_raw_range_and_resets(window,app,tmp_path,monkeypatch):
    n=200_001;fs=10000.;y=np.sin(np.arange(n)*.017)
    path=base.tdms_file(tmp_path,[ChannelObject('G','A',y,{'wf_increment':1/fs})])
    import hashlib
    original_hash=hashlib.sha256(path.read_bytes()).digest()
    monkeypatch.setattr(m,'CFG',replace(m.CFG,lazy=replace(m.CFG.lazy,fullload_threshold=10)))
    window._on_load_ready(base.load(path,[('G','A',n)]));base.wait_jobs(window,app)
    s=window.current_series[0]; key=s['style_key'];assert s['lazy']
    window._alignment_apply_offsets({key:.1})
    window.plot_pane.set_xrange(1.,1.01);window._lazy_view_timer.stop();window._run_lazy_view_update();base.wait_jobs(window,app)
    curve=window.plot_pane._curve_items[key]
    indices=np.rint((curve.xData-.1)*fs).astype(int)
    np.testing.assert_allclose(curve.xData,indices/fs+.1)
    np.testing.assert_array_equal(curve.yData,y[indices])
    assert indices.min()<=9000 and indices.max()>=9100 and len(indices)<5000
    window._alignment_reset_all()
    window._lazy_view_timer.stop();window._run_lazy_view_update();base.wait_jobs(window,app)
    indices=np.rint(curve.xData*fs).astype(int)
    np.testing.assert_allclose(curve.xData,indices/fs)
    np.testing.assert_array_equal(curve.yData,y[indices])
    assert indices.min()<=10000 and indices.max()>=10100 and len(indices)<5000
    assert hashlib.sha256(path.read_bytes()).digest()==original_hash


def test_alignment_project_round_trip_and_old_project_default(window,app,tmp_path):
    path=base.tdms_file(tmp_path,[ChannelObject('G','A',np.arange(101),{'wf_increment':.01})])
    window.open_tdms_path(str(path));base.wait_jobs(window,app)
    state=next(iter(window.files.values()))
    state.tree.topLevelItem(0).child(0).setCheckState(0,Qt.CheckState.Checked)
    window.plot_checked_channels();base.wait_jobs(window,app)
    key=window.current_series[0]['style_key']
    window._alignment_apply_offsets({key:.0014})
    dest=tmp_path/'aligned.tdmsproj';manifest,arrays=window._project_manifest(str(dest))
    save_project_archive(dest,manifest,arrays)
    payload=load_project_archive(str(dest),m.MultiTdmsChannelLoadWorker,m.ChannelRequest,m.ChannelKey)
    window._apply_project(payload);base.wait_jobs(window,app)
    assert window.alignment_manager.offset(key)==.0014
    payload['manifest'].pop('alignments')
    window._apply_project(payload);base.wait_jobs(window,app)
    assert window.alignment_manager.snapshot()=={}


def test_flat_trends_are_not_claimed_as_unique_correlation_offset():
    s=[source('Reference'),source('Target')]
    for ch in s:ch['y']=3.*ch['x']+2.
    with pytest.raises(ValueError,match='tepe.*ayırt'):
        a.estimate_correlation(s,(.1,2.9),.05)


def test_periodic_correlation_gives_ambiguity_warning():
    s=[source('Reference'),source('Target')]
    for ch in s:ch['y']=np.sin(2*np.pi*100*ch['x'])
    r=a.estimate_correlation(s,(.1,2.9),.05)
    assert r['score']>.99
    assert any('Birden fazla' in warning for warning in r['warnings'])


def test_stacked_detached_and_visual_shift_remain_independent(window,app):
    populate(window,app)
    window.style_map['Target']={'x_shift':.01,'y_shift':2.}
    window.update_plot_data_with_filter();base.wait_jobs(window,app)
    window.toggle_detach_plot();base.wait_jobs(window,app)
    window.cmb_plot_mode.setCurrentText('Stacked');base.wait_jobs(window,app)
    stack=window.stacked_view._entries[1]['curve']
    detached=window.detached_win.pane._curve_items['Target']
    original_stack=stack.xData.copy(); original_detached=detached.xData.copy()
    original_y=stack.yData.copy()
    window._alignment_apply_offsets({'Target':-.0014})
    np.testing.assert_allclose(stack.xData,original_stack-.0014)
    np.testing.assert_allclose(detached.xData,original_detached-.0014)
    np.testing.assert_array_equal(stack.yData,original_y)
    assert window.style_map['Target']=={'x_shift':.01,'y_shift':2.}
    window._alignment_reset_all()
    np.testing.assert_array_equal(stack.xData,original_stack)
    np.testing.assert_array_equal(detached.xData,original_detached)
