import threading
import time
from contextlib import contextmanager
import numpy as np
from nptdms import ChannelObject
from PyQt6.QtCore import QPoint, QPointF, Qt
from PyQt6.QtGui import QContextMenuEvent
from PyQt6.QtWidgets import QApplication, QMenu
import tdmsreader as m
import test_regressions as base
from tdms_viewport import ArrayChannel, ViewCache, read_preview

app = base.app
window = base.window


def test_ram_zoom_refines_without_recreating_curves_or_modifying_source(window, app, tmp_path):
    n = 200_000
    y = np.sin(np.arange(n) * .13)
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", y, properties={"wf_increment": .001})])
    window._on_load_ready(base.load(path, [("G", "A", n)]))
    base.wait_jobs(window, app)
    pane = window.plot_pane
    initial_span = np.diff(pane.plot.getViewBox().viewRange()[0])[0]
    assert np.isclose(float(window.lbl_ws_range.text().split()[0]), initial_span, rtol=1e-5)
    curve, legend = pane._left_items[0], pane.legend
    pane.set_axis_ranges({"x": (1., 1.01), "y": (-.5, .5)})
    window._lazy_view_timer.stop()
    window._run_lazy_view_update()
    base.wait_jobs(window, app)
    assert pane._left_items[0] is curve and pane.legend is legend
    np.testing.assert_array_equal(curve.xData, np.arange(999, 1012)*.001)
    np.testing.assert_array_equal(curve.yData, y[999:1012])
    np.testing.assert_allclose(pane.plot.getViewBox().viewRange(), [[1, 1.01], [-.5, .5]])
    assert len(window.current_series[0]["y"]) == n
    assert not window._lazy_view_timer.isActive()  # No range-restore/read loop.
    window._autofit_all_panes()
    base.wait_jobs(window, app)
    np.testing.assert_allclose(pane.plot.getViewBox().viewRange()[0], [0, (n-1)*.001])
    assert pane.plot.getViewBox().viewRange()[1][0] < -.99
    assert pane.plot.getViewBox().viewRange()[1][1] > .99


def test_exact_view_cache_skips_disk_for_contained_zoom(tmp_path, monkeypatch):
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", np.arange(200_000))])
    cache = ViewCache()
    request = dict(style_key="a", path=str(path), group="G", channel="A", n=200_000,
                   x_mode="index", x_base=0., x_inc=1., x0=5000., x1=6000.)
    original = m._open_tdms
    opened = []
    @contextmanager
    def tracked(path):
        opened.append(path)
        with original(path) as tdms:
            yield tdms
    monkeypatch.setattr(m, "_open_tdms", tracked)
    a = base.worker_result(m.LazyViewLoadWorker([request], 80_000, cache))
    b = base.worker_result(m.LazyViewLoadWorker([dict(request, x0=5200., x1=5500.)], 80_000, cache))
    assert not a["errors"] and not b["errors"] and len(opened) == 1
    assert b["updates"]["a"]["exact"]
    np.testing.assert_array_equal(b["updates"]["a"]["x"], b["updates"]["a"]["y"])


def test_lazy_duration_and_full_fit_survive_narrow_zoom(window, app, tmp_path):
    n = 1_000_000
    y = np.sin(np.arange(n)*.001)
    y[900_001] = 7.
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", y, properties={"wf_increment": .0002})])
    window._on_load_ready(base.load(path, [("G", "A", n)]))
    base.wait_jobs(window, app)
    window._update_workspace_summary()
    duration = window.lbl_ws_duration.text()
    window.plot_pane.set_xrange(2., 2.1)
    window._lazy_view_timer.stop()
    window._run_lazy_view_update()
    base.wait_jobs(window, app)
    assert window.current_series[0]["_sample_indices"][0] > 0
    window._update_workspace_summary()
    assert window.lbl_ws_duration.text() == duration
    window._autofit_all_panes()
    base.wait_jobs(window, app)
    assert window.plot_pane.plot.getViewBox().viewRange()[1][1] >= 7.
    np.testing.assert_allclose(window.plot_pane.plot.getViewBox().viewRange()[0], [0., (n-1)*.0002])


def test_metadata_preview_debounces_and_reuses_same_channel(window, app, tmp_path):
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", np.arange(100))])
    window.open_tdms_path(str(path))
    base.wait_jobs(window, app)
    fid, state = next(iter(window.files.items()))
    state.tree.setCurrentItem(state.tree.topLevelItem(0).child(0))
    window.on_selection_changed(fid)
    assert window._preview_timer.isActive()
    window._preview_timer.stop()
    window._run_channel_preview()
    base.wait_jobs(window, app)
    assert len(window._preview_cache) == 1
    window.on_selection_changed(fid)
    assert not window._preview_timer.isActive()
    assert not any(tag == "preview" for _, _, tag in window._jobs)


def test_digital_edges_are_exact_across_blocks_and_cache_is_bounded():
    y = np.zeros(300_000)
    y[65_536:123_457] = 1
    y[220_019:] = 1
    idx, values, exact = read_preview(ArrayChannel(y), 0, len(y), 1000, True)
    np.testing.assert_array_equal(idx, [0, 65_536, 123_457, 220_019, 299_999])
    np.testing.assert_array_equal(values, y[idx])
    assert exact
    cache = ViewCache(max_bytes=160)
    cache.put("a", 0, 300_000, 1000, (idx, values, exact))
    cache.put("b", 0, 300_000, 1000, (idx, values, exact))
    cache.put("c", 0, 300_000, 1000, (idx, values, exact))
    assert cache.bytes <= 160 and len(cache.entries) == 2


def test_initial_full_overview_does_not_reopen_tdms(tmp_path, monkeypatch):
    n = 300_000
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", np.sin(np.arange(n)*.01))])
    s = base.load(path, [("G", "A", n)])["series"][0]
    request = dict(s["lazy_meta"], style_key=s["style_key"], x0=0., x1=float(n-1),
                   overview=(s["_overview_indices"], s["_overview_y"], s["_overview_exact"]),
                   source_fingerprint=s["source_fingerprint"])
    def forbidden(*args):
        raise AssertionError("Initial overview was read twice")
    monkeypatch.setattr(m, "_open_tdms", forbidden)
    payload = base.worker_result(m.LazyViewLoadWorker([request], 80_000))
    assert not payload["errors"]
    assert len(payload["updates"][s["style_key"]]["y"]) == len(s["y"])


def test_latest_view_waits_for_previous_reader(window, app):
    gate = threading.Event()
    class BlockingRead(m.CancellableWorker):
        def run(self):
            gate.wait(2)
            self.finished.emit({"cancelled": self.is_cancelled})
    s = dict(style_key="a", name="A", x=np.arange(100.), y=np.arange(100.), x_mode="index")
    window.current_series = [s]
    window._last_display_series = [s]
    window._start_job(BlockingRead(), lambda p: None, tag="lazy_view")
    window._schedule_lazy_view_update(10, 20)
    window._schedule_lazy_view_update(30, 40)
    window._lazy_view_timer.stop()
    window._run_lazy_view_update()
    assert len([j for j in window._jobs if j[2] == "lazy_view"]) == 1
    assert window._lazy_view_pending == (30., 40.)
    gate.set()
    deadline = time.monotonic()+3
    while (window._jobs or window._lazy_view_pending) and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(.002)
    assert not window._jobs and window._lazy_view_pending is None


def test_right_drag_scales_and_only_ctrl_right_opens_menu(window, app):
    window.show()
    pane = window.plot_pane
    pane.plot_series([dict(style_key="a", name="A", x=np.arange(100.), y=np.arange(100.))], "numeric", "X")
    app.processEvents()
    widget = pane.plot
    point = QPoint(150, 100)
    def menu_event(modifiers=Qt.KeyboardModifier.NoModifier):
        event = QContextMenuEvent(QContextMenuEvent.Reason.Mouse, point, widget.viewport().mapToGlobal(point), modifiers)
        QApplication.sendEvent(widget.viewport(), event)
        app.processEvents()
    menu_event()
    assert not any(isinstance(w, QMenu) and w.isVisible() for w in QApplication.topLevelWidgets())
    vb = widget.getViewBox()
    before = vb.viewRange()[0]
    class Drag:
        def accept(self): pass
        def pos(self): return QPointF(130, 100)
        def lastPos(self): return QPointF(100, 100)
        def screenPos(self): return self.pos()
        def lastScreenPos(self): return self.lastPos()
        def button(self): return Qt.MouseButton.RightButton
        def buttonDownPos(self, *_): return QPointF(100, 100)
    vb.mouseDragEvent(Drag(), axis=0)
    assert vb.viewRange()[0] != before
    menu_event(Qt.KeyboardModifier.ControlModifier)
    menus = [w for w in QApplication.topLevelWidgets() if isinstance(w, QMenu) and w.isVisible()]
    assert len(menus) == 1
    menus[0].close()
