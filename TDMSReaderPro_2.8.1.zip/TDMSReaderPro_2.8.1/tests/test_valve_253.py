"""Accuracy of valve timing against known physical edge times, and automatic setup."""
from pathlib import Path
import statistics
import numpy as np
import pytest
from nptdms import ChannelObject, TdmsFile
from PyQt6.QtCore import Qt
import test_regressions as base
from test_valve import source
from tdms_valve import ValveOptions, SignalOptions, analyze_valve, _duration_cmp
from tdms_valve_auto import auto_analyze, filter_time, profile_levels
from tdms_export import _Channel, ExportOptions

app = base.app
window = base.window

EXAMPLES = Path(__file__).resolve().parents[1]/'examples'
ROLES = {'position': ('open', 'closed'), 'command_closed': ('command', 'closed'), 'command_open': ('command', 'open')}


def cycles(seed, n=6):
    """Continuous edge times of command and both position sensors for n cycles."""
    rng = np.random.default_rng(seed)
    t, out = .2371, []
    for _ in range(n):
        c = {'cmd_on': t}
        c['leave_closed'] = c['cmd_on']+rng.uniform(.020, .045)
        c['arrive_open'] = c['leave_closed']+rng.uniform(.060, .140)
        c['cmd_off'] = c['arrive_open']+rng.uniform(.25, .5)
        c['leave_open'] = c['cmd_off']+rng.uniform(.020, .045)
        c['arrive_closed'] = c['leave_open']+rng.uniform(.080, .160)
        out.append(c); t = c['arrive_closed']+rng.uniform(.25, .5)
    return out, t+.3


def truth(mode, c):
    return {'position': (c['arrive_open']-c['leave_closed'], c['arrive_closed']-c['leave_open']),
            'command_closed': (c['leave_closed']-c['cmd_on'], c['arrive_closed']-c['cmd_off']),
            'command_open': (c['arrive_open']-c['cmd_on'], c['leave_open']-c['cmd_off'])}[mode]


def sampled(kind, edges, fs, end):
    t = np.arange(int(end*fs)+1)/fs
    y = np.ones(len(t)) if kind == 'closed' else np.zeros(len(t))
    for c in edges:
        a, b = {'command': ('cmd_on', 'cmd_off'), 'open': ('arrive_open', 'leave_open'),
                'closed': ('leave_closed', 'arrive_closed')}[kind]
        y[(t >= c[a]) & (t < c[b])] = 0 if kind == 'closed' else 1
    return y


def record(mode, edges, end, fs=(1000, 1000), analog=None, inverted=(False, False), seed=0):
    rng = np.random.default_rng(seed)
    out = []
    for j, kind in enumerate(ROLES[mode]):
        y = sampled(kind, edges, fs[j], end)
        if inverted[j]:
            y = 1-y
        if analog:
            low, high, noise = analog
            y = low+(high-low)*y+rng.normal(0, noise, len(y))
        out.append(source(kind, y, fs[j]))
    return out


def assert_accurate(result, mode, edges, fs):
    events = result['events']
    assert [e['status'] for e in events] == ['complete']*len(events)
    assert [e['direction'] for e in events] == ['opening', 'closing']*len(edges)
    step = 1/min(fs)
    for i, c in enumerate(edges):
        for e, expected in zip(events[2*i:2*i+2], truth(mode, c)):
            assert e['lower']-1e-12 <= expected <= e['upper']+1e-12
            assert abs(e['duration']-expected) < step


@pytest.mark.parametrize('mode', ROLES)
@pytest.mark.parametrize('fs', [(1000, 1000), (5000, 1000), (200, 2000)])
@pytest.mark.parametrize('analog', [None, (0., 24., .4), (4., 20., .3)])
def test_known_durations_are_inside_sampling_bounds(mode, fs, analog):
    edges, end = cycles(sum(map(ord, mode))+fs[0]+fs[1])
    s = record(mode, edges, end, fs, analog)
    auto = auto_analyze(s, ValveOptions(mode=mode))
    assert_accurate(auto, mode, edges, fs)
    assert auto['auto']['hint'] is None
    assert [x.input_mode for x in auto['options'].signals] == ['hysteresis' if analog else 'binary']*2
    manual = analyze_valve(s, auto['options'])
    assert [(e['start_index'], e['end_index'], e['status']) for e in manual['events']] == \
           [(e['start_index'], e['end_index'], e['status']) for e in auto['events']]


@pytest.mark.parametrize('inverted', [(True, False), (False, True), (True, True)])
def test_active_low_wiring_is_accurate_and_suggested_when_missing(inverted):
    edges, end = cycles(7)
    s = record('position', edges, end, analog=(0., 24., .3), inverted=inverted)
    wrong = auto_analyze(s, ValveOptions(mode='position'))
    hint = wrong['auto']['hint']
    assert hint and hint['mode'] == 'position' and not hint['swap'] and hint['active_low'] == inverted
    assert hint['first'] == 'opening'
    options = ValveOptions(mode='position', signals=tuple(SignalOptions(active_low=x) for x in inverted))
    assert_accurate(auto_analyze(s, options), 'position', edges, (1000, 1000))


def test_wrong_connection_or_swapped_command_channels_get_a_hint():
    edges, end = cycles(11)
    s = record('command_closed', edges, end)
    hint = auto_analyze(s, ValveOptions(mode='position'))['auto']['hint']
    assert hint['mode'] == 'command_closed' and not hint['swap']
    hint = auto_analyze(s[::-1], ValveOptions(mode='command_closed'))['auto']['hint']
    assert hint['mode'] == 'command_closed' and hint['swap']
    assert hint['complete'] == 2*len(edges) and hint['problems'] == 0


def test_hint_reveals_the_start_position_it_implies():
    # The 2.4.0 example pairs as inverted position switches too, but only if the valve starts open.
    f = TdmsFile.read(EXAMPLES/'vana_5hz.tdms')
    s = [source(n, f['Vana'][n][:], 5.) for n in ('Acik', 'Kapali')]
    hint = auto_analyze(s, ValveOptions(mode='position'))['auto']['hint']
    assert hint['active_low'] == (True, True) and hint['first'] == 'closing'
    legacy = auto_analyze(s, ValveOptions(mode='legacy'))
    assert legacy['auto']['hint'] is None and legacy['events'][0]['direction'] == 'opening'
    assert [e['status'] for e in legacy['events']][:4] == ['complete']*4


def glitch(y, rng, count, width, keep_out):
    y = y.copy()
    busy = list(np.flatnonzero(np.diff(y) != 0))
    placed = 0
    while placed < count:
        i = int(rng.integers(10, len(y)-10))
        if np.min(np.abs(np.asarray(busy)-i)) > keep_out:
            y[i:i+width] = 1-y[i:i+width]; busy.append(i); placed += 1
    return y


@pytest.mark.parametrize('mode', ROLES)
def test_auto_filter_removes_glitches_that_break_unfiltered_timing(mode):
    edges, end = cycles(21)
    s = record(mode, edges, end)
    rng = np.random.default_rng(5)
    for channel in s:
        channel['y'] = glitch(channel['y'], rng, 6, int(rng.integers(1, 3)), 20)
    plain = analyze_valve(s, ValveOptions(mode=mode))
    assert any(e['status'] != 'complete' for e in plain['events']) or len(plain['events']) != 2*len(edges) or \
        any(abs(e['duration']-t) > 1e-3 for e, t in zip(plain['events'], [x for c in edges for x in truth(mode, c)]))
    auto = auto_analyze(s, ValveOptions(mode=mode))
    assert_accurate(auto, mode, edges, (1000, 1000))
    assert 1 < auto['auto']['filter_samples'] <= 4
    assert sum(auto['ignored_runs']) >= 12


def test_contact_bounce_reports_the_stable_arrival():
    edges, end = cycles(3, n=3)
    s = record('position', edges, end)
    fs = 1000
    for c in edges:
        i = int(np.ceil(c['arrive_open']*fs))
        s[0]['y'][i+1:i+3] = 0; s[0]['y'][i+4] = 0  # stable from i+5
        c['stable_open'] = (i+5)/fs
    result = auto_analyze(s, ValveOptions(mode='position'))
    openings = [e for e in result['events'] if e['direction'] == 'opening']
    assert [e['status'] for e in result['events']] == ['complete']*6
    for e, c in zip(openings, edges):
        assert e['end'] == pytest.approx(c['stable_open'])
        assert e['end_index'] == round(c['stable_open']*fs)


def test_short_genuine_pulse_is_reported_not_filtered():
    edges, end = cycles(4, n=4)
    s = record('command_closed', edges, end)
    gap = edges[1]['cmd_on']-edges[0]['arrive_closed']
    a = int((edges[0]['arrive_closed']+gap/2)*1000)
    s[0]['y'][a:a+12] = 1  # 12 ms command without valve motion
    result = auto_analyze(s, ValveOptions(mode='command_closed'))
    statuses = [e['status'] for e in result['events']]
    assert statuses.count('complete') == 8 and statuses.count('cancelled') == 1
    assert result['auto']['filter_samples'] < 12


def test_lazy_tdms_source_gives_the_same_auto_result(tmp_path):
    edges, end = cycles(9)
    mem = record('position', edges, end, analog=(0., 10., .2))
    path = base.tdms_file(tmp_path, [ChannelObject('V', s['name'], s['y']) for s in mem])
    lazy = []
    for s in mem:
        item = source(s['name'], [])
        item.update(path=str(path), group='V', channel=s['name'], n=len(s['y']))
        lazy.append(item)
    a, b = auto_analyze(mem, ValveOptions(mode='position')), auto_analyze(lazy, ValveOptions(mode='position'))
    assert [(e['start_index'], e['end_index']) for e in a['events']] == [(e['start_index'], e['end_index']) for e in b['events']]
    assert a['options'] == b['options']


def levels(y, fs=1000.):
    return profile_levels(_Channel(source('x', np.asarray(y, dtype=float), fs), None, ExportOptions()))


def test_levels_ignore_spikes_and_find_rare_levels():
    rng = np.random.default_rng(1)
    y = np.where(np.arange(200_000) % 50_000 < 25_000, 0., 5.)+rng.normal(0, .05, 200_000)
    y[rng.integers(0, len(y), 40)] = 100
    p = levels(y)
    assert p['kind'] == 'analog' and p['low'] == pytest.approx(0, abs=.02) and p['high'] == pytest.approx(5, abs=.02)
    assert p['low_threshold'] == pytest.approx(1.5, abs=.02) and p['high_threshold'] == pytest.approx(3.5, abs=.02)
    rare = rng.normal(2., .05, 3_000_000); rare[1_500_000:1_500_300] += 22
    p = levels(rare)
    assert p['high'] == pytest.approx(24, abs=.3) and p['low_threshold'] < 10 < p['high_threshold']
    assert levels([0, 1, np.nan, 1, 0])['kind'] == 'binary'
    assert levels(np.r_[np.zeros(500), np.ones(500)]+rng.normal(0, .2, 1000))['warning']
    with pytest.raises(ValueError, match='sabit'):
        levels(np.full(100, 3.3))
    with pytest.raises(ValueError, match='sıçrama'):
        levels(np.r_[np.zeros(1000), 5, 5, np.zeros(1000)])


@pytest.mark.parametrize('fs', [5., 1000., 3000., 44100., 1e6/7])
@pytest.mark.parametrize('epoch', [0., 1_780_000_000.])
def test_filter_time_keeps_k_sample_runs_and_rejects_shorter(fs, epoch):
    x = epoch+np.arange(200)/fs
    for k in (2, 3, 7, 64):
        hold = filter_time(k, 1/fs)
        assert round(hold*1e7) == pytest.approx(hold*1e7, abs=1e-6) or hold == k/fs
        for i in (0, 57, 120):
            assert _duration_cmp(x[i], x[i+k], hold) >= 0
            assert _duration_cmp(x[i], x[i+k-1], hold) < 0


def load_gui(window, app, tmp_path, arrays, fs=1000.):
    path = base.tdms_file(tmp_path, [ChannelObject('Valve', name, y, properties={'wf_increment': 1/fs, 'unit_string': 'V'})
                                     for name, y in zip(('Acik', 'Kapali'), arrays)])
    window.open_tdms_path(str(path)); base.wait_jobs(window, app)
    next(iter(window.files.values())).tree.topLevelItem(0).setCheckState(0, Qt.CheckState.Checked)
    window.plot_checked_channels(); base.wait_jobs(window, app)
    window.valve_open.setCurrentIndex(1); window.valve_closed.setCurrentIndex(2)


def test_gui_auto_setup_hint_cards_and_manual_override(window, app, tmp_path):
    edges, end = cycles(13, n=4)
    s = record('position', edges, end, analog=(0., 24., .3), inverted=(True, True))
    load_gui(window, app, tmp_path, [x['y'] for x in s])
    assert window.valve_mode.currentData() == 'position' and window.valve_auto.isChecked()
    window._valve_analyze(); base.wait_jobs(window, app)
    assert window._valve_hint['active_low'] == (True, True) and not window.valve_hint_button.isHidden()
    assert 'ters (0 = aktif)' in window.valve_notice_text.text()
    assert 'ilk olay açılma; yani vana kayıt başında kapalı' in window.valve_notice_text.text()
    assert window.valve_cards['issues'][1].text() != '0'
    window._valve_apply_hint(); base.wait_jobs(window, app)
    result = window._valve_result
    assert [c[1].currentData() for c in window.valve_signal_controls] == [True, True]
    assert_accurate(result, 'position', edges, (1000, 1000))
    kind, _, low, high = window.valve_signal_controls[0]
    assert kind.currentData() == 'hysteresis' and low.value() == pytest.approx(7.2, abs=.1) and high.value() == pytest.approx(16.8, abs=.1)
    assert window.valve_hold.value() == pytest.approx(1000*result['options'].hold(0))
    assert window._valve_options() == result['options']
    openings = [e['duration'] for e in result['events'] if e['direction'] == 'opening']
    assert window.valve_cards['opening'][1].text() == f"ort. {round(statistics.fmean(openings)*1000, 3):.10g} ms"
    assert window.valve_cards['issues'][1].text() == '0'
    assert 'Otomatik belirlenen' in window.valve_used.text()
    window.valve_tree.setCurrentItem(window.valve_tree.topLevelItem(0)); base.wait_jobs(window, app)
    window._valve_reject_event()
    assert 'n = 3' in window.valve_cards['opening'][2].text()
    assert window.settings.value('valve/mode') == 'position'
    high.setValue(20)
    assert not window.valve_auto.isChecked() and window._valve_result is None
    window._valve_analyze(); base.wait_jobs(window, app)
    assert window._valve_result['options'].signals[0].high_threshold == 20 and 'auto' not in window._valve_result


def test_gui_swap_moves_roles_and_channel_settings(window, app, tmp_path):
    edges, end = cycles(17, n=3)
    s = record('command_closed', edges, end)
    load_gui(window, app, tmp_path, [x['y'] for x in s[::-1]])
    window.valve_mode.setCurrentIndex(window.valve_mode.findData('command_closed'))
    window._valve_analyze(); base.wait_jobs(window, app)
    hint = window._valve_hint
    assert hint['swap'] and hint['mode'] == 'command_closed' and hint['active_low'] == (False, False)
    first = window.valve_open.currentData()
    window._valve_apply_hint(); base.wait_jobs(window, app)
    assert window.valve_closed.currentData() == first
    assert [c[1].currentData() for c in window.valve_signal_controls] == [False, False]
    assert_accurate(window._valve_result, 'command_closed', edges, (1000, 1000))
    window._valve_swap_channels()
    assert window.valve_open.currentData() == first and window._valve_result is None
