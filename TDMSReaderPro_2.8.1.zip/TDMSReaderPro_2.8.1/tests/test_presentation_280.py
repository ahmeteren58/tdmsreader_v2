"""UI-only changes must preserve timing, old projects and plot interactions."""
import numpy as np
from nptdms import ChannelObject
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QToolButton,QLabel
import tdmsreader as m
import test_regressions as base
from tdms_ui import CsvExportDialog

app=base.app
window=base.window


def draw(window,app,tmp_path):
    path=base.tdms_file(tmp_path,[ChannelObject('AI','Pressure',np.arange(101),properties={'wf_increment':.01})])
    window.open_tdms_path(str(path));base.wait_jobs(window,app)
    state=next(iter(window.files.values()));state.tree.topLevelItem(0).setCheckState(0,Qt.CheckState.Checked)
    window.plot_checked_channels();base.wait_jobs(window,app)
    return path


def test_removed_tabs_have_no_visible_or_hidden_editors(window):
    names=[window.tabs.tabText(i) for i in range(window.tabs.count())]
    assert len(names)==8
    assert 'Manuel Fs' not in names and 'Channel Alignment' not in names
    assert not hasattr(window,'manual_fs_tree') and not hasattr(window,'alignment_tree')
    assert window.manual_fs_tab is None
    menu=[a.text() for top in window.menuBar().actions() if top.menu() for a in top.menu().actions()]
    assert 'Manuel Fs' not in menu
    window._open_manual_fs_tab()
    assert window.tabs.currentWidget() is window.channel_manager_tab
    assert window.tabs.count()==8
    window._activate_tab_by_text('Frekans Analizi (FFT)')
    assert window.tabs.currentWidget() is window.fft_tab


def test_empty_state_tracks_load_clear_and_resize(window,app,tmp_path):
    window.show();app.processEvents()
    assert window._empty_plot.isVisible()
    draw(window,app,tmp_path)
    assert not window._empty_plot.isVisible()
    window.on_clear_plot();app.processEvents()
    assert window._empty_plot.isVisible()
    window.resize(1280,800);app.processEvents()
    assert window._empty_plot.geometry()==window.plot_container.rect()


def test_channel_manager_manual_fs_and_optional_columns(window,app,tmp_path):
    draw(window,app,tmp_path);s=window.current_series[0];values=s['y']
    window._open_channel_manager_tab();tree=window.channel_manager_tree;row=tree.topLevelItem(0)
    fs=tree.itemWidget(row,4);manual=tree.itemWidget(row,5)
    assert not fs.isEnabled() and tree.isColumnHidden(1)
    manual.setChecked(True);assert fs.isEnabled()
    fs.setValue(500);window._apply_channel_manager();base.wait_jobs(window,app)
    assert s['fs_est']==500 and s['x'][-1]==.2 and s['y'] is values
    window.channel_manager_details.setChecked(True);assert not tree.isColumnHidden(1)
    window._populate_channel_manager();row=tree.topLevelItem(0)
    tree.itemWidget(row,5).setChecked(False);window._apply_channel_manager();base.wait_jobs(window,app)
    assert s['fs_est']==100 and s['x'][-1]==1 and s['y'] is values


def test_legacy_offsets_remain_visible_and_can_reset_without_raw_change(window,app,tmp_path):
    draw(window,app,tmp_path);s=window.current_series[0];key=s['style_key'];raw=s['x'].copy();values=s['y']
    window.alignment_manager.set_offsets({key:.006});window._alignment_redraw();window._alignment_refresh()
    assert not window.legacy_offsets.isHidden()
    assert any('elle zaman ofseti' in n for n in window._time_plot_notices())
    np.testing.assert_allclose(window.plot_pane._curve_items[key].xData,raw+.006)
    window._clear_legacy_offsets()
    assert window.legacy_offsets.isHidden() and window.alignment_manager.snapshot()=={}
    np.testing.assert_array_equal(s['x'],raw);assert s['y'] is values
    np.testing.assert_array_equal(window.plot_pane._curve_items[key].xData,raw)


def test_help_and_theme_do_not_rebuild_or_change_data(window,app,tmp_path):
    draw(window,app,tmp_path);s=window.current_series[0];x,y=s['x'],s['y'];curve=window.plot_pane._curve_items[s['style_key']]
    window.tabs.setCurrentWidget(window.time_channels_tab)
    help_button=next(b for b in window.time_channels_tab.findChildren(QToolButton) if b.property('helpButton'))
    text=next(t for t in window.time_channels_tab.findChildren(QLabel) if t.property('pageHelp'))
    assert text.isHidden();help_button.click();assert not text.isHidden()
    help_button.click();assert text.isHidden()
    for theme in ['dark','light']:
        window.set_theme(theme);app.processEvents()
        assert all(not window.tabs.tabIcon(i).isNull() for i in range(8))
        assert s['x'] is x and s['y'] is y
        assert window.plot_pane._curve_items[s['style_key']] is curve


def test_csv_shows_retained_offsets_only_when_relevant(app):
    s=base.memory_source('A',[1,2,3],mode='seconds')
    dialog=CsvExportDialog([s],{s['key']},None)
    assert dialog.aligned.isHidden() and not dialog.options().export_aligned
    dialog.deleteLater()
    dialog=CsvExportDialog([dict(s,alignment_offset=.006)],{s['key']},None)
    assert not dialog.aligned.isHidden()
    dialog.aligned.setChecked(True);assert dialog.options().export_aligned
    dialog.deleteLater()
