"""Qt callback exceptions must fail a test instead of merely reaching stderr."""
import sys
import pytest


@pytest.fixture(autouse=True)
def no_unhandled_qt_callbacks(monkeypatch):
    exceptions = []
    monkeypatch.setattr(sys, "excepthook", lambda *args: exceptions.append(args))
    yield
    assert not exceptions, [(kind.__name__, str(exc)) for kind, exc, _ in exceptions]
