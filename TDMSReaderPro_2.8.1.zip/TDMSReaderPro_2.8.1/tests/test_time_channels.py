"""Clock identity, mixed rates, raw integrity and real GUI time-source changes."""
from dataclasses import replace
import numpy as np
import pytest
from nptdms import ChannelObject, GroupObject
from PyQt6.QtCore import Qt
import tdmsreader as m
import tdms_time_channels as timing
from tdms_io import open_tdms
from tdms_export import export_snapshot,read_source_xy,write_csv,ExportOptions,ExportCancelled
from tdms_project import save_project_archive,load_project_archive
import test_regressions as base

app=base.app
window=base.window


def clock_file(tmp_path,mixed=False):
    return base.tdms_file(tmp_path,[
        ChannelObject('RIO3-9425-1','Slow',np.arange(501)),
        ChannelObject('RIO3-9205-1' if mixed else 'RIO3-9425-2','Fast',np.arange(5001)),
        ChannelObject('RIO3-Times','Mod 1-Time',100.+np.arange(501)*.002),
        ChannelObject('RIO3-Times','Mod 2-Time',100.006+np.arange(5001)*.0002),
        ChannelObject('RIO5-Times','Mod 4-Time',np.full(5001,20.)),
    ])


@pytest.mark.parametrize('lazy',[False,True])
def test_mixed_500_5000_rates_keep_real_start_and_all_samples(tmp_path,monkeypatch,lazy):
    path=clock_file(tmp_path)
    original=path.read_bytes()
    if lazy:monkeypatch.setattr(m,'CFG',replace(m.CFG,lazy=replace(m.CFG.lazy,fullload_threshold=100)))
    slow,fast=base.load(path,[('RIO3-9425-1','Slow',501),('RIO3-9425-2','Fast',5001)])['series']
    for s,fs,n,start in [(slow,500,501,0.),(fast,5000,5001,.006)]:
        assert s['lazy']==lazy
        assert s['sample_count']==n
        assert s['source_fs_est']==pytest.approx(fs)
        assert s['source_x_base']==pytest.approx(start)
        snap=export_snapshot(s)
        x,y=read_source_xy(snap)
        np.testing.assert_array_equal(y,np.arange(n))
        np.testing.assert_allclose(x,start+np.arange(n)/fs,atol=1e-12)
    assert path.read_bytes()==original


def test_mixed_models_are_proposals_not_silent_slot_guesses(tmp_path):
    path=clock_file(tmp_path,True)
    with open_tdms(path) as t:
        r=timing.TimeChannelResolver(t,str(path))
        assert all(not row['automatic'] for row in r.rows)
        props,info=r.bind('RIO3-9425-1','Slow',{})
        assert props=={} and info is None
        assert next(x for x in r.rows if x['group']=='RIO3-9425-1')['target']==('RIO3-Times','Mod 1-Time')
    result=base.load(path,[('RIO3-9425-1','Slow',501),('RIO3-9205-1','Fast',5001)])
    assert all(s['x_mode']=='index' for s in result['series'])


@pytest.mark.parametrize('values,reason',[
    ([2.,2.,2.,2.],'sabit'),([0.,.002,.002,.006],'artmıyor'),
    ([0.,.004,.002,.006],'artmıyor'),([0.,np.nan,.004,.006],'sonlu'),
    ([0.,.001,.004,.006],'Düzensiz'),
])
def test_bad_clocks_never_manufacture_fs_or_drop_signal_samples(tmp_path,values,reason):
    path=base.tdms_file(tmp_path,[ChannelObject('RIO3-9425-1','A',np.arange(4)),ChannelObject('RIO3-Times','Mod 1-Time',values)])
    result=base.load(path,[('RIO3-9425-1','A',4)])
    s=result['series'][0]
    assert s['x_mode']=='index' and s['source_fs_est'] is None
    assert not s['time_channel_binding']['applied']
    assert reason in s['time_channel_binding']['reason']
    np.testing.assert_array_equal(s['y'],np.arange(4))


def test_partial_and_mismatched_clocks_do_not_bind_unknown_arrays(tmp_path):
    path=base.tdms_file(tmp_path,[ChannelObject('RIO3-9425-1','Good',np.ones(5)),
        ChannelObject('RIO3-9425-1','Unknown',np.ones(15)),
        ChannelObject('RIO3-Times','Mod 1-Time',100+np.arange(5)*.002)])
    a,b=base.load(path,[('RIO3-9425-1','Good',5),('RIO3-9425-1','Unknown',15)])['series']
    assert a['x_mode']=='seconds' and b['x_mode']=='index'
    assert len(b['y'])==15 and not b['time_channel_binding']['applied']


@pytest.mark.parametrize('unit,step,fallback,expected',[('ms',.2,'s',5000),('',.2,'ms',5000),('ticks',1,'s',None)])
def test_unit_conversion_and_unsupported_unit(tmp_path,unit,step,fallback,expected):
    path=base.tdms_file(tmp_path,[ChannelObject('RIO3-9425-1','A',np.ones(5)),
        ChannelObject('RIO3-Times','Mod 1-Time',np.arange(5)*step,properties={'unit_string':unit})])
    with open_tdms(path) as t:
        r=timing.TimeChannelResolver(t,str(path),{'unit':fallback})
        props,info=r.bind('RIO3-9425-1','A',{})
        if expected is None:assert not info['applied'] and 'wf_increment' not in props
        else:assert 1/props['wf_increment']==pytest.approx(expected)


def test_native_waveform_timing_is_not_overridden(tmp_path):
    path=base.tdms_file(tmp_path,[ChannelObject('RIO3-9425-1','A',np.ones(5),properties={'wf_increment':.1,'wf_start_offset':3.}),
        ChannelObject('RIO3-Times','Mod 1-Time',100+np.arange(5)*.002)])
    s=base.load(path,[('RIO3-9425-1','A',5)])['series'][0]
    assert s['source_fs_est']==10 and s['x'][0]==3
    assert s['time_channel_binding'] is None


def test_streaming_validation_is_bounded_and_cancellable():
    class Clock:
        dtype=np.dtype('float64')
        calls=[]
        def __len__(self):return 400_001
        def read_data(self,offset,length):
            self.calls.append(length);return 1000.+np.arange(offset,offset+length)*.0002
    clock=Clock();r=timing._validate(clock,1.,lambda:False)
    assert r['valid'] and max(clock.calls)<=timing._BLOCK
    with pytest.raises(ExportCancelled):timing._validate(clock,1.,lambda:True)


def test_validation_cache_does_not_reread_clocks(tmp_path,monkeypatch):
    from tdms_io import PooledChannel
    path=clock_file(tmp_path);calls=[];original=PooledChannel.read_data
    def read(self,*a,**kw):calls.append(kw.get('length'));return original(self,*a,**kw)
    monkeypatch.setattr(PooledChannel,'read_data',read)
    with open_tdms(path) as t:timing.TimeChannelResolver(t,str(path)).reports()
    assert calls;calls.clear()
    with open_tdms(path) as t:timing.TimeChannelResolver(t,str(path)).reports()
    assert not calls


def test_gui_apply_reset_csv_and_project_keep_one_time_source(window,app,tmp_path):
    path=clock_file(tmp_path,True);before=path.read_bytes()
    window.open_tdms_path(str(path));base.wait_jobs(window,app)
    fid=next(iter(window.files));state=window.files[fid]
    for i in range(state.tree.topLevelItemCount()):
        group=state.tree.topLevelItem(i)
        if group.text(0) in ('RIO3-9425-1','RIO3-9205-1'):group.setCheckState(0,Qt.CheckState.Checked)
    window.plot_checked_channels();base.wait_jobs(window,app)
    assert all(s['x_mode']=='index' for s in window.current_series)
    raw=[s['y'] for s in window.current_series]
    window._time_scan(True);base.wait_jobs(window,app)
    by_name={s['name']:s for s in window.current_series};slow,fast=by_name['Slow'],by_name['Fast']
    assert [slow['fs_est'],fast['fs_est']]==pytest.approx([500,5000])
    assert fast['effective_x_base']==pytest.approx(.006)
    assert all(s['y'] is y for s,y in zip(window.current_series,raw))
    assert all(s['effective_fs_source']=='time_channel' for s in window.current_series)
    sources=[export_snapshot(s) for s in window.current_series]
    target=tmp_path/'clock.csv';write_csv(str(target),sources,ExportOptions())
    column=2*next(i for i,s in enumerate(window.current_series) if s['name']=='Fast')
    assert float(base.read_csv(target)[1][column])==pytest.approx(.006)
    saved=tmp_path/'clock.tdmsproj';manifest,arrays=window._project_manifest(str(saved))
    save_project_archive(str(saved),manifest,arrays)
    restored=load_project_archive(str(saved),m.MultiTdmsChannelLoadWorker,m.ChannelRequest,m.ChannelKey)
    assert {s['name']:round(s['source_fs_est']) for s in restored['series']}=={'Slow':500,'Fast':5000}
    window._apply_project(restored);base.wait_jobs(window,app)
    assert window.time_binding_settings[fid]['bindings']
    window._time_reset_file();base.wait_jobs(window,app)
    assert all(s['x_mode']=='index' for s in window.current_series)
    reset=next(s for s in window.current_series if s['name']=='Slow')
    np.testing.assert_array_equal(reset['x'],np.arange(501))
    assert path.read_bytes()==before


def test_manual_fs_remains_explicitly_prioritized_and_can_be_removed(window,tmp_path):
    path=clock_file(tmp_path)
    window.current_series=base.load(path,[('RIO3-9425-1','Slow',501)])['series']
    s=window.current_series[0];window.channel_fs_overrides[s['style_key']]=100
    window._apply_channel_timing();assert s['fs_est']==100
    window.channel_fs_overrides.clear();window._apply_channel_timing()
    assert s['fs_est']==pytest.approx(500) and s['effective_fs_source']=='time_channel'


@pytest.mark.parametrize('lazy',[False,True])
def test_unchanged_valve_engine_receives_mixed_rate_times(window,tmp_path,monkeypatch,lazy):
    from tdms_valve import ValveOptions,analyze_valve
    op=np.zeros(1001);op[100:700]=1
    cl=np.ones(10001);cl[1400:6000]=0
    path=base.tdms_file(tmp_path,[ChannelObject('RIO3-9425-1','Open',op),ChannelObject('RIO3-9425-2','Closed',cl),
        ChannelObject('RIO3-Times','Mod 1-Time',100.006+np.arange(1001)/500),
        ChannelObject('RIO3-Times','Mod 2-Time',100.+np.arange(10001)/5000)])
    if lazy:monkeypatch.setattr(m,'CFG',replace(m.CFG,lazy=replace(m.CFG.lazy,fullload_threshold=100)))
    series=base.load(path,[('RIO3-9425-1','Open',1001),('RIO3-9425-2','Closed',10001)])['series']
    window.current_series=series;window._apply_channel_timing()
    result=analyze_valve([export_snapshot(s) for s in series],ValveOptions(mode='legacy'))
    assert [e['duration'] for e in result['events']]==pytest.approx([.074,.206])
    assert [(e['start_index'],e['end_index']) for e in result['events']]==[(100,1400),(6000,700)]


def test_file_open_only_reads_metadata(tmp_path,monkeypatch):
    from tdms_io import PooledChannel
    path=clock_file(tmp_path)
    def forbidden(*a,**kw):raise AssertionError('Index must not scan time or signal samples')
    monkeypatch.setattr(PooledChannel,'read_data',forbidden)
    payload=base.worker_result(m.TdmsIndexWorker('F1',str(path)))
    assert payload['refs'] and payload['time_catalog']['clocks']


def test_apply_error_keeps_current_times_and_settings(window,app,tmp_path,monkeypatch):
    import tdms_time_channels_ui as ui
    path=clock_file(tmp_path)
    window.open_tdms_path(str(path));base.wait_jobs(window,app)
    fid=next(iter(window.files))
    window.current_series=base.load(path,[('RIO3-9425-1','Slow',501)])['series']
    window._apply_channel_timing();old_x=window.current_series[0]['x']
    previous=dict(window.time_binding_settings)
    def broken(*a,**kw):raise IOError('test read error')
    monkeypatch.setattr(ui,'TimeChannelResolver',broken)
    window._time_scan(True);base.wait_jobs(window,app)
    assert window.time_binding_settings.get(fid, timing.clean_settings())==previous.get(fid,timing.clean_settings())
    assert window.current_series[0]['x'] is old_x
    assert 'mevcut grafik zamanı korundu' in window.time_note.text()
    assert window.time_apply.isEnabled()
