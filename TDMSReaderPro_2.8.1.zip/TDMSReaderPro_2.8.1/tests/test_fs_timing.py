"""Physical timing checks for the reported 5000 Hz / 500 Hz discrepancy."""
import numpy as np
import pytest
from nptdms import ChannelObject
from PyQt6.QtCore import Qt
import tdmsreader as appmod
from tdms_export import export_snapshot, write_csv, ExportOptions
from tdms_inspection import measure_sources
import test_regressions as base
from test_regressions import load, tdms_file, read_csv, worker_result, wait_jobs
from fs_teshis import build_report, time_summary

app = base.app
window = base.window


@pytest.mark.parametrize("mode,lazy,text", [
    ("index", False, False), ("seconds", False, False),
    ("index", False, True), ("index", True, False),
    ("datetime", True, False),
])
def test_5khz_200_sample_valve_event_is_40ms(window, tmp_path, mode, lazy, text):
    n = 2_000_017 if lazy else 10_001
    start = 1_500_000 if lazy else 1000
    end = start + 200
    y = np.zeros(n, dtype=np.int16)
    y[start:end] = 90
    props = {} if mode == "index" else {"wf_increment": 1/5000, "wf_start_offset": 2.0}
    if mode == "datetime":
        props["wf_start_time"] = np.datetime64("2026-09-15T12:00:00")
    path = tdms_file(tmp_path, [ChannelObject("Valve", "Angle", y.astype(str) if text else y, properties=props)])
    s = load(path, [("Valve", "Angle", n)])["series"][0]
    assert s["lazy"] is lazy
    window.current_series = [s]
    before = s["y"].copy()
    for fs, expected_dt in [(5000, .04), (500, .4), (5000, .04)]:
        window.channel_fs_overrides[s["style_key"]] = fs
        window._apply_channel_timing()
        base = s["effective_x_base"]
        indices = s["_sample_indices"] if lazy else np.arange(n)
        np.testing.assert_allclose(s["x"], base + indices/fs, rtol=0, atol=5e-7 if mode == "datetime" else 1e-12)
        np.testing.assert_array_equal(s["y"], before)
        assert s["sample_count"] == n
        # Use the graph's exact coordinates for inclusive CSV endpoints;
        # decimal input rounded a ULP below an endpoint may exclude that sample.
        a, b = base + start*(1/fs), base + end*(1/fs)
        source = export_snapshot(s)
        row = measure_sources([source], [a, b])["rows"][0]
        assert row["a"]["index"] == start and row["b"]["index"] == end
        assert row["a"]["y"] == 90 and row["b"]["y"] == 0
        assert row["dt"] == pytest.approx(expected_dt, abs=5e-7)
        csv_path = tmp_path / "interval.csv"
        write_csv(str(csv_path), [source], ExportOptions(x_range=(a, b)))
        rows = read_csv(csv_path)[1:]
        assert len(rows) == 201
        assert float(rows[-1][0]) - float(rows[0][0]) == pytest.approx(expected_dt, abs=5e-7)
        if lazy:
            meta = s["lazy_meta"]
            result = worker_result(appmod.LazyViewLoadWorker([
                dict(meta, style_key=s["style_key"], x0=a, x1=b)
            ], max_points=100))["updates"][s["style_key"]]
            assert result["indices"][0] > 0
            np.testing.assert_array_equal(result["x"], base + result["indices"]*(1/fs))
    # A later manual change must preserve the original indices of a zoomed view.
    if lazy:
        s.update(x=result["x"], y=result["y"], _sample_indices=result["indices"], _lazy_last_win=result["win"])
        window.channel_fs_overrides[s["style_key"]] = 500
        window._apply_channel_timing()
        np.testing.assert_array_equal(s["x"], s["effective_x_base"] + result["indices"]*(1/500))


def test_hz_khz_units():
    assert appmod.fs_value_to_hz(5, "kHz") == appmod.fs_value_to_hz(5000, "Hz") == 5000


def test_manual_table_5khz_reaches_rendered_curve_and_ab(window, app, tmp_path):
    y = np.zeros(10001); y[1000:1200] = 90
    path = tdms_file(tmp_path, [ChannelObject("AI", "Valve", y)])
    window.open_tdms_path(str(path)); wait_jobs(window, app)
    state = next(iter(window.files.values()))
    state.tree.topLevelItem(0).setCheckState(0, Qt.CheckState.Checked)
    window.plot_checked_channels(); wait_jobs(window, app)
    window._populate_channel_manager()
    tree = window.channel_manager_tree
    row = tree.topLevelItem(0)
    tree.itemWidget(row, 5).setChecked(True)
    tree.itemWidget(row, 4).setValue(5000)
    window._apply_channel_manager(); wait_jobs(window, app)
    s = window.current_series[0]
    assert s["fs_est"] == 5000
    curve = (window.plot_pane._left_items + window.plot_pane._right_items)[0]
    x, values = curve.xData, curve.yData
    transitions = np.flatnonzero(values[1:] != values[:-1])+1
    assert x[transitions[1]]-x[transitions[0]] == pytest.approx(.04)
    window._ab_positions = [.2, .24]
    row = measure_sources(window._inspection_sources(), window._ab_positions)["rows"][0]
    assert row["dt"] == pytest.approx(.04)


@pytest.mark.parametrize("dt,unit,expected", [(.0002, "s", 5000), (.002, "s", 500), (.2, "ms", 5000)])
def test_independent_time_channel_report(tmp_path, dt, unit, expected):
    from nptdms import TdmsFile
    path = tdms_file(tmp_path, [ChannelObject("AI", "Time", np.arange(1001)*dt, properties={"unit_string": unit}), ChannelObject("AI", "Valve", np.ones(1001))])
    before = path.read_bytes()
    with TdmsFile.open(path) as tdms:
        result = time_summary(tdms["AI"]["Time"])
        assert result["fs"] == pytest.approx(expected)
    report = build_report(path, group="AI", channel="Valve", time_group="AI", time_channel="Time", indices=(0, 200))
    assert f"Fs: {expected} Hz" in report
    assert "Δi=200" in report
    assert path.read_bytes() == before


def test_time_report_does_not_guess_units_or_pair_mismatched_channels(tmp_path):
    path = tdms_file(tmp_path, [ChannelObject("AI", "Time", np.arange(1001)*.002), ChannelObject("AI", "Valve", np.ones(101))])
    report = build_report(path, time_group="AI", time_channel="Time")
    assert "Birim bilinmiyor: Fs hesaplanmadı" in report
    assert "1001 != 101" in report


def test_time_report_rejects_irregular_time_as_single_fs(tmp_path):
    path = tdms_file(tmp_path, [ChannelObject("AI", "Time", np.array([0., .002, .001, .1]), properties={"unit_string":"s"})])
    report = build_report(path, time_group="AI", time_channel="Time")
    assert "Tek bir sabit Fs doğrulanamadı" in report
