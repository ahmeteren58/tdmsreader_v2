"""Physical truth, original-sample statistics, gaps and steady-flow UI lifecycle."""
from dataclasses import replace
import csv
import os
import time

import numpy as np
import pytest
from nptdms import ChannelObject
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFileDialog

import test_regressions as base
from tdms_export import export_snapshot, ExportCancelled
from tdms_steady import (analyze_steady, measure_steady, SteadyOptions,
                         PRESSURE_FACTORS, pressure_unit, write_steady_report)
from tdms_steady_ui import suggest_roles

app = base.app
window = base.window


def source(name, role, fs=1000., start=0., mode='seconds', unit=None, y=None, duration=20.):
    t = np.arange(round(fs*duration)+1)/fs
    if y is None:
        active1, active2 = (t>=2)&(t<8), (t>=10)&(t<16)
        if role=='pin':
            y = np.where(active1, 16.908, np.where(active2, 22., 1.))
        elif role=='pout':
            y = np.where(active1, 16.846, np.where(active2, 21.88, 1.))
        else:
            y = np.where(active1, 59.63, np.where(active2, 80., 0.))
    unit = unit or ('kg/s' if role=='flow' else 'bar')
    factor = PRESSURE_FACTORS[unit] if role!='flow' else 1.
    y = np.asarray(y, dtype=float)/factor
    x = start+t[:len(y)]
    s = base.memory_source(name, y, x, mode=mode)
    s.update(role=role, fs_hz=fs, x_base=start, x_inc=1/fs, unit=unit, pressure_unit=unit)
    return s


def record(rates=(1000., 1000., 1000.), start=0., mode='seconds', units=('bar','bar','kg/s')):
    return [source(name, role, fs, start, mode, unit) for name, role, fs, unit in
            zip(('Pin', 'Pout', 'Debi'), ('pin', 'pout', 'flow'), rates, units)]


@pytest.mark.parametrize('rates', [(1000,1000,1000), (100,37,5), (7,5,11)])
@pytest.mark.parametrize('epoch,mode', [(0.,'seconds'), (1791964800.,'datetime')])
@pytest.mark.parametrize('units', [('bar','bar','kg/s'), ('Pa','MPa','kg/s'), ('psi','kPa','kg/s')])
def test_known_physical_plateaus_native_rates_and_units(rates, epoch, mode, units):
    r = analyze_steady(record(rates, epoch, mode, units))
    assert [(e['start']-epoch,e['end']-epoch) for e in r['intervals']] == [(2.,8.),(10.,16.)]
    first, second = r['intervals']
    assert first['dp_bar'] == pytest.approx(.062, abs=1e-12)
    assert second['dp_bar'] == pytest.approx(.12, abs=1e-12)
    assert first['stats']['flow']['mean'] == pytest.approx(59.63)
    assert first['stats']['pin']['n'] == 6*rates[0]
    assert first['stats']['pout']['n'] == 6*rates[1]
    assert first['stats']['flow']['n'] == 6*rates[2]
    assert first['stats']['pin']['std'] == pytest.approx(0., abs=1e-12)
    assert r['flow_threshold'] == pytest.approx(4.)


def test_noise_stats_use_every_sample_and_are_chunk_invariant():
    sources = record()
    rng = np.random.default_rng(184)
    for s in sources:
        s['y'] += rng.normal(0,.0007,len(s['y']))
    r = analyze_steady(sources)
    small = analyze_steady(sources, SteadyOptions(chunk_size=117))
    assert [(e['start'],e['end']) for e in small['intervals']] == [(e['start'],e['end']) for e in r['intervals']]
    for r1,r2 in zip(r['intervals'], small['intervals']):
        for s in sources:
            raw = s['y'][(s['x']>=r1['start'])&(s['x']<r1['end'])]
            stat, other = r1['stats'][s['role']], r2['stats'][s['role']]
            assert stat['mean'] == pytest.approx(raw.mean(), abs=1e-12)
            assert stat['std'] == pytest.approx(raw.std(ddof=1), abs=1e-12)
            assert other['mean'] == pytest.approx(stat['mean'], abs=1e-12)
            assert other['std'] == pytest.approx(stat['std'], abs=1e-12)
            assert stat['min']==raw.min() and stat['max']==raw.max()


def test_transition_and_single_sample_spike_are_excluded():
    sources = record()
    for s in sources:
        s['x'] += .35
    # First active time in common coordinates is now 2.35, aligned bin edges
    # follow that common origin. A spike in bin 4 must split the first plateau.
    sources[0]['y'][4500] = 1000.
    r = analyze_steady(sources)
    assert all(not (e['start'] <= 4.85 < e['end']) for e in r['intervals'])
    assert any(np.max(trace['y'])==1000. for trace in r['traces'])


def test_drifting_pressure_loss_is_not_called_a_stable_plateau():
    fs=1000; t=np.arange(10001)/fs
    s=[source('Pin','pin',fs,y=np.full(len(t),17.)),
       source('Pout','pout',fs,y=16.9-.03*t), source('Debi','flow',fs,y=np.full(len(t),60.))]
    r=analyze_steady(s)
    assert r['intervals']==[]


def test_nan_and_missing_time_never_bridge_a_plateau():
    sources=record(); sources[1]['y'][5000]=np.nan
    r=analyze_steady(sources)
    assert all(not (e['start']<=5.<e['end']) for e in r['intervals'])
    s=record()
    keep=(s[0]['x']<5.)|(s[0]['x']>=6.)
    s[0].update(x=s[0]['x'][keep],y=s[0]['y'][keep],n=int(keep.sum()))
    r=analyze_steady(s)
    assert all(not (e['start']<6. and e['end']>5.) for e in r['intervals'])


def test_zero_flow_is_rejected_and_manual_active_threshold_is_used():
    sources=record()
    r=analyze_steady(sources, SteadyOptions(flow_threshold=70.))
    assert [(e['start'],e['end']) for e in r['intervals']]==[(10.,16.)]
    r=analyze_steady(sources[:2])
    assert any('Debi seçilmedi' in w for w in r['warnings'])
    assert any(e['start']==16. for e in r['intervals'])


def test_minimum_duration_and_search_range_are_enforced():
    assert analyze_steady(record(),SteadyOptions(min_duration_s=7.))['intervals']==[]
    r=analyze_steady(record(),search_bounds=(9.,17.))
    assert [(e['start'],e['end']) for e in r['intervals']]==[(10.,16.)]
    with pytest.raises(ValueError,match='kısa'):
        analyze_steady(record(),search_bounds=(1.,2.))
    with pytest.raises(ValueError,match='Çok fazla'):
        analyze_steady(record(),replace(SteadyOptions(),max_windows=10))


@pytest.mark.parametrize('issue', ['unit','duplicate','fs','mode','time'])
def test_bad_units_time_and_channel_roles_are_explicit_errors(issue):
    s=record()
    if issue=='unit': s[0]['pressure_unit']=None
    if issue=='duplicate': s[1]['key']=s[0]['key']
    if issue=='fs': s[0]['fs_hz']=None
    if issue=='mode': s[1]['x_mode']='datetime'
    if issue=='time': s[0]['x'][999]=s[0]['x'][998]
    with pytest.raises(ValueError): analyze_steady(s)


def test_sparse_windows_require_longer_window_not_implicit_resampling():
    s=record((1.,1.,1.))
    assert analyze_steady(s)['intervals']==[]
    assert analyze_steady(s,SteadyOptions(window_s=3.,min_duration_s=3.))['intervals']


def test_manual_stats_half_open_range_and_no_stability_claim():
    sources=record((100,37,5))
    r=measure_steady(sources,2.5,7.25)['interval']
    for s in sources:
        raw=s['y'][(s['x']>=2.5)&(s['x']<7.25)]
        assert r['stats'][s['role']]['n']==len(raw)
        assert r['stats'][s['role']]['mean']==pytest.approx(raw.mean())
    assert r['dp_bar']==pytest.approx(.062)
    assert r['mode']=='manual' and 'doğrulanmadı' in r['note']
    sources[0]['y'][400]=np.nan
    with pytest.raises(ValueError,match='NaN'):
        measure_steady(sources,2.5,7.25)
    with pytest.raises(ValueError,match='ortak'):
        measure_steady(sources,-1.,3.)


def test_report_is_atomic_includes_units_and_protects_formula_names(tmp_path):
    s=record(); s[0]['name']='=bad()'
    r=analyze_steady(s); manual=measure_steady(s,3.,7.)['interval']
    path=tmp_path/'sonuc.csv'
    write_steady_report(path,r,manual)
    text=path.read_text(encoding='utf-8-sig')
    assert "'=bad()" in text and 'Δp [bar]' in text and '0,062' in text
    rows=list(csv.reader(text.splitlines(),delimiter=';'))
    assert any(row[1:2]==['Elle'] for row in rows)
    previous=path.read_bytes()
    with pytest.raises(ExportCancelled):
        write_steady_report(path,r,cancelled=lambda:True)
    assert path.read_bytes()==previous
    assert not list(tmp_path.glob('*.tmp'))


def test_lazy_tdms_uses_original_samples_not_preview(tmp_path):
    s=record((100,37,5))
    path=base.tdms_file(tmp_path,[ChannelObject('Test',v['name'],v['y'],properties={
        'wf_increment':v['x_inc'],'wf_start_offset':0.,'unit_string':v['unit']}) for v in s])
    payload=base.load(path,[('Test',v['name'],v['n']) for v in s])
    eager=[]; lazy=[]
    for series,original in zip(payload['series'],s):
        # Loading supplies source timing; the UI applies it to fs_est before
        # snapshots. Reproduce that step here without constructing a window.
        series['fs_est']=series['source_fs_est']
        snap=export_snapshot(series); snap.update(role=original['role'],pressure_unit=original['pressure_unit'])
        eager.append(snap)
        # An intentionally wrong preview must not affect full source analysis.
        lazy.append(dict(snap,path=str(path),group='Test',channel=original['name'],n=original['n'],
                         y=np.array([999.]),x=np.array([0.]),x_base=0.,x_inc=original['x_inc']))
    a=analyze_steady(eager); b=analyze_steady(lazy,SteadyOptions(chunk_size=113))
    assert len(a['intervals'])==len(b['intervals'])==2
    for e,f in zip(a['intervals'],b['intervals']):
        assert e['dp_bar']==pytest.approx(f['dp_bar'],abs=1e-12)
        assert e['stats']['pin']['n']==f['stats']['pin']['n']
    os.rename(path,tmp_path/'moved.tdms')


def populate(window,sources):
    window.current_series=[]
    for s in sources:
        window.current_series.append(dict(style_key=s['key'],name=s['name'],unit=s['unit'],file_label='Test',
            x=s['x'],y=s['y'],x_mode=s['x_mode'],fs_est=s['fs_hz'],source_x_mode=s['x_mode'],
            source_x_base=s['x_base'],source_x_inc=s['x_inc'],source_fs_est=s['fs_hz'],sample_count=s['n']))
    window._steady_refresh()
    window._steady_suggest_channels()


def test_ui_auto_selection_region_edit_recalc_and_restore(window,app):
    populate(window,record())
    assert window.steady_units['pin'].currentData()=='bar'
    window._steady_analyze(); base.wait_jobs(window,app)
    assert len(window._steady_result['intervals'])==2
    assert window._steady_selected['dp_bar']==pytest.approx(.062)
    assert window.steady_stats.topLevelItemCount()==3
    window._steady_regions[0].setRegion((3.,7.))
    assert window.steady_a.value()==3. and window.steady_b.value()==7.
    assert window._steady_selected is None and window.steady_cards['dp'][1].text()=='—'
    window._steady_measure(); base.wait_jobs(window,app)
    assert window._steady_manual['stats']['pin']['n']==4000
    window._steady_restore()
    assert window._steady_manual is None and window._steady_selected['mode']=='auto'
    window.steady_noise.setValue(.25)
    assert window._steady_result is None and not window.steady_csv.isEnabled()


def test_ui_unknown_unit_never_assumes_bar_and_utc_range_is_relative(window,app):
    sources=record(start=1791964800.,mode='datetime')
    populate(window,sources)
    window.steady_units['pin'].setCurrentIndex(0)
    window._steady_analyze(); base.wait_jobs(window,app)
    assert window._steady_result is None and 'birimini seçin' in window.steady_summary.text()
    window.steady_units['pin'].setCurrentIndex(window.steady_units['pin'].findData('bar'))
    window.steady_limit.setChecked(True)
    window.steady_search_a.setValue(9.); window.steady_search_b.setValue(17.)
    window._steady_analyze(); base.wait_jobs(window,app)
    assert window.steady_a.value()==10. and window.steady_b.value()==16.
    assert 'UTC' in window.steady_used.text()
    window.set_theme('dark'); app.processEvents()


def test_ui_changed_data_and_cancel_do_not_accept_stale_results(window,app,monkeypatch):
    import tdms_steady_ui as ui
    populate(window,record())
    def delayed(sources,options,cancel,bounds):
        while not cancel(): time.sleep(.002)
        raise ExportCancelled()
    monkeypatch.setattr(ui,'analyze_steady',delayed)
    window._steady_analyze()
    window.steady_channels['pout'].setCurrentIndex(0)
    base.wait_jobs(window,app)
    assert window._steady_result is None and window.steady_run.isEnabled()


def test_ui_csv_exports_all_auto_intervals_and_current_manual(window,app,tmp_path,monkeypatch):
    populate(window,record()); window._steady_analyze(); base.wait_jobs(window,app)
    window.steady_a.setValue(3.); window.steady_b.setValue(7.)
    window._steady_measure(); base.wait_jobs(window,app)
    dest=tmp_path/'sonuc.csv'
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a:(str(dest),'CSV'))
    window._steady_export(); base.wait_jobs(window,app)
    rows=list(csv.reader(dest.read_text(encoding='utf-8-sig').splitlines(),delimiter=';'))
    assert sum(row[1:2]==['Otomatik'] for row in rows)==2
    assert sum(row[1:2]==['Elle'] for row in rows)==1


def test_role_suggestions_never_guess_ambiguous_names():
    s=record()
    assert suggest_roles(s)=={'pin':'Pin','pout':'Pout','flow':'Debi'}
    s.append(dict(s[0],key='Pin2'))
    assert 'pin' not in suggest_roles(s)
    assert pressure_unit('V') is None
    assert pressure_unit('bar(g)')=='bar' and pressure_unit('kPa')=='kPa'


def test_final_partial_window_is_available_for_manual_calculation():
    s=record()
    for channel in s:
        channel['x'] *= 1.015
        channel['fs_hz'] /= 1.015
        channel['x_inc'] *= 1.015
    r=analyze_steady(s)
    assert r['bounds'][1]==pytest.approx(20.3)
    assert r['evaluation_bounds'][1]==20.
    manual=measure_steady(s,19.5,20.3)['interval']
    assert manual['stats']['pin']['n']>1


def test_calibrated_virtual_channel_can_be_selected(window,app):
    populate(window,record())
    pin=window.current_series[0]
    pin['is_virtual']=True; pin['file_label']='Hesaplanan'
    window._steady_refresh()
    assert window.steady_channels['pin'].findData(pin['style_key'])>0
    window._steady_analyze(); base.wait_jobs(window,app)
    assert window._steady_selected['dp_bar']==pytest.approx(.062)


def test_negative_dp_is_preserved_and_explained(window,app):
    s=record(); s[0]['y'],s[1]['y']=s[1]['y'],s[0]['y']
    populate(window,s); window._steady_analyze(); base.wait_jobs(window,app)
    assert window._steady_selected['dp_bar']==pytest.approx(-.062)
    assert 'Δp negatif' in window.steady_detail.text()


def test_source_changed_error_and_cancellation(tmp_path):
    s=record()
    p=tmp_path/'source'; p.write_bytes(b'a')
    stat=p.stat(); s[0].update(source_path=str(p),source_fingerprint={'size':stat.st_size,'mtime_ns':stat.st_mtime_ns})
    p.write_bytes(b'changed')
    with pytest.raises(ValueError,match='değişti'): analyze_steady(s)
    with pytest.raises(ExportCancelled): analyze_steady(record(),cancelled=lambda:True)


def test_large_pressure_offset_keeps_small_standard_deviation():
    s=record(); rng=np.random.default_rng(992)
    for p in s[:2]:
        p['y'] += 1e6+rng.normal(0,.001,len(p['y']))
    r=analyze_steady(s,SteadyOptions(chunk_size=121))
    for e in r['intervals']:
        for p in s[:2]:
            y=p['y'][(p['x']>=e['start'])&(p['x']<e['end'])]
            assert e['stats'][p['role']]['std']==pytest.approx(y.std(ddof=1),abs=1e-10)


def test_actual_demo_workflow_after_load_and_manual_fs(window,app):
    from pathlib import Path
    path=Path(__file__).parents[1]/'examples'/'basinc_kaybi_demo.tdms'
    payload=base.load(path,[('AkisTesti','Pin',26001),('AkisTesti','Pout',26001),('AkisTesti','Debi',2601)])
    window._on_load_ready(payload); base.wait_jobs(window,app)
    window._steady_suggest_channels(); window._steady_analyze(); base.wait_jobs(window,app)
    assert len(window._steady_result['intervals'])==2
    assert window._steady_result['intervals'][0]['dp_bar']==pytest.approx(.062,abs=.0001)
    assert window._steady_result['intervals'][1]['dp_bar']==pytest.approx(.028,abs=.0001)
    result=window._steady_result
    window.chk_smooth.setChecked(True); base.wait_jobs(window,app)
    assert window._steady_result is result  # drawing filters never alter analysis
    # A time edit must cancel/invalidate measurements before they can be used.
    pin=window.current_series[0]
    window.channel_fs_overrides[pin['style_key']]=500.
    window._apply_channel_timing()
    assert window._steady_result is None


def test_unit_metadata_edit_resets_conversion_and_manual_unit_survives_refresh(window,app):
    populate(window,record())
    key=window.steady_channels['pin'].currentData()
    window.style_map[key]={'unit_override':'kPa'}
    window._steady_refresh()
    assert window.steady_units['pin'].currentData()=='kPa'
    window.steady_units['pin'].setCurrentIndex(window.steady_units['pin'].findData('bar'))
    window.current_series[0]['fs_est']=500.
    window._steady_refresh()
    assert window.steady_units['pin'].currentData()=='bar'
