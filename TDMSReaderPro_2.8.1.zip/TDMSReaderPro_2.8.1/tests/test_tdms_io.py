import os
import threading

import numpy as np
import pytest
from nptdms import ChannelObject, TdmsFile, TdmsWriter
from nptdms.test import scenarios

import tdms_io


@pytest.fixture(autouse=True)
def empty_pool():
    tdms_io.clear_pool()
    yield
    tdms_io.clear_pool()


def _equal(actual, expected):
    assert len(actual) == len(expected)
    if len(expected):
        np.testing.assert_array_equal(np.asarray(actual), np.asarray(expected))


@pytest.mark.parametrize("index", [False, True])
@pytest.mark.parametrize("generated,expected", scenarios.get_scenarios())
def test_every_nptdms_layout_reads_identical_windows(tmp_path, generated, expected, index):
    path = tmp_path / "s.tdms"
    path.write_bytes(generated._get_contents())
    if index:
        (tmp_path / "s.tdms_index").write_bytes(generated._get_index_contents())
    with tdms_io.open_tdms(path) as tdms:
        for (group, channel), data in expected.items():
            ch = tdms[group][channel]
            n = len(data)
            assert len(ch) == n
            _equal(ch.read_data(), data)
            _equal(ch[:], data)
            for a in range(0, n + 1):
                for length in (0, 1, 2, 3, n):
                    _equal(ch.read_data(a, length), data[a:a + length])


def _multi_segment_file(path, segments=40, per=37):
    rng = np.random.default_rng(3)
    data = {"A": [], "B": [], "C": []}
    with TdmsWriter(path) as w:
        for s in range(segments):
            objs = []
            for name, dtype in (("A", np.float64), ("B", np.int16), ("C", np.float32)):
                if name == "C" and s % 3 == 1:
                    continue  # Channel absent from some segments.
                count = per + (s % 5 if name != "B" else 0)
                values = (rng.standard_normal(count) * 1000).astype(dtype)
                data[name].append(values)
                objs.append(ChannelObject("G", name, values, {"wf_increment": .001} if s == 0 else {}))
            w.write_segment(objs)
    return {k: np.concatenate(v) for k, v in data.items()}


def test_fast_path_matches_nptdms_across_segments_and_is_used(tmp_path):
    path = tmp_path / "multi.tdms"
    expected = _multi_segment_file(path)
    rng = np.random.default_rng(4)
    with tdms_io.open_tdms(path) as tdms, TdmsFile.open(path) as reference:
        for name, data in expected.items():
            ch = tdms["G"][name]
            assert ch.fast
            assert ch.read_data().dtype == reference["G"][name].read_data().dtype
            for _ in range(60):
                a = int(rng.integers(0, len(data)))
                length = int(rng.integers(0, len(data) - a + 5))
                _equal(ch.read_data(a, length), reference["G"][name].read_data(a, length))
            _equal(ch[5:-3], data[5:-3])
            _equal(ch[::7], data[::7])
            assert ch[-1] == data[-1]


def test_scaled_channel_uses_same_scaling_as_nptdms(tmp_path):
    path = tmp_path / "scaled.tdms"
    raw = np.arange(1000, dtype=np.int32)
    props = {"NI_Number_Of_Scales": 1, "NI_Scale[0]_Scale_Type": "Linear",
             "NI_Scale[0]_Linear_Slope": 0.5, "NI_Scale[0]_Linear_Y_Intercept": 3.0}
    with TdmsWriter(path) as w:
        w.write_segment([ChannelObject("G", "S", raw, props)])
        w.write_segment([ChannelObject("G", "S", raw, props)])
    with tdms_io.open_tdms(path) as tdms, TdmsFile.open(path) as reference:
        ch = tdms["G"]["S"]
        assert ch.fast
        _equal(ch.read_data(900, 300), reference["G"]["S"].read_data(900, 300))
        np.testing.assert_allclose(ch.read_data(0, 3), [3.0, 3.5, 4.0])


def test_truncated_final_segment_reads_like_nptdms(tmp_path):
    path = tmp_path / "cut.tdms"
    with TdmsWriter(path) as w:
        for s in range(3):
            w.write_segment([ChannelObject("G", "A", np.arange(s * 100, s * 100 + 100, dtype=np.float64)),
                             ChannelObject("G", "B", np.arange(100, dtype=np.int32))])
    with open(path, "r+b") as f:
        f.truncate(os.path.getsize(path) - 500)
    with tdms_io.open_tdms(path) as tdms, TdmsFile.open(path) as reference:
        for name in ("A", "B"):
            assert len(tdms["G"][name]) == len(reference["G"][name])
            _equal(tdms["G"][name].read_data(), reference["G"][name].read_data())


def test_metadata_is_reused_until_file_changes_and_handles_are_released(tmp_path, monkeypatch):
    path = tmp_path / "pool.tdms"
    with TdmsWriter(path) as w:
        w.write_segment([ChannelObject("G", "A", np.arange(10.0))])
    opened = []
    original = TdmsFile.open
    monkeypatch.setattr(tdms_io.TdmsFile, "open", staticmethod(lambda p: opened.append(p) or original(p)))
    for _ in range(3):
        with tdms_io.open_tdms(path) as tdms:
            _equal(tdms["G"]["A"][:], np.arange(10.0))
    assert len(opened) == 1
    entry = next(iter(tdms_io._POOL.values()))
    assert entry.users == 0 and entry.tdms._reader._file is None
    os.replace(path, tmp_path / "moved.tdms")  # No open handle keeps the file locked.
    os.replace(tmp_path / "moved.tdms", path)
    with TdmsWriter(path, mode="a") as w:
        w.write_segment([ChannelObject("G", "A", np.arange(10.0, 15.0))])
    with tdms_io.open_tdms(path) as tdms:
        _equal(tdms["G"]["A"][:], np.arange(15.0))
    assert len(opened) == 2
    tdms_io.forget(str(path))
    assert not tdms_io.pooled_paths()


def test_concurrent_sessions_read_consistent_data(tmp_path):
    path = tmp_path / "threads.tdms"
    data = np.arange(400_000, dtype=np.float64)
    with TdmsWriter(path) as w:
        w.write_segment([ChannelObject("G", "A", data), ChannelObject("G", "B", -data)])
    errors = []

    def work(seed):
        rng = np.random.default_rng(seed)
        try:
            for _ in range(40):
                with tdms_io.open_tdms(path) as tdms:
                    a = int(rng.integers(0, len(data)))
                    name = "A" if seed % 2 else "B"
                    got = tdms["G"][name].read_data(a, 5000)
                    want = data[a:a + 5000] * (1 if name == "A" else -1)
                    if not np.array_equal(got, want):
                        errors.append((seed, a))
        except Exception as exc:  # pragma: no cover - reported below
            errors.append(exc)

    threads = [threading.Thread(target=work, args=(i,)) for i in range(6)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors
    entry = next(iter(tdms_io._POOL.values()))
    assert entry.users == 0
