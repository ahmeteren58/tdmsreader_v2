import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import shutil
import zipfile
import json
from dataclasses import replace
from pathlib import Path
import numpy as np
import pytest
from nptdms import ChannelObject
from PyQt6.QtCore import Qt, QPoint
from PyQt6.QtGui import QContextMenuEvent
from PyQt6.QtWidgets import QApplication, QMenu, QMessageBox
from PyQt6.QtTest import QTest
import pyqtgraph as pg
import tdmsreader as appmod
from tdms_export import export_snapshot
from tdms_inspection import measure_sources, inspect_sources
from tdms_project import read_project_archive, save_project_archive
import test_regressions as base

app = base.app
window = base.window


def open_demo(window, app, tmp_path):
    path = base.tdms_file(tmp_path, [
        ChannelObject("AI", "Pressure", np.array(["1.25", "2", "3.5", "", "5"]), properties={"wf_increment": .1, "unit_string": "bar"}),
        ChannelObject("DO", "Command", np.array([0, 1, 1, 0], dtype=np.int16), properties={"wf_increment": .2})])
    window.open_tdms_path(str(path)); base.wait_jobs(window, app)
    state = next(iter(window.files.values()))
    for i in range(state.tree.topLevelItemCount()):
        state.tree.topLevelItem(i).setCheckState(0, Qt.CheckState.Checked)
    window.plot_checked_channels(); base.wait_jobs(window, app)
    return path


@pytest.mark.parametrize("target", ["overlay", "stacked", "detached", "fft"])
def test_only_one_context_menu_and_no_native_menu(window, app, tmp_path, monkeypatch, target):
    open_demo(window, app, tmp_path)
    window.show(); app.processEvents()
    if target == "stacked":
        window.cmb_plot_mode.setCurrentText("Stacked"); base.wait_jobs(window, app)
        widget = window.stacked_view.canvas
    elif target == "detached":
        window.toggle_detach_plot(); base.wait_jobs(window, app)
        widget = window.detached_win.pane.plot
    elif target == "fft":
        window._activate_tab_by_text("Frekans Analizi (FFT)")
        widget = window.fft_plot
    else:
        widget = window.plot_pane.plot
    native = []
    monkeypatch.setattr(pg.ViewBox, "raiseContextMenu", lambda *a: native.append(True))
    app.processEvents()
    point = QPoint(100, 70)
    QTest.mouseClick(widget.viewport(), Qt.MouseButton.RightButton, Qt.KeyboardModifier.ControlModifier, pos=point)
    event = QContextMenuEvent(QContextMenuEvent.Reason.Mouse, point, widget.viewport().mapToGlobal(point), Qt.KeyboardModifier.ControlModifier)
    QApplication.sendEvent(widget.viewport(), event)
    app.processEvents()
    assert native == []
    menus = [w for w in QApplication.topLevelWidgets() if isinstance(w, QMenu) and w.isVisible()]
    assert len(menus) == 1 and menus[0].objectName() == "tdmsPlotContextMenu"
    assert not any("View All" in a.text() or "Plot Options" in a.text() or "Export" == a.text() for a in menus[0].actions())
    menus[0].close(); app.processEvents()


def test_ab_uses_nearest_full_samples_with_offsets_and_keeps_int_precision():
    a = base.memory_source("integer", np.array([2**63+10, 2**63+20, 2**63+30], dtype=np.uint64), [0, 1, 2])
    b = base.memory_source("float", [1., 3.], [0, 2]); b.update(x_shift=1, y_shift=10)
    result = measure_sources([a, b], [1, 2])["rows"]
    assert result[0]["a"]["y"] == 2**63+20 and result[0]["dy"] == 10
    assert result[1]["a"]["x"] == 1 and result[1]["a"]["y"] == 11
    assert result[1]["b"]["index"] == 0  # equidistant -> earlier sample
    outside = measure_sources([a], [-1, 3])["rows"][0]
    assert outside["a"] is None and outside["b"] is None


def test_ab_lazy_reads_original_point_even_if_missing_from_overview(tmp_path, monkeypatch):
    monkeypatch.setattr(appmod, "CFG", replace(appmod.CFG, lazy=replace(appmod.CFG.lazy, fullload_threshold=5, overview_max_points=20)))
    values = np.arange(1000, dtype=float)
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", values, properties={"wf_increment": .001})])
    series = base.load(path, [("G", "A", 1000)])["series"][0]
    assert 433 not in series["_sample_indices"]
    row = measure_sources([export_snapshot(series)], [.433, .721])["rows"][0]
    assert row["a"]["index"] == 433 and row["b"]["y"] == 721


def test_quality_counts_entire_lazy_channel(tmp_path, monkeypatch):
    monkeypatch.setattr(appmod, "CFG", replace(appmod.CFG, lazy=replace(appmod.CFG.lazy, fullload_threshold=5, overview_max_points=20)))
    y = np.arange(2000, dtype=float); y[100:120] = np.nan; y[501] = np.inf
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", y)])
    series = base.load(path, [("G", "A", len(y))])["series"][0]
    source = export_snapshot(series)
    row = inspect_sources([source])["rows"][0]
    assert row["nan"] == 20 and row["inf"] == 1 and row["finite"] == 1979
    assert row["invalid_percent"] == 1.05 and not row.get("error")


def test_quality_object_source_and_loaded_dtype(window, app, tmp_path):
    open_demo(window, app, tmp_path)
    window._request_quality(); base.wait_jobs(window, app)
    row = window.quality_tree.topLevelItem(0)
    assert row.text(1) == "String" and row.text(2) == "float64"
    assert row.text(6) == "1" and row.text(8) == "20"


def test_ab_gui_drag_sync_and_interval_statistics(window, app, tmp_path):
    open_demo(window, app, tmp_path)
    window._show_inspection(0)
    window._ab_positions = [.1, .4]; window._sync_ab_positions()
    window._ab_timer.stop(); window._request_ab_values(); base.wait_jobs(window, app)
    assert window.ab_tree.topLevelItemCount() == 2
    assert window.ab_tree.topLevelItem(0).text(3) == "2"
    window._calculate_ab_stats(); base.wait_jobs(window, app)
    assert window.ab_tree.topLevelItem(0).text(8) == "3"  # one NaN excluded
    assert window.ab_tree.topLevelItem(0).text(9) == "3.5"
    window.cmb_plot_mode.setCurrentText("Stacked"); base.wait_jobs(window, app)
    window._ab_timer.stop()
    window._ab_items[-2][1].setValue(.2)
    assert window.ab_a.value() == .2
    assert all(line.value() == .2 for _, line, i in window._ab_items if i == 0)
    window.ab_check.setChecked(False)


@pytest.mark.parametrize("lazy", [False, True])
def test_project_roundtrip_restores_channels_styles_virtual_and_settings(window, app, tmp_path, monkeypatch, lazy):
    if lazy:
        monkeypatch.setattr(appmod, "CFG", replace(appmod.CFG, lazy=replace(appmod.CFG.lazy, fullload_threshold=2)))
    open_demo(window, app, tmp_path)
    window._populate_calculated_aliases()
    window.calc_name.setText("DeltaP"); window.calc_expression.setText("C1 * 2")
    window._create_calculated_channel(); base.wait_jobs(window, app)
    original = [s["y"].copy() for s in window.current_series]
    key = window.current_series[0]["style_key"]
    window.style_map[key] = {"display_name": "PT-01", "color": (10, 120, 140), "axis": "left", "x_shift": .5, "y_shift": 2.0}
    window.channel_fs_overrides[key] = 20
    window._apply_channel_timing()
    window.update_plot_data_with_filter(); base.wait_jobs(window, app)
    window._on_marker_requested_from("main", .6, 4)
    window.le_axis_y_title.setText("Basınç (bar)")
    window._apply_axis_style_from_controls(show_status=False)
    window.plot_pane.set_xrange(.5, .8)
    window._ab_positions = [.55, .65]
    window.ab_check.setChecked(True); window._ab_timer.stop()
    window.chk_smooth.setChecked(True); base.wait_jobs(window, app)
    window._ab_timer.stop()
    errors = []
    monkeypatch.setattr(QMessageBox, "warning", lambda *args: errors.append(args[-1]))
    path = tmp_path/"saved.tdmsproj"
    window.save_project(path=str(path)); base.wait_jobs(window, app)
    assert path.exists() and not errors, errors
    window.on_clear_plot()
    window.style_map.clear(); window.channel_fs_overrides.clear()
    window._open_project_path(str(path)); base.wait_jobs(window, app)
    window._ab_timer.stop()
    assert not errors, errors
    assert len(window.current_series) == 3
    for s, y in zip(window.current_series, original):
        np.testing.assert_array_equal(s["y"], y)
    assert window.style_map[key]["display_name"] == "PT-01"
    assert window.channel_fs_overrides[key] == 20
    assert window.current_series[0]["fs_est"] == 20
    assert window.current_series[-1]["virtual_expression"] == "C1 * 2"
    assert window.current_series[-1]["virtual_sources"]
    assert window._markers and window.chk_smooth.isChecked()
    assert window.le_axis_y_title.text() == "Basınç (bar)"
    assert window._ab_positions == [.55, .65]
    assert "saved" in window.windowTitle()
    # Saving/loading must not cancel or lose the completed project job.
    assert window._project_progress is None and not window._project_busy
    window.ab_check.setChecked(False)


def test_project_missing_source_and_malformed_state_leave_current_plot(window, app, tmp_path, monkeypatch):
    path = open_demo(window, app, tmp_path)
    project = tmp_path/"project.tdmsproj"
    manifest, virtual = window._project_manifest(str(project))
    save_project_archive(str(project), manifest, virtual)
    existing = window.current_series
    errors = []; monkeypatch.setattr(QMessageBox, "warning", lambda *args: errors.append(args[-1]))
    path.rename(tmp_path/"moved.tdms")
    window._open_project_path(str(project)); base.wait_jobs(window, app)
    assert window.current_series is existing and errors
    (tmp_path/"moved.tdms").rename(path)
    manifest["ui"]["numbers"]["spin_smooth_win"] = "invalid"
    save_project_archive(str(project), manifest, virtual)
    window._open_project_path(str(project)); base.wait_jobs(window, app)
    assert window.current_series is existing and len(errors) == 2


def test_project_relative_paths_survive_folder_move(window, app, tmp_path):
    open_demo(window, app, tmp_path)
    project = tmp_path/"session.tdmsproj"
    manifest, virtual = window._project_manifest(str(project))
    save_project_archive(str(project), manifest, virtual)
    moved = tmp_path/"moved"; moved.mkdir()
    for record in manifest["files"]:
        shutil.copy2(record["path"], moved/Path(record["path"]).name)
    shutil.copy2(project, moved/project.name)
    data, _ = read_project_archive(moved/project.name)
    assert Path(data["files"][0]["resolved_path"]).parent == moved


def test_cancelled_project_save_keeps_existing_target(window, app, tmp_path):
    open_demo(window, app, tmp_path)
    project = tmp_path/"existing.tdmsproj"; project.write_bytes(b"original")
    manifest, virtual = window._project_manifest(str(project))
    from tdms_export import ExportCancelled
    with pytest.raises(ExportCancelled):
        save_project_archive(project, manifest, virtual, cancelled=lambda: True)
    assert project.read_bytes() == b"original"
    assert not list(tmp_path.glob(".*.tmp"))


def test_project_rejects_new_format_version(tmp_path):
    path = tmp_path/"future.tdmsproj"
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("project.json", json.dumps({"format": "TDMSReaderProject", "version": 999}))
    with pytest.raises(ValueError, match="sürümü"):
        read_project_archive(path)


def test_project_detects_source_change_after_loading(window, app, tmp_path, monkeypatch):
    source = open_demo(window, app, tmp_path)
    stat = source.stat()
    os.utime(source, ns=(stat.st_atime_ns, stat.st_mtime_ns + 1_000_000_000))
    errors = []; monkeypatch.setattr(QMessageBox, "warning", lambda *args: errors.append(args[-1]))
    path = tmp_path/"must-not-save.tdmsproj"
    window.save_project(path=str(path)); base.wait_jobs(window, app)
    assert not path.exists() and "değişmiş" in errors[0]
    window._request_quality(); base.wait_jobs(window, app)
    assert "değişti" in window.quality_tree.topLevelItem(0).text(9)


def test_stacked_project_ranges_and_new_file_ids(window, app, tmp_path, monkeypatch):
    open_demo(window, app, tmp_path)
    second = tmp_path/"second"; second.mkdir()
    second_path = base.tdms_file(second, [ChannelObject("G", "B", np.arange(10))])
    window.open_tdms_path(str(second_path)); base.wait_jobs(window, app)
    state = list(window.files.values())[-1]
    state.tree.topLevelItem(0).setCheckState(0, Qt.CheckState.Checked)
    window.plot_checked_channels(); base.wait_jobs(window, app)
    window.cmb_plot_mode.setCurrentText("Stacked"); base.wait_jobs(window, app)
    window._apply_interaction_mode_to_all("zoom")
    assert all(p.getViewBox().state["mouseMode"] == pg.ViewBox.RectMode for p in window.stacked_view._plots)
    window.stacked_view._plots[0].getViewBox().setYRange(-10, 20, padding=0)
    window.stacked_view.set_xrange(0, .3)
    project = tmp_path/"stacked.tdmsproj"
    errors = []; monkeypatch.setattr(QMessageBox, "warning", lambda *args: errors.append(args[-1]))
    window.save_project(path=str(project)); base.wait_jobs(window, app)
    window._open_project_path(str(project)); base.wait_jobs(window, app)
    assert not errors
    assert len(window.files) == 2 and len(window.current_series) == 3
    assert window.cmb_plot_mode.currentText() == "Stacked"
    np.testing.assert_allclose(window.stacked_view._plots[0].getViewBox().viewRange()[1], [-10, 20])
    third = tmp_path/"third"; third.mkdir()
    third_path = base.tdms_file(third, [ChannelObject("G", "C", np.arange(4))])
    window.open_tdms_path(str(third_path)); base.wait_jobs(window, app)
    assert len(window.files) == 3 and len(set(window.files)) == 3


def test_ab_stats_can_be_requested_before_debounce_finishes(window, app, tmp_path):
    open_demo(window, app, tmp_path)
    window._show_inspection(0)
    window._ab_positions = [.1, .4]; window._sync_ab_positions()
    window._calculate_ab_stats(); base.wait_jobs(window, app)
    assert window.ab_tree.topLevelItemCount() == 2
    assert window.ab_tree.topLevelItem(0).text(9) == "3.5"
    window.ab_check.setChecked(False)


def test_project_invalid_background_does_not_clear_current_data(window, app, tmp_path, monkeypatch):
    open_demo(window, app, tmp_path)
    path = tmp_path/"invalid-ui.tdmsproj"
    manifest, virtual = window._project_manifest(str(path))
    manifest["ui"]["background"] = "wrong"
    save_project_archive(path, manifest, virtual)
    existing = window.current_series
    errors = []; monkeypatch.setattr(QMessageBox, "warning", lambda *args: errors.append(args[-1]))
    window._open_project_path(str(path)); base.wait_jobs(window, app)
    assert errors and window.current_series is existing
