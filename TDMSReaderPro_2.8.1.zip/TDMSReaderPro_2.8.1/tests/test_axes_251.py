"""User-visible regressions: seconds, dual-axis zoom, explicit ranges and reloads."""
from dataclasses import replace
import json
import zipfile
import numpy as np
import pytest
from nptdms import ChannelObject
from PyQt6.QtCore import QPointF, Qt
from PyQt6.QtWidgets import QDialog, QMessageBox
import tdmsreader as m
from tdms_axes import AxisRangeDialog, validate_ranges
from tdms_export import export_snapshot, read_source_xy, write_csv, ExportOptions
from tdms_inspection import measure_sources
import test_regressions as base

app = base.app
window = base.window


def dual_pane(app, right_only=False):
    pane = m.PlotPane()
    pane.resize(900, 600)
    pane.show()
    x = np.linspace(0, 10, 1001)
    rows = [dict(style_key='a', name='Pressure', x=x, y=x*10, is_digital=False),
            dict(style_key='b', name='Current', x=x, y=x, is_digital=False)]
    pane.plot_series(rows[1:] if right_only else rows, 'numeric', 'Zaman (s)', {'b': {'axis':'right'}})
    app.processEvents()
    return pane


@pytest.mark.parametrize('lazy', [False, True])
def test_utc_is_seconds_with_stable_file_origin_and_independent_fs(window, tmp_path, monkeypatch, lazy):
    if lazy:
        monkeypatch.setattr(m, 'CFG', replace(m.CFG, lazy=replace(m.CFG.lazy, fullload_threshold=2)))
    t0=np.datetime64('2026-09-28T12:00:00')
    path=base.tdms_file(tmp_path, [
        ChannelObject('G','Early',np.arange(11),properties={'wf_start_time':t0,'wf_increment':.01,'wf_start_offset':.25}),
        ChannelObject('G','Late',np.arange(11),properties={'wf_start_time':t0+np.timedelta64(2,'s'),'wf_increment':.02,'wf_start_offset':.5}),
    ])
    both=base.load(path,[('G','Early',11),('G','Late',11)])
    late=base.load(path,[('G','Late',11)])['series'][0]
    assert both['axis_mode']=='numeric' and both['x_label']=='Zaman (s)'
    assert late['x'][0]==2.5  # Selecting only the later channel must not re-zero it.
    window.current_series=both['series'];window._apply_channel_timing()
    a,b=window.current_series
    for s, expected_base, inc in [(a,.25,.01),(b,2.5,.02)]:
        assert s['x_mode']=='seconds'
        np.testing.assert_allclose(s['x'],expected_base+np.arange(11)*inc,rtol=0,atol=1e-15)
        xx,yy=read_source_xy(export_snapshot(s))
        np.testing.assert_array_equal(xx,s['x']);np.testing.assert_array_equal(yy,np.arange(11))
    window.channel_fs_overrides[b['style_key']]=1000
    window._apply_channel_timing()
    assert b['x'][0]==2.5 and b['x'][-1]==2.51
    assert a['fs_est']==100
    snap=export_snapshot(b)
    row=measure_sources([snap],[2.501,2.503])['rows'][0]
    assert row['a']['index']==1 and row['b']['index']==3
    assert row['dt']==pytest.approx(.002)
    csv_path=tmp_path/'seconds.csv'
    write_csv(str(csv_path),[snap],ExportOptions())
    assert float(base.read_csv(csv_path)[1][0])==2.5


def test_nanosecond_spacing_survives_calendar_removal(tmp_path):
    path=base.tdms_file(tmp_path,[ChannelObject('G','A',np.arange(10),properties={
        'wf_increment':1e-9,'wf_start_time':np.datetime64('2026-09-28')})])
    s=base.load(path,[('G','A',10)])['series'][0]
    np.testing.assert_allclose(np.diff(s['x']),1e-9,rtol=1e-14,atol=0)


def test_invalid_calendar_does_not_discard_valid_fs():
    props=m._relative_waveform_props({'wf_start_time':np.datetime64('NaT'),'wf_increment':.01,'wf_start_offset':.2},None)
    assert m._xmeta_from_channel_props(props)==('seconds',.2,.01)


@pytest.mark.parametrize('right_only',[False,True])
def test_real_wheel_zoom_changes_y2_and_reverse_restores_it(app,right_only):
    pane=dual_pane(app,right_only)
    try:
        vb=pane.plot.getViewBox()
        before=np.array(pane._right_vb.viewRange()[1])
        class Wheel:
            def __init__(self, delta):self.amount=delta
            def delta(self):return self.amount
            def pos(self):return QPointF(vb.width()/2,vb.height()/2)
            def accept(self):pass
        vb.wheelEvent(Wheel(120))
        after=np.array(pane._right_vb.viewRange()[1])
        assert np.ptp(after)<np.ptp(before)*.95
        assert np.ptp(after)/np.ptp(before)==pytest.approx(np.ptp(vb.viewRange()[1])/np.ptp(pane._base_left_yrange))
        vb.wheelEvent(Wheel(-120))
        np.testing.assert_allclose(pane._right_vb.viewRange()[1],before,atol=1e-10)
        # Equivalent completed rectangle range: keep the center 20% vertically.
        l0,l1=vb.viewRange()[1]
        vb.setYRange(l0+.4*(l1-l0),l0+.6*(l1-l0),padding=0)
        assert np.ptp(pane._right_vb.viewRange()[1])==pytest.approx(np.ptp(before)*.2)
        if right_only:
            assert vb.viewRange()[0][0]<=0 and vb.viewRange()[0][1]>=10
    finally:
        pane.close();pane.deleteLater();app.processEvents()


def test_manual_axis_ranges_are_independent_and_become_zoom_reference(app):
    pane=dual_pane(app)
    try:
        before=pane.plot.getViewBox().viewRange()[1][:]
        pane.set_axis_ranges({'y2':(2,3)})
        np.testing.assert_allclose(pane.plot.getViewBox().viewRange()[1],before)
        np.testing.assert_allclose(pane._right_vb.viewRange()[1],[2,3])
        pane.set_axis_ranges({'y':(20,40)})
        np.testing.assert_allclose(pane._right_vb.viewRange()[1],[2,3])
        pane.plot.getViewBox().scaleBy(y=.5)
        assert np.ptp(pane._right_vb.viewRange()[1])==pytest.approx(.5)
        pane.set_right_y_lock(True)
        locked=pane._right_vb.viewRange()[1][:]
        pane.plot.getViewBox().scaleBy(y=.5)
        np.testing.assert_allclose(pane._right_vb.viewRange()[1],locked)
        pane.set_right_y_lock(False)
        np.testing.assert_allclose(pane._right_vb.viewRange()[1],locked)
        pane.set_y_lock(True)
        left_locked=pane.plot.getViewBox().viewRange()[1][:]
        right_span=np.ptp(pane._right_vb.viewRange()[1])
        pane.plot.getViewBox().scaleBy(y=.5)
        np.testing.assert_allclose(pane.plot.getViewBox().viewRange()[1],left_locked)
        assert np.ptp(pane._right_vb.viewRange()[1])==pytest.approx(right_span*.5)
        pane.set_right_y_lock(True)
        pane.set_axis_ranges({'x':(1,2),'y':(-1,1),'y2':(7,9)})
        np.testing.assert_allclose(pane.plot.getViewBox().viewRange(),[[1,2],[-1,1]])
        np.testing.assert_allclose(pane._right_vb.viewRange()[1],[7,9])
    finally:
        pane.close();pane.deleteLater();app.processEvents()


@pytest.mark.parametrize('span',[(1,1),(2,1),(float('nan'),1),(0,float('inf'))])
def test_bad_ranges_fail_before_changing_any_axis(app,span):
    pane=dual_pane(app)
    try:
        before=np.array(pane.plot.getViewBox().viewRange())
        with pytest.raises(ValueError):pane.set_axis_ranges({'x':(1,2),'y':span})
        np.testing.assert_array_equal(pane.plot.getViewBox().viewRange(),before)
    finally:
        pane.close();pane.deleteLater();app.processEvents()


def test_dialog_decimal_comma_scientific_and_validation(app):
    dlg=AxisRangeDialog([('x','X1',(0,10)),('y2','Y2',(0,24))])
    try:
        check,lo,hi=dlg.rows['y2'];check.setChecked(True)
        lo.setText('2,5');hi.setText('3e1')
        assert dlg.values()=={'y2':(2.5,30)}
        hi.setText('nan');dlg._apply()
        assert dlg.result()!=QDialog.DialogCode.Accepted and dlg.error.text()
    finally:dlg.deleteLater();app.processEvents()


def open_two(window,app,tmp_path,monkeypatch,lazy=False,utc=False):
    if lazy:monkeypatch.setattr(m,'CFG',replace(m.CFG,lazy=replace(m.CFG.lazy,fullload_threshold=100)))
    x=np.arange(10001)*.001
    props={'wf_increment':.001}
    if utc:props['wf_start_time']=np.datetime64('2026-09-28T12:00:00')
    path=base.tdms_file(tmp_path,[ChannelObject('G','A',np.sin(x),properties=props),ChannelObject('G','B',20+np.cos(x),properties=props)])
    window.open_tdms_path(str(path));base.wait_jobs(window,app)
    state=next(iter(window.files.values()))
    state.tree.topLevelItem(0).setCheckState(0,Qt.CheckState.Checked)
    window.plot_checked_channels();base.wait_jobs(window,app)
    key=window.current_series[1]['style_key'];window.style_map[key]={'axis':'right'}
    window.update_plot_data_with_filter();base.wait_jobs(window,app)
    return path


def test_lazy_refresh_keeps_exact_y_ranges(window,app,tmp_path,monkeypatch):
    open_two(window,app,tmp_path,monkeypatch,lazy=True)
    pane=window.plot_pane
    pane.set_axis_ranges({'x':(2,2.1),'y':(-.4,.4),'y2':(20.1,20.2)})
    window._lazy_view_timer.stop();window._run_lazy_view_update();base.wait_jobs(window,app)
    np.testing.assert_allclose(pane.plot.getViewBox().viewRange(),[[2,2.1],[-.4,.4]],atol=1e-12)
    np.testing.assert_allclose(pane._right_vb.viewRange()[1],[20.1,20.2],atol=1e-12)
    assert window.current_series[0]['_sample_indices'][0]>0


def test_project_roundtrip_retains_seconds_and_y2_zoom(window,app,tmp_path,monkeypatch):
    open_two(window,app,tmp_path,monkeypatch,utc=True)
    pane=window.plot_pane
    pane.set_axis_ranges({'x':(1,2),'y':(-.5,.5),'y2':(20,20.5)})
    project=tmp_path/'axes.tdmsproj'
    window.save_project(path=str(project));base.wait_jobs(window,app)
    window._open_project_path(str(project));base.wait_jobs(window,app)
    assert all(s['x_mode']=='seconds' for s in window.current_series)
    np.testing.assert_allclose(pane.plot.getViewBox().viewRange(),[[1,2],[-.5,.5]])
    np.testing.assert_allclose(pane._right_vb.viewRange()[1],[20,20.5])
    pane.plot.getViewBox().scaleBy(y=.5)
    assert np.ptp(pane._right_vb.viewRange()[1])==pytest.approx(.25)
    # A genuine pre-2.5.1 timestamp project must discard its stale UTC view.
    with zipfile.ZipFile(project) as archive:parts={name:archive.read(name) for name in archive.namelist()}
    data=json.loads(parts['project.json']);data.pop('time_display')
    data['ui']['x_range']=[1780000000.,1780000001.]
    parts['project.json']=json.dumps(data).encode()
    with zipfile.ZipFile(project,'w') as archive:
        for name,payload in parts.items():archive.writestr(name,payload)
    notices=[];monkeypatch.setattr(QMessageBox,'information',lambda *a:notices.append(a[-1]))
    window._open_project_path(str(project));base.wait_jobs(window,app)
    assert notices and window._current_xrange()[1]<100


def test_range_dialog_main_and_stacked_actions(window,app,tmp_path,monkeypatch):
    open_two(window,app,tmp_path,monkeypatch)
    monkeypatch.setattr(AxisRangeDialog,'exec',lambda self:QDialog.DialogCode.Accepted)
    monkeypatch.setattr(AxisRangeDialog,'values',lambda self:{'x':(2,3),'y2':(19,23)})
    window.btn_axis_ranges.click()
    np.testing.assert_allclose(window.plot_pane._right_vb.viewRange()[1],[19,23])
    window.cmb_plot_mode.setCurrentText('Stacked');base.wait_jobs(window,app)
    key=window.stacked_view._keys[0]
    monkeypatch.setattr(AxisRangeDialog,'values',lambda self:{'x':(4,5),'stacked_y::'+key:(-2,2)})
    window.btn_axis_ranges.click()
    np.testing.assert_allclose(window.stacked_view._plots[0].getViewBox().viewRange(),[[4,5],[-2,2]])
