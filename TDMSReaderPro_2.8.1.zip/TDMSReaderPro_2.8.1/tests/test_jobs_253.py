"""Background job lifecycle under rapid restarts."""
import threading
import time
import test_regressions as base
from tdms_workspace import FunctionWorker

app = base.app
window = base.window


def test_jobs_started_from_completion_callbacks_all_finish(window, app):
    # 2.5.2 could freeze for good when a worker was destroyed in its finishing
    # QThread while the GUI thread was starting the next job, as zoom/pan does.
    chains, length, done, runners = 4, 150, [], set()

    def start(chain, step):
        def work(cancelled):
            runners.add(threading.get_ident())
            return {'chain': chain, 'step': step}
        worker = FunctionWorker(work)
        window._start_job(worker, finished, tag=f'stress{chain}')
        assert worker.thread() is app.thread()

    def finished(payload):
        done.append(payload)
        if payload['step']+1 < length:
            start(payload['chain'], payload['step']+1)

    for chain in range(chains):
        start(chain, 0)
    deadline = time.monotonic()+60
    while len(done) < chains*length and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(.001)
    base.wait_jobs(window, app)
    assert len(done) == chains*length
    assert threading.main_thread().ident not in runners
