"""Behavioral regressions for timing definitions and imperfect recordings."""
import csv
import json
import numpy as np
import pytest
from nptdms import ChannelObject
from PyQt6.QtCore import Qt
from tdms_valve import ValveOptions, SignalOptions, analyze_valve, manual_measurement, write_valve_report
import test_regressions as base
from test_valve import source

app = base.app
window = base.window


def signals(mode='legacy'):
    a = np.zeros(1000); b = np.ones(1000)
    if mode == 'legacy': a[100:700] = 1; b[180:600] = 0
    elif mode == 'position': a[180:600] = 1; b[100:700] = 0
    elif mode == 'command_closed': a[100:600] = 1; b[180:700] = 0
    elif mode == 'command_open': a[100:600] = 1; b[:] = 0; b[180:700] = 1
    return [source('a',a,1000),source('b',b,1000)]


@pytest.mark.parametrize('mode',['legacy','position','command_closed','command_open'])
@pytest.mark.parametrize('chunk',[1,127,262144])
def test_explicit_modes_have_known_duration_and_original_indices(mode,chunk):
    options = ValveOptions(mode=mode,chunk_size=chunk)
    r = analyze_valve(signals(mode),options)
    assert [e['status'] for e in r['events']] == ['complete','complete']
    assert [e['duration'] for e in r['events']] == pytest.approx([.080,.100])
    for event, rule in zip(r['events'],options.rules()):
        assert event['start_channel'] == rule.start_channel
        assert event['end_channel'] == rule.end_channel
        assert manual_measurement(r['sources'],event['direction'],event['start'],event['end'],options)['duration'] == event['duration']


@pytest.mark.parametrize('channel', [0,1])
def test_contact_bounce_restores_closing_without_adding_hold_delay(channel):
    s = signals()
    if channel == 0: s[0]['y'][610] = 0
    else: s[1]['y'][650:652] = 0
    plain = analyze_valve(s)
    assert not any(e['direction'] == 'closing' and e['duration'] == pytest.approx(.1) for e in plain['events'])
    opts = [SignalOptions(),SignalOptions()]; opts[channel] = SignalOptions(min_hold_s=.003)
    r = analyze_valve(s,ValveOptions(signals=tuple(opts)))
    assert [e['duration'] for e in r['events']] == pytest.approx([.08,.1])
    assert r['ignored_runs'][channel] == 1
    assert r['rejected_runs'][channel][0]['i'] == (610 if channel == 0 else 650)


def test_terminal_bounce_reports_stable_edge_not_first_touch():
    s = signals(); s[0]['y'][702:704] = 1; s[0]['y'][706] = 1
    r = analyze_valve(s,ValveOptions(min_hold_s=.003))
    assert r['events'][-1]['duration'] == pytest.approx(.107)
    assert r['events'][-1]['end_index'] == 707


@pytest.mark.parametrize('invert',[(True,False),(False,True),(True,True)])
def test_active_low_conversion_keeps_physical_raw_trace(invert):
    s = signals('position')
    for j, flip in enumerate(invert):
        if flip: s[j]['y'] = 1-s[j]['y']
    o = ValveOptions(mode='position',signals=tuple(SignalOptions(active_low=x) for x in invert))
    r = analyze_valve(s,o)
    assert [e['duration'] for e in r['events']] == pytest.approx([.08,.1])
    for j, flip in enumerate(invert):
        assert r['traces'][j]['y'][0] == s[j]['y'][0]
        assert r['logical_traces'][j]['y'][0] == ((1-s[j]['y'][0]) if flip else s[j]['y'][0])


@pytest.mark.parametrize('chunk',[1,97,262144])
def test_noisy_analog_schmitt_and_glitch_filter_do_not_resample(chunk):
    s = signals('command_closed'); rng = np.random.default_rng(241)
    for channel in s: channel['y'] = .1+4.8*channel['y']+rng.normal(0,.08,1000)
    s[1]['y'][650:652] = 4.9
    config = SignalOptions(input_mode='hysteresis',low_threshold=1,high_threshold=4,min_hold_s=.003)
    r = analyze_valve(s,ValveOptions(mode='command_closed',signals=(config,config),chunk_size=chunk))
    assert [e['duration'] for e in r['events']] == pytest.approx([.08,.1])
    assert r['events'][-1]['end_index'] == 700
    assert r['ignored_runs'] == [0,1]
    m = manual_measurement(s,'closing',.6,.7,r['options'])
    assert m['start_value'] == s[0]['y'][600] and m['end_value'] == s[1]['y'][700]


def test_hysteresis_band_retains_state_across_blocks_and_resets_on_gap():
    a = source('a',[.5,1,.5,.5,np.nan,.5,0,.5,1,.5],10)
    b = source('b',[1]*10,10)
    cfg = SignalOptions(input_mode='hysteresis')
    r = analyze_valve([a,b],ValveOptions(signals=(cfg,cfg),chunk_size=2))
    changes = r['changes'][0]
    assert [(c['i'],c['kind']) for c in changes] == [(0,'gap'),(1,'init'),(4,'gap'),(6,'init'),(8,'rise')]
    assert len(r['events']) == 1 and r['events'][0]['start_index'] == 8


def test_simultaneous_end_and_return_are_ambiguous_not_complete():
    s = signals(); s[1]['y'][700:] = 0
    closing = [e for e in analyze_valve(s)['events'] if e['direction'] == 'closing'][0]
    assert closing['status'] == 'ambiguous' and closing['duration'] is None


def test_manual_position_rule_uses_correct_different_sample_grids():
    a = np.zeros(2000); a[360:1200] = 1
    b = np.ones(1000); b[100:700] = 0
    sources = [source('a',a,2000),source('b',b,1000)]
    options = ValveOptions(mode='position')
    m = manual_measurement(sources,'opening',.1001,.1801,options)
    assert (m['start_index'],m['end_index']) == (100,360)
    assert m['duration'] == pytest.approx(.08)
    c = manual_measurement(sources,'closing',.6001,.7001,options)
    assert (c['start_index'],c['end_index']) == (1200,700)


def test_custom_rules_and_invalid_rule_feedback():
    r = analyze_valve(signals('command_closed'),ValveOptions(mode='custom',opening_rule=(0,'rise',1,'fall'),closing_rule=(0,'fall',1,'rise')))
    assert [e['duration'] for e in r['events']] == pytest.approx([.08,.1])
    with pytest.raises(ValueError,match='farklı'): ValveOptions(mode='custom',opening_rule=(0,'rise',0,'fall'))
    with pytest.raises(ValueError,match='aynı'): ValveOptions(mode='custom',closing_rule=(0,'rise',1,'fall'))
    # A malformed unused custom rule must not block switching back to a preset.
    assert ValveOptions(mode='position',opening_rule=(0,'rise',0,'fall')).rules()[0].start_channel == 1


@pytest.mark.parametrize('kwargs',[{'min_hold_s':float('nan')},{'min_hold_s':-1},{'input_mode':'auto'},
                                   {'input_mode':'hysteresis','low_threshold':1,'high_threshold':1},
                                   {'input_mode':'hysteresis','high_threshold':float('inf')}])
def test_invalid_conditioning_rejected(kwargs):
    with pytest.raises(ValueError): SignalOptions(**kwargs)


def test_report_contains_reproducible_config_and_correct_roles(tmp_path):
    config = SignalOptions(min_hold_s=.003,active_low=True)
    s = signals('position'); s[0]['y'] = 1-s[0]['y']
    r = analyze_valve(s,ValveOptions(mode='position',signals=(config,SignalOptions())))
    target = tmp_path/'audit.csv'; write_valve_report(target,r)
    with target.open(encoding='utf-8-sig') as stream: rows = list(csv.DictReader(stream,delimiter=';'))
    e = rows[0]; options = json.loads(e['settings_json'])
    assert (e['start_channel'],e['start_edge'],e['end_channel'],e['end_edge']) == ('B','fall','A','rise')
    assert e['measurement_mode'] == 'position' and options['signals'][0]['active_low'] is True
    assert float(e['a_hold_s']) == .003 and float(e['b_hold_s']) == 0
    assert float(rows[1]['auto_duration_ms']) == pytest.approx(100)


def test_analog_preview_is_bounded_but_event_uses_all_samples():
    n = 500_000; a = np.zeros(n); b = np.ones(n)
    a[262143:400000] = 1; b[262146:399900] = 0
    cfg = SignalOptions(input_mode='hysteresis')
    r = analyze_valve([source('a',a,1000),source('b',b,1000)],ValveOptions(signals=(cfg,cfg)))
    assert r['events'][0]['duration'] == pytest.approx(.003)
    assert r['events'][0]['start_index'] == 262143
    assert len(r['traces'][0]['x']) < 8100


@pytest.mark.parametrize('analog',[False,True])
def test_gui_mode_conditioning_diagnostics_and_manual_channel_mapping(window,app,tmp_path,analog):
    s = signals('position')
    arrays = [ch['y']*5+.05 if analog else ch['y'] for ch in s]
    path = base.tdms_file(tmp_path,[ChannelObject('Valve',name,y,properties={'wf_increment':.001}) for name,y in zip(('Open','Closed'),arrays)])
    window.open_tdms_path(str(path)); base.wait_jobs(window,app)
    next(iter(window.files.values())).tree.topLevelItem(0).setCheckState(0,Qt.CheckState.Checked)
    window.plot_checked_channels(); base.wait_jobs(window,app)
    window.valve_open.setCurrentIndex(1); window.valve_closed.setCurrentIndex(2)
    window.valve_mode.setCurrentIndex(window.valve_mode.findData('position'))
    window.valve_hold.setValue(3); window.valve_hold_b.setValue(2)
    assert not window.valve_auto.isChecked()
    if analog:
        for kind, polarity, low, high in window.valve_signal_controls:
            low.setValue(1); high.setValue(4); kind.setCurrentIndex(1)
    window._valve_analyze(); base.wait_jobs(window,app)
    assert [e['duration'] for e in window._valve_result['events']] == pytest.approx([.08,.1])
    assert window._valve_draft['start_channel'] == 1
    assert len(window._valve_logic_plots) == 2 and len(window._valve_lines) == 8
    assert 'Başlangıç (B)' in window.valve_detail.text()
    window._valve_approve(); assert window._valve_result['events'][0]['review'] == 'approved'
    window._valve_analyze(); base.wait_jobs(window,app)
    assert len(window._valve_logic_plots) == 2 and len(window._valve_lines) == 8
    window.valve_signal_controls[0][1].setCurrentIndex(1)
    assert window._valve_result is None and len(window._valve_logic_plots) == 0
