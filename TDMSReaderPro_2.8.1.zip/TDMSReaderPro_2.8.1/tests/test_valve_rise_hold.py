"""Reject rig spikes without adding confirmation delay to valve travel time."""
from dataclasses import replace
import numpy as np
import pytest
from tdms_valve import analyze_valve, _changes
from tdms_valve_auto import auto_analyze, _Edges
from tdms_valve_rules import SignalOptions, ValveOptions
from test_valve import source
import test_regressions as base

app = base.app
window = base.window


def rig_record(inverted=(False, False)):
    fs = 1_000_000
    opened = np.zeros(20_000); closed = np.ones(20_000)
    opened[6000:10000] = 1; closed[2000:13000] = 0
    opened[2500:2580] = 1; opened[4000:4800] = 1
    closed[11000:11800] = 1
    return [source(name, 1-y if flip else y, fs)
            for name, y, flip in zip(('open', 'closed'), (opened, closed), inverted)]


@pytest.mark.parametrize('chunk', [127, 262144])
@pytest.mark.parametrize('inverted', [(False, False), (True, True), (True, False)])
def test_microsecond_spikes_do_not_complete_events_early(chunk, inverted):
    sources = rig_record(inverted)
    options = ValveOptions(mode='position', chunk_size=chunk, rise_hold_s=.001,
                           signals=tuple(SignalOptions(active_low=x) for x in inverted))
    for result in (analyze_valve(sources, options), auto_analyze(sources, options)):
        assert [e['status'] for e in result['events']] == ['complete', 'complete']
        assert [(e['start_index'], e['end_index']) for e in result['events']] == [(2000, 6000), (10000, 13000)]
        assert [e['duration'] for e in result['events']] == pytest.approx([.004, .003])
        assert sum(result['ignored_runs']) >= 3
        assert result['options'].rise_hold_s == .001
        assert result.get('auto', {}).get('hint') is None


def run(state, start, end, i):
    return dict(state=state, t=start, prev=start-.00001, i=i, last=end-.00001, last_i=i+1)


def test_rising_hold_boundary_falling_edges_and_terminal_confirmation():
    runs = [run(0, 0., .002, 0), run(1, .002, .003, 200),
            run(0, .003, .00301, 300), run(1, .00301, .0035, 301),
            run(0, .0035, .006, 350), run(1, .006, .0065, 600)]
    changes, ignored = _changes(runs, 0., .001)
    assert [(c['i'], c['kind']) for c in changes] == [(0, 'init'), (200, 'rise'), (300, 'fall')]
    assert [c['i'] for c in ignored] == [301, 600]
    assert changes[1]['t'] == .002


def test_inverted_auto_hint_filters_the_logical_high_level():
    runs = [run(1, 0., .002, 0), run(0, .002, .0021, 200),
            run(1, .0021, .004, 210), run(0, .004, .007, 400)]
    edges = _Edges([(runs, 0, {})], [.00001])
    expected, _ = _changes(runs, 0., .001, inverted=True)
    assert edges.get(0, 0, True, .001) == expected
    assert [(c['i'], c['kind']) for c in expected] == [(0, 'init'), (400, 'rise')]


def test_zero_disables_only_the_new_rising_confirmation():
    sources = rig_record()
    result = analyze_valve(sources, ValveOptions(mode='position', rise_hold_s=0.))
    assert result['events'][0]['end_index'] == 2500


@pytest.mark.parametrize('value', [-1., float('nan'), float('inf')])
def test_invalid_rising_confirmation_rejected(value):
    with pytest.raises(ValueError, match='0→1'):
        ValveOptions(rise_hold_s=value)


def test_gui_rising_confirmation_keeps_auto_enabled(window):
    assert window.valve_rise_hold.value() == 1.
    assert window._valve_options(auto=True).rise_hold_s == .001
    window.valve_rise_hold.setValue(.5)
    assert window.valve_auto.isChecked()
    assert window._valve_options(auto=True).rise_hold_s == .0005
    assert window._valve_options().rise_hold_s == .0005
