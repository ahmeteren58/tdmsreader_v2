import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("TDMSREADER_OPENGL", "0")
import csv
import time
import threading
from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest
from nptdms import TdmsFile, TdmsWriter, ChannelObject
from PyQt6.QtCore import QSettings, QTimer, Qt, QCoreApplication, QEvent
from PyQt6.QtWidgets import QApplication, QMessageBox, QFileDialog
from PyQt6.QtGui import QAction
import tdmsreader as appmod
from tdms_export import ExportOptions, ExportCancelled, export_snapshot, write_csv, read_source_xy
from tdms_numeric import numeric_1d, read_envelope
from tdms_ui import CsvExportDialog


@pytest.fixture(scope="session")
def app():
    qapp = QApplication.instance() or QApplication([])
    qapp.setStyle("Fusion")
    return qapp


@pytest.fixture
def window(app, tmp_path, monkeypatch):
    monkeypatch.setattr(appmod, "QSettings", lambda *args: QSettings(str(tmp_path/"settings.ini"), QSettings.Format.IniFormat))
    w = appmod.MainWindow()
    w.resize(1366, 850)
    yield w
    w.close()
    deadline = time.monotonic()+10
    while w._jobs and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(.002)
    assert not w._jobs
    w.deleteLater()
    # processEvents() alone does not process DeferredDelete outside app.exec().
    # Destroy closed windows so their scenes/timers cannot affect later tests.
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    app.processEvents()


def wait_jobs(w, app, timeout=15):
    deadline = time.monotonic()+timeout
    # Debounce timers may start a job inside processEvents(); only an empty
    # queue observed after event processing means the work has settled.
    while True:
        app.processEvents()
        if not w._jobs or time.monotonic() >= deadline:
            break
        time.sleep(.002)
    assert not w._jobs, "Background work did not finish"


def worker_result(worker):
    done, errors = [], []
    worker.finished.connect(done.append)
    worker.failed.connect(errors.append)
    worker.run()
    assert not errors, errors
    assert len(done) == 1
    return done[0]


def tdms_file(tmp_path, channels):
    path = tmp_path/"ölçüm.tdms"
    with TdmsWriter(path) as writer:
        writer.write_segment(channels)
    return path


def load(path, channel_lengths):
    requests = [appmod.ChannelRequest(appmod.ChannelKey("F1", g, c, n), c) for g,c,n in channel_lengths]
    return worker_result(appmod.MultiTdmsChannelLoadWorker({"F1":{"path":str(path), "label":path.name}}, requests))


def memory_source(name, y, x=None, mode="seconds", key=None):
    x = np.arange(len(y), dtype=float) if x is None else np.asarray(x)
    s = {"name":name,"file_label":"deney.tdms","group":"Sensörler", "style_key":key or name,
         "x":x,"y":np.asarray(y), "x_mode":mode}
    return export_snapshot(s)


def read_csv(path, delimiter=";"):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.reader(f, delimiter=delimiter))


def test_wide_all_channels_unequal_lengths_and_time_bases(tmp_path):
    sources=[memory_source("Basınç", [10,11,12], [0,.1,.2]),
             memory_source("Sıcaklık", [20,21], [5,5.25]),
             memory_source("Durum", [True,False,True,True], [0,1,2,3])]
    path=tmp_path/"all.csv"
    result=write_csv(str(path),sources,ExportOptions(chunk_size=2))
    rows=read_csv(path)
    assert len(rows[0]) == 6 and len(rows) == 5
    assert all(len(r)==6 for r in rows)
    assert rows[1] == ["0.0","10","5.0","20","0","1"]
    assert rows[-1] == ["","","","","3","1"]
    assert result["samples"] == 9 and result["channels"] == 3
    assert path.read_bytes().startswith(b"\xef\xbb\xbf")


def test_integer64_precision_is_not_lost(tmp_path):
    values=np.array([2**63+123,2**64-1],dtype=np.uint64)
    path=tmp_path/"uint.csv"
    write_csv(str(path),[memory_source("counter",values)])
    assert [int(r[1]) for r in read_csv(path)[1:]]==list(values)


def test_float_roundtrip_and_nan_are_explicit(tmp_path):
    values=np.array([np.pi,np.nextafter(1.0,2.0),np.nan,np.inf,-np.inf])
    path=tmp_path/"float.csv"
    write_csv(str(path),[memory_source("float",values)])
    parsed=np.array([float(r[1]) for r in read_csv(path)[1:]])
    np.testing.assert_array_equal(parsed,values)


def test_duplicate_names_and_csv_quoting(tmp_path):
    sources=[memory_source('P; "a"\nline',[1]),memory_source('P; "a"\nline',[2])]
    path=tmp_path/"quote.csv"
    write_csv(str(path),sources)
    rows=read_csv(path)
    assert len(set(rows[0]))==4
    assert rows[1]==["0.0","1","0.0","2"]


@pytest.mark.parametrize("layout",["wide","long"])
def test_range_export_inclusive_with_shifts(tmp_path,layout):
    source=memory_source("shift",[10,11,12,13],[0,.1,.2,.3])
    source.update(x_shift=2,y_shift=5)
    path=tmp_path/"range.csv"
    result=write_csv(str(path),[source],ExportOptions(layout=layout,x_range=(2.1,2.2),apply_shifts=True))
    rows=read_csv(path)
    assert result["counts"]==[2]
    assert float(rows[1][-2])==2.1 and float(rows[1][-1])==16


def test_long_layout_retains_identity_and_original_sample_index(tmp_path):
    path=tmp_path/"long.csv"
    write_csv(str(path),[memory_source("A",[1,2,3]),memory_source("B",[4,5])],ExportOptions(layout="long",x_range=(1,2)))
    rows=read_csv(path)
    assert rows[0]==["channel_id","file","group","channel","unit","sample_index","x_mode","x","y"]
    assert [r[0] for r in rows[1:]]==["C1","C1","C2"]
    assert [r[5] for r in rows[1:]]==["1","2","1"]


def test_turkish_excel_number_format(tmp_path):
    path=tmp_path/"tr.csv"
    write_csv(str(path),[memory_source("sıcaklık",[1.25],[.125])],ExportOptions(decimal=","))
    assert read_csv(path)[1]==["0,125","1,25"]
    with pytest.raises(ValueError): ExportOptions(delimiter=",",decimal=",")


def test_cancel_preserves_destination_and_removes_temporary_file(tmp_path):
    path=tmp_path/"existing.csv"; path.write_text("previous")
    flag=[False]
    with pytest.raises(ExportCancelled):
        write_csv(str(path),[memory_source("a",np.arange(100))],ExportOptions(chunk_size=10),
                  cancelled=lambda:flag[0],progress=lambda n:flag.__setitem__(0,True))
    assert path.read_text()=="previous"
    assert sorted(p.name for p in tmp_path.iterdir())==["existing.csv"]


def test_missing_source_does_not_overwrite_or_fall_back(tmp_path):
    source=memory_source("missing",[1,2])
    source.update(path=str(tmp_path/"missing.tdms"),channel="missing")
    path=tmp_path/"existing.csv"; path.write_text("previous")
    with pytest.raises(Exception): write_csv(str(path),[source])
    assert path.read_text()=="previous"
    with pytest.raises(Exception): read_source_xy(source)


def test_mismatched_lengths_fail_without_output(tmp_path):
    s=memory_source("a",[1,2]); s["x"]=np.arange(1)
    with pytest.raises(ValueError):write_csv(str(tmp_path/"bad.csv"),[s])
    assert not (tmp_path/"bad.csv").exists()


@pytest.mark.parametrize("start",[np.datetime64('2026-09-13T12:00:00'),np.datetime64('1970-01-01T00:00:00')])
def test_full_and_lazy_time_metadata_agree(tmp_path,monkeypatch,start):
    props={"wf_increment":.002,"wf_start_offset":.25,"wf_start_time":start}
    path=tdms_file(tmp_path,[ChannelObject("G","A",np.arange(20),properties=props)])
    full=load(path,[("G","A",20)])["series"][0]
    monkeypatch.setattr(appmod,"CFG",replace(appmod.CFG,lazy=replace(appmod.CFG.lazy,fullload_threshold=5)))
    lazy=load(path,[("G","A",20)])["series"][0]
    assert full["x_mode"]==lazy["x_mode"]=="seconds"
    np.testing.assert_allclose(full["x"], .25 + np.arange(20)*.002, rtol=0, atol=1e-15)
    assert full["source_fs_est"]==lazy["source_fs_est"]==500
    np.testing.assert_array_equal(full["x"],lazy["x"])
    np.testing.assert_array_equal(full["y"],lazy["y"])


def test_high_rate_epoch_never_deduplicates_measurements(tmp_path):
    path=tdms_file(tmp_path,[ChannelObject("G","A",np.arange(10),properties={"wf_increment":1e-9,"wf_start_time":np.datetime64('2026-01-01')})])
    s=load(path,[("G","A",10)])["series"][0]
    assert len(s["x"])==len(s["y"])==10
    assert s["source_fs_est"]==pytest.approx(1e9)


@pytest.mark.parametrize("increment",[0,-1,np.nan,np.inf])
def test_invalid_waveform_increment_falls_back_to_index(increment):
    assert appmod._xmeta_from_channel_props({"wf_increment":increment})==("index",0,1)


def test_bad_channel_does_not_hide_later_channels(tmp_path):
    path=tdms_file(tmp_path,[ChannelObject("G","text",np.array(["hello","world"])),ChannelObject("G","valid",np.array([1,2,3]))])
    result=load(path,[("G","text",2),("G","valid",3)])
    assert len(result["errors"])==1
    assert [s["name"] for s in result["series"]]==["valid"]


@pytest.mark.parametrize("values, expected", [
    (np.array([1.25, np.float32(-2.5), 3], dtype=object), [1.25, -2.5, 3]),
    (np.array([" 1.25 ", "-2.5e1", "+.75"], dtype=object), [1.25, -25, .75]),
    (np.array(["1,25", "-2,5E+1", ",75"]), [1.25, -25, .75]),
    (np.array([b"1.25", b"-2.5", b"3"]), [1.25, -2.5, 3]),
    (np.array(["1", "", None, "NaN", "Inf", "-Infinity"], dtype=object),
     [1, np.nan, np.nan, np.nan, np.inf, -np.inf]),
])
def test_numeric_object_and_text_samples(values, expected):
    before = values.copy()
    actual = numeric_1d(values)
    assert actual.dtype.kind in "biuf" and actual.flags.c_contiguous
    np.testing.assert_array_equal(actual, expected)
    np.testing.assert_array_equal(values, before)


@pytest.mark.parametrize("values", [[-(2**63), 2**63-1], [2**63+123, 2**64-1]])
def test_integer_object_values_remain_exact_in_analysis_and_csv(tmp_path, values):
    source = memory_source("counter", np.array(values, dtype=object))
    _, y = read_source_xy(source)
    assert y.dtype.kind in "iu"
    assert list(map(int, y)) == values
    target = tmp_path / "object-integers.csv"
    write_csv(str(target), [source])
    assert [int(row[1]) for row in read_csv(target)[1:]] == values


@pytest.mark.parametrize("bad", ["sensor offline", "1,234.56", "1e999", 1+2j, {"v": 2}])
def test_invalid_object_sample_has_position_and_is_not_silently_dropped(bad):
    with pytest.raises(ValueError, match=r"102\. örnek"):
        numeric_1d(np.array(["1.25", bad, "3.5"], dtype=object), sample_offset=100)


@pytest.mark.parametrize("lazy", [False, True])
def test_tdms_numeric_string_channels_load_analyze_and_export(tmp_path, monkeypatch, lazy):
    # npTDMS returns String channels as object, exactly the dtype in the report.
    props = {"wf_increment": .01}
    path = tdms_file(tmp_path, [
        ChannelObject("AI", "OPT-1", np.array(["1", "2.5", "-3e-1", "4,25", ""]), properties=props),
        ChannelObject("AI", "OPT-2", np.array(["10,25", "20", "30.5"]), properties=props),
    ])
    with TdmsFile.open(path) as tdms:
        assert tdms["AI"]["OPT-1"][:].dtype.kind == "O"
    if lazy:
        monkeypatch.setattr(appmod, "CFG", replace(appmod.CFG,
            lazy=replace(appmod.CFG.lazy, fullload_threshold=2)))
    result = load(path, [("AI", "OPT-1", 5), ("AI", "OPT-2", 3)])
    assert not result.get("errors"), result
    assert len(result["series"]) == 2
    sources = [export_snapshot(s) for s in result["series"]]
    for s, expected in zip(result["series"], [[1, 2.5, -.3, 4.25, np.nan], [10.25, 20, 30.5]]):
        assert s["lazy"] is lazy
        x, y = read_source_xy(export_snapshot(s))
        np.testing.assert_array_equal(y, expected)
        np.testing.assert_allclose(x, np.arange(len(expected)) * .01)
    target = tmp_path / "OPT.csv"
    export = write_csv(str(target), sources, ExportOptions(chunk_size=2, decimal=","))
    rows = read_csv(target)
    assert export["counts"] == [5, 3] and len(rows[0]) == 4
    assert rows[2] == ["0,01", "2,5", "0,01", "20,0"]
    assert rows[-1] == ["0,04", "NaN", "", ""]


def test_string_conversion_used_in_memory_csv_and_analysis(tmp_path):
    source = memory_source("numeric text", np.array(["1,5", "2,75", ""], dtype=object))
    _, y = read_source_xy(source)
    np.testing.assert_array_equal(y, [1.5, 2.75, np.nan])
    target = tmp_path / "memory-text.csv"
    write_csv(str(target), [source], ExportOptions(apply_shifts=True))
    assert [r[1] for r in read_csv(target)[1:]] == ["1.5", "2.75", "NaN"]
    assert source["y"].dtype.kind == "O", "Export must not mutate its source"


def test_large_string_channel_keeps_decimal_values_after_integer_only_block(tmp_path):
    n = 262_150
    values = np.full(n, "1", dtype=object)
    values[262_145] = "2.75"
    path = tdms_file(tmp_path, [ChannelObject("AI", "OPT-1", values)])
    source = memory_source("OPT-1", [])
    source.update(path=str(path), group="AI", channel="OPT-1", n=n, x_mode="index")
    x, y = read_source_xy(source)
    assert y.dtype.kind == "f" and len(y) == n
    assert y[262_145] == 2.75 and x[-1] == n-1
    with TdmsFile.open(path) as tdms:
        ids, preview = read_envelope(tdms["AI"]["OPT-1"], 0, n, 500)
    assert 262_145 in ids and max(preview) == 2.75


def test_invalid_later_string_block_preserves_existing_csv(tmp_path):
    path = tdms_file(tmp_path, [ChannelObject("AI", "OPT-1", np.array(["1", "2", "invalid", "4"]))])
    source = memory_source("OPT-1", [])
    source.update(path=str(path), group="AI", channel="OPT-1", n=4, x_mode="index")
    target = tmp_path / "previous.csv"
    target.write_text("previous contents")
    with pytest.raises(ValueError, match=r"3\. örnek"):
        write_csv(str(target), [source], ExportOptions(chunk_size=2))
    assert target.read_text() == "previous contents"
    assert not list(tmp_path.glob(".*.tmp"))


@pytest.mark.parametrize("lazy", [False, True])
def test_object_tdms_channels_plot_and_export_through_gui(window, app, tmp_path, monkeypatch, lazy):
    props = {"wf_increment": .01}
    path = tdms_file(tmp_path, [
        ChannelObject("AI", "OPT-1", np.array(["1.2", "2.5", "-3", "4.25"]), properties=props),
        ChannelObject("AI", "OPT-2", np.array(["10,25", "20,5", "30"]), properties=props),
    ])
    if lazy:
        monkeypatch.setattr(appmod, "CFG", replace(appmod.CFG,
            lazy=replace(appmod.CFG.lazy, fullload_threshold=2)))
    warnings = []
    monkeypatch.setattr(QMessageBox, "warning", lambda *args: warnings.append(args[-1]))
    monkeypatch.setattr(QMessageBox, "critical", lambda *args: warnings.append(args[-1]))
    window.open_tdms_path(str(path)); wait_jobs(window, app)
    state = next(iter(window.files.values()))
    state.tree.topLevelItem(0).setCheckState(0, Qt.CheckState.Checked)
    window.plot_checked_channels(); wait_jobs(window, app)
    assert not warnings, warnings
    assert len(window.current_series) == 2
    np.testing.assert_array_equal(window.current_series[0]["y"], [1.2, 2.5, -3, 4.25])
    # Inspect actual plotted samples, not only the loader's output.
    curves = window.plot_pane.plot.getPlotItem().listDataItems()
    assert any(np.array_equal(curve.getData()[1], [1.2, 2.5, -3, 4.25]) for curve in curves)
    target = tmp_path / "OPT-gui.csv"
    window._begin_csv_export(str(target), [export_snapshot(s) for s in window.current_series], ExportOptions())
    wait_jobs(window, app)
    assert not warnings, warnings
    assert len(read_csv(target)[0]) == 4
    assert read_csv(target)[-1][-2:] == ["", ""]
    window._lazy_view_timer.stop()


def test_lazy_real_tdms_preserves_spikes_and_exports_every_sample(tmp_path):
    n=2_000_017
    y=np.zeros(n); y[123_457]=1024; y[1_987_654]=-512; y[100_003]=np.nan
    path=tdms_file(tmp_path,[ChannelObject("G","A",y,properties={"wf_increment":.001})])
    s=load(path,[("G","A",n)])["series"][0]
    assert s["lazy"] and len(s["y"])<n
    assert np.nanmax(s["y"])==1024 and np.nanmin(s["y"])==-512
    assert 123_457 in s["_sample_indices"] and n-1 in s["_sample_indices"]
    target=tmp_path/"lazy.csv"
    result=write_csv(str(target),[export_snapshot(s),memory_source("second",[7,8])])
    assert result["counts"]==[n,2]
    with target.open(encoding="utf-8-sig",newline="") as f:
        reader=csv.reader(f,delimiter=";"); header=next(reader)
        assert len(header)==4
        rows=0
        for i,row in enumerate(reader):
            if i==123_457: assert row[1]=="1024.0"
            rows+=1
        assert rows==n
        assert float(row[0])==pytest.approx((n-1)*.001)
        assert row[2:]==["",""]


def test_envelope_reads_are_bounded_and_endpoints_preserved():
    calls=[]; y=np.arange(700_000,dtype=float); y[33]=np.nan; y[41]=1e9
    class Channel:
        def read_data(self,offset,length):
            calls.append(length);return y[offset:offset+length]
    ids,values=read_envelope(Channel(),0,len(y),500)
    assert max(calls)<=262_144 and len(values)<=500
    assert ids[0]==0 and ids[-1]==len(y)-1 and 41 in ids
    assert np.isnan(values).any()


def test_filter_does_not_replace_missing_data_or_join_gaps():
    y=np.r_[np.ones(20),np.nan,np.ones(20)*100]
    filtered=appmod.apply_savgol_safe(y,11)
    np.testing.assert_allclose(filtered,y,rtol=1e-12,equal_nan=True)


def test_interval_integral_does_not_bridge_nan_gap():
    stats=appmod.compute_interval_statistics(np.arange(5),np.array([1,1,np.nan,3,3]),0,4)
    assert stats["n"]==4 and stats["invalid_n"]==1
    assert stats["integral"]==4


@pytest.mark.parametrize("n,k",[(9,4),(8,4),(100,10),(101,10)])
def test_fft_single_sided_amplitude_including_odd_last_bin(n,k):
    y=np.cos(2*np.pi*k*np.arange(n)/n)
    result=worker_result(appmod.FFTWorker("a",np.arange(n)/100,y,100,False,False,False))
    assert result["mag_linear"][k]==pytest.approx(1,abs=1e-12)


def test_fft_rejects_unknown_fs_on_index_axis():
    s=memory_source("a",np.ones(10),mode="index")
    worker=appmod.FFTWorker("a",np.array([]),np.array([]),None,False,False,False,source=s)
    errors=[];worker.failed.connect(errors.append);worker.run()
    assert errors and "İndeks" in errors[0]


def test_fft_rejects_missing_values():
    worker=appmod.FFTWorker("a",np.arange(10),np.r_[np.ones(9),np.nan],10,False,False,False)
    errors=[];worker.failed.connect(errors.append);worker.run()
    assert errors and "NaN/Inf" in errors[0]


def test_calculation_aligns_epoch_times_without_relative_tolerance():
    epoch=1_780_000_000.
    a=memory_source("a",[10,20,30],[epoch,epoch+1,epoch+2],mode="datetime")
    b=memory_source("b",[1,2,3],[epoch+.5,epoch+1.5,epoch+2.5],mode="datetime")
    result=worker_result(appmod.CalculatedChannelWorker("delta","bar","C1-C2",{"C1":a,"C2":b}))
    np.testing.assert_allclose(result["y"],[np.nan,18.5,27.5],equal_nan=True)


@pytest.mark.parametrize("expr",["C1.__class__", "__import__('os')", "C1[0]", "C1 + 'x'", "C1 if 1 else C2"])
def test_calculated_expression_rejects_unsafe_or_nonnumeric_syntax(expr):
    with pytest.raises((ValueError,SyntaxError)):appmod._validate_calc_expression(expr,{"C1","C2"})


def test_export_dialog_defaults_to_all_channels_and_explicit_visibility(app):
    sources=[memory_source("a",[1],key="a"),memory_source("b",[2],key="b")]
    dialog=CsvExportDialog(sources,{"a"},(0,1))
    assert len(dialog.selected_sources())==2
    dialog.select(lambda s:s["key"]=="a")
    assert dialog.selected_sources()==[sources[0]]
    dialog.select(lambda s:False)
    assert not dialog.export_button.isEnabled()
    dialog.close()


def test_menu_shortcuts_are_unique(window):
    sequences=[a.shortcut().toString() for a in window.findChildren(QAction) if not a.shortcut().isEmpty()]
    assert sequences.count("Ctrl+E")==1
    assert sequences.count("Ctrl+O")==1
    assert sequences.count("Ctrl+Shift+S")==1


def test_clearing_plot_discards_queued_worker_result(window,app):
    received=[]
    class Worker(appmod.CancellableWorker):
        def run(self):
            time.sleep(.03)
            self.finished.emit({"series":["obsolete"]})
    window._start_job(Worker(),received.append,tag="filter")
    window.on_clear_plot()
    wait_jobs(window,app)
    assert received==[] and window.current_series is None


def test_close_keeps_thread_alive_until_worker_exits(window,app):
    class Worker(appmod.CancellableWorker):
        def run(self):
            time.sleep(.7)
            self.finished.emit({})
    window.show()
    window._start_job(Worker(),lambda p:None,tag="load")
    window.close()
    assert window._jobs and window._closing and window.isVisible()
    wait_jobs(window,app)
    for _ in range(5):app.processEvents()
    assert not window.isVisible()


def test_manual_fs_reset_restores_original_timeline(window,app,tmp_path):
    path=tdms_file(tmp_path,[ChannelObject("G","A",np.arange(100),properties={"wf_increment":.01,"wf_start_offset":2.0})])
    series=load(path,[("G","A",100)])["series"]
    window.current_series=series
    key=series[0]["style_key"]
    original=series[0]["x"].copy()
    window.channel_fs_overrides[key]=10
    window._apply_channel_timing()
    assert series[0]["x"][-1]==pytest.approx(11.9)
    window.channel_fs_overrides.clear()
    window._apply_channel_timing()
    np.testing.assert_array_equal(series[0]["x"],original)


def test_end_to_end_multichannel_gui_export(window,app,tmp_path):
    path=tdms_file(tmp_path,[ChannelObject("G","Pressure",np.arange(80,dtype=float),properties={"wf_increment":.01,"unit_string":"bar"}),ChannelObject("G","Temperature",np.arange(40,dtype=float)+20,properties={"wf_increment":.02,"unit_string":"K"})])
    window.open_tdms_path(str(path));wait_jobs(window,app)
    st=next(iter(window.files.values()))
    st.tree.topLevelItem(0).setCheckState(0,Qt.CheckState.Checked)
    window.plot_checked_channels();wait_jobs(window,app)
    assert len(window.current_series)==2
    window._begin_csv_export(str(tmp_path/"gui.csv"),[export_snapshot(s) for s in window.current_series],ExportOptions())
    wait_jobs(window,app)
    assert len(read_csv(tmp_path/"gui.csv")[0])==4
    assert window._export_progress is None
    assert "CSV kaydedildi" in window.status.currentMessage()
    window._close_file_tab(1);wait_jobs(window,app)
    assert not window.current_series


@pytest.mark.parametrize("mode",["Overlay","Stacked"])
def test_svg_export_respects_selected_format(window,app,tmp_path,monkeypatch,mode):
    y=np.sin(np.arange(100)/10)
    s={"style_key":"test","name":"A","x":np.arange(100)/10,"y":y,"x_mode":"seconds"}
    window.current_series=[s]
    window.cmb_plot_mode.setCurrentText(mode)
    window.update_plot_data_with_filter();wait_jobs(window,app)
    monkeypatch.setattr(QFileDialog,"getSaveFileName",lambda *a,**kw:(str(tmp_path/"graph"),"SVG vektör (*.svg)"))
    errors=[];monkeypatch.setattr(QMessageBox,"critical",lambda *args:errors.append(args[-1]))
    window.save_plot_image()
    assert not errors,errors
    assert "<svg" in (tmp_path/"graph.svg").read_text()


def test_style_key_escapes_ambiguous_separators():
    assert appmod.style_key_for_channel("F1", "a|b", "c") != appmod.style_key_for_channel("F1", "a", "b|c")


def test_date_axis_uses_utc(app):
    axis = appmod.EditableDateAxisItem(orientation="bottom")
    assert axis.utcOffset == 0


def test_export_cancel_button_preserves_existing_file(window,app,tmp_path,monkeypatch):
    from PyQt6.QtWidgets import QPushButton
    # Synchronize an in-flight write with the GUI click. A 1 ms timer alone
    # can fire after a fast writer has already atomically committed the file.
    clicked = threading.Event()
    original_write = appmod.write_csv
    def in_flight_write(path, sources, options, cancelled, progress):
        first = True
        def report(value):
            nonlocal first
            progress(value)
            if first:
                first = False
                assert clicked.wait(10), "GUI cancellation was not delivered"
        return original_write(path, sources, options, cancelled, report)
    monkeypatch.setattr(appmod, "write_csv", in_flight_write)
    target=tmp_path/"cancel.csv";target.write_text("original")
    window._begin_csv_export(str(target),[memory_source("A",np.arange(500_000))],ExportOptions(chunk_size=1000))
    cancel=next(b for b in window._export_progress.findChildren(QPushButton) if b.text()=="İptal")
    def click_cancel():
        cancel.click()
        clicked.set()
    QTimer.singleShot(1,click_cancel)
    wait_jobs(window,app)
    assert target.read_text()=="original"
    assert window._export_progress is None


def test_lazy_autofit_restores_full_time_span(window,app,tmp_path,monkeypatch):
    monkeypatch.setattr(appmod,"CFG",replace(appmod.CFG,lazy=replace(appmod.CFG.lazy,fullload_threshold=5)))
    path=tdms_file(tmp_path,[ChannelObject("G","A",np.sin(np.arange(1000)),properties={"wf_increment":.01})])
    s=load(path,[("G","A",1000)])["series"][0]
    s["x"],s["y"]=s["x"][100:200],s["y"][100:200]
    s["_sample_indices"]=np.arange(100,200)
    window.current_series=[s]
    window.update_plot_data_with_filter();wait_jobs(window,app)
    window.plot_pane.set_xrange(1,2)
    window._autofit_all_panes()
    assert window.plot_pane.plot.getViewBox().viewRange()[0]==pytest.approx([0,9.99])
    window._lazy_view_timer.stop()


def test_mode_switch_with_digital_right_axis_has_no_qt_callback_errors(window,app,monkeypatch):
    import sys
    errors=[]
    monkeypatch.setattr(sys,"excepthook",lambda *args:errors.append(args))
    window.show()
    x=np.arange(100)/10
    window.current_series=[{"style_key":"a","name":"analog","x":x,"y":np.sin(x),"x_mode":"seconds"},
                           {"style_key":"b","name":"digital","x":x,"y":(x>3).astype(int),"is_digital":True,"x_mode":"seconds"}]
    window.update_plot_data_with_filter();wait_jobs(window,app)
    for mode in ("Stacked","Overlay","Stacked","Overlay"):
        window.cmb_plot_mode.setCurrentText(mode)
        app.processEvents()
    window.on_clear_plot();app.processEvents()
    assert not errors,errors
