import csv
from dataclasses import replace
import numpy as np
import pytest
from nptdms import ChannelObject
from PyQt6.QtCore import QPoint, Qt
from PyQt6.QtGui import QContextMenuEvent
from PyQt6.QtWidgets import QApplication, QFileDialog, QMenu
from PyQt6.QtTest import QTest
import pyqtgraph as pg
import tdmsreader as m
import test_regressions as base
from tdms_export import ExportCancelled
from tdms_valve import ValveOptions, analyze_valve, manual_measurement, write_valve_report

app=base.app
window=base.window


def source(name,y,fs=5.,start=0.,mode='seconds'):
    x=start+np.arange(len(y))/fs
    s=base.memory_source(name,np.asarray(y),x,mode=mode)
    s.update(fs_hz=fs,x_base=start,x_inc=1/fs)
    return s


def pair(fs=5.,start=0.,mode='seconds'):
    op=np.zeros(26);cl=np.ones(26)
    op[5:19]=1; cl[8:15]=0
    return [source('Open',op,fs,start,mode),source('Closed',cl,fs,start,mode)]


@pytest.mark.parametrize('fs',[5,5000])
@pytest.mark.parametrize('chunk',[1,7,262144])
def test_all_cycles_exact_samples_and_uncertainty(fs,chunk):
    result=analyze_valve(pair(fs),ValveOptions(chunk_size=chunk))
    opening,closing=result['events']
    assert [e['direction'] for e in result['events']]==['opening','closing']
    assert all(e['status']=='complete' for e in result['events'])
    assert opening['duration']==pytest.approx(3/fs)
    assert closing['duration']==pytest.approx(4/fs)
    assert opening['lower']==pytest.approx(2/fs)
    assert opening['upper']==pytest.approx(4/fs)
    assert (opening['start_index'],opening['end_index'])==(5,8)
    assert (closing['start_index'],closing['end_index'])==(15,19)


def test_utc_and_different_channel_rates_are_not_resampled():
    epoch=1_780_000_000.
    op=np.zeros(51);op[10:39]=1
    cl=np.ones(26);cl[8:15]=0
    result=analyze_valve([source('Open',op,10,epoch,'datetime'),source('Closed',cl,5,epoch,'datetime')])
    a,b=result['events']
    assert a['duration']==pytest.approx(.6,abs=3e-7)
    assert b['duration']==pytest.approx(.9,abs=3e-7)
    assert (a['start_index'],a['end_index'],b['start_index'],b['end_index'])==(10,8,15,39)


def test_first_high_is_not_a_rising_edge():
    result=analyze_valve([source('Open',[1,1,1,1]),source('Closed',[1,1,0,0])])
    assert result['events']==[]


@pytest.mark.parametrize('op,cl,status',[
    ([0,1,1,1,1],[1,1,1,1,1],'incomplete'),
    ([0,1,0,0,0],[1,1,1,0,0],'cancelled'),
    ([0,1,1,1,1],[0,0,0,0,0],'unpaired'),
    ([0,1,1,1,1],[1,1,np.nan,0,0],'invalid'),
    ([0,1,1,1,1],[1,np.nan,0,0,0],'invalid'),
    ([0,1,np.inf,1,1],[1,1,1,0,0],'invalid'),
])
def test_missing_cancelled_or_unpaired_events_never_claim_a_duration(op,cl,status):
    result=analyze_valve([source('Open',op),source('Closed',cl)])
    assert len(result['events'])==1
    assert result['events'][0]['status']==status
    assert result['events'][0]['duration'] is None


def test_timeout_cannot_pair_with_a_later_cycle():
    result=analyze_valve(pair(),ValveOptions(max_wait_s=.4))
    assert [e['status'] for e in result['events']]==['timeout','timeout']


def test_no_edges_across_nan_gaps():
    result=analyze_valve([source('Open',[0,np.nan,1,1]),source('Closed',[1,1,1,0])])
    assert result['events']==[] and result['invalid_samples']==[1,0]


def test_same_timestamp_is_zero_with_nonzero_sampling_bounds():
    result=analyze_valve([source('Open',[0,1,1]),source('Closed',[1,0,0])])
    e=result['events'][0]
    assert e['status']=='complete' and e['duration']==0
    assert e['upper']==pytest.approx(.2) and e['lower']==0


def test_minimum_persistence_filters_chatter_without_shifting_edge_time():
    op=np.zeros(30);op[3]=1;op[10:]=1
    cl=np.ones(30);cl[15:]=0
    result=analyze_valve([source('Open',op,10),source('Closed',cl,10)],ValveOptions(min_hold_s=.2,chunk_size=4))
    assert len(result['events'])==1 and result['ignored_runs'][0]==1
    assert result['events'][0]['start_index']==10
    assert result['events'][0]['duration']==pytest.approx(.5)


def test_short_unconfirmed_end_run_does_not_produce_complete_event():
    result=analyze_valve([source('Open',[0,0,1,1,1,1]),source('Closed',[1,1,1,1,1,0])],ValveOptions(min_hold_s=.1))
    assert result['events'][0]['status']=='incomplete'


@pytest.mark.parametrize('mutation,message',[
    (lambda p:p[1].update(key=p[0]['key']),'farklı'),
    (lambda p:p[1].update(x_mode='index'),'zaman'),
    (lambda p:p[0].update(fs_hz=None),'Fs'),
    (lambda p:p[0]['y'].__setitem__(5,2),'0/1'),
    (lambda p:p[0]['x'].__setitem__(5,p[0]['x'][4]),'artan'),
    (lambda p:p[0].update(x=p[0]['x']+100),'örtüşmüyor'),
])
def test_invalid_input_is_explicit(mutation,message):
    p=pair();mutation(p)
    with pytest.raises(ValueError,match=message):analyze_valve(p)


def test_cancelled_and_excessively_dense_records_do_not_return_partial_success():
    with pytest.raises(ExportCancelled):analyze_valve(pair(),cancelled=lambda:True)
    with pytest.raises(ValueError,match='geçiş'):
        analyze_valve([source('a',[0,1]*10),source('b',[1,0]*10)],ValveOptions(max_transitions=3))


def test_recording_overlap_does_not_extrapolate():
    p=pair(); p[1]=source('Closed',[1]*7)
    e=analyze_valve(p)['events'][0]
    assert e['status']=='incomplete' and e['duration'] is None


def test_manual_positions_snap_to_original_channels_and_keep_auto():
    p=pair();r=analyze_valve(p)
    a=manual_measurement(p,'opening',1.01,1.81)
    assert a['start_index']==5 and a['end_index']==9
    assert a['duration']==pytest.approx(.8)
    assert r['events'][0]['duration']==pytest.approx(.6)
    with pytest.raises(ValueError,match='önce'):manual_measurement(p,'opening',3,1)
    with pytest.raises(ValueError,match='sınır'):manual_measurement(p,'opening',-1,1)


def test_atomic_report_preserves_auto_review_and_protects_source(tmp_path):
    p=pair();p[0]['name']='=1+1';p[0]['channel']='=1+1'
    r=analyze_valve(p);e=r['events'][0]
    e.update(manual=manual_measurement(p,'opening',1,1.8),review='adjusted',review_note='=danger')
    path=tmp_path/'report.csv';write_valve_report(path,r)
    with path.open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f,delimiter=';'))
    assert len(rows)==2
    assert float(rows[0]['auto_duration_s'])==pytest.approx(.6)
    assert float(rows[0]['manual_duration_s'])==pytest.approx(.8)
    assert rows[0]['review_note']=="'=danger"
    p[0]['source_path']=str(path)
    original=path.read_bytes()
    with pytest.raises(ValueError,match='üzerine'):write_valve_report(path,r)
    assert path.read_bytes()==original


def load_valve(window,app,tmp_path,monkeypatch,lazy=False):
    if lazy:monkeypatch.setattr(m,'CFG',replace(m.CFG,lazy=replace(m.CFG.lazy,fullload_threshold=2,overview_max_points=4)))
    p=pair()
    path=base.tdms_file(tmp_path,[ChannelObject('Valve',name,s['y'],properties={'wf_increment':.2}) for name,s in zip(('Open','Closed'),p)])
    window.open_tdms_path(str(path));base.wait_jobs(window,app)
    next(iter(window.files.values())).tree.topLevelItem(0).setCheckState(0,Qt.CheckState.Checked)
    window.plot_checked_channels();base.wait_jobs(window,app)
    window.valve_mode.setCurrentIndex(window.valve_mode.findData('legacy'))
    window.valve_open.setCurrentIndex(1);window.valve_closed.setCurrentIndex(2)
    return path


@pytest.mark.parametrize('lazy',[False,True])
def test_gui_detect_review_restore_export_and_time_invalidation(window,app,tmp_path,monkeypatch,lazy):
    load_valve(window,app,tmp_path,monkeypatch,lazy)
    window._valve_analyze();base.wait_jobs(window,app)
    assert window.valve_tree.topLevelItemCount()==2
    assert window._valve_result['events'][0]['duration']==pytest.approx(.6)
    e=window._valve_result['events'][0]
    window._valve_approve();assert e['review']=='approved'
    window.valve_b.setValue(1.8)
    assert not window.valve_accept.isEnabled() and e['review']=='pending'
    window._valve_timer.stop();window._valve_request_manual();base.wait_jobs(window,app)
    window._valve_approve()
    assert e['review']=='adjusted' and e['manual']['duration']==pytest.approx(.8)
    assert e['duration']==pytest.approx(.6)
    target=tmp_path/'review.csv'
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *args:(str(target),'CSV'))
    window._valve_export();assert target.exists()
    window._valve_reject_event();assert e['review']=='rejected'
    window._valve_restore_auto();base.wait_jobs(window,app)
    assert e['review']=='pending' and e['manual'] is None
    assert window.valve_b.value()==pytest.approx(1.6)
    window.channel_fs_overrides[window.current_series[0]['style_key']]=5000
    window._apply_channel_timing()
    assert window._valve_result is None and not window.valve_csv.isEnabled()
    assert window.valve_tree.topLevelItemCount()==0


def test_gui_cancel_and_channel_clear_cannot_restore_stale_results(window,app,tmp_path,monkeypatch):
    load_valve(window,app,tmp_path,monkeypatch)
    window._valve_analyze();window._valve_cancel();base.wait_jobs(window,app)
    assert window._valve_result is None
    window._valve_analyze();base.wait_jobs(window,app)
    assert window._valve_result
    window.on_clear_plot();base.wait_jobs(window,app)
    assert window._valve_result is None and window.valve_open.count()==1


def test_valve_plot_has_one_context_menu(window,app,tmp_path,monkeypatch):
    load_valve(window,app,tmp_path,monkeypatch)
    window.tabs.setCurrentWidget(window.valve_tab);window.show();app.processEvents()
    widget=window.valve_canvas;point=QPoint(100,70);native=[]
    monkeypatch.setattr(pg.ViewBox,'raiseContextMenu',lambda *a:native.append(True))
    QTest.mouseClick(widget.viewport(),Qt.MouseButton.RightButton,Qt.KeyboardModifier.ControlModifier,pos=point)
    event=QContextMenuEvent(QContextMenuEvent.Reason.Mouse,point,widget.viewport().mapToGlobal(point), Qt.KeyboardModifier.ControlModifier)
    QApplication.sendEvent(widget.viewport(),event);app.processEvents()
    menus=[w for w in QApplication.topLevelWidgets() if isinstance(w,QMenu) and w.isVisible()]
    assert not native and len(menus)==1
    menus[0].close()


def test_step_preview_changes_at_measured_sample_and_small_window_scrolls(window,app,tmp_path,monkeypatch):
    load_valve(window,app,tmp_path,monkeypatch)
    window._valve_analyze();base.wait_jobs(window,app)
    curve,_=window._valve_curves[0]
    x,y=curve.getData()
    mode=curve.opts['stepMode']
    xx,yy=pg.PlotCurveItem._generateStepModeData(mode,x,y,None)
    rising=np.flatnonzero(np.diff(yy)>0)+1
    assert xx[rising[0]]==1.0  # first high original sample; never one sample early
    window.tabs.setCurrentWidget(window.valve_tab);window.resize(1280,768);window.show();app.processEvents()
    assert window.height()==768
    assert window.valve_tab.verticalScrollBar().maximum()>0


def test_late_cross_chunk_event_uses_full_lazy_tdms(tmp_path):
    n=600001
    op=np.zeros(n,dtype=np.int16);op[262143:400000]=1
    cl=np.ones(n,dtype=np.int16);cl[262146:399996]=0
    path=base.tdms_file(tmp_path,[ChannelObject('V','o',op),ChannelObject('V','c',cl)])
    sources=[]
    for name,y in [('o',op),('c',cl)]:
        s=source(name,[])  # lazy payload does not contain the measured samples
        s.update(path=str(path),group='V',channel=name,n=n)
        sources.append(s)
    rows=analyze_valve(sources)['events']
    assert rows[0]['duration']==pytest.approx(.6) and rows[0]['start_index']==262143
    assert rows[1]['duration']==pytest.approx(.8)


@pytest.mark.parametrize('epoch',[0.,1780000000.])
def test_inclusive_timeout_and_hold_at_exact_sampling_boundary(epoch):
    p=pair(start=epoch,mode='datetime' if epoch else 'seconds')
    rows=analyze_valve(p,ValveOptions(max_wait_s=.6))['events']
    assert rows[0]['status']=='complete'  # inclusive max, despite 1.6 - 1.0 rounding
    assert rows[1]['status']=='timeout'
    # A one-sample 5 Hz pulse lasts .2 s; equality is accepted consistently.
    p=[source('Open',[0,0,0,0,0,1,0,0],start=epoch),source('Closed',[1,1,1,1,1,0,0,0],start=epoch)]
    rows=analyze_valve(p,ValveOptions(min_hold_s=.2))['events']
    assert rows and rows[0]['status']=='complete' and rows[0]['duration']==0
