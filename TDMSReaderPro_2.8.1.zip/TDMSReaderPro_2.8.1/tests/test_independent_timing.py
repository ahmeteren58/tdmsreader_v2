"""Regression gates for manual/metadata-only timing and legacy project migration."""
import json
import zipfile
from dataclasses import replace
import numpy as np
import pytest
from nptdms import ChannelObject
from PyQt6.QtWidgets import QMessageBox, QCheckBox
import tdmsreader as m
import test_regressions as base
from tdms_export import export_snapshot, write_csv, ExportOptions
from tdms_project import save_project_archive, read_project_archive
from tdms_workspace import CHECKS, NUMBERS

app = base.app
window = base.window


@pytest.mark.parametrize("lazy", [False, True])
def test_different_lengths_and_metadata_never_infer_another_rate(window, tmp_path, monkeypatch, lazy):
    if lazy:
        monkeypatch.setattr(m, "CFG", replace(m.CFG, lazy=replace(m.CFG.lazy, fullload_threshold=2)))
    path = base.tdms_file(tmp_path, [
        ChannelObject("G", "Fast", np.arange(5001), properties={"wf_increment": .0002}),
        ChannelObject("G", "Slow", np.arange(501), properties={"wf_increment": .002}),
        ChannelObject("G", "Unknown", np.arange(51)),
    ])
    fast, slow, unknown = base.load(path, [("G", "Fast", 5001), ("G", "Slow", 501), ("G", "Unknown", 51)])["series"]
    window.current_series = [fast, slow, unknown]
    # Deliberately inject removed settings from an old session.
    unknown.update(auto_fs_hz=12345, auto_x_mode="seconds", auto_x_base=99., auto_x_inc=1/12345)
    window._apply_channel_timing()
    assert [s["fs_est"] for s in window.current_series] == [5000, 500, None]
    assert unknown["x_mode"] == "index"
    assert not any(k.startswith("auto_") for k in unknown)
    window.channel_fs_overrides[fast["style_key"]] = 500
    window._apply_channel_timing()
    assert fast["x"][-1] == 10 and slow["x"][-1] == 1
    assert unknown["x"][-1] == 50
    window.channel_fs_overrides[unknown["style_key"]] = 5000
    window._apply_channel_timing()
    assert unknown["fs_est"] == 5000 and unknown["x"][-1] == .01
    window.current_series.remove(fast)
    window._apply_channel_timing()
    assert [s["fs_est"] for s in window.current_series] == [500, 5000]
    window.channel_fs_overrides.clear()
    window._apply_channel_timing()
    assert unknown["x_mode"] == "index" and unknown["fs_est"] is None
    assert slow["fs_est"] == 500
    target = tmp_path / "unknown.csv"
    write_csv(str(target), [export_snapshot(unknown)], ExportOptions())
    assert float(base.read_csv(target)[-1][0]) == 50


def test_same_manual_rate_is_not_adjusted_by_sample_counts(window, tmp_path):
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", np.zeros(5001)), ChannelObject("G", "B", np.zeros(501))])
    window.current_series = base.load(path, [("G", "A", 5001), ("G", "B", 501)])["series"]
    window.channel_fs_overrides = {s["style_key"]: 5000 for s in window.current_series}
    window._apply_channel_timing()
    a, b = window.current_series
    assert a["x"][-1] == 1 and b["x"][-1] == .1
    assert a["fs_est"] == b["fs_est"] == 5000


def test_stale_persistent_settings_and_controls_are_gone(window):
    window.settings.setValue("manual_fs/enabled", True)
    window.settings.setValue("manual_fs/common_duration", True)
    window.settings.setValue("manual_fs/value", 50000)
    window.settings.setValue("fft/fs_hint", 500000)
    window._restore_ui_state()
    for name in ("chk_auto_sync", "chk_manual_fs_plot", "sp_manual_fs_plot", "cmb_manual_fs_unit", "fs_fft", "_apply_auto_fs_sync"):
        assert not hasattr(window, name)
        assert name not in CHECKS + NUMBERS
    labels = [b.text() for b in window.findChildren(QCheckBox)]
    assert not any("Referans" in label or "Ortak test" in label for label in labels)


def test_fs_change_clears_obsolete_measurements_but_noop_does_not(window, tmp_path):
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", np.arange(1001), properties={"wf_increment": .0002})])
    window.current_series = base.load(path, [("G", "A", 1001)])["series"]
    window._apply_channel_timing()
    window._on_marker_requested_from("main", .02, 100)
    window._ab_positions = [.02, .04]
    window._last_fft_payload = {"fs": 5000}
    window._apply_channel_timing()
    assert window._markers and window._ab_positions == [.02, .04]
    window.channel_fs_overrides[window.current_series[0]["style_key"]] = 500
    window._apply_channel_timing()
    assert not window._markers and window._ab_positions is None and window._last_fft_payload is None


@pytest.mark.parametrize("manual", [None, 5000.])
def test_fft_uses_the_same_rate_as_the_graph(window, app, tmp_path, manual):
    n = 1000
    y = np.cos(2*np.pi*10*np.arange(n)/n)
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", y, properties={"wf_increment": .002})])
    window.current_series = base.load(path, [("G", "A", n)])["series"]
    s = window.current_series[0]
    if manual:
        window.channel_fs_overrides[s["style_key"]] = manual
    window._apply_channel_timing()
    window._refresh_series_comboboxes()
    window.chk_fft_window.setChecked(False)
    window.compute_fft(); base.wait_jobs(window, app)
    result = window._last_fft_payload
    assert result["fs"] == s["fs_est"] == (manual or 500)
    assert result["freq"][np.argmax(result["mag_linear"]) ] == (manual or 500)*.01


def test_fft_does_not_estimate_rate_from_numeric_x():
    worker = m.FFTWorker("unknown", np.arange(100)*.0002, np.ones(100), None, False, False, False)
    errors = []; worker.failed.connect(errors.append); worker.run()
    assert errors and "tahmin edilmez" in errors[0]


@pytest.mark.parametrize("lazy", [False, True])
def test_old_project_cannot_restore_reference_rates(window, app, tmp_path, monkeypatch, lazy):
    if lazy:
        monkeypatch.setattr(m, "CFG", replace(m.CFG, lazy=replace(m.CFG.lazy, fullload_threshold=2)))
    from PyQt6.QtCore import Qt
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", np.arange(101), properties={"wf_increment": .002}), ChannelObject("G", "B", np.arange(11))])
    window.open_tdms_path(str(path)); base.wait_jobs(window, app)
    next(iter(window.files.values())).tree.topLevelItem(0).setCheckState(0, Qt.CheckState.Checked)
    window.plot_checked_channels(); base.wait_jobs(window, app)
    first_key = window.current_series[0]["style_key"]
    window.channel_fs_overrides[first_key] = 5000
    window._apply_channel_timing()
    window._populate_calculated_aliases()
    window.calc_expression.setText("C1*2")
    window._create_calculated_channel(); base.wait_jobs(window, app)
    target = tmp_path / "legacy.tdmsproj"
    manifest, arrays = window._project_manifest(str(target))
    save_project_archive(str(target), manifest, arrays)
    with zipfile.ZipFile(target) as archive:
        parts = {name: archive.read(name) for name in archive.namelist()}
    data = json.loads(parts["project.json"])
    data["version"] = 1; data.pop("timing_policy", None)
    data["channels"][1]["automatic"] = {"auto_fs_hz": 50000, "auto_x_mode":"seconds", "auto_x_base":99.}
    data["ui"]["checks"].update(chk_auto_sync=True, chk_manual_fs_plot=True)
    data["ui"]["numbers"].update(sp_manual_fs_plot=50000, fs_fft=1234)
    data["ui"].update(fs_unit="kHz", x_range=[99, 100], ab_positions=[99, 100], ab_enabled=True,
                       markers=[{"x":99,"y":1,"label":"obsolete"}])
    parts["project.json"] = json.dumps(data).encode()
    with zipfile.ZipFile(target, "w") as archive:
        for name, payload in parts.items(): archive.writestr(name, payload)
    notices=[]
    monkeypatch.setattr(QMessageBox, "information", lambda *a: notices.append(a[-1]))
    window._open_project_path(str(target)); base.wait_jobs(window, app)
    a,b,v=window.current_series
    assert a["fs_est"] == 5000 and a["x"][-1] == .02
    assert b["x_mode"] == "index" and b["x"][-1] == 10 and b["fs_est"] is None
    assert v["x_mode"] == "index" and v["fs_est"] is None
    assert notices and not window._markers and not window._ab_enabled
    assert window._ab_positions is None
    # Resaving uses the new format and contains no removed fields.
    new_path = tmp_path / "current.tdmsproj"
    manifest, arrays = window._project_manifest(str(new_path))
    save_project_archive(str(new_path), manifest, arrays)
    restored,_ = read_project_archive(str(new_path))
    assert restored["version"] == 2
    assert not any("automatic" in r for r in restored["channels"])
    assert "fs_unit" not in restored["ui"]
    assert set(restored["ui"]["numbers"]) == set(NUMBERS)


def test_calculated_channel_inherits_explicit_source_rate_without_estimation(window, app, tmp_path):
    path = base.tdms_file(tmp_path, [ChannelObject("G", "A", np.arange(1001), properties={"wf_increment": .002})])
    window.current_series = base.load(path, [("G", "A", 1001)])["series"]
    window.channel_fs_overrides[window.current_series[0]["style_key"]] = 5000
    window._apply_channel_timing(); window._populate_calculated_aliases()
    window.calc_expression.setText("C1*2")
    window._create_calculated_channel(); base.wait_jobs(window, app)
    virtual = window.current_series[-1]
    assert virtual["is_virtual"] and virtual["fs_est"] == 5000
    window._apply_channel_timing()
    assert window._effective_fs_source(virtual) == (5000, "Hesaplanan / manuel")
    assert virtual["x"][-1] == .2
