"""Common-duration semantics and the large-channel overview boundary."""
from dataclasses import replace

import numpy as np
from nptdms import ChannelObject

import tdmsreader as m
import test_regressions as base
from tdms_export import export_snapshot, read_source_xy
from tdms_project import save_project_archive, load_project_archive

app = base.app
window = base.window


def test_opt_in_common_duration_restores_independent_timing(window, app, tmp_path):
    path = base.tdms_file(tmp_path, [
        ChannelObject("G", "Reference", np.arange(5001), properties={"wf_increment": .0002}),
        ChannelObject("G", "Slow", np.arange(501), properties={"wf_increment": .005}),
        ChannelObject("G", "Unknown", np.arange(51)),
    ])
    window.current_series = base.load(path, [("G", "Reference", 5001),
        ("G", "Slow", 501), ("G", "Unknown", 51)])["series"]
    window._refresh_common_duration_references()
    a, b, c = window.current_series
    window._apply_channel_timing()
    assert (a["x"][-1], b["x"][-1], c["x_mode"]) == (1., 2.5, "index")
    assert window.cmb_common_reference.currentData() == a["style_key"]
    window.chk_common_duration.setChecked(True)
    base.wait_jobs(window, app)
    assert [s["x"][-1] for s in (a, b, c)] == [1., 1., 1.]
    assert [s["fs_est"] for s in (a, b, c)] == [5000., 500., 50.]
    assert all(s["effective_fs_source"] == "common_duration" for s in (a, b, c))
    window.chk_common_duration.setChecked(False)
    base.wait_jobs(window, app)
    assert b["x"][-1] == 2.5 and b["fs_est"] == 200
    assert c["x_mode"] == "index" and c["fs_est"] is None


def test_absolute_reference_origin_and_manual_rate():
    reference = {"style_key": "utc", "sample_count": 101,
                 "source_x_mode": "datetime", "source_x_base": 1_700_000_000.,
                 "source_x_inc": .02}
    assert m.common_duration_timing([reference], "utc", {}) == (2., "datetime", 1_700_000_000.)
    assert m.common_duration_timing([reference], "utc", {"utc": 100.}) == (1., "datetime", 1_700_000_000.)


def test_common_duration_requires_known_reference_and_uses_original_count(window, app, tmp_path, monkeypatch):
    monkeypatch.setattr(m, "CFG", replace(m.CFG, lazy=replace(m.CFG.lazy, fullload_threshold=10)))
    path = base.tdms_file(tmp_path, [
        ChannelObject("G", "A", np.arange(101), properties={"wf_increment": .01}),
        ChannelObject("G", "B", np.arange(21)),
    ])
    a, b = base.load(path, [("G", "A", 101), ("G", "B", 21)])["series"]
    assert a["lazy"] and b["lazy"]
    assert m.common_duration_timing([a, b], a["style_key"], {}) == (1., "seconds", 0.)
    window.current_series = [a, b]
    window._refresh_common_duration_references()
    window.chk_common_duration.setChecked(True)
    base.wait_jobs(window, app)
    assert b["x_mode"] == "seconds" and b["fs_est"] == 20.
    assert b["lazy_meta"]["x_inc"] == .05
    x, y = read_source_xy(export_snapshot(b))
    assert len(y) == 21 and x[-1] == 1.0
    window.cmb_common_reference.setCurrentIndex(window.cmb_common_reference.findData(b["style_key"]))
    # In common mode a derived rate must never become a new reference rate.
    assert not window.chk_common_duration.isChecked()
    assert "Fs değeri bilinmiyor" in window.lbl_common_duration.text()


def test_one_million_samples_use_bounded_peak_preserving_overview(tmp_path):
    n = 1_000_000
    signal = np.zeros(n, dtype=np.float32)
    signal[345_678] = 1234
    path = base.tdms_file(tmp_path, [ChannelObject("G", "Pressure", signal,
        properties={"wf_increment": .0002})])
    s = base.load(path, [("G", "Pressure", n)])["series"][0]
    assert s["lazy"] and s["sample_count"] == n
    assert len(s["y"]) <= m.CFG.lazy.overview_max_points + 3
    assert np.max(s["y"]) == 1234
    assert s["_sample_indices"][np.argmax(s["y"])] == 345_678
    x, y = read_source_xy(export_snapshot(s))
    assert len(x) == n and len(y) == n and y[345_678] == 1234


def test_common_duration_project_roundtrip(window, app, tmp_path):
    path = base.tdms_file(tmp_path, [
        ChannelObject("G", "Fast", np.arange(101), properties={"wf_increment": .01}),
        ChannelObject("G", "Slow", np.arange(11)),
    ])
    window.open_tdms_path(str(path))
    base.wait_jobs(window, app)
    st = next(iter(window.files.values()))
    from PyQt6.QtCore import Qt
    st.tree.topLevelItem(0).setCheckState(0, Qt.CheckState.Checked)
    window.plot_checked_channels()
    base.wait_jobs(window, app)
    window.chk_common_duration.setChecked(True)
    base.wait_jobs(window, app)
    assert window.current_series[1]["x"][-1] == 1.
    project_path = tmp_path / "common.tdmsproj"
    manifest, arrays = window._project_manifest(str(project_path))
    assert manifest["ui"]["common_duration"] is True
    save_project_archive(str(project_path), manifest, arrays)
    payload = load_project_archive(str(project_path), m.MultiTdmsChannelLoadWorker,
        m.ChannelRequest, m.ChannelKey)
    window._apply_project(payload)
    base.wait_jobs(window, app)
    assert window.chk_common_duration.isChecked()
    assert window.current_series[1]["x"][-1] == 1.
