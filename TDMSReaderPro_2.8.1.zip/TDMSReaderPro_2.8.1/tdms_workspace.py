"""Project, inspection and A/B workspace integration kept separate from plotting."""
from __future__ import annotations
import math
import threading
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import QObject, Qt, QTimer, pyqtSignal, QSignalBlocker, QEvent
from PyQt6.QtGui import QAction, QColor, QFont, QKeySequence, QContextMenuEvent
from PyQt6.QtWidgets import (
    QApplication, QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QTreeWidget, QTreeWidgetItem, QLabel, QPushButton, QDoubleSpinBox, QCheckBox,
    QHeaderView, QMenu, QFileDialog, QMessageBox, QProgressDialog, QToolButton,
)
from tdms_export import export_snapshot, ExportCancelled
from tdms_inspection import measure_sources, inspect_sources
from tdms_project import save_project_archive, load_project_archive, file_reference
from tdms_alignment import display_time_shift

CHECKS = ("chk_smooth", "chk_fft_log", "chk_fft_window",
          "chk_fft_remove_mean", "chk_fft_detrend", "chk_fft_hide_dc", "chk_fft_peak",
          "chk_region", "chk_click_mark")
NUMBERS = ("spin_smooth_win", "sp_fft_fmin", "sp_fft_fmax")


class FunctionWorker(QObject):
    finished = pyqtSignal(dict)
    failed = pyqtSignal(str)
    def __init__(self, function):
        super().__init__()
        self.function = function
        self._cancel_event = threading.Event()
    def cancel(self):
        self._cancel_event.set()
    @property
    def is_cancelled(self):
        return self._cancel_event.is_set()
    def run(self):
        try:
            def cancelled():
                return self.is_cancelled
            cancelled.event = self._cancel_event
            result = self.function(cancelled)
            self.finished.emit(result if not self.is_cancelled else {"cancelled": True})
        except ExportCancelled:
            self.finished.emit({"cancelled": True})
        except Exception as exc:
            self.failed.emit(str(exc))


class PlotMenuGesture(QObject):
    """Ordinary right drag belongs to the plot; Ctrl+right opens its menu."""
    def eventFilter(self, watched, event):
        if event.type() == QEvent.Type.ContextMenu:
            allowed = (event.reason() == QContextMenuEvent.Reason.Keyboard or
                       bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier))
            if not allowed:
                event.accept()
                return True
        return False


def disable_native_menus(widget, plot=None):
    """Qt owns our context menu; pyqtgraph must not open another on mouse release."""
    widget.scene().contextMenu = []
    if plot is not None:
        plot.setMenuEnabled(False)
        plot.hideButtons()
    widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
    if not hasattr(widget, "_plot_menu_gesture"):
        widget._plot_menu_gesture = PlotMenuGesture(widget)
        widget.installEventFilter(widget._plot_menu_gesture)
        widget.viewport().installEventFilter(widget._plot_menu_gesture)
        widget.setToolTip("Sağ tuşla sürükle: ölçekle. Ctrl + sağ tık: grafik menüsü.")


def show_plot_menu(parent, widget, position, entries):
    previous = getattr(widget, "_tdms_context_menu", None)
    if previous is not None:
        try:
            previous.close()
            previous.deleteLater()
        except RuntimeError:
            pass
    menu = QMenu(parent)
    menu.setObjectName("tdmsPlotContextMenu")
    widget._tdms_context_menu = menu
    for entry in entries:
        if entry is None:
            menu.addSeparator()
            continue
        label, callback = entry[:2]
        action = menu.addAction(label)
        action.triggered.connect(callback)
        if len(entry) == 3:
            action.setCheckable(True)
            action.setChecked(bool(entry[2]))
    menu.popup(widget.mapToGlobal(position))
    return menu


def _jsonable(value):
    if isinstance(value, QColor):
        return list(value.getRgb()[:3])
    if isinstance(value, np.ndarray):
        return [_jsonable(v) for v in value.tolist()]
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def _format(value):
    if value is None:
        return "—"
    if isinstance(value, (int, np.integer)):
        return str(value)
    if isinstance(value, (float, np.floating)):
        if math.isnan(value):
            return "NaN"
        return f"{value:.10g}"
    return str(value)


class WorkspaceMixin:
    def _init_workspace(self, loader_factory, request_type, key_type, range_worker, version):
        self._workspace_types = (loader_factory, request_type, key_type)
        self._range_worker_type = range_worker
        self._app_version = version
        self._project_path = None
        self._project_busy = False
        self._project_progress = None
        self._project_restore_pending = None
        self._ab_enabled = False
        self._ab_positions = None
        self._ab_items = []
        self._ab_token = 0
        self._quality_token = 0
        self._quality_signature = None
        self._last_load_errors = []
        self._ab_timer = QTimer(self)
        self._ab_timer.setSingleShot(True)
        self._ab_timer.setInterval(220)
        self._ab_timer.timeout.connect(self._request_ab_values)
        self._build_inspection_dock()
        self._wire_workspace_menus()
        self._simplify_workspace()
        self.plot_pane.ab_requested.connect(self._toggle_ab_from_menu)
        disable_native_menus(self.stacked_view.canvas)
        self.stacked_view.canvas.customContextMenuRequested.connect(self._stacked_context_menu)
        disable_native_menus(self.fft_plot, self.fft_plot.getPlotItem())
        self.fft_plot.customContextMenuRequested.connect(self._fft_context_menu)

    def _build_inspection_dock(self):
        self.inspection_dock = QDockWidget("Ölçüm ve Veri Kalitesi", self)
        self.inspection_dock.setObjectName("inspectionDock")
        self.inspection_dock.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea)
        self.inspection_tabs = QTabWidget()
        self.inspection_dock.setWidget(self.inspection_tabs)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.inspection_dock)
        ab = QWidget(); layout = QVBoxLayout(ab)
        row = QHBoxLayout()
        self.ab_check = QCheckBox("A/B imleçleri")
        self.ab_check.toggled.connect(self._set_ab_enabled)
        row.addWidget(self.ab_check)
        self.ab_a, self.ab_b = QDoubleSpinBox(), QDoubleSpinBox()
        for label, box in (("A:", self.ab_a), ("B:", self.ab_b)):
            box.setDecimals(9); box.setRange(-1e15, 1e15); box.setKeyboardTracking(False)
            box.setMinimumWidth(155)
            row.addWidget(QLabel(label)); row.addWidget(box)
            box.valueChanged.connect(self._ab_boxes_changed)
        center = QPushButton("Görünüme Yerleştir")
        center.clicked.connect(self._center_ab)
        row.addWidget(center)
        self.ab_stats_button = QPushButton("Aralık İstatistiği")
        self.ab_stats_button.clicked.connect(self._calculate_ab_stats)
        row.addWidget(self.ab_stats_button)
        row.addStretch(1)
        layout.addLayout(row)
        self.ab_note = QLabel("A ve B'yi sürükleyin. Değerler en yakın özgün örnekten okunur; SG uygulanmaz, görüntü kaydırmaları uygulanır.")
        self.ab_note.setWordWrap(True); layout.addWidget(self.ab_note)
        self.ab_tree = self._inspection_tree(["Kanal", "Birim", "X(A)", "Y(A)", "X(B)", "Y(B)", "ΔX örnek", "ΔY", "N", "Ortalama", "RMS"])
        layout.addWidget(self.ab_tree)
        self.inspection_tabs.addTab(ab, "A/B Ölçümü")
        quality = QWidget(); layout = QVBoxLayout(quality)
        row = QHBoxLayout()
        self.quality_refresh = QPushButton("Tüm Örnekleri Denetle")
        self.quality_refresh.clicked.connect(self._request_quality)
        cancel = QPushButton("Durdur"); cancel.clicked.connect(self._cancel_quality)
        row.addWidget(self.quality_refresh); row.addWidget(cancel); row.addStretch(1)
        layout.addLayout(row)
        self.quality_note = QLabel("Yüklenmiş kanalların tamamını denetler. Önizleme üzerinden eksik örnek yüzdesi hesaplanmaz.")
        self.quality_note.setWordWrap(True); layout.addWidget(self.quality_note)
        self.quality_tree = self._inspection_tree(["Dosya / Kanal", "Kaynak türü", "Yüklenen tür", "Birim", "Fs / Kaynak", "Örnek", "NaN", "Inf", "Geçersiz %", "Durum"])
        self.quality_tree.setColumnWidth(0, 250)
        self.quality_tree.setColumnWidth(4, 180)
        layout.addWidget(self.quality_tree)
        self.inspection_tabs.addTab(quality, "Veri Kalitesi")
        self.inspection_dock.hide()

    def _inspection_tree(self, headers):
        tree = QTreeWidget()
        tree.setHeaderLabels(headers)
        tree.setRootIsDecorated(False)
        tree.setAlternatingRowColors(True)
        tree.setUniformRowHeights(True)
        tree.header().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        tree.setColumnWidth(0, 205)
        for i in range(1, len(headers)):
            tree.setColumnWidth(i, 105)
        return tree

    def _wire_workspace_menus(self):
        file_menu = self.menuBar().actions()[0].menu()
        first = file_menu.actions()[0]
        for text, shortcut, callback in [
            ("Proje Aç…", "Ctrl+Shift+O", self.open_project),
            ("Projeyi Kaydet", "Ctrl+S", self.save_project),
            ("Projeyi Farklı Kaydet…", "Ctrl+Alt+S", lambda: self.save_project(save_as=True)),
        ]:
            action = QAction(text, self); action.setShortcut(QKeySequence(shortcut))
            action.triggered.connect(callback); file_menu.insertAction(first, action)
        file_menu.insertSeparator(first)
        view_menu = self.menuBar().actions()[1].menu()
        view_menu.addSeparator()
        view_menu.addAction("A/B Ölçüm Paneli", lambda: self._show_inspection(0))
        view_menu.addAction("Veri Kalitesi", lambda: self._show_inspection(1))
        self.ab_action = QAction("A/B imleçleri", self)
        self.ab_action.setShortcut(QKeySequence("Ctrl+M"))
        self.ab_action.triggered.connect(self._toggle_ab_from_menu)
        self.addAction(self.ab_action)

    def _simplify_workspace(self):
        # Keep the ribbon as the one primary set of interaction controls.
        # Detached windows retain their own toolbar.
        self.plot_pane._quickbar.hide()
        self.plot_pane._info.setParent(self.status)
        self.plot_pane._info.setMinimumWidth(0)
        self.status.addPermanentWidget(self.plot_pane._info, 1)
        self.plot_pane._info.show()
        self.preview_box.setVisible(False)
        toggle = QToolButton()
        toggle.setText("Kanal Özelliklerini Göster")
        toggle.setCheckable(True)
        toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        toggle.setArrowType(Qt.ArrowType.RightArrow)
        toggle.setAccessibleName("Kanal özelliklerini aç veya kapat")
        def show_properties(on):
            self.preview_box.setVisible(on)
            toggle.setText("Kanal Özelliklerini Gizle" if on else "Kanal Özelliklerini Göster")
            toggle.setArrowType(Qt.ArrowType.DownArrow if on else Qt.ArrowType.RightArrow)
        toggle.toggled.connect(show_properties)
        parent_layout = self.preview_box.parentWidget().layout()
        parent_layout.insertWidget(parent_layout.indexOf(self.preview_box), toggle)
        self.properties_toggle = toggle
        self.rb_marker.setText("İşaret")
        for button in self.ribbon.findChildren(QToolButton):
            if button.text() == "Kaydet":
                button.setText("Grafiği\nKaydet")
            elif button.text() == "Ölçüm":
                button.setText("A/B Ölçüm")
                button.clicked.disconnect()
                button.clicked.connect(lambda: self._show_inspection(0))
        # Add a compact project menu and quality command without adding a row.
        project = self._make_ribbon_button("Proje", icon=QApplication.style().standardIcon(QApplication.style().StandardPixmap.SP_DialogSaveButton), tooltip="Çalışmayı aç / kaydet")
        menu = QMenu(project)
        menu.addAction("Proje Aç…", self.open_project)
        menu.addAction("Projeyi Kaydet", self.save_project)
        menu.addAction("Projeyi Farklı Kaydet…", lambda: self.save_project(save_as=True))
        project.setMenu(menu); project.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        quality = self._make_ribbon_button("Veri Kalitesi", icon=project.icon(), tooltip="Veri türleri, Fs kaynağı ve eksik örnekler")
        quality.setText("Veri\nKalitesi")
        quality.clicked.connect(lambda: self._show_inspection(1))
        self.ribbon.layout().insertWidget(0, project)
        self.ribbon.layout().insertWidget(self.ribbon.layout().count()-1, quality)
        self.tabs.setUsesScrollButtons(True)
        self.tabs.tabBar().setExpanding(False)
        self.btn_uncheck_all.setText("Seçimi Kaldır")

    def _stacked_context_menu(self, position):
        show_plot_menu(self, self.stacked_view.canvas, position, [
            ("Eksen Aralıkları…", self._open_axis_ranges),
            ("Tüm Grafikleri Sığdır", self._autofit_all_panes),
            ("Kaydır", lambda: self._apply_interaction_mode_to_all("pan"), self.plot_pane._interaction_mode == "pan"),
            ("Dikdörtgen Yakınlaştır", lambda: self._apply_interaction_mode_to_all("zoom"), self.plot_pane._interaction_mode == "zoom"),
            ("A/B Ölçüm Paneli", lambda: self._show_inspection(0)),
            ("Veri Kalitesi", lambda: self._show_inspection(1)), None,
            ("Grafiği Panoya Kopyala", self.copy_plot_to_clipboard),
            ("Grafiği Kaydet…", self.save_plot_image)])

    def _fft_context_menu(self, position):
        show_plot_menu(self, self.fft_plot, position, [
            ("Spektrumu Sığdır", self.fft_plot.autoRange),
            ("Grafiği Panoya Kopyala", self.copy_plot_to_clipboard),
            ("Grafiği Kaydet…", self.save_plot_image)])

    def _show_inspection(self, index):
        self.inspection_tabs.setCurrentIndex(index)
        self.inspection_dock.show(); self.inspection_dock.raise_()
        self.resizeDocks([self.inspection_dock], [245], Qt.Orientation.Vertical)
        if index == 0:
            self.ab_check.setChecked(True)
        else:
            self._request_quality()

    def _toggle_ab_from_menu(self):
        if not self._ab_enabled:
            self._show_inspection(0)
        else:
            self.ab_check.setChecked(False)

    def _workspace_plots(self):
        plots = [self.plot_pane.plot.getPlotItem()] + list(self.stacked_view._plots)
        if self.detached_win is not None:
            plots.append(self.detached_win.pane.plot.getPlotItem())
        return plots

    def _current_xrange(self):
        if self.cmb_plot_mode.currentText() == "Stacked" and self.stacked_view._plots:
            return self.stacked_view._plots[0].getViewBox().viewRange()[0]
        return self.plot_pane.plot.getViewBox().viewRange()[0]

    def _center_ab(self):
        lo, hi = self._current_xrange()
        self._ab_positions = [lo + .25*(hi-lo), lo + .75*(hi-lo)]
        self._sync_ab_positions()

    def _set_ab_enabled(self, enabled):
        self._ab_enabled = bool(enabled)
        if enabled and self._ab_positions is None:
            self._center_ab()
        self._attach_ab_lines()
        if enabled:
            self._ab_timer.start()
        else:
            self._ab_timer.stop(); self._cancel_jobs(["ab", "ab_stats"])

    def _ab_boxes_changed(self):
        self._ab_positions = [self.ab_a.value(), self.ab_b.value()]
        self._sync_ab_positions()

    def _sync_ab_positions(self):
        if self._ab_positions is None:
            return
        for box, value in zip((self.ab_a, self.ab_b), self._ab_positions):
            with QSignalBlocker(box):
                box.setValue(value)
        for _, line, index in self._ab_items:
            try:
                with QSignalBlocker(line):
                    line.setValue(self._ab_positions[index])
            except RuntimeError:
                pass
        self._ab_token += 1
        self._cancel_jobs(["ab", "ab_stats"])
        self.ab_tree.clear()
        if self._ab_enabled:
            self._ab_timer.start()

    def _attach_ab_lines(self):
        plots = self._workspace_plots()
        old_plots = {id(plot) for plot, _, _ in self._ab_items}
        if old_plots != {id(plot) for plot in plots}:
            for plot, line, _ in self._ab_items:
                try:
                    plot.removeItem(line)
                except RuntimeError:
                    pass
            self._ab_items = []
            for plot in plots:
                for i, (name, color) in enumerate((("A", "#087F8C"), ("B", "#C26B00"))):
                    line = pg.InfiniteLine(pos=(self._ab_positions or [0, 1])[i], angle=90,
                        movable=True, pen=pg.mkPen(color, width=2), hoverPen=pg.mkPen(color, width=3),
                        label=name, labelOpts={"position": .94, "color": color, "fill": "#FFFFFF"})
                    line.setZValue(100)
                    plot.addItem(line, ignoreBounds=True)
                    line.sigPositionChanged.connect(lambda item, index=i: self._ab_line_moved(index, item.value()))
                    self._ab_items.append((plot, line, i))
        for _, line, _ in self._ab_items:
            line.setVisible(self._ab_enabled and bool(self.current_series))
        self._style_ab_lines()

    def _style_ab_lines(self):
        colors = ("#5CD4DE", "#FFD080") if self._theme == "dark" else ("#087F8C", "#C26B00")
        fill = "#1A2030" if self._theme == "dark" else "#FFFFFF"
        for _, line, index in getattr(self, "_ab_items", []):
            try:
                line.setPen(pg.mkPen(colors[index], width=2))
                line.setHoverPen(pg.mkPen(colors[index], width=3))
                line.label.fill = pg.mkBrush(fill)
                line.label.setColor(colors[index])
                line.label.update()
            except RuntimeError:
                pass

    def _ab_line_moved(self, index, value):
        if self._ab_positions is None:
            return
        self._ab_positions[index] = float(value)
        self._sync_ab_positions()

    def _inspection_sources(self, visible=False):
        sources = []
        display_styles = self._alignment_display_styles()
        for s in self.current_series or []:
            style = self.style_map.get(s["style_key"], {})
            if visible and style.get("visible", True) is False:
                continue
            source = export_snapshot(s, dict(style, x_shift=display_time_shift(display_styles.get(s['style_key'], {}))))
            fs, origin = self._effective_fs_source(s)
            source.update(source_data_type=s.get("source_data_type", "Hesaplanan" if s.get("is_virtual") else "—"),
                          source_path=s.get("source_path", ""), source_fingerprint=s.get("source_fingerprint"), fs_text=f"{fs:.8g} Hz · {origin}" if fs else "Bilinmiyor / indeks")
            sources.append(source)
        return sources

    def _request_ab_values(self):
        if not self._ab_enabled or not self.current_series or self._closing or self._project_busy:
            return
        sources = self._inspection_sources(visible=True)
        self._ab_token += 1
        token = self._ab_token
        positions = list(self._ab_positions)
        self.ab_note.setText("Tam çözünürlüklü örnekler okunuyor…")
        worker = FunctionWorker(lambda cancel: measure_sources(sources, positions, cancel))
        self._start_job(worker, lambda p: self._ab_ready(token, p), tag="ab", cancel_tags=["ab", "ab_stats"])

    def _ab_ready(self, token, payload):
        if token != self._ab_token:
            return
        self.ab_tree.clear()
        modes = set()
        for row in payload["rows"]:
            a, b = row.get("a") or {}, row.get("b") or {}
            modes.add(row["mode"])
            values = [row["name"], row["unit"], a.get("x"), a.get("y"), b.get("x"), b.get("y"), row.get("dt"), row.get("dy"), None, None, None]
            display = [_format(v) for v in values]
            if row["mode"] == "datetime":
                for column in (2, 4):
                    if values[column] is not None:
                        display[column] = datetime.fromtimestamp(values[column], timezone.utc).strftime("%H:%M:%S.%f")
            item = QTreeWidgetItem(display)
            item.setData(0, Qt.ItemDataRole.UserRole, row["key"])
            details = row.get("error") or f"A örnek indeksi: {a.get('index', 'aralık dışı')} · B örnek indeksi: {b.get('index', 'aralık dışı')}\nX türü: {row['mode']} · En yakın özgün örnek; interpolasyon yok."
            for i in range(len(values)):
                item.setToolTip(i, details + (f"\nTam değer: {values[i]!r}" if values[i] is not None else ""))
            self.ab_tree.addTopLevelItem(item)
        unit = "örnek" if modes == {"index"} else "s"
        self.ab_tree.headerItem().setText(6, f"ΔX ({unit})")
        self.ab_note.setText(f"İmleç aralığı: {_format(self._ab_positions[1]-self._ab_positions[0])} {unit}. "
            "Tablodaki X ve ΔX, seçilen özgün örneklere aittir. SG uygulanmaz; kaydırmalar uygulanır. "
            + ("Karma zaman türleri: kanalların X türlerini kontrol edin." if len(modes)>1 else ""))

    def _calculate_ab_stats(self):
        if not self.current_series or not self._ab_positions or self._ab_positions[0] == self._ab_positions[1]:
            return
        self._ab_token += 1
        token = self._ab_token
        self._ab_timer.stop()
        requests = self._range_stats_requests()
        sources = self._inspection_sources(visible=True)
        positions = list(self._ab_positions)
        lo, hi = sorted(positions)
        self.ab_note.setText("A/B aralığı tam çözünürlükte analiz ediliyor…")
        def begin_stats(payload):
            if token != self._ab_token:
                return
            self._ab_ready(token, payload)
            self._start_job(self._range_worker_type(token, requests, lo, hi),
                lambda p: self._ab_stats_ready(token, p), tag="ab_stats", cancel_tags=["ab_stats"])
        self._start_job(FunctionWorker(lambda cancel: measure_sources(sources, positions, cancel)),
            begin_stats, tag="ab", cancel_tags=["ab", "ab_stats"])

    def _ab_stats_ready(self, token, payload):
        if token != self._ab_token:
            return
        lookup = {self.ab_tree.topLevelItem(i).data(0, Qt.ItemDataRole.UserRole): self.ab_tree.topLevelItem(i) for i in range(self.ab_tree.topLevelItemCount())}
        for row in payload.get("rows", []):
            item = lookup.get(row["style_key"])
            if item is not None:
                for column, key in ((8, "n"), (9, "mean"), (10, "rms")):
                    item.setText(column, _format(row[key]))
        self.ab_note.setText("A/B aralığı analiz edildi. İstatistikler SG'den bağımsızdır; kaydırmalar uygulanır. " + " · ".join(payload.get("errors", [])))

    def _request_quality(self):
        if self._project_busy:
            return
        sources = self._inspection_sources()
        self._quality_token += 1
        token = self._quality_token
        self.quality_tree.clear()
        if not sources:
            self.quality_note.setText("Önce kanalları çizim alanına yükleyin. " + " · ".join(self._last_load_errors))
            return
        self.quality_note.setText("Tüm örnekler bloklar halinde denetleniyor…")
        self.quality_refresh.setEnabled(False)
        self._start_job(FunctionWorker(lambda cancel: inspect_sources(sources, cancel)),
                        lambda p: self._quality_ready(token, p), self._quality_failed,
                        tag="quality", cancel_tags=["quality"])

    def _quality_ready(self, token, payload):
        if token != self._quality_token:
            return
        self.quality_refresh.setEnabled(True)
        self.quality_tree.clear()
        for r in payload["rows"]:
            state = r.get("error") or ("Eksik son TDMS segmenti" if r.get("incomplete") else "Geçersiz örnek var" if r.get("invalid_percent", 0) else "Tamam")
            item = QTreeWidgetItem([_format(v) for v in [f"{r['file']} / {r['name']}", r["source_type"], r.get("loaded_type"), r["unit"], r["fs"], r["count"], r.get("nan"), r.get("inf"), r.get("invalid_percent"), state]])
            for i in range(10):
                item.setToolTip(i, item.text(i))
            self.quality_tree.addTopLevelItem(item)
        self.quality_note.setText(f"{len(payload['rows'])} kanalın tüm örnekleri denetlendi. Tür, npTDMS'nin okuduğu veri türüdür. " + " · ".join(self._last_load_errors))

    def _quality_failed(self, message):
        self.quality_refresh.setEnabled(True)
        self.quality_note.setText(message)

    def _cancel_quality(self):
        self._quality_token += 1
        self._cancel_jobs(["quality"])
        self.quality_refresh.setEnabled(True)
        self.quality_note.setText("Denetim durduruldu; tamamlanmış bir kalite sonucu gösterilmiyor.")

    def _workspace_data_changed(self):
        self._valve_refresh()
        self._steady_refresh()
        self._alignment_refresh()
        if not hasattr(self, "ab_tree"):
            return
        self._ab_token += 1
        self._cancel_jobs(["ab", "ab_stats"])
        self.ab_tree.clear()
        signature = [(s.get("style_key"), s.get("sample_count", len(s["y"])),
                      s.get("fs_est"), s.get("x_mode"), self.style_map.get(s["style_key"], {}).get("display_name"),
                      self.style_map.get(s["style_key"], {}).get("unit_override"),
                      None if s.get("lazy") else id(s["y"])) for s in self.current_series or []]
        if signature != self._quality_signature:
            self._quality_signature = signature
            self._quality_token += 1
            self._cancel_jobs(["quality"])
            self.quality_tree.clear()
            self.quality_refresh.setEnabled(True)
            self.quality_note.setText("Veri/ayarlar değişti. Güncel sonuç için Tüm Örnekleri Denetle'ye basın.")
        self._ab_timer.stop()
        if not self.current_series:
            self._ab_positions = None
        self._attach_ab_lines()

    def _workspace_rendered(self):
        if not hasattr(self, "ab_tree"):
            return
        if self.detached_win is not None and not getattr(self.detached_win, "_ab_connected", False):
            self.detached_win.pane.ab_requested.connect(self._toggle_ab_from_menu)
            self.detached_win._ab_connected = True
        self._attach_ab_lines()
        self._apply_interaction_mode_to_all()
        if self._project_restore_pending is not None:
            pending = self._project_restore_pending
            self._project_restore_pending = None
            if pending.get("x_range"):
                lo, hi = pending["x_range"]
                self.plot_pane.set_xrange(lo, hi)
                self.stacked_view.set_xrange(lo, hi)
            restored_y = {}
            if pending.get("y_range"):
                restored_y["y"] = pending["y_range"]
            if pending.get("y2_range") and self.plot_pane._right_vb is not None:
                restored_y["y2"] = pending["y2_range"]
            self.plot_pane.set_axis_ranges(restored_y)
            self.plot_pane.set_y_lock(bool(pending.get("y_lock")))
            self.plot_pane.set_right_y_lock(bool(pending.get("y2_lock")))
            for key, plot in zip(self.stacked_view._keys, self.stacked_view._plots):
                if key in pending.get("stacked_ranges", {}):
                    plot.getViewBox().setYRange(*pending["stacked_ranges"][key], padding=0)
            if pending.get("ab_positions") is not None:
                self._ab_positions = pending["ab_positions"]
                self._sync_ab_positions()
            self.ab_check.setChecked(bool(pending.get("ab_enabled")))
        if self._ab_enabled and self.current_series:
            if self._ab_positions is None:
                self._center_ab()
            self._ab_timer.start()

    def _project_manifest(self, path):
        files = []
        for fid, state in self.files.items():
            record = file_reference(state.path, path)
            record.update(id=fid, checked=[])
            tree = state.tree
            for i in range(tree.topLevelItemCount()):
                group = tree.topLevelItem(i)
                for j in range(group.childCount()):
                    child = group.child(j)
                    key = child.data(0, Qt.ItemDataRole.UserRole)
                    record["checked"].append({"group": key.group, "channel": key.channel,
                        "name": child.text(0), "checked": child.checkState(0) == Qt.CheckState.Checked})
            files.append(record)
        channels, virtual, arrays = [], [], []
        for s in self.current_series or []:
            if s.get("is_virtual"):
                virtual.append(_jsonable({k: v for k, v in s.items() if k not in ("x", "y", "source_x", "_sample_indices") and not k.startswith("_lazy")}))
                arrays.append({name: np.asarray(s.get(name, s["x"])) for name in ("x", "y", "source_x")})
            else:
                if s.get("file_id") not in self.files:
                    raise ValueError("Kaynak dosyası açık olmayan bir kanal kaydedilemez.")
                fingerprint = s.get("source_fingerprint")
                actual = next(r for r in files if r["id"] == s["file_id"])
                if fingerprint and any(actual[k] != fingerprint[k] for k in ("size", "mtime_ns")):
                    raise ValueError("TDMS kaynağı kanal yüklendikten sonra değişmiş. Yeniden yükleyip kaydedin.")
                channels.append({"file_id": s["file_id"], "group": s["group"], "channel": s["channel"],
                    "length": self._series_sample_count(s), "name": s["name"]})
        ui = {"checks": {k: getattr(self, k).isChecked() for k in CHECKS},
              "numbers": {k: getattr(self, k).value() for k in NUMBERS},
              "common_duration": self.chk_common_duration.isChecked(),
              "common_reference": self.cmb_common_reference.currentData(),
              "plot_mode": self.cmb_plot_mode.currentText(),
              "theme": self._theme, "background": list(self.plot_bg_rgb), "axis": self._collect_axis_style_from_controls(),
              "x_range": self._current_xrange() if self.current_series else None,
              "ab_positions": self._ab_positions, "ab_enabled": self._ab_enabled,
              "legend": self.plot_pane._legend_visible, "mode": self.plot_pane._interaction_mode,
              "y_lock": self.plot_pane._y_lock_enabled, "y2_lock": self.plot_pane._right_y_lock_enabled,
              "stacked_ranges": {k: p.getViewBox().viewRange()[1] for k, p in zip(self.stacked_view._keys, self.stacked_view._plots)},
              "y_range": self.plot_pane.plot.getViewBox().viewRange()[1],
              "y2_range": self.plot_pane._right_vb.viewRange()[1] if self.plot_pane._right_vb else None,
              "details": self.controls_dock.isVisible(), "properties": self.properties_toggle.isChecked(),
              "splitter": self._main_splitter.sizes(),
              "markers": [{k: m[k] for k in ("x", "y", "label")} for m in self._markers.values()]}
        return _jsonable({"application_version": self._app_version, "files": files, "channels": channels,
                          "virtual": virtual, "styles": self.style_map, "alignments": self.alignment_manager.snapshot(),
                          "fs_overrides": self.channel_fs_overrides, "ui": ui}), arrays

    def save_project(self, _checked=False, *, save_as=False, path=None, on_saved=None):
        if self._project_busy:
            return
        if any(tag in ("load", "index", "calc") for _, _, tag in self._jobs):
            self.status.showMessage("Kaydetmeden önce kanal yükleme/hesaplama işleminin bitmesini bekleyin.", 5000)
            return
        if path is None:
            path = None if save_as else self._project_path
            if not path:
                path, _ = QFileDialog.getSaveFileName(self, "Projeyi Kaydet", self._project_path or "calisma.tdmsproj", "TDMSReader Projesi (*.tdmsproj)")
        if not path:
            return
        if not path.lower().endswith(".tdmsproj"):
            path += ".tdmsproj"
        try:
            manifest, virtual = self._project_manifest(path)
        except Exception as exc:
            QMessageBox.warning(self, "Proje Kaydedilemedi", str(exc))
            return
        worker = FunctionWorker(lambda cancel: save_project_archive(path, manifest, virtual, cancel))
        self._begin_project_job(worker, "Proje kaydediliyor…", lambda p: self._project_saved(p, on_saved))

    def _project_saved(self, payload, on_saved=None):
        self._project_path = payload["path"]
        self._update_project_title()
        self.status.showMessage("Proje kaydedildi. TDMS kaynak dosyalarını proje ile birlikte saklayın.", 6000)
        if on_saved is not None:
            on_saved()

    def _update_project_title(self):
        title = Path(self._project_path).stem if self._project_path else "Yeni çalışma"
        self.setWindowTitle(f"{title} · TDMSReader Pro {self._app_version} · AKBGB")

    def open_project(self, _checked=False):
        if self._project_busy:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Proje Aç", self._project_path or "", "TDMSReader Projesi (*.tdmsproj)")
        if not path:
            return
        if self.current_series:
            answer = QMessageBox.question(self, "Çalışmayı Kaydet",
                "Başka bir proje açılacak. Mevcut çalışmayı önce kaydetmek ister misiniz?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Save)
            if answer == QMessageBox.StandardButton.Cancel:
                return
            if answer == QMessageBox.StandardButton.Save:
                self.save_project(on_saved=lambda: self._open_project_path(path))
                return
        self._open_project_path(path)

    def _open_project_path(self, path):
        if self._project_busy:
            return
        self._cancel_jobs(["ab", "ab_stats", "quality"])
        self._ab_timer.stop()
        types = self._workspace_types
        worker = FunctionWorker(lambda cancel: load_project_archive(path, *types, cancelled=cancel))
        self._begin_project_job(worker, "Proje ve kaynak kanallar doğrulanıyor…", self._apply_project)

    def _begin_project_job(self, worker, text, finished):
        self._project_busy = True
        self.centralWidget().setEnabled(False)
        self.inspection_dock.setEnabled(False)
        self.menuBar().setEnabled(False)
        progress = QProgressDialog(text, "İptal", 0, 0, self)
        progress.setWindowTitle("TDMSReader Projesi")
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        self._project_progress = progress
        cleaned = False
        def cleanup():
            nonlocal cleaned
            if cleaned:
                return
            cleaned = True
            self._project_busy = False
            self.centralWidget().setEnabled(True)
            self.inspection_dock.setEnabled(True)
            self.menuBar().setEnabled(True)
            with QSignalBlocker(progress):
                progress.close()
            progress.deleteLater()
            if self._project_progress is progress:
                self._project_progress = None
        def ready(payload):
            cleanup()
            try:
                finished(payload)
            except Exception as exc:
                QMessageBox.warning(self, "Proje", str(exc))
        def failed(message):
            cleanup()
            QMessageBox.warning(self, "Proje Açılamadı / Kaydedilemedi", message)
        def cancel():
            worker.cancel()
            cleanup()
            self.status.showMessage("Proje işlemi iptal edildi; mevcut çalışma korunuyor.", 5000)
        progress.canceled.connect(cancel)
        self._start_job(worker, ready, failed, tag="project")
        progress.show()

    def _validate_project_ui(self, data):
        self.alignment_manager.validate(data.get('alignments', {}))
        ui = data["ui"]
        required = {"checks", "numbers", "axis", "background", "plot_mode", "theme"}
        if not required.issubset(ui):
            raise ValueError("Proje arayüz ayarları eksik.")
        rgb = ui["background"]
        if not isinstance(rgb, list) or len(rgb) != 3 or not all(isinstance(v, int) and 0 <= v <= 255 for v in rgb):
            raise ValueError("Geçersiz grafik arka planı.")
        axis = ui["axis"]
        if not isinstance(axis, dict):
            raise ValueError("Geçersiz eksen stili.")
        for key in ("x_title", "y_title", "y2_title", "font_family"):
            if key in axis and not isinstance(axis[key], str):
                raise ValueError("Geçersiz eksen metni.")
        for key in ("title_size", "tick_size"):
            if key in axis and (not isinstance(axis[key], int) or not 7 <= axis[key] <= 28):
                raise ValueError("Geçersiz eksen yazı boyutu.")
        sizes = ui.get("splitter", [])
        if not isinstance(sizes, list) or (sizes and (len(sizes) != 2 or not all(isinstance(v, int) and 0 <= v <= 100000 for v in sizes))):
            raise ValueError("Geçersiz panel boyutu.")
        ranges = ui.get("stacked_ranges", {})
        if not isinstance(ranges, dict):
            raise ValueError("Geçersiz Stacked eksen aralığı.")
        for span in ranges.values():
            if not isinstance(span, list) or len(span) != 2 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in span) or span[1] <= span[0]:
                raise ValueError("Geçersiz Stacked eksen aralığı.")
        for section in ("checks", "numbers", "axis"):
            if not isinstance(ui.get(section), dict):
                raise ValueError("Geçersiz proje arayüz ayarları.")
        for name, value in ui["checks"].items():
            if name not in CHECKS or not isinstance(value, bool):
                raise ValueError("Geçersiz proje seçim ayarı.")
        for name, value in ui["numbers"].items():
            if name not in NUMBERS or not isinstance(value, (float, int)) or not math.isfinite(value):
                raise ValueError("Geçersiz proje sayısal ayarı.")
            box = getattr(self, name)
            if value < box.minimum() or value > box.maximum():
                raise ValueError("Proje ayarı desteklenen aralığın dışında.")
        if ui.get("plot_mode") not in ("Overlay", "Stacked") or ui.get("theme") not in ("light", "dark"):
            raise ValueError("Geçersiz proje görünüm ayarı.")
        if not isinstance(ui.get("common_duration", False), bool) or ui.get("common_reference") is not None and not isinstance(ui["common_reference"], str):
            raise ValueError("Geçersiz ortak süre ayarı.")
        for name in ("x_range", "y_range", "y2_range", "ab_positions"):
            value = ui.get(name)
            if value is not None and (not isinstance(value, list) or len(value) != 2 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in value)):
                raise ValueError("Geçersiz proje eksen aralığı.")
        for name in ("x_range", "y_range", "y2_range"):
            if ui.get(name) is not None and ui[name][1] <= ui[name][0]:
                raise ValueError("Proje eksen aralığı artan olmalı.")
        for style in data["styles"].values():
            if not isinstance(style, dict):
                raise ValueError("Geçersiz kanal stili.")
            for name in ("width", "x_shift", "y_shift"):
                if name in style and (not isinstance(style[name], (float, int)) or not math.isfinite(style[name])):
                    raise ValueError("Geçersiz kanal stili sayısı.")
            for name in ("display_name", "unit_override", "axis"):
                if name in style and not isinstance(style[name], str):
                    raise ValueError("Geçersiz kanal stili metni.")
            rgb = style.get("color")
            if rgb is not None and (not isinstance(rgb, list) or len(rgb) not in (3, 4) or not all(isinstance(v, int) and 0 <= v <= 255 for v in rgb)):
                raise ValueError("Geçersiz kanal rengi.")
        if not isinstance(data.get("fs_overrides"), dict) or not all(isinstance(v, (int, float)) and math.isfinite(v) and v > 0 for v in data["fs_overrides"].values()):
            raise ValueError("Geçersiz kanal Fs ayarı.")
        for marker in ui.get("markers", []):
            if not all(isinstance(marker.get(k), (int, float)) and math.isfinite(marker[k]) for k in ("x", "y")) or not isinstance(marker.get("label"), str):
                raise ValueError("Geçersiz işaret.")

    def _apply_project(self, payload):
        data, ui = payload["manifest"], payload["manifest"]["ui"]
        self._validate_project_ui(data)  # before clearing any previous state
        self._cancel_jobs([tag for _, _, tag in self._jobs if tag != "project"])
        self.on_clear_plot()
        if self.detached_win is not None:
            self.detached_win.close()
        for i in range(self.file_tabs.count()-1, 0, -1):
            page = self.file_tabs.widget(i)
            self.file_tabs.removeTab(i); page.deleteLater()
        self.files.clear()
        self.style_map = data["styles"]
        self.alignment_manager.restore(data.get('alignments', {}))
        self.channel_fs_overrides = data["fs_overrides"]
        self.file_counter = 0
        for record in data["files"]:
            fid = record["id"]
            self.open_tdms_path(payload["files"][fid]["path"], file_id=fid, index_refs=payload["indexes"][fid])
            state = self.files[fid]
            saved = {(c["group"], c["channel"]): c for c in record.get("checked", [])}
            with QSignalBlocker(state.tree):
                for i in range(state.tree.topLevelItemCount()):
                    group = state.tree.topLevelItem(i)
                    for j in range(group.childCount()):
                        item = group.child(j); key = item.data(0, Qt.ItemDataRole.UserRole)
                        entry = saved.get((key.group, key.channel))
                        if entry:
                            item.setText(0, entry["name"])
                            item.setCheckState(0, Qt.CheckState.Checked if entry["checked"] else Qt.CheckState.Unchecked)
        self.current_series = payload["series"] or None
        self._refresh_common_duration_references(ui.get("common_reference"))
        self.chk_common_duration.setEnabled(bool(self.current_series))
        with QSignalBlocker(self.chk_common_duration):
            self.chk_common_duration.setChecked(ui.get("common_duration", False))
        self._virtual_channel_counter = len(data["virtual"])
        widgets = [getattr(self, k) for k in CHECKS+NUMBERS] + [self.cmb_plot_mode]
        blockers = [QSignalBlocker(w) for w in widgets]
        for name, value in ui["checks"].items():
            getattr(self, name).setChecked(value)
        for name, value in ui["numbers"].items():
            getattr(self, name).setValue(value)
        self.cmb_plot_mode.setCurrentText(ui["plot_mode"])
        del blockers
        self.set_theme(ui["theme"])
        self.plot_bg_rgb = tuple(ui["background"])
        self._apply_background_everywhere()
        axis = ui["axis"]
        for key, widget in (("x_title", self.le_axis_x_title), ("y_title", self.le_axis_y_title), ("y2_title", self.le_axis_y2_title)):
            widget.setText(axis.get(key, ""))
        self.cmb_axis_font.setCurrentFont(QFont(axis.get("font_family", "Arial")))
        self.sp_axis_title_size.setValue(axis.get("title_size", 11))
        self.sp_axis_tick_size.setValue(axis.get("tick_size", 9))
        self.chk_axis_title_bold.setChecked(axis.get("title_bold", False))
        self.chk_axis_tick_bold.setChecked(axis.get("tick_bold", False))
        self._apply_axis_style_from_controls(show_status=False)
        self._apply_channel_timing()
        self._active_plot_mode = ui["plot_mode"]
        self.plot_container.setCurrentWidget(self.stacked_view if ui["plot_mode"] == "Stacked" else self.plot_pane)
        self.plot_pane.set_y_lock(False)
        self.plot_pane.set_right_y_lock(False)
        self.plot_pane.set_legend_visible(ui.get("legend", True))
        self._apply_interaction_mode_to_all(ui.get("mode", "pan"))
        self._set_region_enabled_all(self.chk_region.isChecked())
        self._set_click_mark_enabled_all(self.chk_click_mark.isChecked())
        self.rb_marker.setChecked(self.chk_click_mark.isChecked())
        self.properties_toggle.setChecked(ui.get("properties", False))
        self._set_advanced_controls_visible(ui.get("details", False))
        if ui.get("splitter"):
            self._main_splitter.setSizes(ui["splitter"])
        self.clear_markers()
        for marker in ui.get("markers", []):
            self._on_marker_requested_from("main", marker["x"], marker["y"])
            self._markers[self._marker_counter]["label"] = marker["label"]
            self.marker_list.topLevelItem(self.marker_list.topLevelItemCount()-1).setText(0, marker["label"])
        self.virtual_tree.clear()
        for series in self.current_series or []:
            if series.get("is_virtual"):
                self.virtual_tree.addTopLevelItem(QTreeWidgetItem([series["name"], series.get("virtual_expression", "")]))
        self._project_path = payload["path"]
        self._update_project_title()
        self._refresh_series_comboboxes()
        self._update_selection_count()
        self._show_plot_tab()
        self._project_restore_pending = ui
        self.update_plot_data_with_filter()
        self._refresh_statistics()
        self._update_workspace_summary()
        if not self.current_series:
            self._workspace_rendered()
        if data.get("relative_time_migrated"):
            QMessageBox.information(self, "Zaman ekseni saniyeye çevrildi",
                "Eski UTC projesi saniye ekseniyle açıldı. Fs ve kanal değerleri korundu. "
                "Eski X görünümü ve ölçüm noktaları temizlendi. Hesaplanan UTC kanallarının "
                "zaman başlangıcı kaynak kanalına göre dönüştürüldü; çok dosyalı hesaplanan kanalları yeniden kontrol edin.")
        if data.get("timing_migrated"):
            QMessageBox.information(self, "Zaman ayarları güncellendi",
                "Eski projenin referans/ortak süre ve ayrı FFT Fs ayarları kaldırıldı. "
                "Kanallar yalnız manuel Fs veya kendi TDMS metadata'sıyla açıldı; ikisi de yoksa indeks kullanılır. "
                "Eski ölçüm noktaları temizlendi. Eski hesaplanan kanalları yeniden oluşturun veya kendi manuel Fs'lerini girin.")
        self.status.showMessage("Proje açıldı; kanal zamanı manuel Fs / metadata ile kuruldu.", 5000)
