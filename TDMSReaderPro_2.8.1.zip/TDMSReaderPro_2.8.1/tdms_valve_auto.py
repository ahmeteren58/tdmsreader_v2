"""Derive valve input settings from the recorded samples.

Input type, thresholds and the glitch filter come from the data. Connection
type, channel roles and active level stay the user's choice: a wrong mode with
inverted inputs can pair every edge cleanly while swapping opening and closing,
so alternatives are only ever offered as a hint.
"""
from __future__ import annotations
from collections import Counter
from contextlib import ExitStack
from dataclasses import replace
import math
import numpy as np
from tdms_valve import _bounds, _changes, _check, _evaluate, _open_sources, _pair, _scan, _validate_sources
from tdms_valve_rules import SignalOptions, ValveOptions

SUGGESTED_MODES = ('position', 'command_closed', 'command_open')
PROBLEM_STATUSES = frozenset({'unpaired', 'cancelled', 'ambiguous', 'timeout'})
FILTER_SAMPLES = (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 64)
# The automatic filter never exceeds this share of the shortest measured
# duration, so it removes contact bounce but not genuinely short cycles.
FILTER_LIMIT = .2
FILTER_STEPS_PER_S = 10_000_000
PROFILE_CHUNK = 262_140
PROFILE_SAMPLES = 1_000_000
DENSE_CHANGES = 20_000
HINT_BUDGET = 3_000_000
INVERSIONS = ((False, False), (True, False), (False, True), (True, True))


def _mad(values):
    if len(values) < 2:
        return 0.
    return 1.4826*float(np.median(np.abs(values-np.median(values))))


def _rounded(low, high):
    a, b = round(low, 6), round(high, 6)
    return (a, b) if a < b else (low, high)


def profile_levels(channel, cancelled=lambda: False, progress=lambda f: None):
    """Classify one channel as exact 0/1 or two-level analog with hysteresis thresholds."""
    n, name = channel.n, channel.s['name']
    stride = max(1, math.ceil(n/PROFILE_SAMPLES))
    finite, lo, hi, binary = 0, math.inf, -math.inf, True
    med_lo, med_hi = math.inf, -math.inf
    raw, medians = [], []
    for offset in range(0, n, PROFILE_CHUNK):
        _check(cancelled)
        _, _, values = channel.block(offset, offset+PROFILE_CHUNK)
        y = np.asarray(values, dtype=float)
        v = y[np.isfinite(y)]
        if v.size:
            finite += v.size
            lo, hi = min(lo, float(v.min())), max(hi, float(v.max()))
            binary = binary and not np.any((v != 0) & (v != 1))
        raw.append(v[::stride])
        # Five-sample medians ignore one- and two-sample spikes when locating levels.
        blocks = y[:len(y)//5*5].reshape(-1, 5)
        blocks = blocks[np.all(np.isfinite(blocks), axis=1)]
        if len(blocks):
            med = np.median(blocks, axis=1)
            med_lo, med_hi = min(med_lo, float(med.min())), max(med_hi, float(med.max()))
            medians.append(med[::stride])
        progress(min(1., (offset+len(y))/n))
    if not finite:
        raise ValueError(f'{name}: sonlu örnek yok; sinyal seviyeleri belirlenemedi.')
    if hi == lo:
        raise ValueError(f'{name}: sinyal kayıt boyunca sabit ({lo:g}); açılma/kapanma geçişi yok. Doğru kanalı seçtiğinizi kontrol edin.')
    if binary:
        return {'kind': 'binary', 'low': 0., 'high': 1., 'noise': 0.,
                'low_threshold': .3, 'high_threshold': .7, 'warning': ''}
    if not math.isfinite(med_lo):
        med_lo, med_hi = lo, hi
    if med_hi <= med_lo:
        raise ValueError(f'{name}: sinyalde yalnız bir-iki örneklik sıçramalar var; kararlı iki seviye bulunamadı. Doğru kanalı seçtiğinizi kontrol edin.')
    mid = (med_lo+med_hi)/2
    m, r = np.concatenate(medians), np.concatenate(raw)
    lower, upper = m[m < mid], m[m >= mid]
    low = float(np.median(lower)) if len(lower) >= 20 else med_lo
    high = float(np.median(upper)) if len(upper) >= 20 else med_hi
    if high <= low:
        low, high = med_lo, med_hi
    swing = high-low
    noise = max(_mad(r[r < mid]), _mad(r[r >= mid]))
    low_th, high_th = _rounded(low+.3*swing, low+.7*swing)
    warning = 'seviyeler gürültüden net ayrışmıyor; eşikleri ham grafikte kontrol edin' if 8*noise > swing else ''
    return {'kind': 'analog', 'low': low, 'high': high, 'noise': noise,
            'low_threshold': low_th, 'high_threshold': high_th, 'warning': warning}


def _conditioning(level):
    if level['kind'] == 'binary':
        return SignalOptions()
    return SignalOptions(input_mode='hysteresis', low_threshold=level['low_threshold'],
                         high_threshold=level['high_threshold'])


def filter_time(samples, dt):
    """Hold time that accepts runs of `samples` samples and rejects shorter ones.

    Rounded down to the settings resolution so the value shown in the UI
    selects exactly the same runs.
    """
    if samples <= 0:
        return 0.
    exact = samples*dt
    shown = math.floor(exact*FILTER_STEPS_PER_S+1e-6)/FILTER_STEPS_PER_S
    return shown if shown > (samples-1)*dt*(1+1e-9) else exact


def _flip_changes(changes):
    swap = {'rise': 'fall', 'fall': 'rise'}
    return [dict(c, state=1-c['state'], kind=swap.get(c['kind'], c['kind'])) if c['state'] >= 0 else c
            for c in changes]


def _outcome(events, changes, bounds):
    """Score a pairing; edges that no event explains count against it.

    A bounce on the end channel can complete an event early and leave only
    unexplained edges behind, so problem statuses alone cannot reveal it.
    """
    lo, hi = bounds
    counts = Counter(e['status'] for e in events)
    durations = [e['duration'] for e in events if e['status'] == 'complete']
    problems = sum(counts[s] for s in PROBLEM_STATUSES)
    edges = sum(c['kind'] in ('rise', 'fall') and lo <= c['t'] <= hi for cs in changes for c in cs)
    used = {(e['start_channel'], e['start_index']) for e in events}
    used |= {(e['end_channel'], e['end_index']) for e in events if e['end_index'] is not None}
    stray = max(0, edges-len(used))
    return {'score': len(durations)-problems-stray, 'complete': len(durations), 'problems': problems,
            'stray': stray, 'events': len(events), 'shortest': min(durations) if durations else None,
            'total': sum(durations), 'first': events[0]['direction'] if events else None}


class _Edges:
    """Accepted edges per channel, filter length and polarity, computed on demand."""
    def __init__(self, scans, dts):
        self.scans, self.dts, self.cache = scans, dts, {}

    def hold(self, j, samples):
        return filter_time(samples, self.dts[j])

    def get(self, j, samples, inverted, rise_hold=0.0):
        key = (j, samples, inverted, rise_hold)
        if key not in self.cache:
            if inverted and not rise_hold:
                self.cache[key] = _flip_changes(self.get(j, samples, False))
            else:
                self.cache[key] = _changes(self.scans[j][0], self.hold(j, samples),
                                           rise_hold, inverted)[0]
        return self.cache[key]


def _search(edges, options, bounds, cancelled, samples, order=(0, 1), inversions=((False, False),), budget=None):
    """Best glitch filter (and, for hints, polarity) for one channel order and mode."""
    best = None
    for inverted in inversions:
        for k in (0,)+samples:
            chosen = [edges.get(order[i], k, inverted[i], options.rise_hold_s) for i in (0, 1)]
            if budget is not None:
                budget[0] -= len(chosen[0])+len(chosen[1])
                if budget[0] < 0:
                    return best
            try:
                outcome = _outcome(_pair(chosen, options, bounds, cancelled), chosen, bounds)
            except ValueError:
                continue
            holds = [edges.hold(order[i], k) for i in (0, 1)]
            if k and (outcome['shortest'] is None or max(holds) > FILTER_LIMIT*outcome['shortest']):
                continue
            key = (outcome['score'], -sum(inverted), -k)
            if best is None or key > best['key']:
                best = {'key': key, 'inverted': inverted, 'samples': k, 'holds': holds, **outcome}
    return best


def _needs_hint(outcome):
    return outcome['problems'] > 0 or outcome['complete'] == 0 or outcome['stray'] > 2


def _hint(edges, options, bounds, cancelled, samples, current):
    """Best-pairing alternative to the user's settings, or None.

    Several readings can pair cleanly (e.g. a flipped command measuring dwell
    instead of travel); those usually lose an edge at the record boundaries.
    Ties keep the chosen mode and channel order, then prefer fewer changes and
    shorter durations. The 2.4.0 rule is never proposed: with inverted inputs
    it pairs position switch records cleanly but labels closing as opening.
    """
    budget = [HINT_BUDGET]
    polarity = [s.active_low for s in options.signals]
    candidates = [] if options.mode == 'legacy' else [(0, options.mode, False), (1, options.mode, True)]
    candidates += [(1, m, swap) for m in SUGGESTED_MODES if m != options.mode for swap in (False, True)]
    best = None
    for stage, mode, swap in candidates:
        order = (1, 0) if swap else (0, 1)
        inversions = INVERSIONS[1:] if stage == 0 else INVERSIONS
        alt = _search(edges, replace(options, mode=mode), bounds, cancelled, samples, order, inversions, budget)
        if alt and alt['complete'] and alt['score'] > current['score']:
            changes = (mode != options.mode)+swap+sum(alt['inverted'])
            rank = (alt['score'], -stage, -changes, -alt['total'])
            if best is None or rank > best['rank']:
                active_low = tuple(polarity[order[i]] != alt['inverted'][i] for i in (0, 1))
                best = dict(alt, mode=mode, swap=swap, active_low=active_low, rank=rank)
        if budget[0] < 0:
            break
    return best


def auto_analyze(sources, options=ValveOptions(), cancelled=lambda: False, progress=lambda p: None):
    """Detect input type, thresholds and glitch filter, then analyze like analyze_valve.

    The mode, channel order and active levels in `options` are kept. A clearly
    better pairing under other settings is returned in result['auto']['hint'].
    """
    _validate_sources(sources)
    with ExitStack() as stack:
        channels = _open_sources(stack, sources)
        levels = [profile_levels(ch, cancelled, lambda f, j=j: progress(int(30*(j+f)/2)))
                  for j, ch in enumerate(channels)]
        conditioned = replace(options, signals=tuple(
            replace(_conditioning(level), active_low=signal.active_low)
            for level, signal in zip(levels, options.signals)))
        scans = _scan(channels, conditioned, cancelled, lambda f: progress(30+int(45*f)))
    _validate_sources(sources)
    bounds = _bounds(scans)
    edges = _Edges(scans, [1/float(s['fs_hz']) for s in sources])
    dense = sum(len(edges.get(j, 0, False)) for j in (0, 1)) > DENSE_CHANGES
    samples = FILTER_SAMPLES[::3] if dense else FILTER_SAMPLES
    best = _search(edges, conditioned, bounds, cancelled, samples) or {
        'samples': 0, 'holds': [0., 0.], 'score': 0, 'complete': 0, 'problems': 0, 'stray': 0}
    progress(85)
    hint = _hint(edges, conditioned, bounds, cancelled, samples, best) if _needs_hint(best) else None
    final = replace(conditioned, signals=tuple(
        replace(s, min_hold_s=hold) for s, hold in zip(conditioned.signals, best['holds'])))
    result = _evaluate(sources, final, scans, cancelled)
    result['auto'] = {'levels': levels, 'filter_samples': best['samples'], 'complete': best['complete'],
                      'problems': best['problems'], 'stray': best['stray'], 'hint': hint}
    progress(100)
    return result
