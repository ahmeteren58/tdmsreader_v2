# 2.8.0 — UI/UX

- `tdms_presentation.py`: ortak başlık/isteğe bağlı yardım, sekme sırası,
  başlangıç ekranı, ikonlar, tema ve eski proje ofset bildirimi. Fs editörü
  aynı değeri gereksiz sondaki sıfırlar olmadan gösterir; locale ve duyarlık korunur.
- `tdmsreader.py`: sekme/menü bağlantıları, Kanal Yöneticisi Fs editörü,
  kompakt sütunlar ve sunum bağlantıları. Eski Fs açma çağrısı Kanal Yöneticisi'ne yönlenir.
- `tdms_time_channels_ui.py`: kısa durum, yardım ve dar pencerede sığan seçimler.
  Zaman eşleme kararları değişmedi.
- `tdms_alignment_ui.py`: normal açılışta eski düzenleyici oluşturulmaz.
  Eski proje modeli ve gösterim dönüşümü korunur. Uyumluluk bileşen testleri
  eski düzenleyiciyi açıkça `build_ui=True` ile ayrı oluşturur.
- `tdms_ui.py`: sade CSV seçenekleri; eski ofset seçeneği yalnız ilgiliyse görünür.
- Yerel açık/koyu SVG ikonları; altı yeni UI işlev testi.

2.7.0 ile bayt bayt aynı motorlar: TDMS I/O, jobs, viewport/downsampling,
numeric, export, inspection, project, time-channel resolver, alignment state,
workspace, steady ve bütün `tdms_valve*.py` dosyaları. Vana timing ve fake pulse
filtering algoritmalarına dokunulmadı. Ham veri değişmez.
