"""Full-resolution cursor samples and bounded-memory data quality scans."""
from contextlib import ExitStack
import math
import os
import numpy as np
from tdms_io import open_tdms
from tdms_export import _Channel, ExportOptions, ExportCancelled


def nearest_sample(channel, position):
    """Return the nearest original sample; ties choose the earlier index.

    Outside the channel's time bounds, return None, never an extrapolated value.
    Monotonic in-memory X is validated by the caller once per channel.
    """
    s, n = channel.s, channel.n
    if n == 0 or not math.isfinite(position):
        return None
    def x_at(index):
        if channel.ch is None:
            return float(s["x"][index]) + s["x_shift"]
        return (index if s["x_mode"] == "index" else s["x_base"] + index*s["x_inc"]) + s["x_shift"]
    if position < x_at(0) or position > x_at(n-1):
        return None
    lo, hi = 0, n
    while lo < hi:
        mid = (lo+hi)//2
        if x_at(mid) < position:
            lo = mid+1
        else:
            hi = mid
    candidates = [i for i in (lo-1, lo) if 0 <= i < n]
    index = min(candidates, key=lambda i: (abs(x_at(i)-position), i))
    _, x, y = channel.block(index, index+1)
    return {"index": index, "x": x[0].item(), "y": y[0].item()}


def measure_sources(sources, positions, cancelled=lambda: False):
    rows = []
    with ExitStack() as stack:
        handles = {}
        for s in sources:
            if cancelled():
                raise ExportCancelled()
            row = {"key": s["key"], "name": s["name"], "unit": s["unit"], "mode": s["x_mode"]}
            try:
                path = s["path"]
                if path and path not in handles:
                    handles[path] = stack.enter_context(open_tdms(path))
                ch = _Channel(s, handles.get(path), ExportOptions(apply_shifts=True))
                if not path:
                    x = np.asarray(s["x"])
                    if not np.all(np.isfinite(x)) or np.any(np.diff(x) < 0):
                        raise ValueError("A/B için artan, sonlu bir X ekseni gerekli.")
                row["a"], row["b"] = [nearest_sample(ch, p) for p in positions]
                if row["a"] is not None and row["b"] is not None:
                    row["dy"] = row["b"]["y"]-row["a"]["y"]
                    row["dt"] = row["b"]["x"]-row["a"]["x"]
            except Exception as exc:
                row["error"] = str(exc)
            rows.append(row)
    return {"rows": rows}


def inspect_sources(sources, cancelled=lambda: False):
    rows = []
    with ExitStack() as stack:
        handles = {}
        for s in sources:
            if cancelled():
                raise ExportCancelled()
            row = {"key": s["key"], "name": s["name"], "file": s["file_label"],
                   "source_type": s.get("source_data_type", "—"), "unit": s["unit"],
                   "fs": s.get("fs_text", "—"), "count": s["n"]}
            try:
                origin = s.get("source_path") or s["path"]
                fingerprint = s.get("source_fingerprint")
                if origin and fingerprint:
                    stat = os.stat(origin)
                    if stat.st_size != fingerprint["size"] or stat.st_mtime_ns != fingerprint["mtime_ns"]:
                        raise ValueError("Kaynak dosya değişti; kanalları yeniden yükleyin.")
                if origin and origin not in handles:
                    handles[origin] = stack.enter_context(open_tdms(origin))
                source_file = handles.get(origin)
                if source_file:
                    ch = source_file[s["group"]][s["channel"]]
                    if len(ch) != s["n"]:
                        raise ValueError("Kaynak örnek sayısı değişti; dosyayı yeniden açın.")
                    row["incomplete"] = bool(source_file.file_status.incomplete_final_segment)
                adapter = _Channel(s, handles.get(s["path"]), ExportOptions())
                nan = inf = finite = 0
                for i in range(0, adapter.count, 262144):
                    if cancelled():
                        raise ExportCancelled()
                    _, _, y = adapter.block(i, i+262144)
                    row["loaded_type"] = str(y.dtype)
                    nan += int(np.count_nonzero(np.isnan(y)))
                    inf += int(np.count_nonzero(np.isinf(y)))
                    finite += int(np.count_nonzero(np.isfinite(y)))
                row.update(nan=nan, inf=inf, finite=finite,
                           invalid_percent=100*(nan+inf)/s["n"] if s["n"] else 0)
            except ExportCancelled:
                raise
            except Exception as exc:
                row["error"] = str(exc)
            rows.append(row)
    return {"rows": rows}
