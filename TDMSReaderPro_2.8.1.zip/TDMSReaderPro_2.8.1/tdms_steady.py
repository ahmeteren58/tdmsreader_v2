"""Steady-flow intervals and pressure loss on original samples, in bounded blocks.

The detector uses non-overlapping time windows, not a decimated plotting trace.
Only complete windows shared by all selected channels can enter an automatic
interval. Channel means/stds retain each channel's native sampling; pressure
loss is explicitly the difference of these means. No interpolation, filter,
display offset or inferred sensor uncertainty is applied.
"""
from __future__ import annotations

from contextlib import ExitStack
from dataclasses import asdict, dataclass
import csv
import math
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace

import numpy as np

from tdms_export import _Channel, ExportOptions, ExportCancelled, _text
from tdms_io import open_tdms
from tdms_numeric import read_envelope

PRESSURE_FACTORS = {'bar': 1., 'mbar': .001, 'Pa': 1e-5, 'kPa': .01,
                    'MPa': 10., 'psi': .06894757293168361}
ROLES = ('pin', 'pout', 'flow')
ROLE_NAMES = {'pin': 'Giriş basıncı', 'pout': 'Çıkış basıncı', 'flow': 'Debi'}


def pressure_unit(text):
    """Recognise pressure metadata; do not guess gauge/absolute reference."""
    token = str(text or '').strip().lower().replace(' ', '')
    aliases = {'barg': 'bar', 'bara': 'bar', 'bar(g)': 'bar', 'bar(a)': 'bar',
               'psig': 'psi', 'psia': 'psi', 'kpag': 'kPa', 'kpaa': 'kPa'}
    return aliases.get(token, next((u for u in PRESSURE_FACTORS if u.lower() == token), None))


@dataclass(frozen=True)
class SteadyOptions:
    window_s: float = 1.
    min_duration_s: float = 3.
    noise_pct: float = .5
    drift_pct: float = 1.
    pressure_floor_bar: float = .005
    flow_floor: float = 0.
    dp_floor_bar: float = .005
    flow_threshold: float | None = None  # None: 5% of the 95th percentile |bin mean|
    chunk_size: int = 262_144
    max_windows: int = 200_000
    max_intervals: int = 5000

    def __post_init__(self):
        for name in ('window_s', 'min_duration_s', 'noise_pct', 'drift_pct'):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) <= 0:
                raise ValueError(f'{name}: pozitif, sonlu bir değer gerekli.')
        for name in ('pressure_floor_bar', 'flow_floor', 'dp_floor_bar'):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) < 0:
                raise ValueError(f'{name}: negatif olmayan, sonlu bir değer gerekli.')
        if self.flow_threshold is not None and (not math.isfinite(self.flow_threshold) or self.flow_threshold < 0):
            raise ValueError('Debi eşiği negatif olamaz.')
        if self.chunk_size < 1 or self.max_windows < 1 or self.max_intervals < 1:
            raise ValueError('Geçersiz blok/pencere sınırı.')


def _check(cancelled):
    if cancelled():
        raise ExportCancelled()


def _validate(sources):
    if len(sources) not in (2, 3) or [s.get('role') for s in sources] != list(ROLES[:len(sources)]):
        raise ValueError('Giriş ve çıkış basıncını; isterseniz debi kanalını seçin.')
    if len({s['key'] for s in sources}) != len(sources):
        raise ValueError('Her rol için farklı bir kanal seçin.')
    if len({s['x_mode'] for s in sources}) != 1 or sources[0]['x_mode'] not in ('seconds', 'datetime'):
        raise ValueError('Kanalların zaman türü aynı olmalı (saniye veya UTC). Manuel Fs / zaman bilgilerini kontrol edin.')
    for s in sources:
        fs = s.get('fs_hz')
        if fs is None or not math.isfinite(float(fs)) or float(fs) <= 0:
            raise ValueError(f"{s['name']}: Fs bilinmiyor; kanal bazlı Manuel Fs girin.")
        if s['n'] < 3:
            raise ValueError(f"{s['name']}: en az üç örnek gerekli.")
        if s['role'] != 'flow' and s.get('pressure_unit') not in PRESSURE_FACTORS:
            raise ValueError(f"{s['name']}: basınç birimini seçin; birim tahmin edilmez.")
        p, fingerprint = s.get('source_path') or s.get('path'), s.get('source_fingerprint')
        if p and fingerprint:
            st = os.stat(p)
            if st.st_size != fingerprint['size'] or st.st_mtime_ns != fingerprint['mtime_ns']:
                raise ValueError(f"{s['name']}: kaynak dosya değişti; yeniden yükleyin.")


def _open(stack, sources, bounds=None):
    handles = {p: stack.enter_context(open_tdms(p)) for p in dict.fromkeys(s['path'] for s in sources if s.get('path'))}
    return [_Channel(s, handles.get(s.get('path')), ExportOptions(x_range=bounds)) for s in sources]


def _bounds(channels):
    ends = []
    for ch in channels:
        _, a, _ = ch.block(0, 1)
        _, b, _ = ch.block(ch.n-1, ch.n)
        if not len(a) or not len(b) or not np.isfinite(a[0]) or not np.isfinite(b[0]):
            raise ValueError(f"{ch.s['name']}: geçersiz başlangıç/bitiş zamanı.")
        ends.append((float(a[0]), float(b[0])))
    lo, hi = max(a for a, _ in ends), min(b for _, b in ends)
    if hi <= lo:
        raise ValueError('Kanalların zaman aralıkları örtüşmüyor. Başlangıçları kontrol edin.')
    return lo, hi


def _empty_bins(n):
    data = {k: np.zeros(n, dtype=float) for k in ('mean', 'm2', 'tmean', 'tm2', 'cov')}
    data.update(count=np.zeros(n, dtype=np.int64), total=np.zeros(n, dtype=np.int64),
                minimum=np.full(n, np.inf), maximum=np.full(n, -np.inf),
                first=np.full(n, np.inf), last=np.full(n, -np.inf), gap=np.zeros(n, dtype=bool))
    return data


def _accumulate(bins, ids, t, y):
    """Merge centred block moments; avoids E[y²]-E[y]² cancellation."""
    if not len(ids):
        return
    np.add.at(bins['total'], ids, 1)
    np.minimum.at(bins['first'], ids, t)
    np.maximum.at(bins['last'], ids, t)
    finite = np.isfinite(y)
    ids, t, y = ids[finite], t[finite], y[finite]
    if not len(ids):
        return
    starts = np.r_[0, np.flatnonzero(np.diff(ids)) + 1]
    lengths = np.diff(np.r_[starts, len(ids)])
    ix, ref_y, ref_t = ids[starts], y[starts], t[starts]
    dy, dt = y - np.repeat(ref_y, lengths), t - np.repeat(ref_t, lengths)
    sy, st = np.add.reduceat(dy, starts), np.add.reduceat(dt, starts)
    mean, tmean = ref_y + sy/lengths, ref_t + st/lengths
    m2 = np.maximum(0., np.add.reduceat(dy*dy, starts) - sy*sy/lengths)
    tm2 = np.maximum(0., np.add.reduceat(dt*dt, starts) - st*st/lengths)
    cov = np.add.reduceat(dy*dt, starts) - sy*st/lengths
    old = bins['count'][ix]
    new = old + lengths
    dv, dtime = mean - bins['mean'][ix], tmean - bins['tmean'][ix]
    factor = old * (lengths / new)
    bins['m2'][ix] += m2 + dv*dv*factor
    bins['tm2'][ix] += tm2 + dtime*dtime*factor
    bins['cov'][ix] += cov + dv*dtime*factor
    bins['mean'][ix] += dv*(lengths/new)
    bins['tmean'][ix] += dtime*(lengths/new)
    bins['count'][ix] = new
    np.minimum.at(bins['minimum'], ids, y)
    np.maximum.at(bins['maximum'], ids, y)


def _scan(ch, lo, hi, options, cancelled):
    nwin = int(round((hi-lo)/options.window_s))
    bins = _empty_bins(nwin)
    factor = PRESSURE_FACTORS[ch.s['pressure_unit']] if ch.s['role'] != 'flow' else 1.
    previous = None
    px, py = [], []
    precision = max(1e-10, 4*abs(float(np.spacing(lo))))
    dt = 1/float(ch.s['fs_hz'])
    for offset in range(0, ch.count, options.chunk_size):
        _check(cancelled)
        _, xx, yy = ch.block(offset, offset+options.chunk_size)
        x, y = np.asarray(xx, dtype=float), np.asarray(yy, dtype=float)*factor
        if not len(x) or not np.all(np.isfinite(x)) or np.any(np.diff(x) <= 0) or (previous is not None and x[0] <= previous):
            raise ValueError(f"{ch.s['name']}: zamanlar sonlu ve kesin artan olmalı.")
        ids = np.floor((x-lo+precision)/options.window_s).astype(np.int64)
        valid = (ids >= 0) & (ids < nwin) & (x < hi-precision)
        _accumulate(bins, ids[valid], (x-lo)[valid], y[valid])
        # Missing time must split a plateau even when both endpoints lie in
        # different windows. A chunk boundary is treated identically.
        prior = np.r_[previous if previous is not None else x[0], x[:-1]]
        missing = np.flatnonzero(x-prior > 2.5*dt+precision)
        for j in missing:
            a = max(0, int(math.floor((prior[j]-lo)/options.window_s)))
            b = min(nwin-1, int(math.floor((x[j]-lo)/options.window_s)))
            if b >= a:
                bins['gap'][a:b+1] = True
        previous = float(x[-1])
        reader = SimpleNamespace(read_data=lambda offset, length: y[offset:offset+length])
        ix, vals = read_envelope(reader, 0, len(y), max(5, math.ceil(6000*len(y)/max(1, ch.count))), cancelled)
        px.append(x[ix]); py.append(vals)
    _check(cancelled)
    count = bins['count']
    std = np.sqrt(np.divide(bins['m2'], count-1, out=np.full(nwin, np.inf), where=count>1))
    slope = np.divide(bins['cov'], bins['tm2'], out=np.zeros(nwin), where=bins['tm2']>0)
    # Low-rate data are allowed only when a window actually spans >=3 samples.
    edges = np.arange(nwin)*options.window_s
    coverage = (count >= max(3, int(math.floor(options.window_s/dt*.8)))) & (count == bins['total']) & ~bins['gap']
    coverage &= (bins['first'] <= edges+1.5*dt+precision) & (bins['last'] >= edges+options.window_s-1.5*dt-precision)
    floor = options.flow_floor if ch.s['role'] == 'flow' else options.pressure_floor_bar
    level = np.abs(bins['mean'])
    noise_tol = np.maximum(floor, options.noise_pct/100*level)
    drift_tol = np.maximum(floor, options.drift_pct/100*level)
    stable = coverage & (std <= noise_tol+1e-12) & (np.abs(slope)*options.window_s <= drift_tol+1e-12)
    stable &= bins['maximum']-bins['minimum'] <= np.maximum(8*noise_tol, 2*drift_tol)+1e-12
    bins.update(std=std, slope=slope, coverage=coverage, stable=stable)
    return bins, {'x': np.concatenate(px) if px else np.array([]), 'y': np.concatenate(py) if py else np.array([])}


def _summary(bins, a, b):
    n = bins['count'][a:b]
    count = int(n.sum())
    means = bins['mean'][a:b]
    ref = float(means[0])
    mean = ref + float(np.dot(n, means-ref)/count)
    m2 = float(np.sum(bins['m2'][a:b] + n*(means-mean)**2))
    return {'n': count, 'mean': mean, 'std': math.sqrt(max(0., m2)/(count-1)) if count>1 else None,
            'min': float(np.min(bins['minimum'][a:b])), 'max': float(np.max(bins['maximum'][a:b]))}


def _interval(scans, sources, a, b, lo, window_s):
    stats = {s['role']: _summary(scan, a, b) for s, scan in zip(sources, scans)}
    return {'start': lo+a*window_s, 'end': lo+b*window_s, 'duration': (b-a)*window_s,
            'stats': stats, 'dp_bar': stats['pin']['mean']-stats['pout']['mean'], 'mode': 'auto',
            'endpoint_rule': '[başlangıç, bitiş)', 'note': ''}


def analyze_steady(sources, options=SteadyOptions(), cancelled=lambda: False, search_bounds=None):
    _validate(sources)
    _check(cancelled)
    with ExitStack() as stack:
        channels = _open(stack, sources)
        lo, hi = _bounds(channels)
        common_bounds = (lo, hi)
        if search_bounds is not None:
            a, b = map(float, search_bounds)
            if not math.isfinite(a) or not math.isfinite(b) or b <= a:
                raise ValueError('Arama başlangıcı bitişten küçük olmalı.')
            lo, hi = max(lo, a), min(hi, b)
        nwin = int(math.floor((hi-lo)/options.window_s + 1e-9))
        if nwin < max(1, math.ceil(options.min_duration_s/options.window_s-1e-9)):
            raise ValueError('Ortak/arama aralığı asgari kararlı süreden kısa. Süreyi/pencereyi azaltın veya aramayı genişletin.')
        if nwin > options.max_windows:
            raise ValueError(f'Çok fazla değerlendirme penceresi var; pencere süresini artırın (en az {(hi-lo)/options.max_windows:.3g} s).')
        search_hi = hi
        hi = lo+nwin*options.window_s
        # Pooled sessions reuse the same indexed metadata and byte-range reader.
        ranged = _open(stack, sources, (lo, search_hi))
        scans, traces = [], []
        for ch in ranged:
            scan, trace = _scan(ch, lo, hi, options, cancelled)
            scans.append(scan); traces.append(trace)
    _validate(sources)
    mask = np.logical_and.reduce([s['stable'] for s in scans])
    threshold = None
    if len(sources) == 3:
        flow = scans[2]
        values = np.abs(flow['mean'][flow['coverage']])
        scale = float(np.percentile(values, 95)) if len(values) else 0.
        if scale == 0 and len(values):
            scale = float(values.max())
        threshold = options.flow_threshold if options.flow_threshold is not None else .05*scale
        mask &= np.abs(flow['mean']) > threshold
    intervals = []
    start = None
    lower = upper = None
    min_bins = max(1, math.ceil(options.min_duration_s/options.window_s-1e-9))
    floor = np.array([options.pressure_floor_bar, options.pressure_floor_bar]+([options.flow_floor] if len(sources)==3 else [])+[options.dp_floor_bar])
    means = np.vstack([s['mean'] for s in scans]+[scans[0]['mean']-scans[1]['mean']])

    def finish(end):
        if start is not None and end-start >= min_bins:
            intervals.append(_interval(scans, sources, start, end, lo, options.window_s))
            if len(intervals) > options.max_intervals:
                raise ValueError('Çok fazla kararlı aralık var; aramayı daraltın veya asgari süreyi artırın.')

    for i in range(nwin):
        if i % 4096 == 0:
            _check(cancelled)
        if not mask[i]:
            finish(i); start = None
            continue
        current = means[:, i]
        if start is not None:
            lo2, hi2 = np.minimum(lower, current), np.maximum(upper, current)
            tol = np.maximum(floor, options.drift_pct/100*np.maximum(np.abs(lo2), np.abs(hi2)))
            if np.any(hi2-lo2 > tol+1e-12):
                finish(i); start = None
            else:
                lower, upper = lo2, hi2
        if start is None:
            start, lower, upper = i, current.copy(), current.copy()
    finish(nwin)
    _check(cancelled)
    warnings = []
    if len(sources) == 2:
        warnings.append('Debi seçilmedi: sıfır akışlı bekleme bölümleri basınçtan ayırt edilemeyebilir.')
    if len({s.get('source_path') or s.get('path') or s.get('file_label') for s in sources}) > 1:
        warnings.append('Farklı dosyalar kullanılıyor; kayıt başlangıçlarının gerçekten eş zamanlı olduğunu kontrol edin.')
    if any(s.get('fs_source') == 'common_duration' for s in sources):
        warnings.append('Ortak test süresi varsayımı açık; zaman eşleşmesi bu varsayıma dayanıyor.')
    rejected = {s['role']: {'total': nwin, 'coverage': int(np.count_nonzero(~b['coverage'])),
                            'unsteady': int(np.count_nonzero(b['coverage'] & ~b['stable']))}
                for s, b in zip(sources, scans)}
    return {'sources': sources, 'options': asdict(options), 'bounds': (lo, search_hi), 'evaluation_bounds': (lo, hi), 'common_bounds': common_bounds,
            'intervals': intervals, 'traces': traces, 'flow_threshold': threshold, 'warnings': warnings,
            'rejected': rejected, 'time_mode': sources[0]['x_mode']}


def measure_steady(sources, start, end, cancelled=lambda: False, chunk_size=262_144):
    """Manual [start, end) interval, still using original samples and units."""
    _validate(sources)
    if not math.isfinite(start) or not math.isfinite(end) or end <= start:
        raise ValueError('Başlangıç bitişten küçük olmalı.')
    stats = {}
    with ExitStack() as stack:
        channels = _open(stack, sources)
        lo, hi = _bounds(channels)
        if start < lo-1e-7 or end > hi+1e-7:
            raise ValueError('Elle aralık tüm kanalların ortak zaman sınırları içinde olmalı.')
        channels = _open(stack, sources, (start, end))
        for ch in channels:
            bins = _empty_bins(1)
            scale = PRESSURE_FACTORS[ch.s['pressure_unit']] if ch.s['role'] != 'flow' else 1.
            previous = None
            dt = 1/float(ch.s['fs_hz'])
            precision = max(1e-10, 4*abs(float(np.spacing(start))))
            for offset in range(0, ch.count, chunk_size):
                _check(cancelled)
                _, xx, yy = ch.block(offset, offset+chunk_size)
                x, y = np.asarray(xx, dtype=float), np.asarray(yy, dtype=float)*scale
                keep = x < end-precision
                x, y = x[keep], y[keep]
                if not len(x):
                    continue
                if not np.all(np.isfinite(x)) or np.any(np.diff(x) <= 0) or (previous is not None and x[0] <= previous):
                    raise ValueError(f"{ch.s['name']}: zamanlar kesin artan olmalı.")
                if not np.all(np.isfinite(y)):
                    raise ValueError(f"{ch.s['name']}: aralıkta NaN/Inf var; daha dar bir aralık seçin.")
                prior = np.r_[previous if previous is not None else x[0], x[:-1]]
                if np.any(x-prior > 2.5*dt+precision):
                    raise ValueError(f"{ch.s['name']}: aralıkta zaman boşluğu var; daha dar bir aralık seçin.")
                _accumulate(bins, np.zeros(len(x), dtype=np.int64), x-start, y)
                previous = float(x[-1])
            if bins['count'][0] < 2:
                raise ValueError(f"{ch.s['name']}: aralıkta en az iki örnek gerekli.")
            stats[ch.s['role']] = _summary(bins, 0, 1)
    _validate(sources)
    _check(cancelled)
    return {'interval': {'start': start, 'end': end, 'duration': end-start, 'stats': stats,
                         'dp_bar': stats['pin']['mean']-stats['pout']['mean'], 'mode': 'manual',
                         'endpoint_rule': '[başlangıç, bitiş)',
                         'note': 'Elle seçildi; otomatik kararlılık ölçütleri doğrulanmadı.'}}


def write_steady_report(path, result, manual=None, cancelled=lambda: False):
    """Atomic, Excel-friendly report containing every interval and used settings."""
    dest = Path(path).expanduser().absolute()
    if any((s.get('source_path') or s.get('path')) and
           os.path.normcase(os.path.realpath(dest)) == os.path.normcase(os.path.realpath(s.get('source_path') or s['path']))
           for s in result['sources']):
        raise ValueError('Rapor hedefi kaynak TDMS dosyası olamaz.')
    tmp = None
    def number(value):
        return '' if value is None else format(value, '.12g').replace('.', ',')
    try:
        _check(cancelled)
        with tempfile.NamedTemporaryFile(mode='w', newline='', encoding='utf-8-sig', dir=dest.parent,
                                         prefix='.'+dest.name+'.', suffix='.tmp', delete=False) as f:
            tmp = f.name
            w = csv.writer(f, delimiter=';')
            w.writerow(['TDMSReader Pro', 'Kararlı akış / basınç kaybı'])
            w.writerow(['Zaman türü', result['time_mode'], 'UTC ise zamanlar Unix saniyesidir'])
            w.writerow(['Aralık kuralı', '[başlangıç, bitiş)'])
            w.writerow(['Hesap', 'Δp = ort(Pin) - ort(Pout); σ örnek standart sapmasıdır, sensör belirsizliği değildir.'])
            w.writerow(['Veri', 'Özgün örnekler; çizim kaydırma/yumuşatma ve interpolasyon yok. Kanal ortalamaları kendi örnekleme hızlarında.'])
            for s in result['sources']:
                w.writerow([ROLE_NAMES[s['role']], _text(s['name']), _text(s.get('file_label', '')),
                            _text(s.get('group', '')), _text(s.get('channel', '')),
                            'Birim', _text(s.get('pressure_unit', s.get('unit', ''))), 'Fs [Hz]', number(s['fs_hz']),
                            'Fs kaynağı', _text(s.get('fs_source') or '')])
            for k, v in result['options'].items():
                w.writerow(['Ayar', k, number(v) if isinstance(v, (int, float)) else str(v)])
            w.writerow(['Kullanılan |debi| eşiği', number(result.get('flow_threshold'))])
            for note in result['warnings']:
                w.writerow(['Not', _text(note)])
            w.writerow([])
            header = ['Aralık', 'Tür', 'Başlangıç [s]', 'Bitiş [s]', 'Süre [s]', 'Δp [bar]', 'Δp [mbar]']
            for role in ROLES[:len(result['sources'])]:
                unit = 'bar' if role != 'flow' else result['sources'][2].get('unit') or 'kaynak birimi'
                header.extend([f'{ROLE_NAMES[role]} {k}'+(f' [{unit}]' if k != 'n' else '') for k in ('ort', 'σ', 'min', 'maks', 'n')])
            w.writerow(header+['Not'])
            intervals = result['intervals']+([manual] if manual is not None else [])
            for i, interval in enumerate(intervals, 1):
                _check(cancelled)
                row = [i, 'Otomatik' if interval['mode']=='auto' else 'Elle',
                       *[number(interval[k]) for k in ('start', 'end', 'duration', 'dp_bar')], number(interval['dp_bar']*1000)]
                for role in ROLES[:len(result['sources'])]:
                    row.extend(number(interval['stats'][role][k]) for k in ('mean', 'std', 'min', 'max', 'n'))
                w.writerow(row+[_text(interval.get('note', ''))])
            f.flush(); os.fsync(f.fileno())
        _check(cancelled)
        os.replace(tmp, dest); tmp = None
    finally:
        if tmp is not None:
            try:
                os.unlink(tmp)
            except FileNotFoundError:
                pass
    return {'path': str(dest)}
