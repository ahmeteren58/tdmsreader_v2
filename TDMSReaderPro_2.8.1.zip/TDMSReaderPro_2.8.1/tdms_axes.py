"""Explicit numeric view ranges; data and sampling rates are never modified."""
from __future__ import annotations

import math
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QGridLayout, QHBoxLayout, QLabel, QCheckBox,
    QLineEdit, QPushButton, QScrollArea, QWidget,
)


def validate_ranges(ranges):
    result = {}
    for key, pair in ranges.items():
        lo, hi = (float(v) for v in pair)
        if not (math.isfinite(lo) and math.isfinite(hi) and hi > lo):
            raise ValueError("Her eksende minimum ve maksimum sonlu olmalı; minimum < maksimum olmalıdır.")
        result[key] = (lo, hi)
    return result


class AxisRangeDialog(QDialog):
    """Apply checked axes atomically, with full-precision/scientific input."""

    def __init__(self, entries, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Eksen Aralıkları")
        self.resize(620, min(600, 220 + 42 * len(entries)))
        root = QVBoxLayout(self)
        note = QLabel("Değiştirmek istediğiniz eksenleri seçin ve sınırlarını girin. "
                      "X1 zaman ekseninde birim saniyedir; Fs bilinmiyorsa örnek indeksidir. "
                      "Nokta, virgül veya 1e-3 gibi bilimsel gösterim kullanılabilir.")
        note.setWordWrap(True)
        root.addWidget(note)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        grid = QGridLayout(content)
        grid.setColumnMinimumWidth(0, 140)
        grid.setHorizontalSpacing(12)
        for col, title in enumerate(("Uygula / Eksen", "Minimum", "Maksimum")):
            grid.addWidget(QLabel(title), 0, col)
        self.rows = {}
        for row, (key, caption, bounds) in enumerate(entries, 1):
            check = QCheckBox(caption)
            lower, upper = (QLineEdit(format(float(v), ".17g")) for v in bounds)
            for box in (lower, upper):
                box.textEdited.connect(lambda _text, c=check: c.setChecked(True))
                box.setMinimumWidth(115)
            grid.addWidget(check, row, 0)
            grid.addWidget(lower, row, 1)
            grid.addWidget(upper, row, 2)
            self.rows[key] = (check, lower, upper)
        grid.setRowStretch(len(entries) + 1, 1)
        scroll.setWidget(content)
        root.addWidget(scroll)
        self.error = QLabel()
        self.error.setWordWrap(True)
        root.addWidget(self.error)
        buttons = QHBoxLayout()
        buttons.addStretch()
        cancel = QPushButton("İptal")
        apply = QPushButton("Uygula")
        apply.setProperty("primary", True)
        apply.setDefault(True)
        cancel.clicked.connect(self.reject)
        apply.clicked.connect(self._apply)
        buttons.addWidget(cancel)
        buttons.addWidget(apply)
        root.addLayout(buttons)

    def values(self):
        ranges = {}
        for key, (check, lower, upper) in self.rows.items():
            if check.isChecked():
                try:
                    ranges[key] = tuple(float(b.text().strip().replace(",", ".")) for b in (lower, upper))
                except ValueError:
                    raise ValueError(f"{check.text()}: Geçerli sayısal sınırlar girin.") from None
        return validate_ranges(ranges)

    def _apply(self):
        try:
            if not self.values():
                raise ValueError("En az bir eksen seçin.")
        except ValueError as exc:
            self.error.setText(str(exc))
            return
        self.accept()
