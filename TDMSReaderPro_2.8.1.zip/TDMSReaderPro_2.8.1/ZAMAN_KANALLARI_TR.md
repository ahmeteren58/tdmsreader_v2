# Zaman Kanalları — 2.7.0

500 Hz ile 5000 Hz kanallar birlikte kullanılabilir. Her veri grubu kendi
Times kanalını kullanır; örnekler taşınmaz, silinmez veya resample edilmez.

## Kullanım

1. TDMS dosyasını açın ve istediğiniz kanalları çizin.
2. **Zaman Kanalları** sekmesine geçin. Dosyayı seçin; isterseniz `RIO3`
   gibi bir arama yapın. Fs, başlangıç farkı ve doğrulama durumu görünür.
3. Aynı modelin modül adları açık olduğunda eşleme otomatik yapılır:
   `RIO3-9425-3 → RIO3-Times / Mod 3-Time`. Bu modül 500 Hz, başka bir
   RIO3 modülü 5000 Hz olabilir. Hız Times dizisinden ayrı ayrı hesaplanır.
4. Farklı model gruplarında son numara yeniden 1'den başlayabilir.
   Grup sırası veya örnek sayısına dayanan aday **öneri** olarak gösterilir.
   Bunlar fiziksel slot kimliği kanıtı değildir. Kanal/slot listenizle
   kontrol edin, gerekirse dropdown'dan değiştirip **Uygula** deyin.
   Öneri yanlış veya belirsizse bağlamayın; yalnız eşit örnek sayısı yetmez.
5. **Denetle** kaydedilmiş eşlemeleri inceler; yeni seçimleri veya
   birim değişimini uygulamak için **Uygula** kullanılır.

Bir modül seçimi, yalnız zaman kanalıyla örnek sayısı birebir aynı olan
kanallarına uygulanır. Farklı uzunluktaki `Unknown` dizilerine zaman uydurulmaz.
Kendi waveform metadata'sı geçerli kanallar önceki davranışını korur.
Genel `Time`, `Times`, `Timestamp(s)`, `Zaman` isimli sayısal zaman kanalları
dropdown'da elle seçilebilir; genel dosyalarda isimden otomatik bağlama yapılmaz.

## Birimler ve doğrulama

- `unit_string` / `unit` etiketi varsa s, ms, µs/us veya ns dönüşümü kullanılır.
- Etiket yoksa panelde seçili birim kullanılır; varsayılan **s**. Bu bir
  kullanıcı varsayımıdır, örnek sayısından çıkarılmaz. Panel ve grafik bunu belirtir.
- Desteklenmeyen birim, sabit zaman, NaN/Inf, geri gidiş, tekrarlı örnek,
  uzunluk uyuşmazlığı veya düzensiz zaman bağlanmaz. Mevcut metadata/indeks
  yöntemine dönülür; gerekirse kullanıcı açıkça Manuel Fs seçebilir.
- Bu sürüm düzenli sayısal zaman dizilerini destekler. Bütün zaman örnekleri
  sınırlı bloklarla denetlenir; yalnız baş/son iki değerden hız kabul edilmez.
  Float yuvarlaması toleransı dışında kalan düzensiz zamanlar ortalama Fs ile
  yaklaşık gösterilmez.

## Ortak başlangıç ve süreler

Geçerli zaman kanallarındaki en erken ilk zaman dosyanın ortak sıfırıdır.
Sabit/geçersiz Times kanalları bu başlangıcı belirleyemez. Her kanal için
`x[i] = (ilk_zaman - ortak_köken) + i * dt` kullanılır. Her kanalı ayrı ayrı
sıfırlamak yoktur. Kaynak zaman kanalı ve ham sinyal dosyada değişmez.

Örnek testte RIO3'ün ilk kaydı RIO1 hedef basınç kaydından 6 ms sonra gelir.
Bu fark korunur; acquisition hatası diye otomatik silinmez. Ortak köken başka
bir modülün daha erken başlangıcı olursa PT satırında sıfırdan farklı bir değer
görmek normaldir. İki kanal arasındaki 6 ms fark yine korunur.

Yeni temel zaman grafik, zoom/pan, FFT, A/B, aralık istatistikleri, CSV,
Basınç Kaybı ve mevcut Vana Analizi veri girişinde kullanılır. Vana timing ve
fake pulse filtre algoritmaları değiştirilmedi. Farklı hızlar, aynı zaman
birimi ve doğrulanmış ortak kayıt kökeni varsa birlikte analiz edilebilir.
500 Hz örneklerde aralık 2 ms, 5000 Hz'de 0,2 ms'dir; daha hızlı kanala bağlamak
yavaş kanalın fiziksel zaman çözünürlüğünü artırmaz.

Kanal Yöneticisi’ndeki **Elle Fs** ve **Ortak Süre** mevcut önceliğini korur. Times hızını kullanmak
için ilgili Manuel Fs atamasını temizleyin ve Ortak Süre'yi kapatın. Grafik ve
panelde bu geçersiz kılma için bilgi gösterilir. Zamanı değişen kaynaklarla
önceden üretilmiş hesaplanan kanalları yeniden oluşturun.

2.8.0’da Channel Alignment sekmesi kaldırılmıştır. Eski projedeki elle ofsetler korunur ve Zaman Kanalları ekranında bildirilir.
Önceden +6 ms gibi kayıt başlangıcını temsil etmek amacıyla girilmiş ofsetleri
kontrol edin; yeni bağlama sonrası aynı farkı iki kez eklemeyin. Alignment
ofsetleri Vana Analizi'ne uygulanmaz; bağlanan orijinal Times ekseni uygulanır.

## Geri alma, proje ve performans

Bir grupta **Bağlama / eski zaman yöntemi**, o grubun bağını kaldırır.
**Bağlamayı Kapat**, seçili dosyada Times bağlamasını kapatır;
özgün waveform metadata / indeks yöntemi geri gelir. Manuel Fs ve Alignment
ayrı ayarlardır, bu düğme onları silmez.

Eşlemeler, açık/kapalı durumu ve etiketsiz birim seçimi `.tdmsproj` içinde
kaydedilir. Eski projelerde Times bağlama kapalı açılır; eski ölçümler sessizce
başka bir zaman eksenine geçirilmez. Yeni projede sonradan tekrar kapatılabilir.

Dosya açılışında yalnız metadata okunur. İlk çizimde/denetimde zamanlar arka
planda ve bloklarla doğrulanır. Doğrulama sonuçları dosya boyutu/mtime/inode
kimliğiyle önbelleğe alınır. Zoom/pan ve tekrar çizim Times dizilerini yeniden
taramaz. Bağlama değişikliği yüklü sinyal değerlerini yeniden okumadan zaman
koordinatlarını günceller; mevcut lazy/envelope/downsampling motoru kullanılır.

Times bağlama, timestamp'lerin doğru atanmasını sağlar; test ekibinin bu
timestamp'leri gerçek örnek alma anına doğru ilişkilendirdiğini veya RIO'ların
donanımsal olarak senkron olduğunu kanıtlamaz. Bunlar için doğrulanmış ortak
bir senkron olayı gerekir. Fiziksel vana/basınç gecikmesi otomatik silinmez.

Demo: `examples/time_channels_mixed_rates.tdms`.
