# Kararlı akış ve otomatik basınç kaybı — 2.5.5

Bu sekme, seçtiğiniz giriş basıncı, çıkış basıncı ve isteğe bağlı debi kanalının
**aynı anda kararlı kaldığı zaman aralıklarını** bulur. Her aralık ayrı bir test
noktasıdır; farklı debilerdeki veya farklı basınç seviyelerindeki aralıklar tek
ortalamada birleştirilmez.

## Hızlı kullanım

1. TDMS dosyasını açın, ilgili kanalları işaretleyip **Seçili Kanalları Çiz** düğmesine basın.
2. **Basınç Kaybı** sekmesini açın.
3. Giriş basıncı, çıkış basıncı ve mümkünse debi kanalını seçin. **Kanal adlarından öner**,
   Pin / Pout / Debi / P1 / P2 gibi tekil adları eşleştirmeye yardımcı olur; önerilen rolleri kontrol edin.
4. Her basıncın mevcut veri birimini seçin. Tanınan metadata birimi önerilir; bilinmeyen birim varsayılmaz.
   bar, mbar, Pa, kPa, MPa ve psi desteklenir. İki basınç aynı referansta olmalıdır:
   ikisi de manometrik veya ikisi de mutlak. Birim seçimi sensör kalibrasyonu değildir.
5. Başlangıç için **Standart**, **1 s pencere**, **3 s asgari süre** kullanın.
6. **Kararlı Aralıkları Bul** düğmesine basın. En uzun uygun aralık seçilir;
   diğer aralıkları tablodan seçebilirsiniz. Hesap tamamlandığında ayarlar katlanır;
   **Kanallar ve analiz ayarları** düğmesiyle tekrar açılır.
7. Seçili yeşil bölgeyi basınç ve debi grafiklerinde kontrol edin.
8. Sonuçları **Sonuçları CSV’ye Aktar** ile kaydedin.

`examples/basinc_kaybi_demo.tdms`, farklı Fs ve farklı basınç birimleri içeren
iki sentetik test noktasıdır. Pin bar, Pout kPa, Debi kg/s birimindedir. İlk
oturmuş noktada yaklaşık **16,908 / 16,846 bar**, **59,63 kg/s** ve
**0,062 bar = 62 mbar** elde edilir. İkinci noktada yaklaşık **12,1 / 12,072 bar**,
**35 kg/s** ve **0,028 bar** elde edilir. Bu dosya gerçek deney verisi değildir.

## Ne hesaplanıyor?

Her kanal için özgün örneklerden aritmetik ortalama, örnek standart sapması
(σ, payda n−1), minimum, maksimum ve örnek sayısı hesaplanır. Basınçlar önce
bar birimine dönüştürülür:

**Δp = ort(Pgiriş) − ort(Pçıkış)**

Örnek: 16,908 − 16,846 = **0,062 bar**.

Aralıklar **[başlangıç, bitiş)** kuralını kullanır: başlangıç dahil, bitiş hariçtir.
Farklı Fs’lerde her kanal aynı zaman aralığındaki **kendi özgün örnekleriyle**
ortalama alır; örnek sayıları farklı olabilir. İnterpolasyon veya yeniden
örnekleme yapılmaz. Bu nedenle sonuç, farklı Fs’ler için “eşleştirilmiş anlık
Δp örneklerinin ortalaması” olarak sunulmaz. Δp için σ veya ölçüm belirsizliği
üretilmez; kanalların σ değerleri ayrı gösterilir.

σ, verinin aralık içindeki dalgalanmasıdır; sensör hassasiyeti veya toplam
ölçüm belirsizliği değildir. Özellikle küçük Δp’de sensör kalibrasyonunu ve
basınç ölçüm noktalarını ayrıca değerlendirin.

## Otomatik kararlılık mantığı

Arama bölgesi, tüm seçili kanalların ortak zaman aralığıdır. İsterseniz aramayı
başlangıç/bitiş kutularından daraltabilirsiniz. Pencereler ortak arama
başlangıcına hizalanır. Her pencerenin **tüm örnekleri** bloklar halinde okunur.

Bir pencerenin kabulü için:

- Her kanalda en az üç örnek ve beklenen örnek sayısının en az yaklaşık %80’i bulunur.
  Pencere kenarları da kapsanmalıdır. NaN/Inf bulunan pencere kabul edilmez.
- Beklenen örnek aralığının 2,5 katından büyük zaman boşluğu aralığı keser.
- Pencere içindeki σ, gürültü toleransının altında kalır.
- Doğrusal eğimin pencere süresindeki değişimi, sürüklenme toleransının altında kalır.
- Dar, yüksek pikleri kaçırmamak için ham min–maks açıklığı ayrıca kontrol edilir:
  açıklık ≤ max(8 × gürültü toleransı, 2 × sürüklenme toleransı).
- Debi seçilmişse |pencere ortalaması| aktif debi eşiğini aşar.

Ardışık uygun pencereler birleştirilirken **her kanalın ve Δp’nin pencere
ortalamalarının toplam açıklığı** sürüklenme toleransını aşamaz. Böylece küçük
adımlarla sürekli kayan sinyaller sınırsız uzun bir “kararlı bölge” oluşturmaz.
Asgari süreyi sağlayan her ortak bölge ayrı sonuç olur. Süre, tam pencere
sayısına yukarı yuvarlanır. Son kısmi pencere otomatik sonuca alınmaz;
grafikte incelenip elle hesaplanabilir.

Bu eşikler, “bu toleranslar içinde kararlı” anlamına gelir. Ölçütün tüm
deneyler için aynı olması beklenmez; test süresine ve veri gürültüsüne göre
ayarlanmalıdır. Geçişi içeren pencerelerin elenmesi nedeniyle otomatik sınırlar
pencere çözünürlüğündedir; kesin test sınırı gerekiyorsa elle daraltın.

## Toleransları ayarlama

| Önayar | Azami σ / seviye | Azami sürüklenme | Mutlak P ve Δp toleransı |
| --- | ---: | ---: | ---: |
| Sıkı | %0,2 | %0,5 | 0,002 bar |
| Standart | %0,5 | %1 | 0,005 bar |
| Esnek | %1 | %2 | 0,01 bar |

Bir kanalın gürültü toleransı **max(mutlak tolerans, |pencere ortalaması| × σ yüzdesi)**,
sürüklenme toleransı ise **max(mutlak tolerans, |seviye| × sürüklenme yüzdesi)** olur.
Birleştirmede seviye, aday aralıktaki en büyük mutlak pencere ortalamasıdır.
Δp’nin birleştirme toleransı kendi seviyesine ve kendi mutlak toleransına dayanır.
Örneğin 0,062 bar Δp için Standart sürüklenme toleransı
max(0,005, 0,062 × 0,01) = **0,005 bar** olur.

**Gelişmiş ayarlar** ile yüzdeleri, mutlak basınç / Δp / debi toleranslarını ve
aktif debi eşiğini değiştirebilirsiniz. Önayar alanı, elle değişiklikte **Özel** olur.
Debi mutlak toleransı ve eşiği **kanalın mevcut birimindedir**.

Varsayılan otomatik aktif debi eşiği, geçerli pencerelerdeki |debi ortalamalarının|
95. yüzdeliğinin **%5’i**dir. Bu ölçek sıfırsa mevcut en büyük seviyeye bakılır.
Kullanılan eşik sonuçta ve CSV’de yazılır. Çok farklı debi seviyeleri veya uzun
bekleme içeren testlerde otomatik eşiği kapatıp fiziksel bir alt sınır girin.
Debi seçilmezse akış olmayan sabit basınç bölümleri de kararlı bulunabilir;
uygulama bunu sonuçta belirtir.

## Elle inceleme ve hesap

Yeşil bölgenin uçlarını sürükleyin veya başlangıç/bitiş kutularını değiştirin.
Eski sayısal sonuç hemen kaldırılır. **Elle Aralığı Hesapla** ile seçtiğiniz
aralığın özgün örnekleri arka planda okunur. Elle sonuç **otomatik kararlılık
doğrulaması içermez**; bu durum açıkça belirtilir. Veri/zaman boşluğu içeren
elle aralık hesaplanmaz; daha dar, ortak bir bölüm seçin.

**Seçili Otomatik Aralığa Dön** tablodaki otomatik sonuca döner. CSV, tüm
otomatik aralıkları ve varsa son hesaplanan elle aralığı içerir. Negatif Δp
mutlak değere çevrilmez; roller/birimler/basınç referansı/akış yönü kontrolü
için mesaj gösterilir.

Grafikte sağ sürükleme mevcut ölçekleme davranışını kullanır; **Ctrl + sağ tık**
seçili aralığa sığdırma ve tüm aramayı gösterme menüsünü açar.

## Zaman, kalibrasyon ve büyük veri

- TDMS zaman bilgisi veya kanal bazlı Manuel Fs kullanılır. Fs bilinmiyorsa hesap
  yapılmaz. 1 Hz gibi düşük hızlarda en az üç örnek sağlayacak pencere seçin.
- Saniye ve UTC zaman türleri karıştırılmaz. UTC kayıtları grafikte ve kutularda
  ortak kayıt başlangıcına göre saniye olarak gösterilir; UTC başlangıcı ayrıca yazılır.
- Farklı dosyalarda başlangıçların gerçekten aynı deneye ait olduğunu kontrol edin.
  **Ortak test süresi varsayımı** açıksa analiz bu zaman eksenini kullanır ve bunu belirtir.
- Grafik yumuşatması, görünürlük ve görsel X/Y kaydırmaları analizin değerlerini
  değiştirmez. Kalibrasyon gerekiyorsa **Hesaplanan Kanal** ile fiziksel birime
  dönüştürüp bu kanalı seçebilirsiniz.
- Büyük/lazy kanalların azaltılmış önizlemesi hesapta kullanılmaz; TDMS’deki özgün
  örnekler mevcut bayt aralığı okuma altyapısıyla okunur. Bellek kullanımını sınırlamak
  için tam veri kopyası oluşturulmaz; pencere özetleri tutulur. Grafikte yalnızca
  pikleri koruyan önizleme kullanılır.
- Analiz kullanıcı düğmeye bastığında başlar, arka planda çalışır ve **Durdur** ile
  iptal edilebilir. Kanal/zaman/birim/ayar değişirse eski iş ve sonuç iptal edilir.
- En çok 200.000 pencere ve 5.000 sonuç aralığı desteklenir; sınır aşılırsa aramayı
  daraltma veya pencereyi/süreyi artırma önerilir. Sessiz veri kesme yapılmaz.
- Sonuçlar `.tdmsproj` içinde saklanmaz. CSV raporu ayarları, kanal adlarını,
  birimleri, Fs bilgilerini ve tüm sonuçları içerir; UTF-8 BOM, noktalı virgül ve
  ondalık virgül kullanır. Kaynak dosya üzerine yazılmaz; kayıt atomiktir.

## Çalıştırma

ZIP’in tamamını çıkarın. Mevcut bağımlılıklar yüklüyse PyCharm’da
`tdmsreader.py` dosyasını çalıştırın; ek bağımlılık gerekmez.
Demo yeniden üretimi: `python examples/create_steady_demo.py`.
Sayısal ve arayüz testleri: `python -m pytest -q`.
