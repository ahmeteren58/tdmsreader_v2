# Channel Alignment / Synchronization — 2.6.0

Bu özellik, kanalların **zaman koordinatına sabit bir ofset** ekler:

**t_corrected = t_original + alignment_offset**

Pozitif ofset kanalı sağa, negatif ofset sola taşır. TDMS dosyasına yazılmaz;
kaynak zaman dizisi, sinyal değerleri, örnek sayısı ve sırası değiştirilmez.
Fs değişikliği, clock drift düzeltmesi veya veri başından/sonundan örnek silme yapılmaz.

## Başlangıç

1. TDMS dosyasını açın, kanalları seçip **Seçili Kanalları Çiz** düğmesine basın.
2. **Channel Alignment** sekmesini açın.
3. Manuel ofset girin veya bir yöntemle ofset **önerisi** hesaplayın.
4. Ana grafikte sonucu kontrol edin. Gerekirse **Reset Channel Alignment** ya da
   **Reset All Alignments** kullanın.

Sync, Synch, Synchronization ve Trigger adları özel işlem görmez. Referansı
kullanıcı seçer; program otomatik referans veya otomatik alignment uygulamaz.

## Manuel ofset

Tablodan bir veya daha fazla kanal satırı seçin (Ctrl / Shift). Ofseti **ms**
veya **s** biriminde girip **Seçililere Uygula** düğmesine basın. Değer, her seçili
kanalın **yeni toplam alignment ofseti** olur; önceki ofsete eklenmez.
Her kanala farklı ofset vermek için kanalları tek tek seçin.

| Kanal | Girilen ofset | Sonuç |
| --- | ---: | --- |
| P_Inlet | 0 ms | Aynı zaman konumu |
| P_Outlet | +0,4 ms | 0,0004 s sağa |
| Flow | −1,2 ms | 0,0012 s sola |

Birimi değiştirmek fiziksel ofseti değiştirmez: 1,4 ms = 0,0014 s.
İndeks eksenine ms uygulanmaz; önce **Manuel Fs** sekmesinden zaman ekseni oluşturun.
Sonradan indeks moduna dönülen kanalın ofseti saklanır ancak çizimde uygulanmaz;
Reset bu durumda da çalışır.

## Reference Channel + Edge Alignment

1. **Reference Channel** ve **Target Channel** seçin.
2. **Method → Edge Alignment** ve **Rising Edge / Falling Edge** seçin.
3. Analiz başlangıcı ve bitişini ayarlayın. **Görünen Aralığı Al** ana grafiğin
   o andaki X aralığını kutulara aktarır. İlk varsayılan aralık en fazla 10 saniyedir.
4. **Estimate** düğmesine basın.
5. Öneriyi kontrol edin; **Apply Alignment** ile yalnız hedef kanala uygulayın.

Yöntem, seçili aralıktaki **ilk 0→1 veya 1→0 kenarını**, azaltılmış grafik
önizlemesi yerine özgün örneklerden bulur. Kenar zamanı, geçişin görüldüğü
ilk örneğin zamanıdır; örnekler arasında yapay kesinlik üretilmez. Aralık
başındaki kenar, varsa hemen önceki gerçek örnekle doğrulanır. Dosyanın ilk
örneğinin 1 olması tek başına rising edge sayılmaz.

**offset = t_reference_edge − t_target_edge**

Örnek: referans kenar 1,0000 s, hedef kenar 1,0014 s ise hedef ofseti
**−1,4 ms** olur. Hedefteki olay daha geç görüldüğü için sola kaydırılır.
Referansın mevcut alignment ofseti de hesaba katılır. Öneri hedefin yeni toplam
ofsetidir; tekrar Estimate/Apply yapınca ofset birikmez.

Birden fazla kenar varsa sayıları gösterilir ve ilk kenarların kullanıldığı
belirtilir. Yanlış çevrimleri eşleştirmemek için aralığı tek bir ortak olaya daraltın.
Bu sürüm pulse filtering / debounce uygulamaz; Vana Analizi filtresini kullanmaz.
NaN veya büyük zaman boşluğu üzerinden kenar üretilmez. Tamamen 0/1 sabit kanalda
veya uygun kenar yoksa **No valid rising/falling edge found in selected channel.**
mesajı gösterilir. 0/1 olmayan kanalda bu yöntem kullanılmaz.

## Analog Cross-Correlation

1. Aynı olayı temsil eden iki kanalı ve **Cross-Correlation** yöntemini seçin.
2. Analiz aralığını, belirgin ortak değişimleri içerecek şekilde daraltın.
3. **Arama: ±** alanına izin verdiğiniz kaymayı ms olarak girin (ör. 50 ms).
4. **Estimate** ile ofseti, korelasyon skorunu ve analiz çözünürlüğünü görün.
5. Uygun olduğuna karar verirseniz **Apply Alignment** kullanın.

Korelasyon, seçilen aralık ile iki kanalın ortak zaman kapsamını kullanır.
Farklı Fs’ler için yalnız analiz sırasında geçici ortak grid oluşturulur.
Analog kanallarda lineer interpolasyon, dijital kanallarda **zero-order hold**
kullanılır. Dijital kenarlar rampaya dönüştürülmez. Grafikte resampling yapılmaz.

En fazla **32.768 grid noktası** kullanılır. Sadece gerekli örnekler/braketler
ve küçük komşu bloklar okunur; çok büyük bir kaydı sırf korelasyon için tam
boyutta yüklemez. Grid adımı, yavaş kanalın örnek aralığından daha küçük seçilmez.
Büyük zaman pencerelerinde grid kabalaşır; ince olaylarda aliasing olabilir.
Bu durumda daha dar bir analiz aralığı seçin. Analiz çözünürlüğü ayrıca gösterilir.

Her lag için örtüşen bölümde normalize Pearson korelasyonu hesaplanır.
Uygun iç tepede üç noktalı parabol ile ofset tahmini iyileştirilir; bu işlem
ek örnekleme hassasiyeti veya ölçüm belirsizliği garantisi değildir. Gösterilen
skor grid tepesindeki korelasyondur. Skor bir güven olasılığı değildir.

Sabit sinyal, ayırt edilemeyen düz rampa, yetersiz örnek, arama aralığına göre
çok kaba grid veya örneklenen bölgede NaN/zaman boşluğu varsa açık mesaj verilir.
Düşük skor, arama sınırındaki tepe ve birden fazla benzer tepe ayrıca belirtilir.
Periyodik sinyallerde farklı çevrimler aynı derecede iyi eşleşebilir.

**Korelasyon acquisition kayması ile gerçek fiziksel gecikmeyi ayıramaz.**
Örneğin valf komutundan sonra basıncın geç yükselmesi gerçek sistem cevabı
olabilir. Program bunu otomatik olarak düzeltmez. Ofset önerisi yalnız kullanıcı
Apply dediğinde hedef kanala yazılır.

## Mevcut görsel X Δ ile ilişki

Alignment ayrı bir `ChannelAlignmentManager` state’inde tutulur. Eski X/Y
kaydırma alanları, stiller ve kaynak diziler değişmez. Ana grafikte:

**display_time = original_time + alignment_offset + mevcut görsel X Δ**

Tabloda alignment ve görsel X Δ ayrı sütunlardadır. Edge/korelasyon tahmini,
eski görsel X Δ veya Y Δ kaydırmalarını kullanmaz; alignment state’ini dikkate alır.
Eski görsel X Δ değeriniz varsa ana grafiğin görünür aralığını seçerken bunu
dikkate alın. Reset Alignment yalnız alignment’ı sıfırlar; eski görsel kaydırmayı
korur. Stil sıfırlama da alignment’ı değiştirmez.

Overlay, Stacked ve ayrılmış grafik aynı ofseti kullanır. Apply/Reset mevcut
eğrileri ve filtre sonucunu tekrar kullanır; filtre işi yeniden koşturulmaz.
Zoom/pan, pik koruma, görünür pencere okuma ve cache altyapısı korunur.
Ham koordinata geri dönüşte lazy okuma aralığından ofset çıkarılır.

## Analizlerin kapsamı

| Araç | Alignment uygulanınca |
| --- | --- |
| Ana grafik / Stacked / ayrılmış grafik | Zaman koordinatı kayar |
| A/B ölçümü ve Aralık Analizi | Grafikteki düzeltilmiş koordinatı kullanır; eski aralık sonuçları temizlenir |
| Vana Analizi / valve timing / fake pulse filter | Değişmez; özgün zamanlarla çalışır |
| Basınç Kaybı otomasyonu | Önceki gibi özgün zamanlarla çalışır |
| FFT / Hesaplanan Kanal | Önceki kaynak zaman ve değer davranışını korur |

Bu sürümün amacı zaman koordinatını kullanıcı denetiminde hizalamaktır;
diğer analizlerin fiziksel zaman tanımını sessizce değiştirmez.

## CSV Export

CSV penceresine **Export aligned timestamps** seçeneği eklendi. Varsayılanı kapalıdır.

| Seçenekler | Aktarılan zaman |
| --- | --- |
| İki seçenek de kapalı | Etkin metadata / Manuel Fs zamanı |
| Yalnız Export aligned timestamps açık | Kaynak zamanı + alignment |
| Yalnız eski X/Y kaydırması açık | Önceki gibi kaynak zamanı + görsel X Δ |
| İkisi de açık | Kaynak zamanı + alignment + görsel X Δ |

Alignment, Y değerlerini değiştirmez. Eski X/Y kaydırma seçeneği açık ise
önceki gibi görsel Y Δ da aktarılır. Yan yana/uzun tablo düzeni, sayı biçimi,
tam çözünürlük ve atomik kayıt korunur. **Görünen X aralığı** seçimi daima
grafikte görülen düzeltilmiş koordinata göre örnek seçer; çıktı zamanının
orijinal/hizalanmış olması ayrı bir karardır. Kaynak TDMS üzerine yazılamaz.

## Kayıt, Reset ve zaman bilgisi

- Ofsetler saniye cinsinden ve kanalların mevcut benzersiz kimliğiyle tutulur.
- `.tdmsproj` kaydı ofsetleri de içerir. Eski projeler sıfır alignment ile açılır.
- Uygulamayı proje kaydetmeden kapatırsanız alignment state’i saklanmaz.
- Reset Channel seçili tablo satırlarını; Reset All tüm alignment state’ini sıfırlar.
- UTC veride kutular okunabilir bir kökene göre saniyedir; UTC kökeni açıklamada yazılır.
  Farklı zaman türleri (saniye / UTC / indeks) tahminde karıştırılmaz.
- Kanal, Fs, zaman ekseni, analiz aralığı veya alignment değiştiğinde eski tahmin
  iptal edilir; eski sonuç sonradan Apply edilemez. Arka plan işi **Durdur** ile iptal edilebilir.

## Demo ve çalıştırma

`examples/channel_alignment_demo.tdms` sentetik acquisition kaymaları içerir:

| Referans | Hedef | Yöntem | Beklenen hedef ofseti |
| --- | --- | --- | ---: |
| AnalogReference (5 kHz) | AnalogDelayed (7 kHz) | Korelasyon, 0,1–2,9 s, ±50 ms | Yaklaşık −2,2 ms |
| Sync (10 kHz) | DigitalDelayed (10 kHz) | Rising / Falling, ilk ortak kenar | −1,4 ms |
| SyncZero | DigitalDelayed | Edge | Kenar bulunamadı mesajı |

Bu dosya gerçek deney verisi değildir. Kanal adları otomatik seçilmez.
Demo üretimi: `python examples/create_alignment_demo.py`.
ZIP’in tamamını çıkarıp mevcut ortamınızda `tdmsreader.py` çalıştırın.
Ek bağımlılık eklenmedi. Testler: `python -m pytest -q`.
