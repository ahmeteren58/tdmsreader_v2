"""Time-channel controls and small hooks; no changes to valve algorithms."""
from __future__ import annotations
import copy
from PyQt6.QtCore import Qt, QSignalBlocker
from PyQt6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,
                            QCheckBox,QPushButton,QTreeWidget,QTreeWidgetItem,QHeaderView,QLineEdit)
from tdms_io import open_tdms
from tdms_time_channels import TimeChannelResolver,clean_settings
from tdms_workspace import FunctionWorker
from tdms_presentation import page_header


class TimeChannelsMixin:
    def _init_time_channels(self):
        self.time_binding_settings={}
        self._time_catalog={}
        self._time_reports={}
        self._time_serial=0
        self.time_channels_tab=QWidget();layout=QVBoxLayout(self.time_channels_tab)
        layout.setContentsMargins(14,12,14,12)
        page_header(layout,'Zaman Kanalları',
            'Her modül kendi zaman kanalıyla eşleşir. Açık eşleşmeler otomatik, grup sırası önerileri kullanıcı onayıyla uygulanır. '
            'Birim etiketi yoksa seçili birim kullanılır; varsayılan saniyedir. Sabit veya düzensiz zamanlar bağlanmaz. '
            'Manuel Fs ve Ortak Süre ayarları önceliklidir. Bağlama, donanım senkronizasyonunu doğrulamaz.')
        row=QHBoxLayout();self.time_file=QComboBox();row.addWidget(QLabel('Dosya:'));row.addWidget(self.time_file,1)
        self.time_enabled=QCheckBox('Zaman kanalı kullan');self.time_enabled.setChecked(True);row.addWidget(self.time_enabled)
        self.time_unit=QComboBox()
        for label,value in [('s','s'),('ms','ms'),('µs','us'),('ns','ns')]:self.time_unit.addItem(label,value)
        row.addWidget(QLabel('Eksik birim:'));row.addWidget(self.time_unit);layout.addLayout(row)
        self.time_unit.setToolTip('Yalnız birim etiketi bulunmayan zaman kanallarında kullanılır. Geçerli birim etiketi önceliklidir.')
        self.time_search=QLineEdit();self.time_search.setPlaceholderText('Modül ara: RIO3, 9205…');self.time_search.setClearButtonEnabled(True)
        layout.addWidget(self.time_search)
        self.time_tree=QTreeWidget();self.time_tree.setRootIsDecorated(False);self.time_tree.setAlternatingRowColors(True)
        self.time_tree.setHeaderLabels(['Modül','Örnek sayısı','Zaman kanalı','Fs [Hz]','Başlangıç [ms]','Durum'])
        self.time_tree.header().setStretchLastSection(False)
        self.time_tree.header().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.time_tree.header().setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch)
        for i,width in enumerate((140,115,245,80,115,255)):self.time_tree.setColumnWidth(i,width)
        layout.addWidget(self.time_tree,1)
        buttons=QHBoxLayout();self.time_check=QPushButton('Denetle')
        self.time_check.setToolTip('Kaydedilmiş eşlemeleri denetler. Yeni kanal veya birim seçimini uygulamak için Eşlemeleri Uygula kullanın.')
        self.time_apply=QPushButton('Uygula');self.time_apply.setProperty('primary',True)
        self.time_reset=QPushButton('Bağlamayı Kapat')
        self.time_reset.setToolTip('Seçili dosyada Times bağlamasını kapatır; özgün TDMS / indeks yöntemine döner.')
        buttons.addWidget(self.time_check);buttons.addWidget(self.time_apply);buttons.addWidget(self.time_reset);buttons.addStretch()
        layout.addLayout(buttons)
        self.time_note=QLabel('Zaman eşlemesi için bir dosya açın.')
        self.time_note.setWordWrap(True);self.time_note.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.time_note)
        self.tabs.addTab(self.time_channels_tab,'Zaman Kanalları')
        self.time_file.currentIndexChanged.connect(self._time_refresh)
        self.time_search.textChanged.connect(self._time_filter)
        self.time_check.clicked.connect(lambda:self._time_scan(False))
        self.time_apply.clicked.connect(lambda:self._time_scan(True))
        self.time_reset.clicked.connect(self._time_reset_file)

    def _time_files_payload(self):
        return {fid:{'path':st.path,'label':st.label,'time_binding':copy.deepcopy(self.time_binding_settings.get(fid,clean_settings()))}
                for fid,st in self.files.items()}

    def _time_index_ready(self,payload):
        fid=payload['file_id']
        if fid not in self.files:return
        self._time_catalog[fid]=payload.get('time_catalog',{'rows':[],'clocks':[]})
        self._time_refresh_files(fid)

    def _time_refresh_files(self,preferred=None):
        if not hasattr(self,'time_file'):return
        old=preferred or self.time_file.currentData()
        with QSignalBlocker(self.time_file):
            self.time_file.clear()
            for fid,st in self.files.items():self.time_file.addItem(st.label,fid)
            self.time_file.setCurrentIndex(max(0,self.time_file.findData(old)))
        self._time_refresh()

    def _time_refresh(self,*_):
        if not hasattr(self,'time_tree'):return
        fid=self.time_file.currentData();settings=clean_settings(self.time_binding_settings.get(fid))
        self.time_enabled.setChecked(settings['enabled']);self.time_unit.setCurrentIndex(self.time_unit.findData(settings['unit']))
        self.time_tree.clear();catalog=self._time_catalog.get(fid,{})
        reports={r['group']:r for r in self._time_reports.get(fid,[])}
        choices=catalog.get('clocks',[])
        for row in catalog.get('rows',[]):
            if not row.get('lengths'):continue
            group=row['group'];r=reports.get(group,{});h=r.get('health',{})
            target=row.get('target');explicit=settings['bindings'].get(group,'auto')
            item=QTreeWidgetItem([group,', '.join(str(x) for x in row['lengths']),'',
                f"{h['fs']:.8g}" if h.get('valid') else '—',f"{h['base']*1000:+.6f}" if h.get('valid') else '—',''])
            item.setData(0,Qt.ItemDataRole.UserRole,dict(row));self.time_tree.addTopLevelItem(item)
            item.setToolTip(1,item.text(1))
            combo=QComboBox();combo.setMinimumWidth(0)
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            combo.setMinimumContentsLength(0)
            combo.addItem(('Otomatik: '+target[1]) if row['automatic'] and target else
                          ('Öneri: '+target[1]+' (onay)') if target else 'Eşlenmemiş','auto')
            combo.addItem('Bağlama / eski zaman yöntemi',None)
            for pair in choices:combo.addItem(' / '.join(pair),list(pair))
            if explicit is None:combo.setCurrentIndex(1)
            elif explicit!='auto':combo.setCurrentIndex(max(0,combo.findData([explicit['group'],explicit['channel']])))
            combo.setToolTip('Örnek sayısı tek başına doğru modül eşleşmesini kanıtlamaz. Grup sırası önerilerini kontrol edin.')
            self.time_tree.setItemWidget(item,2,combo)
            if h and not h.get('valid'):text=h.get('reason','Geçersiz zaman')
            elif not settings['enabled']:text='Kapalı / eski zaman yöntemi'
            elif explicit is None:text='Bu grup için kapalı'
            elif r.get('active') and h.get('valid'):text='Bağlı · '+('Kullanıcı seçimi' if explicit!='auto' else row['method'])
            elif target and not row['automatic'] and explicit=='auto':text='Öneri — onay bekliyor'
            else:text='Denetim / çizim sırasında doğrulanır'
            if h.get('assumed_unit'):text+=' · birim: '+h['unit']+' (varsayım)'
            if h and not h.get('valid'):
                short='Örnek sayısı farklı' if 'örnek sayı' in text.lower() else 'Geçersiz zaman';status='invalid'
            elif not settings['enabled'] or explicit is None:short='Kapalı';status='off'
            elif r.get('active') and h.get('valid'):short='Bağlı';status='linked'
            elif target and not row['automatic'] and explicit=='auto':short='Onay bekliyor';status='pending'
            else:short='Denetlenmedi';status='off'
            item.setText(5,short);item.setToolTip(5,text)
            item.setData(5,Qt.ItemDataRole.UserRole,status)
            if target:combo.setToolTip(combo.toolTip()+'\nÖneri: '+' / '.join(target))
        for b in (self.time_check,self.time_apply,self.time_reset):b.setEnabled(fid in self.files)
        if fid in self.files:
            bound=sum(bool(r.get('active') and r.get('health',{}).get('valid')) for r in reports.values())
            pending=sum(bool(r.get('target') and r.get('health',{}).get('valid') and not r.get('automatic') and not r.get('explicit')) for r in reports.values())
            self.time_note.setText(f'{bound} modül bağlı · {pending} öneri onay bekliyor' if pending else f'{bound} modül bağlı')
        else:
            self.time_note.setText('Zaman eşlemesi için bir dosya açın.')
        self._time_filter()
        if hasattr(self,'_time_status_theme'):self._time_status_theme()

    def _time_filter(self,*_):
        term=self.time_search.text().strip().casefold()
        for i in range(self.time_tree.topLevelItemCount()):
            item=self.time_tree.topLevelItem(i);item.setHidden(term not in item.text(0).casefold())

    def _time_selected_settings(self):
        settings={'enabled':self.time_enabled.isChecked(),'unit':self.time_unit.currentData(),'bindings':{}}
        for i in range(self.time_tree.topLevelItemCount()):
            item=self.time_tree.topLevelItem(i);row=item.data(0,Qt.ItemDataRole.UserRole)
            choice=self.time_tree.itemWidget(item,2).currentData()
            if choice=='auto':
                if row.get('target') and not row['automatic']:
                    settings['bindings'][row['group']]={'group':row['target'][0],'channel':row['target'][1]}
            elif choice is None:settings['bindings'][row['group']]=None
            else:settings['bindings'][row['group']]={'group':choice[0],'channel':choice[1]}
        return clean_settings(settings)

    def _time_scan(self,apply=False,settings=None):
        fid=self.time_file.currentData()
        if fid not in self.files:return
        # Scan uses the configured choices; Apply also accepts visible proposals.
        settings=clean_settings(settings if settings is not None else self._time_selected_settings() if apply
                                else self.time_binding_settings.get(fid))
        previous=copy.deepcopy(self.time_binding_settings.get(fid,clean_settings()))
        if apply:
            self.time_binding_settings[fid]=settings
            self._cancel_jobs(['load','preview','lazy_view','filter'])
            self._preview_cache.clear()
        path=self.files[fid].path;self._time_serial+=1;serial=self._time_serial
        current=[dict(s) for s in self.current_series or [] if s.get('file_id')==fid and not s.get('is_virtual')]
        self.time_note.setText('Zaman kanalları arka planda denetleniyor…');self.time_apply.setEnabled(False)
        def work(cancelled):
            with open_tdms(path) as tdms:
                resolver=TimeChannelResolver(tdms,path,settings,cancelled)
                reports=resolver.reports();bindings={}
                for s in current:
                    # A native waveform time source keeps its precedence.
                    props={'wf_increment':1.} if s.get('native_time',{}).get('waveform') else {}
                    _,info=resolver.bind(s['group'],s['channel'],props)
                    bindings[s['style_key']]=info
                return {'reports':reports,'bindings':bindings,'catalog':{'rows':resolver.rows,'clocks':list(resolver.clocks)}}
        def ready(payload):
            if payload.get('cancelled') or fid not in self.files or serial!=self._time_serial:return
            self._time_reports[fid]=payload['reports'];self._time_catalog[fid]=payload['catalog']
            if apply:
                for s in self.current_series or []:
                    if s.get('style_key') not in payload['bindings']:continue
                    info=payload['bindings'][s['style_key']];native=s.get('native_time')
                    if native is None:continue
                    s['time_channel_binding']=info
                    if info and info.get('applied'):
                        h=info['health'];s.update(source_x_mode='seconds',source_x_base=h['base'],source_x_inc=h['inc'],source_fs_est=h['fs'])
                    else:s.update(source_x_mode=native['mode'],source_x_base=native['base'],source_x_inc=native['inc'],source_fs_est=native['fs'])
                self._apply_channel_timing();self._refresh_series_comboboxes()
                if self.current_series:self.update_plot_data_with_filter()
            self._time_refresh()
            if apply and self.current_series:
                note=[]
                if self.chk_common_duration.isChecked():note.append('Ortak Süre açık: Times yerine süre varsayımı kullanılıyor.')
                if self.channel_fs_overrides:note.append('Elle Fs etkin. Times hızını kullanmak için Kanal Yöneticisi’nden kaldırın.')
                if any(s.get('is_virtual') for s in self.current_series):note.append('Zamanı değişen kaynaklara bağlı hesaplanan kanalları yeniden oluşturun.')
                if self.alignment_manager.snapshot():note.append('Eski projedeki elle ofsetler korunuyor; aşağıdaki bilgiyi kontrol edin.')
                if note:self.time_note.setText(self.time_note.text()+'\n'+' '.join(note))
        worker=FunctionWorker(work)
        def failed(message):
            if serial!=self._time_serial or fid not in self.files:return
            if apply:self.time_binding_settings[fid]=previous
            self._time_refresh()
            self.time_note.setText('Zaman bağlama tamamlanamadı; mevcut grafik zamanı korundu. '+message)
        self._start_job(worker,ready,on_failed=failed,tag='time_binding',cancel_tags=['time_binding'])

    def _time_reset_file(self):
        self._time_scan(True,{'enabled':False,'unit':'s','bindings':{}})

    def _time_loaded_reports(self,payload):
        for fid,data in payload.get('time_bindings',{}).items():
            if fid not in self.files:continue
            self._time_reports[fid]=data['reports'];self._time_catalog[fid]=data['catalog']
        self._time_refresh_files()

    def _time_plot_notices(self):
        notices=[];pending=set();invalid=set();assumed=False;overridden=0
        for s in self.current_series or []:
            if s.get('is_virtual'):continue
            info=s.get('time_channel_binding') or {}
            if info.get('applied'):
                assumed=assumed or info['health'].get('assumed_unit',False)
                overridden+=int(s.get('effective_fs_source') in ('channel_manual','common_duration'))
            elif info:
                invalid.add(s.get('group',''))
            elif s.get('x_mode')=='index':
                rows=self._time_catalog.get(s.get('file_id'),{}).get('rows',[])
                if any(r['group']==s.get('group') and r.get('target') and not r.get('automatic') for r in rows):
                    pending.add(s.get('group',''))
        if pending:notices.append(f'{len(pending)} modülün zaman eşlemesi onay bekliyor. Zaman Kanalları’nı kontrol edin.')
        if invalid:notices.append(f'{len(invalid)} modülde zaman verisi geçersiz veya uzunluğu farklı.')
        if assumed:notices.append('Zaman birimi dosyada yok; seçili birim kullanılıyor.')
        if overridden:notices.append(f'{overridden} Times eşlemeli kanalda Manuel Fs / Ortak Süre öncelikli. Times hızını kullanmak için ilgili varsayımı kaldırın.')
        legacy=self.alignment_manager.snapshot()
        if legacy:notices.append(f'Eski projeden {len(legacy)} elle zaman ofseti etkin. Zaman Kanalları’ndan kontrol edin.')
        return notices

    def _project_manifest(self,path):
        manifest,arrays=super()._project_manifest(path)
        for r in manifest['files']:r['time_binding']=copy.deepcopy(self.time_binding_settings.get(r['id'],clean_settings()))
        return manifest,arrays

    def _apply_project(self,payload):
        # Validate before super() changes any visible project state.
        settings={r['id']:clean_settings(r.get('time_binding',{'enabled':False})) for r in payload['manifest']['files']}
        self._validate_project_ui(payload['manifest'])
        self.time_binding_settings=settings;self._time_catalog={};self._time_reports={};self._time_serial+=1
        super()._apply_project(payload)
        self._time_loaded_reports(payload)
