# TDMSReader Pro 2.3.0 — Fs davranışı ve teşhis

Bu not, uygulamanın kullandığı zaman politikasını açıklar. Gerçek cihaz kaydı paylaşılmadığı için cihazın fiziksel örnekleme hızını doğrulamaz; yalnızca dosyada kaydedilen örnekler ve geçerli TDMS metadatası üzerinden yazılım davranışını tanımlar.

## Uygulamadaki tek zaman politikası

Her kanal için sıra şöyledir:

1. Kanalın kendi pozitif manuel Fs ataması varsa `x[i] = x0 + i/Fs`.
2. Manuel atama yoksa kanalın kendi `wf_increment` değeri kullanılır; `Fs = 1/wf_increment`.
3. Geçerli metadata da yoksa `x[i] = i` örnek indeksi kullanılır ve Fs bilinmiyor gösterilir.

Başka kanalın Fs'si, örnek sayısı, kayıt süresi veya X dizisi bu karara katılmaz. Uygulama başka bir Time kanalını otomatik eşlemez. `wf_start_time` ve `wf_start_offset` varsa başlangıç korunur; bunlar örnek aralığını değiştirmez. Metadata içindeki rastgele `Fs` adındaki özel özellik otomatik olarak waveform zamanı sayılmaz.

Grafik, FFT, A/B, aralık analizi ve CSV aynı etkin kanal zamanını kullanır. Manuel Fs değiştiğinde eski işaretler, A/B konumları ve FFT sonucu temizlenir; yeni grafikte yeniden ölçüm yapılmalıdır.

## 5 kHz ile 500 Hz arasındaki fark

Sabit hızda aynı kanal için iki özgün örnek arasındaki süre:

`Δt = (i₂ - i₁) / Fs`

| Örnek aralığı | 5 kHz | 500 Hz |
| ---: | ---: | ---: |
| 1 örnek | 0,2 ms | 2 ms |
| 200 örnek | 40 ms | 400 ms |
| 5001 örneğin ilk-son aralığı | 1 s | 10 s |

Bu nedenle 500 Hz seçildiğinde 10 kat daha uzun süre görülmesi beklenir. Mekanik olayın beklenen süresi, cihazın dosyaya kaydettiği etkin Fs için tek başına kanıt değildir. DAQ 5 kHz'de örnek alıp dosyaya her 10. örneği yazmış olabilir; vana kanalı basınç kanalından farklı hızda olabilir; kayıt sırasında blok kaybı/decimation uygulanmış olabilir. Bunlar gerçek dosya incelenmeden birbirinden ayrılamaz.

## Dosyada bağımsız kontrol

`fs_teshis.py` salt okunur çalışır ve her kanalın örnek sayısını, `wf_increment`, `wf_start_time`, `wf_start_offset` ve ilk/son zaman bilgisini raporlar:

```powershell
.\.venv\Scripts\python.exe .\fs_teshis.py "C:\Veri\test.tdms" --report fs_raporu.txt
```

Kanal ve zaman dizisi adları biliniyorsa:

```powershell
.\.venv\Scripts\python.exe .\fs_teshis.py "C:\Veri\test.tdms" --group "AI" --channel "OPT-1" --time-group "AI" --time-channel "Time" --time-unit s --report fs_raporu.txt
```

Gerçek zaman dizisi saniye cinsinden `0, 0.0002, 0.0004…` ise 5 kHz; `0, 0.002, 0.004…` ise 500 Hz aralığına karşılık gelir. Zaman dizisinin başka kanala fiziksel olarak bire bir ait olduğu ayrıca kontrol edilmelidir. Eşit örnek sayısı tek başına eşleşme kanıtı değildir.

A/B tablosu hücre ipuçlarında görünen özgün örnek indeksleriyle etkin aralık Fs'si hesaplanabilir. Örneğin 200 örnekte 0,4 s görülen bir olayın etkin hızı 500 Hz'dir; 5 kHz varsayımıyla aynı indeks aralığı 0,04 s olur.

## Veri Kalitesi paneli neyi gösterir?

Panel, yüklenen değerlerin sayısal durumunu denetler: NaN/Inf sayısı, geçersiz örnek yüzdesi, kaynak veri türü, örnek sayısı, birim, etkin Fs ve Fs kaynağı. Büyük kanallar bloklar halinde tam kayıt üzerinden taranır. Bu sonuçlar sensörün fiziksel doğruluğunu, cihaz saatini veya kaydedilmemiş örnekleri doğrulamaz; veriyi değiştirmez.

Panelde `5000 Hz · Kanal manuel` yazması, 5000 Hz değerinin kullanıcı tarafından uygulandığını belirtir. `5000 Hz · TDMS metadata` dosyadaki `wf_increment` bilgisini gösterir. `Bilinmiyor / indeks` durumda saniye ölçeği iddia edilmez.

## Eski projeler

2.2.x projeleri açılırken eski referans/ortak süre ve ayrı FFT Fs alanları okunmaz. Kaynak kanallardaki manuel atamalar korunur, eski ölçüm koordinatları temizlenir. Eski hesaplanan kanalların sonuçları indeks eksenine alınır; güvenilir yeni Fs biliniyorsa kanala ayrıca atayın veya kanalı yeniden oluşturun. Yeni proje biçimi v2 yalnız manuel/metadata politikasını içerir.

## Sınırlar

Gerçek kullanıcı TDMS dosyası ve cihaz yapılandırması olmadan yazılımın dosyaya yazılmış etkin hızı 5 kHz diye onaylanamaz. `time_track()` ve `wf_increment` de TDMS metadata'sını okur; yanlış metadata'yı bağımsız doğrulayamaz. Min/maks önizleme gösterim içindir, örnekleri silmez; CSV ve A/B tam özgün örnekleri kullanır.
