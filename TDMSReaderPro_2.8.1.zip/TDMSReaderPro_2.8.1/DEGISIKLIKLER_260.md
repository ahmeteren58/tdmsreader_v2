# 2.6.0 — Channel Alignment / Synchronization

Yeni modüller:
- `tdms_alignment.py`: ayrı ChannelAlignmentManager state’i, tam örnek kenar
  taraması, sınırlı grid/okuma ile korelasyon; TDMS veya kaynak dizi yazımı yok.
- `tdms_alignment_ui.py`: manuel çoklu seçim, ms/s, Estimate → Apply, Reset,
  kaynak/zaman değişiminde tahmin iptali; mevcut arka plan işlerini kullanır.

Mevcut dosyalardaki küçük entegrasyonlar:
- `tdmsreader.py`: sekme/state oluşturma; yalnız çizim koordinatına ofset;
  lazy görünür pencerenin ham zaman aralığına dönüştürülmesi; CSV snapshot metadata’sı.
- `tdms_workspace.py`: hizalanmış grafikte A/B koordinatları; arayüz yenileme;
  `.tdmsproj` içinde alignment state’ini doğrulama/kayıt/geri yükleme.
- `tdms_export.py`: varsayılanı kapalı `export_aligned` seçeneği; zaman sütununa
  ofset ekleme; görünür aralık seçiminin grafiğe göre çalışması.
- `tdms_ui.py`: mevcut CSV penceresinde bağımsız aligned timestamp seçeneği.

Ekler:
- `tests/test_alignment.py`: bilinen ofsetler, farklı Fs, UTC, CSV, GUI,
  lazy zoom/reset, proje ve kaynak veri bütünlüğü kontrolleri.
- `examples/create_alignment_demo.py` ve `examples/channel_alignment_demo.tdms`.
- `CHANNEL_ALIGNMENT_TR.md`, `TEST_260.txt`, güncel README ve ekran örnekleri.

Değiştirilmeyen kritik modüller önceki 2.5.5 sürümüyle byte düzeyinde karşılaştırıldı:
`tdms_valve.py`, `tdms_valve_auto.py`, `tdms_valve_controls.py`,
`tdms_valve_rules.py`, `tdms_valve_ui.py`, `tdms_io.py`, `tdms_viewport.py`,
`tdms_jobs.py`, `tdms_numeric.py`, `tdms_project.py`, `tdms_steady.py`, `tdms_steady_ui.py`.

Vana Analizi algoritmaları, timing ve fake pulse filtresi değişmedi.
Yükleyici/downsampling motoru yeniden yazılmadı. Yeni bağımlılık yok.
