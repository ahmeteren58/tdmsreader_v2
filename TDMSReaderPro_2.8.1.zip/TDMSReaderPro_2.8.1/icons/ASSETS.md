# İkon kaynakları

- `app_icon.png`: Kullanıcının gönderdiği ana uygulama görselinin değiştirilmemiş kopyası.
- `light/*.svg`, `dark/*.svg`: Bu güncelleme için kodla çizilmiş yeni vektör araç ikonları. Üçüncü taraf ikon seti kullanılmadı. Yeni SVG çizimlerini bu uygulamada değiştirebilir ve yeniden kullanabilirsiniz.
- Mevcut uygulamanın ve kullanıcının sağladığı görselin lisansı bu güncellemeyle değiştirilmez. Bağımlılıkların kendi lisansları geçerlidir.

2.2.0: `project.svg` ve `quality.svg` açık/koyu varyantları aynı özgün vektör ailesine eklendi. Üçüncü taraf ikon alınmadı.

2.8.0: chart, channels, clock, valve, gauge, statistics, wave, formula, info, check, refresh, reset, clear, stop ve primary action ikonları uygulama için özgün SVG olarak çizildi. Açık/koyu tema varyantları yereldir; ek bağımlılık veya ağ bağlantısı gerekmez.

2.8.1: close ve dash_white ikonları aynı özgün vektör ailesine eklendi (açık/koyu). Üçüncü taraf ikon alınmadı.
