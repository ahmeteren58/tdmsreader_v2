"""Valve setup: connection type, channel roles and input conditioning."""
from PyQt6.QtCore import Qt, QSignalBlocker
from PyQt6.QtWidgets import (QWidget, QGridLayout, QLabel, QComboBox, QCheckBox,
                             QDoubleSpinBox, QGroupBox, QToolButton)
from tdms_valve_rules import MODES, ROLES, ValveOptions, SignalOptions


def _setting_bool(value, default):
    if value is None:
        return default
    return str(value).lower() in ('1', 'true', 'yes')


class ValveSettingsMixin:
    def _valve_build_controls(self, root):
        box = QGroupBox('1 · Bağlantı ve kanallar')
        grid = QGridLayout(box)
        grid.setContentsMargins(12, 18, 12, 10); grid.setHorizontalSpacing(8); grid.setVerticalSpacing(6)
        self.valve_mode = QComboBox()
        for key, (label, _) in MODES.items():
            self.valve_mode.addItem(label, key)
        self.valve_mode.setToolTip('Kayıttaki iki sinyalin ne olduğunu seçin. Açılma ve kapanmanın hangi kenarlar arasında ölçüleceğini belirler.')
        grid.addWidget(QLabel('Bağlantı türü:'), 0, 0)
        grid.addWidget(self.valve_mode, 0, 1, 1, 3)
        self.valve_rule = QLabel(); self.valve_rule.setWordWrap(True); self.valve_rule.setProperty('valveHint', True)
        grid.addWidget(self.valve_rule, 1, 1, 1, 3)
        self.valve_open, self.valve_closed = QComboBox(), QComboBox()
        self.valve_channel_labels = [QLabel(), QLabel()]
        polarities = []
        for j, combo in enumerate((self.valve_open, self.valve_closed)):
            combo.setMinimumContentsLength(18)
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            combo.currentIndexChanged.connect(self._valve_selection_changed)
            polarity = QComboBox()
            polarity.addItem('Normal (1 = aktif)', False); polarity.addItem('Ters (0 = aktif)', True)
            polarity.setToolTip('Aktif: sensör konumu algılıyor veya açma komutu verilmiş. '
                                'Normalde kapalı kontak / pull-up bağlantısında sinyal tersidir.')
            polarity.currentIndexChanged.connect(self._valve_settings_changed)
            polarities.append(polarity)
            grid.addWidget(self.valve_channel_labels[j], 2+j, 0)
            grid.addWidget(combo, 2+j, 1)
            grid.addWidget(polarity, 2+j, 2)
        self.valve_swap = QToolButton(); self.valve_swap.setText('⇅ A ↔ B')
        self.valve_swap.setToolTip('İki kanalın rollerini ve kanal ayarlarını yer değiştir.')
        self.valve_swap.clicked.connect(self._valve_swap_channels)
        grid.addWidget(self.valve_swap, 2, 3, 2, 1)
        grid.setColumnStretch(1, 1)
        self.valve_custom = QWidget(); custom = QGridLayout(self.valve_custom); custom.setContentsMargins(0, 0, 0, 0)
        self.valve_custom_rules = []
        for row, (label, default) in enumerate((('Açılma', (0, 0, 1, 1)), ('Kapanma', (1, 0, 0, 1)))):
            custom.addWidget(QLabel(label+':'), row, 0)
            boxes = []
            for col in range(4):
                combo = QComboBox()
                if col % 2 == 0:
                    combo.addItem('A', 0); combo.addItem('B', 1)
                else:
                    combo.addItem('0→1', 'rise'); combo.addItem('1→0', 'fall')
                combo.setCurrentIndex(default[col]); combo.currentIndexChanged.connect(self._valve_settings_changed)
                boxes.append(combo); custom.addWidget(combo, row, col+1 if col < 2 else col+2)
            custom.addWidget(QLabel('→'), row, 3); self.valve_custom_rules.append(boxes)
        custom.setColumnStretch(6, 1)
        grid.addWidget(self.valve_custom, 4, 1, 1, 3)
        self.valve_auto = QCheckBox('Giriş türünü, eşikleri ve parazit filtresini veriden belirle (önerilen)')
        self.valve_auto.setToolTip('0/1 veya analog seviyeler, histerezis eşikleri ve kontak sıçramasını eleyen kararlılık süresi '
                                   'her hesaplamada özgün örneklerden bulunur. Bağlantı türü, kanal rolleri ve aktif seviye sizin seçiminizdir.')
        self.valve_auto.toggled.connect(self._valve_auto_toggled)
        grid.addWidget(self.valve_auto, 5, 0, 1, 4)
        self.valve_rise_hold = QDoubleSpinBox()
        self.valve_rise_hold.setDecimals(4); self.valve_rise_hold.setRange(0, 1e7)
        self.valve_rise_hold.setSuffix(' ms'); self.valve_rise_hold.setSingleStep(.1)
        self.valve_rise_hold.setValue(1.0); self.valve_rise_hold.setKeyboardTracking(False)
        self.valve_rise_hold.setToolTip('Her iki kanalda 0→1 geçişi, sinyal en az bu süre boyunca 1 kalırsa kabul edilir. '
                                       'Daha kısa 1 darbeleri elenir; kabul edilen kenarın ilk örnek zamanı korunur. '
                                       '1→0 için ek süre uygulanmaz. Otomatik ayar açıkken de geçerlidir; 0 = kapalı.')
        self.valve_rise_hold.valueChanged.connect(self._valve_settings_changed)
        grid.addWidget(QLabel('0→1 doğrulama süresi:'), 6, 0)
        grid.addWidget(self.valve_rise_hold, 6, 1)
        root.addWidget(box)

        self.valve_advanced_button = QToolButton()
        self.valve_advanced_button.setText('Gelişmiş ayarlar: giriş türü, eşikler, parazit filtresi, azami bekleme')
        self.valve_advanced_button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.valve_advanced_button.setCheckable(True); self.valve_advanced_button.setArrowType(Qt.ArrowType.RightArrow)
        root.addWidget(self.valve_advanced_button)
        self.valve_advanced = QWidget(); advanced = QGridLayout(self.valve_advanced); advanced.setContentsMargins(18, 0, 0, 0)
        for col, text in enumerate(('Kanal', 'Giriş türü', 'Alt eşik', 'Üst eşik', 'Parazit filtresi')):
            advanced.addWidget(QLabel(text), 0, col)
        self.valve_hold, self.valve_hold_b = QDoubleSpinBox(), QDoubleSpinBox()
        self.valve_signal_controls = []
        for j, hold in enumerate((self.valve_hold, self.valve_hold_b)):
            mode = QComboBox()
            mode.addItem('Kesin 0/1', 'binary'); mode.addItem('Analog + histerezis', 'hysteresis')
            low, high = QDoubleSpinBox(), QDoubleSpinBox()
            for spin, val in ((low, .3), (high, .7)):
                spin.setDecimals(6); spin.setRange(-1e12, 1e12); spin.setValue(val)
                spin.setKeyboardTracking(False); spin.setToolTip('Kaynağın ham Y biriminde eşik; grafik Y kaydırması uygulanmaz.')
                spin.valueChanged.connect(self._valve_manual_edit)
            mode.currentIndexChanged.connect(self._valve_manual_edit)
            hold.setDecimals(4); hold.setRange(0, 1e7); hold.setSuffix(' ms'); hold.setSingleStep(1)
            hold.setKeyboardTracking(False); hold.valueChanged.connect(self._valve_manual_edit)
            hold.setToolTip('Bu süreden kısa durumlar (kontak sıçraması, parazit) yok sayılır. '
                            'Kenar zamanı kabul edilen durumun ilk örneğidir; süre hesabına gecikme eklenmez. 0 = filtre kapalı.')
            advanced.addWidget(QLabel('AB'[j]), j+1, 0)
            for col, widget in enumerate((mode, low, high, hold), 1):
                advanced.addWidget(widget, j+1, col)
            self.valve_signal_controls.append((mode, polarities[j], low, high))
        self.valve_wait = QDoubleSpinBox()
        self.valve_wait.setDecimals(3); self.valve_wait.setRange(0, 1e9); self.valve_wait.setSuffix(' s'); self.valve_wait.setSingleStep(.1)
        self.valve_wait.setKeyboardTracking(False); self.valve_wait.valueChanged.connect(self._valve_settings_changed)
        self.valve_wait.setSpecialValueText('Kayıt sonuna kadar')
        self.valve_wait.setToolTip('Başlangıç ile bitiş arasındaki azami süre; aşılırsa olay “Süre aşıldı” olur. 0 = ortak kayıt sonuna kadar.')
        advanced.addWidget(QLabel('Azami bekleme:'), 3, 0, 1, 2); advanced.addWidget(self.valve_wait, 3, 2)
        note = QLabel('Otomatik ayar açıkken giriş türü, eşikler ve filtre her hesaplamada veriden belirlenip burada gösterilir; '
                      'birini değiştirirseniz otomatik ayar kapanır. Histerezis: üst eşikte 1, alt eşikte 0; arada önceki seviye korunur.')
        note.setWordWrap(True); note.setProperty('valveHint', True); advanced.addWidget(note, 4, 0, 1, 5)
        advanced.setColumnStretch(1, 1); advanced.setColumnStretch(2, 1); advanced.setColumnStretch(3, 1); advanced.setColumnStretch(4, 1)
        root.addWidget(self.valve_advanced); self.valve_advanced.hide()
        self.valve_advanced_button.toggled.connect(self._valve_toggle_advanced)
        settings = getattr(self, 'settings', None)
        stored = settings.value('valve/mode', 'position') if settings is not None else 'position'
        with QSignalBlocker(self.valve_mode):
            self.valve_mode.setCurrentIndex(max(0, self.valve_mode.findData(stored)))
        with QSignalBlocker(self.valve_auto):
            self.valve_auto.setChecked(_setting_bool(settings.value('valve/auto') if settings is not None else None, True))
        self.valve_mode.currentIndexChanged.connect(self._valve_mode_changed)
        self._valve_update_rule()

    def _valve_toggle_advanced(self, checked):
        self.valve_advanced.setVisible(checked)
        self.valve_advanced_button.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)

    def _valve_store(self, key, value):
        settings = getattr(self, 'settings', None)
        if settings is not None:
            settings.setValue(key, value)

    def _valve_options(self, auto=False):
        if auto:
            # Conditioning is detected from the data; only the active level is the user's.
            signals = tuple(SignalOptions(active_low=c[1].currentData()) for c in self.valve_signal_controls)
        else:
            signals = tuple(SignalOptions(input_mode=c[0].currentData(), active_low=c[1].currentData(),
                                          min_hold_s=round(hold.value()/1000, 7), low_threshold=c[2].value(), high_threshold=c[3].value())
                            for c, hold in zip(self.valve_signal_controls, (self.valve_hold, self.valve_hold_b)))
        rules = [tuple(box.currentData() for box in boxes) for boxes in self.valve_custom_rules]
        return ValveOptions(max_wait_s=self.valve_wait.value(), mode=self.valve_mode.currentData(),
                            signals=signals, opening_rule=rules[0], closing_rule=rules[1],
                            rise_hold_s=round(self.valve_rise_hold.value()/1000, 7))

    def _valve_update_rule(self):
        mode = self.valve_mode.currentData()
        for j, label in enumerate(self.valve_channel_labels):
            label.setText(f"{'AB'[j]} · {ROLES[mode][j]}:")
        self.valve_custom.setVisible(mode == 'custom')
        for kind, _, low, high in self.valve_signal_controls:
            low.setEnabled(kind.currentData() == 'hysteresis'); high.setEnabled(low.isEnabled())
        text = MODES[mode][1]
        if mode == 'custom':
            try:
                rules = self._valve_options().rules()
                text = f'Açılma: {rules[0].description()}   |   Kapanma: {rules[1].description()}'
            except ValueError as exc:
                text = str(exc)
        self.valve_rule.setText(text)

    def _valve_mode_changed(self, *args):
        self._valve_store('valve/mode', self.valve_mode.currentData())
        self._valve_settings_changed()

    def _valve_settings_changed(self, *args):
        self._valve_update_rule()
        self._valve_selection_changed()

    def _valve_manual_edit(self, *args):
        if self.valve_auto.isChecked():
            self.valve_auto.setChecked(False)
        self._valve_settings_changed()

    def _valve_auto_toggled(self, checked):
        self._valve_store('valve/auto', bool(checked))
        self._valve_show_settings_state()

    def _valve_signal_state(self, j):
        kind, polarity, low, high = self.valve_signal_controls[j]
        hold = (self.valve_hold, self.valve_hold_b)[j]
        return kind.currentIndex(), polarity.currentIndex(), low.value(), high.value(), hold.value()

    def _valve_set_signal_state(self, j, state):
        widgets = (*self.valve_signal_controls[j], (self.valve_hold, self.valve_hold_b)[j])
        blockers = [QSignalBlocker(w) for w in widgets]
        try:
            kind, polarity, low, high, hold = widgets
            kind.setCurrentIndex(state[0]); polarity.setCurrentIndex(state[1])
            low.setValue(state[2]); high.setValue(state[3]); hold.setValue(state[4])
        finally:
            for blocker in blockers:
                blocker.unblock()

    def _valve_swap_channels(self):
        a, b = self.valve_open.currentIndex(), self.valve_closed.currentIndex()
        states = [self._valve_signal_state(j) for j in (0, 1)]
        with QSignalBlocker(self.valve_open), QSignalBlocker(self.valve_closed):
            self.valve_open.setCurrentIndex(b); self.valve_closed.setCurrentIndex(a)
        self._valve_set_signal_state(0, states[1]); self._valve_set_signal_state(1, states[0])
        self._valve_settings_changed()

    def _valve_apply_detected(self, options):
        """Show the conditioning an automatic analysis used without invalidating it."""
        for j, signal in enumerate(options.signals):
            kind, polarity, low, high = self.valve_signal_controls[j]
            state = (kind.findData(signal.input_mode), polarity.findData(signal.active_low),
                     signal.low_threshold if signal.input_mode == 'hysteresis' else low.value(),
                     signal.high_threshold if signal.input_mode == 'hysteresis' else high.value(),
                     options.hold(j)*1000)
            self._valve_set_signal_state(j, state)
        self._valve_update_rule()
