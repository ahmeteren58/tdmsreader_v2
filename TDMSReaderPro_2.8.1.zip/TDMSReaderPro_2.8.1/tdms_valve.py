"""Auditable valve timing on original samples; no resampling or inferred Fs."""
from __future__ import annotations
from contextlib import ExitStack
from dataclasses import asdict
import csv
import heapq
import itertools
import json
import math
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import numpy as np
from tdms_io import open_tdms
from tdms_export import _Channel, ExportOptions, ExportCancelled, _text
from tdms_inspection import nearest_sample
from tdms_numeric import read_envelope
from tdms_valve_rules import ValveOptions, SignalOptions as SignalOptions  # public API


def _check(cancelled):
    if cancelled():
        raise ExportCancelled()


def _duration_cmp(start, end, limit):
    delta = end - start
    tolerance = max(1e-12, 2*abs(float(np.spacing(max(abs(start), abs(end))))))
    if math.isclose(delta, limit, rel_tol=1e-12, abs_tol=tolerance):
        return 0
    return 1 if delta > limit else -1


def _validate_sources(sources):
    if len(sources) != 2 or sources[0]['key'] == sources[1]['key']:
        raise ValueError('A ve B için iki farklı kanal seçin.')
    modes = {s['x_mode'] for s in sources}
    if len(modes) != 1 or next(iter(modes)) not in ('seconds', 'datetime'):
        raise ValueError('İki kanal da aynı zaman türünde olmalı (saniye veya UTC). Kanal bazlı Manuel Fs / metadata bilgilerini kontrol edin.')
    for s in sources:
        fs = s.get('fs_hz')
        if fs is None or not math.isfinite(float(fs)) or float(fs) <= 0:
            raise ValueError(f"{s['name']}: Fs bilinmiyor; Manuel Fs atayın.")
        if s['n'] < 2:
            raise ValueError(f"{s['name']}: en az iki örnek gerekli.")
        if s.get('source_path') and s.get('source_fingerprint'):
            stat = os.stat(s['source_path'])
            if any(getattr(stat, attr) != s['source_fingerprint'][key]
                   for attr, key in [('st_size', 'size'), ('st_mtime_ns', 'mtime_ns')]):
                raise ValueError(f"{s['name']}: kaynak dosya değişti; yeniden yükleyin.")


def _runs(channel, options, signal, cancelled, progress):
    """Stream full resolution conditioning and exact run/sample boundaries."""
    runs, raw_x, raw_y = [], [], []
    previous_time, schmitt_state, invalid_n = None, -1, 0
    for offset in range(0, channel.n, options.chunk_size):
        _check(cancelled)
        idx, xx, yy = channel.block(offset, offset + options.chunk_size)
        x, y = np.asarray(xx, dtype=float), np.asarray(yy)
        if not len(x):
            raise ValueError(f"{channel.s['name']}: eksik veri bloğu.")
        if not np.all(np.isfinite(x)) or np.any(np.diff(x) <= 0) or (previous_time is not None and x[0] <= previous_time):
            raise ValueError(f"{channel.s['name']}: zamanlar sonlu ve kesin artan olmalı.")
        finite = np.isfinite(y)
        if signal.input_mode == 'binary':
            bad = finite & (y != 0) & (y != 1)
            if np.any(bad):
                j = int(np.flatnonzero(bad)[0])
                raise ValueError(f"{channel.s['name']}: örnek {int(idx[j])} = {y[j]}; 0/1 olmayan veri. Analog giriş için histerezis modunu ve eşikleri seçin.")
            state = np.where(finite, y, -1).astype(np.int8)
        else:
            # -2 means retain previous level; -1 is unknown and resets on gaps.
            anchors = np.where(~finite, -1, np.where(y >= signal.high_threshold, 1,
                              np.where(y <= signal.low_threshold, 0, -2))).astype(np.int8)
            positions = np.maximum.accumulate(np.where(anchors != -2, np.arange(len(y))+1, 0))
            state = np.r_[np.int8(schmitt_state), anchors][positions]
            schmitt_state = int(state[-1])
            # Preview alone is reduced. Classification above uses every sample.
            reader = SimpleNamespace(read_data=lambda offset, length: y[offset:offset+length])
            pick, vals = read_envelope(reader, 0, len(y), max(5, math.ceil(8000*len(y)/channel.n)), cancelled)
            _check(cancelled)
            raw_x.append(x[pick]); raw_y.append(vals)
        if signal.active_low:
            state = np.where(state >= 0, 1-state, -1).astype(np.int8)
        invalid_n += int(np.count_nonzero(~finite))
        boundaries = np.r_[0, np.flatnonzero(np.diff(state)) + 1, len(state)]
        for a, b in zip(boundaries[:-1], boundaries[1:]):
            _check(cancelled)
            val = int(state[a])
            if runs and runs[-1]['state'] == val:
                runs[-1].update(last=float(x[b-1]), last_i=int(idx[b-1]))
            else:
                if len(runs) > options.max_transitions:
                    raise ValueError('Çok fazla geçiş var. Giriş türünü/eşikleri kontrol edin veya kaydı bölün.')
                runs.append({'state': val, 't': float(x[a]), 'prev': float(x[a-1]) if a else previous_time,
                             'i': int(idx[a]), 'last': float(x[b-1]), 'last_i': int(idx[b-1])})
        previous_time = float(x[-1])
        progress(min(100, int(100*(offset+len(x))/channel.n)))
    raw = {'x': np.concatenate(raw_x), 'y': np.concatenate(raw_y)} if raw_x else _trace(runs)
    if signal.input_mode == 'binary' and signal.active_low:
        raw['y'] = 1-raw['y']
    return runs, invalid_n, raw


def _changes(runs, hold, rise_hold=0.0, inverted=False):
    """Confirm persistence; retain the first sample time, not confirmation time."""
    state, changes, ignored = None, [], []
    for i, r in enumerate(runs):
        if inverted and r['state'] >= 0:
            r = dict(r, state=1-r['state'])
        val = r['state']
        if val == -1:
            changes.append(dict(r, kind='gap')); state = None
            continue
        end = runs[i+1]['t'] if i+1 < len(runs) else r['last']
        required = max(hold, rise_hold) if val == 1 else hold
        if _duration_cmp(r['t'], end, required) < 0:
            ignored.append(dict(r, observed_s=end-r['t']))
            continue
        if state is None:
            kind = 'init'
        elif val == state:
            continue
        else:
            kind = 'rise' if val == 1 else 'fall'
        changes.append(dict(r, kind=kind)); state = val
    return changes, ignored


def _trace(runs):
    x, y = [], []
    for r in runs:
        val = float(r['state']) if r['state'] >= 0 else float('nan')
        x.extend((r['t'], r['last'])); y.extend((val, val))
    return {'x': np.asarray(x), 'y': np.asarray(y)}


def _accepted_trace(changes, runs):
    # Stop a plateau at the next accepted boundary, including unknown intervals.
    accepted = [dict(c, last=changes[i+1]['t'] if i+1 < len(changes) else runs[-1]['last'])
                for i, c in enumerate(changes)]
    if not accepted or accepted[0]['t'] > runs[0]['t']:
        accepted.insert(0, dict(state=-1, t=runs[0]['t'], last=accepted[0]['t'] if accepted else runs[-1]['last']))
    return _trace(accepted)


def _open_sources(stack, sources):
    handles = {p: stack.enter_context(open_tdms(p)) for p in dict.fromkeys(s['path'] for s in sources if s['path'])}
    return [_Channel(s, handles.get(s['path']), ExportOptions()) for s in sources]


def _scan(channels, options, cancelled, progress):
    """Condition each channel once; returns (runs, invalid count, raw preview) per channel."""
    scans = []
    for j, ch in enumerate(channels):
        _check(cancelled)
        scans.append(_runs(ch, options, options.signals[j], cancelled, lambda n, j=j: progress((j+n/100)/len(channels))))
    return scans


def _bounds(scans):
    lo, hi = max(s[0][0]['t'] for s in scans), min(s[0][-1]['last'] for s in scans)
    if hi <= lo:
        raise ValueError('Kanalların zaman aralıkları örtüşmüyor. Başlangıç zamanlarını kontrol edin.')
    return lo, hi


def _evaluate(sources, options, scans, cancelled=lambda: False):
    changes, rejected = zip(*(_changes(runs, options.hold(j), options.rise_hold_s)
                              for j, (runs, _, _) in enumerate(scans)))
    bounds = _bounds(scans)
    events = _pair(changes, options, bounds, cancelled)
    return {'events': events, 'sources': sources, 'options': options, 'bounds': bounds,
            'traces': [raw for _, _, raw in scans],
            'logical_traces': [_trace(runs) for runs, _, _ in scans],
            'accepted_traces': [_accepted_trace(c, runs) for c, (runs, _, _) in zip(changes, scans)],
            'changes': list(changes), 'rejected_runs': list(rejected),
            'invalid_samples': [bad for _, bad, _ in scans], 'ignored_runs': [len(r) for r in rejected]}


def analyze_valve(sources, options=ValveOptions(), cancelled=lambda: False, progress=lambda p: None):
    """Analyze A/B using an explicit preset or custom start/end edges."""
    _validate_sources(sources)
    with ExitStack() as stack:
        scans = _scan(_open_sources(stack, sources), options, cancelled, lambda f: progress(int(80*f)))
    _validate_sources(sources)
    result = _evaluate(sources, options, scans, cancelled)
    progress(100)
    return result


def _pair(changes, options, bounds, cancelled=lambda: False):
    """Match accepted edges of both channels to the opening/closing rules."""
    lo, hi = bounds
    states, pending, events = [None, None], [None, None], []
    rules = options.rules()

    def finish(j, status, note, end=None):
        start, rule = pending[j], rules[j]
        if start is None:
            return
        event = {'direction': rule.direction, 'status': status, 'note': note, 'mode': options.mode,
                 'start_channel': rule.start_channel, 'end_channel': rule.end_channel,
                 'start_edge': rule.start_edge, 'end_edge': rule.end_edge,
                 'start': start['t'], 'start_prev': start['prev'], 'start_index': start['i'],
                 'end': None, 'end_prev': None, 'end_index': None, 'duration': None,
                 'lower': None, 'upper': None, 'review': 'pending', 'manual': None, 'review_note': ''}
        if end is not None:
            event.update(end=end['t'], end_prev=end['prev'], end_index=end['i'], duration=max(0., end['t']-start['t']),
                         lower=max(0., end['prev']-start['t']), upper=max(0., end['t']-start['prev']))
        events.append(event)
        if len(events) > options.max_events:
            raise ValueError(f'{options.max_events} olay sınırı aşıldı; kaydı daha kısa parçalarda analiz edin.')
        pending[j] = None

    merged = heapq.merge(*[[(c['t'], j, i, c) for i, c in enumerate(cs)] for j, cs in enumerate(changes)])
    for t, group in itertools.groupby(merged, key=lambda item: item[0]):
        _check(cancelled)
        batch = {j: c for _, j, _, c in group}
        if t > hi:
            break
        before = states.copy()
        for j, c in batch.items():
            states[j] = None if c['state'] < 0 else c['state']
        if t < lo:
            continue
        for j, rule in enumerate(rules):
            if pending[j] is None:
                continue
            own, other = batch.get(rule.start_channel, {}), batch.get(rule.end_channel, {})
            cancelled_edge = own.get('kind') == rule.cancel_edge
            completed_edge = other.get('kind') == rule.end_edge
            if options.max_wait_s and _duration_cmp(pending[j]['t'], t, options.max_wait_s) > 0:
                finish(j, 'timeout', f'Azami bekleme aşıldı; beklenen bitiş: {rule.description()}.')
            elif None in states:
                finish(j, 'invalid', 'Ölçüm aralığında NaN/Inf veya eşik bandında belirsiz durum var.')
            elif cancelled_edge and completed_edge:
                finish(j, 'ambiguous', 'Bitiş ve başlatan sinyalin geri dönüşü aynı zaman damgasında; sıraları örnekleme ile ayırt edilemiyor. Elle inceleyin.')
            elif cancelled_edge:
                finish(j, 'cancelled', f"{'AB'[rule.start_channel]} başlangıç durumuna geri döndü; {rule.description()} bitişi henüz görülmedi. Kısa darbe veya yanlış ölçüm modu olabilir.")
            elif completed_edge:
                finish(j, 'complete', '', other)
        for j, rule in enumerate(rules):
            c = batch.get(rule.start_channel, {})
            if c.get('kind') != rule.start_edge:
                continue
            pending[j] = c
            if None in states:
                finish(j, 'invalid', 'Başlangıç anında bir kanalın durumu bilinmiyor (veri boşluğu veya eşik bandı).')
            elif before[rule.end_channel] != rule.expected_end_state:
                actual = before[rule.end_channel]
                finish(j, 'unpaired', f"Başlangıç öncesi {'AB'[rule.end_channel]}={actual if actual is not None else 'bilinmiyor'}; beklenen {rule.expected_end_state}. Mod/polariteyi ve önceki çevrimin tamamlanmasını kontrol edin. Kural: {rule.description()}.")
            elif batch.get(rule.end_channel, {}).get('kind') == rule.end_edge:
                finish(j, 'complete', 'Aynı zaman damgası; alt örnek süresi çözülemez.', batch[rule.end_channel])
    for j, rule in enumerate(rules):
        if pending[j] is not None:
            timed_out = options.max_wait_s and _duration_cmp(pending[j]['t'], hi, options.max_wait_s) > 0
            finish(j, 'timeout' if timed_out else 'incomplete', f'Ortak kayıt aralığında doğrulanmış bitiş yok. Kural: {rule.description()}. Kararlılık süresi için kayıt sonunda yeterli örnek olmayabilir.')
    events.sort(key=lambda e: (e['start'], e['direction']))
    return events


def manual_measurement(sources, direction, start, end, options=ValveOptions()):
    """Snap cursors to original samples of the selected rule's start/end channels."""
    _validate_sources(sources)
    if direction not in ('opening', 'closing'):
        raise ValueError('Bilinmeyen ölçüm yönü.')
    rule = options.rules()[0 if direction == 'opening' else 1]
    values = []
    with ExitStack() as stack:
        handles = {p: stack.enter_context(open_tdms(p)) for p in dict.fromkeys(s['path'] for s in sources if s['path'])}
        for j, pos in ((rule.start_channel, start), (rule.end_channel, end)):
            ch = _Channel(sources[j], handles.get(sources[j]['path']), ExportOptions())
            if ch.ch is None and (not np.all(np.isfinite(ch.s['x'])) or np.any(np.diff(ch.s['x']) <= 0)):
                raise ValueError('Manuel ölçüm için kesin artan zaman gerekli.')
            sample = nearest_sample(ch, pos)
            if (sample is None or not math.isfinite(sample['y']) or
                    (options.signals[j].input_mode == 'binary' and sample['y'] not in (0, 1))):
                raise ValueError('İmleç kanal sınırları dışında, veri boşluğunda veya 0/1 modunda geçersiz bir örnekte.')
            values.append(sample)
    _validate_sources(sources)
    if values[1]['x'] < values[0]['x']:
        raise ValueError('Bitiş başlangıçtan önce olamaz.')
    return {'start': values[0]['x'], 'end': values[1]['x'], 'duration': values[1]['x']-values[0]['x'],
            'start_index': values[0]['index'], 'end_index': values[1]['index'],
            'start_value': values[0]['y'], 'end_value': values[1]['y'],
            'start_channel': rule.start_channel, 'end_channel': rule.end_channel}


def write_valve_report(path, result):
    """Atomic audit CSV; automatic and reviewed measurements stay separate."""
    destination = Path(path).absolute()
    sources, options = result['sources'], result['options']
    for source in sources:
        original = source.get('source_path') or source['path']
        if original and (os.path.realpath(original) == os.path.realpath(destination) or
                         (destination.exists() and os.path.exists(original) and os.path.samefile(original, destination))):
            raise ValueError('Rapor kaynak TDMS dosyasının üzerine yazılamaz.')
    columns = ['event','direction','status','auto_start_s','auto_end_s','auto_duration_s','auto_duration_ms',
               'auto_start_index','auto_end_index','sampling_lower_s','sampling_upper_s',
               'review','manual_start_s','manual_end_s','manual_duration_s','manual_start_index','manual_end_index',
               'manual_start_value','manual_end_value','review_note','note','open_channel','closed_channel',
               'open_fs_hz','closed_fs_hz','time_mode','min_hold_s','max_wait_s',
               'rule','open_key','closed_key','open_path','closed_path','open_fs_source','closed_fs_source',
               'measurement_mode','channel_a','channel_b','start_channel','start_edge','end_channel','end_edge',
               'a_hold_s','b_hold_s','settings_json']
    fd, tmp = tempfile.mkstemp(dir=destination.parent, suffix='.tmp', prefix='.'+destination.name)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8-sig', newline='') as stream:
            writer = csv.writer(stream, delimiter=';'); writer.writerow(columns)
            labels = [' / '.join([s['file_label'], s['group'], s['channel']]) for s in sources]
            settings = json.dumps(asdict(options), ensure_ascii=False, sort_keys=True)
            for i, e in enumerate(result['events'], 1):
                manual = e['manual'] or {}
                rule = options.rules()[0 if e['direction'] == 'opening' else 1]
                writer.writerow([i,e['direction'],e['status'],e['start'],e['end'],e['duration'],
                                 None if e['duration'] is None else 1000*e['duration'],e['start_index'],e['end_index'],e['lower'],e['upper'],e['review'],
                                 *[manual.get(k) for k in ('start','end','duration','start_index','end_index','start_value','end_value')],
                                 _text(e['review_note']),_text(e['note']),*map(_text,labels),*[s['fs_hz'] for s in sources],
                                 sources[0]['x_mode'],options.min_hold_s,options.max_wait_s,
                                 'rise_to_opposite_fall_v1' if options.mode == 'legacy' else rule.description(),
                                 *[_text(s['key']) for s in sources], *[_text(s.get('source_path') or s['path']) for s in sources],
                                 *[_text(s.get('fs_source') or '') for s in sources],options.mode,*map(_text,labels),
                                 'AB'[rule.start_channel],rule.start_edge,'AB'[rule.end_channel],rule.end_edge,
                                 options.hold(0),options.hold(1),settings])
            stream.flush(); os.fsync(stream.fileno())
        os.replace(tmp, destination); tmp = None
    finally:
        if tmp is not None:
            os.unlink(tmp)
