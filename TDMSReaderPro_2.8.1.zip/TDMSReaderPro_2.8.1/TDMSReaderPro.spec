# Build on the target operating system with: python -m PyInstaller TDMSReaderPro.spec
from pathlib import Path
root = Path(SPECPATH)
a = Analysis(
    [str(root / "tdmsreader.py")],
    pathex=[str(root)],
    binaries=[],
    datas=[(str(root / "icons"), "icons")],
    hiddenimports=["PyQt6.QtSvg", "pyqtgraph.exporters", "scipy.signal"],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True,
    name="TDMSReaderPro", debug=False, bootloader_ignore_signals=False,
    strip=False, upx=False, console=False,
    icon=str(root / "icons" / "app_icon.png"),
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="TDMSReaderPro")
