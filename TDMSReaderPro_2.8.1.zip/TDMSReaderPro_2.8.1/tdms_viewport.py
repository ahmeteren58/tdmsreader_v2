"""Bounded display previews. These arrays must never be used for analysis/export."""
from collections import OrderedDict
import numpy as np
from tdms_numeric import numeric_1d, read_envelope


def point_budget(channel_count, maximum=80_000, pixels=0):
    """Per-curve display budget.

    A min/max envelope needs about two values per pixel column; four per device
    pixel keeps spikes and edges exact. Every extra point is stroked again on
    each crosshair move, pan or zoom, so the budget follows the plot width.
    """
    budget = min(maximum, max(12_000, 120_000 // max(1, channel_count)))
    if pixels and pixels > 0:
        budget = min(budget, max(4_000, 4 * int(pixels)))
    return budget


def digital_indices(y):
    """Keep exact transition coordinates, endpoints and both sides of NaN gaps."""
    y = np.asarray(y)
    if not y.size:
        return np.array([], dtype=np.int64)
    return np.unique(np.r_[0, np.flatnonzero(y[1:] != y[:-1]) + 1, len(y) - 1])


def read_preview(channel, start, stop, max_points, digital=False, cancelled=lambda: False):
    if not digital:
        idx, y = read_envelope(channel, start, stop, max_points, cancelled)
        return idx, y, stop - start <= max_points
    # Sparse digital signals retain real edge times, including block boundaries.
    # Dense switching falls back to a bounded overview; exact analysis uses TDMS.
    indices, values, count, previous = [], [], 0, None
    for a in range(start, stop, 65_536):
        if cancelled():
            return np.array([], dtype=np.int64), np.array([], dtype=float), False
        y = numeric_1d(channel.read_data(offset=a, length=min(65_536, stop-a)), sample_offset=a)
        if len(y) != min(65_536, stop-a):
            raise IOError("TDMS kanalının istenen veri aralığı eksik okundu.")
        pick = np.flatnonzero(y[1:] != y[:-1]) + 1
        if a == start or y[0] != previous:
            pick = np.r_[0, pick]
        if a + len(y) == stop:
            pick = np.unique(np.r_[pick, len(y)-1])
        count += len(pick)
        if count > max_points:
            idx, values = read_envelope(channel, start, stop, max_points, cancelled)
            return idx, values, False
        previous = y[-1]
        indices.append(a + pick)
        values.append(y[pick])
    if not indices:
        return np.array([], dtype=np.int64), np.array([], dtype=float), True
    return np.concatenate(indices), np.concatenate(values), True


class ArrayChannel:
    def __init__(self, y):
        self.y = np.asarray(y)

    def read_data(self, offset, length):
        return self.y[offset:offset+length]


def display_xy(x, y, max_points, digital=False, bounds=None, cancelled=lambda: False):
    x, y = np.asarray(x), np.asarray(y)
    start, stop = 0, min(len(x), len(y))
    if bounds is not None and stop:
        lo, hi = sorted(bounds)
        if np.all(np.isfinite(x)) and np.all(np.diff(x) >= 0):
            # Retain neighbouring points so clipped lines/steps enter the view.
            start = max(0, int(np.searchsorted(x, lo, side="left"))-1)
            stop = min(stop, int(np.searchsorted(x, hi, side="right"))+1)
        else:
            selected = np.flatnonzero(np.isfinite(x) & (x >= lo) & (x <= hi))
            if not len(selected):
                return x[:0], y[:0], True
            start, stop = max(0, selected[0]-1), min(stop, selected[-1]+2)
    idx, values, exact = read_preview(ArrayChannel(y), start, stop, max_points, digital, cancelled)
    return x[idx], values, exact


class ViewCache:
    """Byte-limited LRU; one sequential preview reader owns each instance."""
    def __init__(self, max_bytes=32 * 1024**2):
        self.max_bytes = max_bytes
        self.entries = OrderedDict()
        self.bytes = 0

    def get(self, source_key, start, stop, budget):
        for key in reversed(self.entries):
            source, a, b, stored_budget = key
            idx, y, exact = self.entries[key]
            # A reduced overview is reusable only for the identical interval.
            if source == source_key and ((a == start and b == stop and stored_budget == budget) or
                    (exact and a <= start and b >= stop and len(idx) <= budget)):
                self.entries.move_to_end(key)
                if exact and (a != start or b != stop):
                    lo = max(0, int(np.searchsorted(idx, start))-1)
                    hi = min(len(idx), int(np.searchsorted(idx, stop, side="right"))+1)
                    return idx[lo:hi], y[lo:hi], True
                return idx, y, exact
        return None

    def put(self, source_key, start, stop, budget, result):
        key = (source_key, start, stop, budget)
        size = result[0].nbytes + result[1].nbytes
        if size > self.max_bytes:
            return
        previous = self.entries.pop(key, None)
        if previous is not None:
            self.bytes -= previous[0].nbytes + previous[1].nbytes
        self.entries[key] = result
        self.bytes += size
        while self.bytes > self.max_bytes:
            _, old = self.entries.popitem(last=False)
            self.bytes -= old[0].nbytes + old[1].nbytes
