# TDMSReader Pro 2.5.2 — Grafik akıcılığı ve sağ tuş

## Geri bildirimin değerlendirmesi

| Öneri | Karar ve uygulama |
| --- | --- |
| Zoomda eğrileri/eksenleri silmeden `setData` kullanma | Uygulandı. Görünüm yenilemesi yalnız mevcut eğrilerin dizilerini değiştirir. Lejant, X/Y1/Y2 sınırları, işaretler ve etkileşim modu yerinde kalır. |
| RAM'deki kanallarda görünür aralığa göre yeniden önizleme | Uygulandı. 80–250 bin örneklik bir kanalda dar aralığa zoom yapıldığında tam RAM verisinden ayrıntı gelir. SG açıksa RAM'deki filtrelenmiş dizi esas alınır. |
| Disk okumalarını tek sırada tutma | Uygulandı. Eski okuyucu tamamen bitmeden yenisi başlamaz. En son istenen aralık bekletilir; eski sonuçlar anında geçersizleşir. İptal kontrolü için önizleme blokları yaklaşık 65.536 örneğe indirildi. npTDMS altta daha büyük TDMS segmenti okuyabilir. |
| Aynı aralığı tekrar okumama, komşu aralık önbelleği | Uygulandı. 32 MiB sınırında LRU önbellek kullanılır. Tam çözülmüş bir pencerenin içindeki zoom ve aynı önizleme aralığı dosyayı açmadan kullanılır. İlk tam önizleme de uygun nokta bütçesinde tekrar okunmaz. Kaynak boyutu/değişiklik zamanı anahtara dahildir. |
| Dosyaları sürekli açık tutma | Uygulanmadı. Bir okuma grubunda dosya bir kez açılır; grup bitince kapanır. Böylece Windows'ta dosya taşıma/değiştirme ve kapanış yönetimi basit kalır. Önbellek tekrar okuma maliyetini azaltır. |
| Kanal sayısına göre nokta bütçesi | Uygulandı. Overlay ve Stacked için kanal başına `min(80.000, max(12.000, 120.000/kanal_sayısı))`. En düşük kanal bütçesi nedeniyle toplam, çok kanalda 120 bini aşabilir. |
| İmleç ve aralık bildirimlerini azaltma | Uygulandı. Artı çizgileri mevcut hızında hareket eder; nokta/metin ve özet şeridi yaklaşık 10 Hz yenilenir. Gizli Stacked/Overlay görünümüne her harekette aralık gönderilmez. |
| Toplam Süre'nin zoomla değişmesi | Düzeltildi. Büyük kanalda özgün örnek sayısı ve etkin zaman adımı kullanılır. Gösterilen Aralık ile Toplam Süre ayrıdır. |
| Dijital kanalda gerçek geçiş indeksleri | Uygulandı. Seyrek dijital geçişler blok sınırlarında da tam özgün indeksle korunur; Overlay ve Stacked aynı yöntemi kullanır. Bütçeyi aşan çok yoğun anahtarlamada sınırlı min/maks önizlemesine dönülür; ölçüm yine tüm örneklerden yapılır. |
| NaN taramasını azaltma | Sonlu olduğu kontrol edilmiş çizim dizisinde `skipFiniteCheck` kullanılır. NaN/Inf varsa sonlu bağlantı kontrolü devam eder. |
| `ascontiguousarray` kopyasını kaldırma | Değişiklik gerekmiyor. NumPy zaten aynı türde, bitişik diziyi yeniden kopyalamadan döndürür. Bitişik olmayan girişin güvenli dönüşümü korunmuştur. |
| İlk indirgemeyi arka plana taşıma | Uygulandı. İlk grafik dizilerinin hazırlanması filtre/çizim hazırlama işinde yapılır. Zoom yalnız görünüm okuyucusunu kullanır; ayrıca filtre işi oluşturmaz. |
| Kanal metadata önbelleği ve debounce | Uygulandı. 150 ms bekleme ve 512 kanal girişine kadar önbellek. Kaynak boyutu/değişiklik zamanı değişince eski metadata kullanılmaz. |
| OpenGL'yi ayar menüsüne taşıma | Bu sürümde eklenmedi. Yazılım çizimi varsayılan; mevcut `TDMSREADER_OPENGL=1` başlangıç seçeneği korunuyor. Sürücü/uzak masaüstü davranışı bu ortamda doğrulanamadığı için çalışan uygulamada canlı geçiş eklenmedi. |

## Sağ tuş kullanımı

- **Sağ tuşla sürükleme:** mevcut eksen ölçekleme davranışı devam eder. Sıradan sağ tık ve sürükleme sonunda menü açılmaz.
- **Ctrl + sağ tık:** grafik menüsünü açar. Overlay, Stacked, ayrılmış pencere, FFT ve vana grafikleri aynı kuralı kullanır.
- Üst çubuktaki **Aralık**, **Sığdır** ve **Görünüm** komutları da kullanılabilir.

## Korunan hesaplar ve sınırlar

Özgün örnek zamanı, saniye ekseni, kanal bazlı Fs, ortak süre varsayımı, CSV, FFT normalizasyonu ve vana tespit kuralları değiştirilmedi. Yeni `tdms_viewport.py` yalnız çizim dizileri üretir; sayısal analiz/export kaynağı değildir. Geniş görünüm her örneği gösterme garantisi vermez. Hassas kenar ölçümünü tam çözünürlüklü A/B veya vana analizinden yapın.

**Sığdır**, son zoom penceresini değil tüm kaydın önizlemesini kullanır. Değişiklikler kaynak pakettir; ZIP'i tamamen yeni klasöre çıkarın. Windows EXE için `TDMSReaderPro.spec` ile tekrar derleyin.

Doğrulama: `TEST_252.txt`. Gerçek kullanıcı TDMS kaydı ve Windows EXE performansı bu ortamda denenmedi; Windows'ta sabit bir hızlanma yüzdesi iddia edilmiyor.
