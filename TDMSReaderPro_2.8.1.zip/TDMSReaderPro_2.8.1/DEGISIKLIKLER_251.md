# TDMSReader Pro 2.5.1 — İnceleme ve düzeltmeler

## Bulunan nedenler

1. **UTC görünümü:** `wf_increment` ile birlikte `wf_start_time` görüldüğünde yükleyici Unix zamanı oluşturuyor, `x_mode=datetime` seçiliyor ve tarih ekseni devreye giriyordu. Kullanıcı açısından sıradan bir testin ekseni saat/tarih olarak görünüyordu.
2. **Y2 yakınlaşmıyordu:** Y2 için oransal zoom hesabı zaten mevcuttu. Ancak ardından çalışan sınırlandırma, yeni Y2 aralığının bütün kanal verisini içermesini zorunlu kılıyordu. Yakınlaştırma sonucu bu nedenle geri genişletiliyordu.
3. **Manuel sınırlar:** Mevcut X minimum/maksimum alanları vardı; Y1/Y2 için aynı olanak yoktu. Y2'yi elle değiştirmek tek başına yeterli değildi; sonraki zoomun bu yeni sınırı esas alması gerekiyordu.
4. **Büyük dosyalarda görünüm kaybı:** Yakınlaştırılan bölge yeniden yüklenince grafik yeniden oluşturuluyor, sadece X görünümü geri getiriliyordu. Y1/Y2 sınırları yeniden ölçeklenebiliyordu.
5. **Yalnız sağ eksende kanal:** X sınırları sol ViewBox üzerinden hesaplandığı için yalnız Y2'ye atanan kanalların tamamına sığdırma eksik kalabiliyordu.

## Uygulanan çözüm

- Takvim başlangıcı, grafik X dizisi oluşturulmadan kaldırılır. Aynı dosyada geçerli en erken waveform başlangıcı referans alınır; kanal başlangıç farkları ve waveform ofseti korunur. Önce epoch dizisi oluşturup sonra çıkarmak yerine doğrudan saniye dizisi kurulması yüksek Fs'de hassasiyet kaybını da önler.
- Her dosyanın başlangıç referansı, seçili kanallardan bağımsız olarak metadata üzerinden bulunur. Bir kanalı gizlemek/seçmek diğerinin zamanını değiştirmez. Dosyalar arası takvim hizalama yerine dosya bazlı saniye ekseni kullanılır.
- Fs seçimi, ortak süre seçeneği, veri örnekleri, Y değerleri, vana algoritması ve FFT normalizasyonu korunur. Tarih bilgisi olmayan ve Fs'si bilinmeyen kanallar indeks olarak kalır.
- Y2'de tüm veriyi içerme zorunluluğu kaldırılır. Zoom ve kaydırma oransal çalışır; bağımsız eksen kilitleri korunur. Kilidi açarken görünüm zıplamaz.
- Yeni aralık penceresi yalnız seçili eksenleri değiştirir. Bütün sınırlar önce doğrulanır; hatalı bir girişte kısmi uygulama yapılmaz. Sayılar tam hassasiyetle ve bilimsel gösterimle girilebilir.
- Manuel aralık, Y sığdırma ve proje geri yükleme sonrasında Y1–Y2 zoom referansları yenilenir. Büyük dosya yeniden çiziminde her iki Y aralığı ve Stacked kanal aralıkları korunur.
- Sağ eksendeki kanalların X sınırları da tüm veriye sığdırmada hesaba katılır. Y sığdırmada NaN/Inf örnekleri aralık hesabından çıkarılır.
- Eski UTC proje görünüm/ölçüm koordinatları yeni saniye eksenine yanlışlıkla taşınmaz. Eski hesaplanan kanalın Y örnekleri korunur, zaman referansı dönüştürülür; çok dosyalı eski hesaplamalar yeniden kontrol edilmelidir.

## Kullanım

1. Üst çubuktan **Aralık** seçin. Aynı pencere **Görünüm → Eksen Aralıkları…** veya grafik sağ tık menüsünden açılır.
2. X1, Y1 ve/veya Y2 satırlarını işaretleyin. Alanı yazıyla düzenlemek o satırı da işaretler.
3. Örneğin X1 minimum=4, maksimum=8; Y2 minimum=1, maksimum=4 girin.
4. **Uygula**'ya basın. Y1 seçilmediyse mevcut Y1 sınırları korunur. Sonrasında normal zoom/kaydırma kullanılabilir.
5. Y2 zoomda sabit kalsın isterseniz sağ tık menüsünden **Sağ Y Ekseni Kilidi** açın; hareket etsin istiyorsanız kapatın.

X1'in birimi zaman metadata'sı veya Manuel Fs varsa saniye, yoksa örnek indeksidir. Y1/Y2 birimleri kanalın kendi birimleridir. Bu penceredeki sınırlar yalnız görünümü değiştirir; veriyi kırpmaz veya yeniden örneklemez. CSV'de ayrıca seçilen dışa aktarma aralığı seçeneği geçerlidir.

## Kapsam ve doğrulama

Değişen uygulama dosyaları: `tdmsreader.py`, `tdms_workspace.py`, `tdms_project.py`; yeni modül: `tdms_axes.py`. Vana hesaplama modülleri değiştirilmedi. Yeni regresyon testleri `tests/test_axes_251.py` içinde bulunur. Test ortamında kapanan Qt pencerelerinin ertelenmiş silme olayları da işlenir; uzun test koşularında eski pencere/zamanlayıcıların sonraki testlere taşınması önlenir. CSV iptal testinde, 1 ms zamanlayıcının aktarım bittikten sonra çalışabilmesinden doğan yarış giderildi: test yazmayı ilk ilerleme bildiriminde bekletip iptal düğmesini tıklatır. Böylece iptal gerçekten devam eden bir yazmaya uygulanır; mevcut hedefin değişmemesi kontrolü korunur. CSV uygulama kodu değiştirilmedi.

Testler Linux üzerinde PyQt6'nin offscreen platformuyla çalıştırılmıştır. Windows EXE üretimi veya kullanıcının sorun yaşadığı özgün TDMS kaydı üzerinde deneme yapılmamıştır; o kayıt bu ZIP'te bulunmuyor. Örnekler ve sentetik tarihli TDMS kayıtları kullanılmıştır. Doğrulama sonucu `TEST_251.txt` dosyasına yazılmıştır.

## Kurulum

ZIP'i yeni klasöre tamamen çıkartın. Yalnız `tdmsreader.py` dosyasını kopyalamayın; yeni `tdms_axes.py` dahil bütün modüller birlikte bulunmalıdır. `baslat_windows.bat` veya `python tdmsreader.py` ile açın. Başlıkta 2.5.1 görmelisiniz. Mevcut EXE kendiliğinden güncellenmez; yeniden paketlemek için:

```powershell
python -m pip install -r requirements.txt
python -m pip install pyinstaller
python -m PyInstaller --clean --noconfirm TDMSReaderPro.spec
```

Çıktı `dist/TDMSReaderPro/TDMSReaderPro.exe` olur; bütün `dist/TDMSReaderPro` klasörünü birlikte taşıyın.
