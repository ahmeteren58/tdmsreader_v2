"""Focused CSV options UI, kept separate from signal-processing code."""
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTreeWidget, QTreeWidgetItem,
    QPushButton, QComboBox, QFormLayout, QCheckBox, QHeaderView,
)
from tdms_export import ExportOptions
from tdms_presentation import page_header


class CsvExportDialog(QDialog):
    def __init__(self, sources, visible_keys, x_range, parent=None):
        super().__init__(parent)
        self.sources, self.x_range = sources, x_range
        self.setWindowTitle("CSV dışa aktar")
        self.resize(800, 580)
        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 20)
        root.setSpacing(12)
        page_header(root,"CSV Dışa Aktar","Yüklenmiş kanalları özgün çözünürlükte dışa aktarır. "
                    "Yeni kanallar eklemek için önce ana grafiğe ekleyin. Yan yana düzende her kanalın kendi zamanı bulunur; "
                    "aynı satır aynı an anlamına gelmez. Filtreleme uygulanmaz; kısa kanalların kalan hücreleri boş kalır.")
        self.tree = QTreeWidget()
        self.tree.setRootIsDecorated(False)
        self.tree.setHeaderLabels(["Kanal", "Dosya / Grup", "Birim", "Örnek"])
        self.tree.setAlternatingRowColors(True)
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for i, s in enumerate(sources):
            item = QTreeWidgetItem([s["name"], " / ".join(v for v in (s["file_label"], s["group"]) if v), s["unit"], f"{s['n']:,}"])
            item.setData(0, Qt.ItemDataRole.UserRole, i)
            item.setSizeHint(0, QSize(0, 30))
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(0, Qt.CheckState.Checked)
            for col in range(4):
                item.setToolTip(col, item.text(col))
            self.tree.addTopLevelItem(item)
        root.addWidget(self.tree, 1)
        selection = QHBoxLayout()
        for caption, predicate in [("Tümünü seç", lambda s: True),
                                   ("Grafikte görünenler", lambda s: s["key"] in visible_keys),
                                   ("Seçimi kaldır", lambda s: False)]:
            b = QPushButton(caption)
            b.clicked.connect(lambda checked=False, p=predicate: self.select(p))
            selection.addWidget(b)
        selection.addStretch()
        root.addLayout(selection)
        form = QFormLayout()
        self.layout_combo = QComboBox()
        self.layout_combo.addItem("Yan yana — her kanal için X ve Y sütunu", "wide")
        self.layout_combo.addItem("Uzun tablo — kanal kimliği, örnek, X ve Y", "long")
        self.range_combo = QComboBox()
        self.range_combo.addItem("Tüm kayıt — tam çözünürlük", None)
        if x_range is not None:
            self.range_combo.addItem(f"Görünen X aralığı ({x_range[0]:.9g} … {x_range[1]:.9g})", x_range)
        self.format_combo = QComboBox()
        self.format_combo.addItem("Noktalı virgül (;) / ondalık nokta (.)", (";", "."))
        self.format_combo.addItem("Excel Türkçe: noktalı virgül (;) / ondalık virgül (,)", (";", ","))
        self.format_combo.addItem("Virgül (,) / ondalık nokta (.)", (",", "."))
        self.format_combo.addItem("Sekme / ondalık nokta (.)", ("\t", "."))
        form.addRow("Tablo düzeni", self.layout_combo)
        form.addRow("Veri aralığı", self.range_combo)
        form.addRow("Sayı biçimi", self.format_combo)
        root.addLayout(form)
        self.shifts = QCheckBox("Grafikteki X / Y kaydırmalarını uygula")
        root.addWidget(self.shifts)
        self.aligned = QCheckBox('Eski projedeki elle zaman ofsetlerini dahil et')
        self.aligned.setToolTip('Kapalı: Times / TDMS temel zamanları. Açık: eski projede kayıtlı elle ofsetler eklenir. Sinyal değerleri değişmez.')
        root.addWidget(self.aligned)
        self.aligned.setVisible(any(s.get('alignment_offset') for s in sources))
        explanation = QLabel("Yan yana tabloda her kanalın kendi zaman sütunu bulunur.")
        explanation.setWordWrap(True)
        root.addWidget(explanation)
        actions = QHBoxLayout()
        self.count_label = QLabel()
        actions.addWidget(self.count_label, 1)
        cancel = QPushButton("İptal")
        cancel.clicked.connect(self.reject)
        self.export_button = QPushButton("Dışa Aktar…")
        self.export_button.setProperty("primary", True)
        self.export_button.setDefault(True)
        self.export_button.clicked.connect(self.accept)
        actions.addWidget(cancel)
        actions.addWidget(self.export_button)
        root.addLayout(actions)
        self.tree.itemChanged.connect(self.update_count)
        self.update_count()

    def select(self, predicate):
        self.tree.blockSignals(True)
        for i, s in enumerate(self.sources):
            self.tree.topLevelItem(i).setCheckState(0, Qt.CheckState.Checked if predicate(s) else Qt.CheckState.Unchecked)
        self.tree.blockSignals(False)
        self.update_count()

    def selected_sources(self):
        return [s for i, s in enumerate(self.sources)
                if self.tree.topLevelItem(i).checkState(0) == Qt.CheckState.Checked]

    def update_count(self, *_):
        selected = self.selected_sources()
        self.count_label.setText(f"{len(selected)} / {len(self.sources)} kanal seçili")
        self.export_button.setEnabled(bool(selected))

    def options(self):
        delim, decimal = self.format_combo.currentData()
        return ExportOptions(layout=self.layout_combo.currentData(), delimiter=delim, decimal=decimal,
                             x_range=self.range_combo.currentData(), apply_shifts=self.shifts.isChecked(),
                             export_aligned=self.aligned.isChecked())
