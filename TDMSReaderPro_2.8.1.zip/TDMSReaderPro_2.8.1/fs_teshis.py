"""Read-only TDMS timing diagnosis; requires only numpy and npTDMS, no Qt.

python fs_teshis.py test.tdms --report fs_raporu.txt
python fs_teshis.py test.tdms --group AI --channel OPT-1 --indices 1000 1200
python fs_teshis.py test.tdms --group AI --channel OPT-1 --time-group AI --time-channel Time --time-unit s
"""
from __future__ import annotations
import argparse
from datetime import timedelta
import math
from pathlib import Path
import re
import sys
import numpy as np
from nptdms import TdmsFile


def _seconds(value):
    if isinstance(value, np.timedelta64):
        return float(value / np.timedelta64(1, "s"))
    if isinstance(value, timedelta):
        return value.total_seconds()
    return float(value)


def _positive(value):
    result = float(value)
    if not math.isfinite(result) or result <= 0:
        raise argparse.ArgumentTypeError("Pozitif, sonlu sayı gerekli.")
    return result


def _time_unit(properties, explicit=None):
    unit = explicit or properties.get("unit_string", properties.get("unit", ""))
    unit = str(unit).strip().lower().replace("µ", "u").replace("μ", "u")
    return {"s": 1., "sec": 1., "seconds": 1., "second": 1., "saniye": 1.,
            "ms": .001, "us": 1e-6, "ns": 1e-9}.get(unit)


def _time_values(channel, offset, length):
    a = np.asarray(channel.read_data(offset=offset, length=length))
    if a.dtype.kind == "M":
        return a
    if a.dtype.kind not in "biufOSU":
        raise ValueError(f"Desteklenmeyen zaman veri türü: {a.dtype}")
    if a.dtype.kind in "OSU":
        a = np.array([float((v.decode('utf-8-sig') if isinstance(v, bytes) else str(v)).strip().replace(',', '.')) for v in a])
    return a.astype(np.float64)


def time_summary(channel, explicit_unit=None):
    """Probe three windows; do not present sampled checks as a full-record scan."""
    n = len(channel)
    if n < 2:
        raise ValueError("Zaman kanalında en az iki örnek gerekli.")
    count = min(4096, n)
    offsets = sorted({0, max(0, n//2-count//2), n-count})
    first, last = _time_values(channel, 0, 1)[0], _time_values(channel, n-1, 1)[0]
    datetime_values = isinstance(first, np.datetime64)
    factor = 1. if datetime_values else _time_unit(channel.properties, explicit_unit)
    diffs = []
    for offset in offsets:
        values = _time_values(channel, offset, count)
        if datetime_values:
            if np.any(np.isnat(values)):
                raise ValueError("İncelenen zaman değerleri NaT içeriyor.")
            delta = np.diff(values) / np.timedelta64(1, "s")
        else:
            delta = np.diff(values)
        diffs.append(np.asarray(delta, dtype=float))
    delta = np.concatenate(diffs)
    span = _seconds(last-first) if datetime_values else float(last-first)
    if factor is not None and not datetime_values:
        delta = delta*factor
        span *= factor
    finite = delta[np.isfinite(delta)]
    median = float(np.median(finite)) if len(finite) else math.nan
    positive = bool(np.all(np.isfinite(delta)) and np.all(delta > 0))
    uniform = bool(positive and np.allclose(delta, median, rtol=1e-4, atol=abs(median)*1e-6))
    span_valid = math.isfinite(span) and span > 0
    return {"n": n, "first": str(first), "last": str(last), "unit_known": factor is not None,
            "median_dt": median, "min_dt": float(np.min(finite)) if len(finite) else math.nan,
            "max_dt": float(np.max(finite)) if len(finite) else math.nan,
            "span": span, "positive": positive, "uniform": uniform,
            "fs": 1/median if factor is not None and uniform and span_valid else None,
            "mean_fs": (n-1)/span if factor is not None and positive and span_valid else None,
            "factor": factor, "datetime": datetime_values}


def build_report(path, *, assumed_fs=5000., group=None, channel=None, time_group=None,
                 time_channel=None, time_unit=None, known_duration=None, indices=None):
    lines = ["TDMS Fs teşhis raporu", f"Dosya: {Path(path).name}",
             "Bu araç uygulamadan bağımsız olarak kaynak dosyayı okur; TDMS'yi değiştirmez.",
             "500/5000 Hz süreleri varsayımsaldır; gerçek Fs kanıtı değildir.",
             "wf_increment / time_track aynı metadata'ya dayanır; iki bağımsız doğrulama sayılmaz.", ""]
    def metadata(label, props):
        selected = [(str(k), str(v)) for k, v in props.items() if re.search(r"(time|increment|offset|sample|rate|freq|decim|averag|clock|unit|hz|dt$)", str(k), re.I)]
        for k, v in selected:
            lines.append(f"  {label}.{k} = {v[:300]}")
    with TdmsFile.open(path) as tdms:
        lines.append(f"Eksik son segment: {tdms.file_status.incomplete_final_segment}")
        metadata("Dosya", tdms.properties)
        channels = [ch for g in tdms.groups() for ch in g.channels()]
        candidates = [f"{ch.group_name}/{ch.name}" for ch in channels
                      if re.search(r"(time|timestamp|zaman)", ch.name, re.I)]
        lines.append("Adından zaman kanalı olabilecekler (otomatik eşlenmedi): " + (", ".join(candidates) or "yok"))
        selected = [ch for ch in channels if (group is None or ch.group_name == group) and (channel is None or ch.name == channel)]
        if not selected:
            raise ValueError("Belirtilen grup/kanal bulunamadı.")
        ts = None
        tc = None
        if time_channel is not None:
            tc = tdms[time_group][time_channel]
            ts = time_summary(tc, time_unit)
            unit = "s" if ts["unit_known"] else "bilinmeyen zaman birimi"
            lines += ["", f"Kullanıcının seçtiği zaman kanalı: {time_group}/{time_channel}",
                      f"  N={ts['n']}; ilk={ts['first']}; son={ts['last']}",
                      f"  Baş/orta/son pencerelerde Δt min/medyan/max: {ts['min_dt']:.12g} / {ts['median_dt']:.12g} / {ts['max_dt']:.12g} {unit}",
                      f"  Artan/sonlu: {ts['positive']}; yaklaşık eşit aralıklı: {ts['uniform']}",
                      f"  İlk-son süre: {ts['span']:.12g} {unit}"]
            if ts["fs"] is not None:
                lines.append(f"  İncelenen zaman farklarından Fs: {ts['fs']:.12g} Hz; ilk-son ortalama: {ts['mean_fs']:.12g} Hz")
                if not math.isclose(ts["fs"], ts["mean_fs"], rel_tol=1e-4):
                    lines.append("  UYARI: yerel Δt ile ilk-son süre uyumsuz. Kayıtta zaman boşluğu/sıfırlanma olabilir; sabit Fs tüm kaydı açıklamıyor.")
            elif not ts["unit_known"]:
                lines.append("  Birim bilinmiyor: Fs hesaplanmadı. --time-unit s/ms/us/ns ile gerçek birimi belirtin.")
            else:
                lines.append("  Tek bir sabit Fs doğrulanamadı: geçersiz/düzensiz/tekrarlanan zamanlar olabilir.")
            lines.append("  Bu kontrol tüm zaman kanalını taramaz; eşit örnek sayısı aynı saate/sinyale ait olmayı kanıtlamaz.")
        for ch in selected:
            n = len(ch)
            lines += ["", f"KANAL: {ch.group_name}/{ch.name}", f"  Kaynak örnek sayısı N: {n}; NumPy türü: {ch.dtype}"]
            metadata("Grup", tdms[ch.group_name].properties)
            metadata("Kanal", ch.properties)
            inc = None
            try:
                value = _seconds(ch.properties["wf_increment"])
                if math.isfinite(value) and value > 0:
                    inc = value
            except (KeyError, TypeError, ValueError, OverflowError):
                pass
            if inc is None:
                lines.append("  Geçerli kanal wf_increment yok. Uygulama bu kanala kendiliğinden bir Time kanalı eşlemez.")
            else:
                lines.append(f"  Kanal metadata Fs={1/inc:.12g} Hz; ilk-son süre={(n-1)*inc if n else 0:.12g} s")
            if n < 2:
                lines.append("  Süre karşılaştırması için en az 2 örnek gerekli.")
                continue
            for fs in dict.fromkeys([float(assumed_fs), 5000., 500.]):
                lines.append(f"  {fs:.12g} Hz VARSAYILIRSA ilk-son süre: {(n-1)/fs:.12g} s")
            if known_duration is not None:
                lines.append(f"  Kullanıcının bildirdiği ilk-son süre {known_duration:.12g} s ise ortalama kayıt Fs: {(n-1)/known_duration:.12g} Hz")
            if ts:
                if ts["n"] != n:
                    lines.append(f"  Zaman kanalı uzunluğu {ts['n']} != {n}. Bire bir eşleme kurulamaz; oran tek başına seyrekleştirme kanıtı değildir.")
                else:
                    lines.append("  Zaman kanalıyla N eşit. Bire bir örnek eşleşmesini kayıt düzeninden ayrıca doğrulayın.")
            if indices is not None:
                a, b = indices
                if not 0 <= a < b < n:
                    raise ValueError(f"{ch.group_name}/{ch.name}: indeksler 0 <= A < B < N olmalı.")
                lines.append(f"  Seçilen özgün indeksler (0 tabanlı): A={a}, B={b}, Δi={b-a}")
                lines.append(f"  Olay süresi: 5000 Hz'de {(b-a)/5000:.12g} s; 500 Hz'de {(b-a)/500:.12g} s")
                if inc is not None:
                    lines.append(f"  Kanal metadata'sıyla olay süresi: {(b-a)*inc:.12g} s")
                if ts and ts["n"] == n and ts["unit_known"]:
                    ta, tb = _time_values(tc, a, 1)[0], _time_values(tc, b, 1)[0]
                    dt = _seconds(tb-ta) if ts["datetime"] else float(tb-ta)*ts["factor"]
                    lines.append(f"  Kullanıcının eşlediği gerçek zaman değerleriyle olay farkı: {dt:.12g} s (eşleme doğruysa)")
    lines += ["", "Yorum: 500 Hz seçince süre 10 kat büyür; beklenen süreye uyması gerçek Fs'nin 500 Hz olduğunu tek başına kanıtlamaz.",
              "Kanalların kayıt öncesi seyrekleştirilmesi, blok ortalaması, farklı kayıt hızı ve zaman eşlemesi kayıt yazılımında ayrıca incelenmelidir."]
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("file", type=Path)
    parser.add_argument("--group")
    parser.add_argument("--channel")
    parser.add_argument("--assumed-fs", type=_positive, default=5000.)
    parser.add_argument("--known-duration", type=_positive, help="Kanalın ilk-son örneği arasındaki bağımsız bilinen süre, saniye")
    parser.add_argument("--time-group")
    parser.add_argument("--time-channel")
    parser.add_argument("--time-unit", choices=["s", "ms", "us", "ns"])
    parser.add_argument("--indices", type=int, nargs=2, metavar=("A", "B"), help="0 tabanlı özgün örnek indeksleri")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    if bool(args.time_group) != bool(args.time_channel):
        parser.error("--time-group ve --time-channel birlikte kullanılmalı.")
    if args.time_unit and not args.time_channel:
        parser.error("--time-unit için bir zaman kanalı belirtin.")
    if args.report and (args.report.resolve() == args.file.resolve() or args.report.suffix.lower() != ".txt"):
        parser.error("Rapor kaynaktan farklı bir .txt dosyası olmalı.")
    try:
        report = build_report(args.file, assumed_fs=args.assumed_fs, group=args.group, channel=args.channel,
                              time_group=args.time_group, time_channel=args.time_channel, time_unit=args.time_unit,
                              known_duration=args.known_duration, indices=args.indices)
        if args.report:
            args.report.write_text(report, encoding="utf-8-sig")
            print(f"Rapor: {args.report}")
        else:
            if hasattr(sys.stdout, "reconfigure"):
                sys.stdout.reconfigure(errors="replace")
            print(report)
    except (OSError, KeyError, ValueError, TypeError) as exc:
        parser.exit(1, f"Teşhis tamamlanamadı: {exc}\n")


if __name__ == "__main__":
    main()
