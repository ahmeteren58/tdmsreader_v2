"""Background jobs on Python threads with GUI-thread result delivery.

Workers stay in the GUI thread and are destroyed there; the job thread only
calls ``worker.run()``. PyQt releases the GIL while it queues a signal
emission, so a job thread never waits for a Qt lock while holding the GIL.

The previous QThread + moveToThread + deleteLater lifecycle destroyed
Python-owned workers inside the finishing QThread. sip needs the GIL there
while Qt holds its connection locks, so a GUI thread that was starting the
next job (moveToThread/connect) at that moment deadlocked the application.
"""
from __future__ import annotations

import logging
import threading

from PyQt6.QtCore import QObject, pyqtSignal

logger = logging.getLogger(__name__)


class JobThread(QObject):
    """Runs one worker; ``done`` is queued to the GUI thread after its results."""

    done = pyqtSignal()

    def __init__(self, worker: QObject, name: str = "") -> None:
        super().__init__()
        self.worker = worker
        self._interrupted = threading.Event()
        self._thread = threading.Thread(
            target=self._run, name=name or f"tdms-{type(worker).__name__}", daemon=True)

    def _run(self) -> None:
        try:
            self.worker.run()
        except Exception as exc:
            logger.exception("Arka plan işi beklenmedik biçimde sonlandı")
            failed = getattr(self.worker, "failed", None)
            if failed is not None:
                failed.emit(f"Arka plan işlemi başarısız:\n{exc}")
        finally:
            self.done.emit()

    def start(self) -> None:
        self._thread.start()

    def requestInterruption(self) -> None:
        self._interrupted.set()

    def isInterruptionRequested(self) -> bool:
        return self._interrupted.is_set()

    def isRunning(self) -> bool:
        return self._thread.is_alive()

    def isFinished(self) -> bool:
        return self._thread.ident is not None and not self._thread.is_alive()

    def wait(self, msecs: int | None = None) -> bool:
        if self._thread.ident is None:
            return True
        self._thread.join(None if msecs is None else max(0, msecs) / 1000)
        return not self._thread.is_alive()
