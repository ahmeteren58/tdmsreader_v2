# TDMSReader Pro 2.5.3 — Vana analizi ve tanı

Bu araç, iki kaydedilmiş sinyalde tanımladığınız kenarların arasındaki süreyi ölçer. Hangi sinyalin komut, hangisinin konum geri bildirimi olduğu ölçümün fiziksel anlamını değiştirir. Bağlantı türü, kanal rolleri ve aktif seviye **sizin seçiminizdir**. Kanal adından rol veya polarite tahmin edilmez; otomatik ayar bunları değiştirmez, yalnız öneri olarak sunar.

## Hızlı kullanım (2.5.3)

1. TDMS dosyasını açın. İki kanalı işaretleyip **Seçili Kanalları Çiz**'e basın. Kanalın `wf_increment` değeri yoksa **Manuel Fs** sekmesinde gerçek kanal hızını girin.
2. **Vana Analizi → 1 · Bağlantı ve kanallar**
   - **Bağlantı türü:** kayıttaki iki sinyalin ne olduğunu seçin. Varsayılan **İki konum sensörü (açık + kapalı)**. Altındaki açıklama açılma ve kapanmanın hangi kenarlar arasında ölçüleceğini yazar.
   - **A / B kanalı:** satır başlıkları seçili türe göre rolü söyler; örneğin *A · Açma komutu*, *B · Kapalı konum sensörü*.
   - **Aktif seviye:** sensör konumu algıladığında veya komut verildiğinde sinyal 1 ise **Normal (1 = aktif)**, 0 ise (normalde kapalı kontak, pull-up) **Ters (0 = aktif)** seçin.
   - **⇅ A ↔ B:** kanalları rolleri ve kanal ayarlarıyla birlikte yer değiştirir.
   - **Giriş türünü, eşikleri ve parazit filtresini veriden belirle (önerilen):** varsayılan açıktır.
3. **Süreleri Hesapla**'ya basın.
4. **2 · Sonuç** bölümünde açılma ve kapanma kartlarını okuyun: ortalama, min/maks, σ ve olay sayısı `n`. Altındaki satır, hesapta **kullanılan ayarları** yazar: giriş türü, bulunan seviyeler ve eşikler, aktif seviye, filtre süresi. **Kontrol edilecek olay** kartı sıfır değilse **Sonrakini göster ›** ile sorunlu olaylara sırayla gidin.
5. Uyarı kutusunda bir **Öneri** varsa okuyun. Kanal bağlantınıza uyuyorsa **Öneriyi uygula ve yeniden hesapla**'ya basın.
6. **3 · Olaylar ve elle doğrulama** bölümünde olayları ham sinyal üzerinde kontrol edin. Gerekirse Baş./Bit. çizgilerini sürükleyip **Doğrulamayı Kaydet** veya **Reddet** kullanın. Kartlar hemen güncellenir.
7. **CSV'ye Aktar** ile sonuçları saklayın.

Son seçilen bağlantı türü ve otomatik ayar tercihi uygulama ayarlarında hatırlanır. Kanal, Fs veya ayar değişikliği mevcut sonucu ve doğrulamaları temizler.

## Otomatik ayar neyi belirler?

Otomatik ayar açıkken her hesaplamada özgün örneklerden şunlar belirlenir. Bulunan değerler **Gelişmiş ayarlar** alanlarına yazılır, böylece hangi değerin kullanıldığını görebilirsiniz.

| Ayar | Nasıl belirlenir |
| --- | --- |
| Giriş türü | Kanalın sonlu örnekleri yalnız 0 ve 1 ise (NaN/Inf hariç) **Kesin 0/1**, aksi hâlde **Analog + histerezis**. |
| Seviyeler | Beşer örneklik blokların medyanları kullanılır; bir-iki örneklik sıçramalar seviyeyi kaydırmaz. Düşük/yüksek seviye, iki kümenin medyanıdır. Kayıtta nadir görülen seviye de bulunur. Çok büyük kanallarda seviye için en fazla yaklaşık 1 milyon örneklik eşit aralıklı alt küme kullanılır; min/maks ve 0/1 kontrolü tüm örneklerden yapılır. |
| Eşikler | Seviye farkının %30'u (alt) ve %70'i (üst). Gürültü (MAD tabanlı σ) seviye farkının 1/8'inden büyükse "seviyeler gürültüden net ayrışmıyor" uyarısı verilir. |
| Parazit filtresi | Filtresiz ve 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 64 örneklik adaylar denenir. En iyi eşleşmeyi veren **en kısa** filtre seçilir. Eşleşme puanı = tamamlanan olay − sorunlu olay (başlangıç uyumsuz, geri dönen, belirsiz, süre aşımı) − hiçbir olaya ait olmayan kenar. Filtre, ölçülen en kısa sürenin %20'sini aşamaz; bu nedenle gerçek kısa hareketler elenmez, "Başlatan sinyal geri döndü" olarak raporlanır. |

Filtre süresi her kanalın kendi örnek aralığından hesaplanır ve arayüzde gösterilen ms değeri tam olarak aynı durumları seçer. Otomatik ayar zaman hesabını değiştirmez: aynı ayarlar elle girildiğinde sonuç birebir aynıdır.

**Gelişmiş ayarlar**'da giriş türü, eşik veya filtre değiştirirseniz otomatik ayar kapanır ve değerler girdiğiniz gibi kullanılır. Aktif seviye, bağlantı türü veya azami bekleme değişikliği otomatik ayarı kapatmaz.

## Öneriler

Seçili ayarlarla sorunlu olay kalırsa, hiç olay tamamlanmazsa veya ikiden fazla açıklanamayan kenar varsa uygulama şu alternatifleri aynı taramayla dener:

- Aynı bağlantı türünde bir veya iki kanalın aktif seviyesini değiştirmek,
- A ve B kanallarını yer değiştirmek,
- diğer bağlantı türleri (*Eski kural* ve *Özel* önerilmez).

Belirgin biçimde daha iyi eşleşen seçenek, neyin değiştiği ve kaç olayın tamamlandığıyla birlikte yazılır. Ayrıca **ilk olayın yönü ve bunun gerektirdiği kayıt başı vana konumu** belirtilir.

Öneri yalnız kenar eşleşmesine dayanır. Örneğin iki kanalın ikisini birden ters çevirmek aynı kaydı zıt yönde bir hareket gibi okuyabilir: açılmalar kapanma olarak etiketlenir. Bu yüzden öneri kendiliğinden uygulanmaz. Uygulamadan önce kanal rollerini ve kayıt başında vananın açık mı kapalı mı olduğunu bilinen test düzeninizle karşılaştırın.

## 2.4.0 neden kapanmayı kaçırabiliyordu?

Eski algoritma açılmada `A yükselir → B düşer`, kapanmada `B yükselir → A düşer` sırasını arıyordu. Her iki sinyalin de 1 olduğu süreyi ölçüyordu. Bu kural bazı elektrik bağlantıları için uygundur; her vana kaydı için uygun değildir.

Aktif yüksek iki konum sensöründe kapanma genellikle **açık konumdan ayrılma (A düşer) → kapalı konuma varma (B yükselir)** şeklindedir. Eski kuralın sırası bunun tersidir. A bir açma komutuysa kapanmanın başlangıcı yine komutun düşmesi olabilir. Bu durumda yalnız filtre süresini artırmak yanlış kuralı düzeltmez.

İkinci sorun kontak sıçraması veya kısa parazit darbeleridir. Tek bir örnek yanlış bir bitiş ya da geri dönüş gibi görünebilir. Örneğin 100 ms'lik kapanma 10 ms bulunabilir veya yarıda iptal edilebilir. Ana grafiğe uygulanan SG filtresi vana analizine uygulanmadığı için grafiği yumuşatmak bu eşleştirmeyi değiştirmez.

## Bağlantı türleri

| Bağlantı türü | A kanalı | B kanalı | Açılma | Kapanma |
| --- | --- | --- | --- | --- |
| İki konum sensörü (açık + kapalı) | Açık konum sensörü | Kapalı konum sensörü | B 1→0 → A 0→1 | A 1→0 → B 0→1 |
| Açma komutu + kapalı konum sensörü | Açma komutu | Kapalı konum sensörü | A 0→1 → B 1→0 | A 1→0 → B 0→1 |
| Açma komutu + açık konum sensörü | Açma komutu | Açık konum sensörü | A 0→1 → B 0→1 | A 1→0 → B 1→0 |
| Eski kural (2.4.0 uyumlu) | Açık sinyali | Kapalı sinyali | A 0→1 → B 1→0 | B 0→1 → A 1→0 |
| Özel kenar eşleştirme | A kanalı | B kanalı | Başlangıç/bitiş kanal ve kenarları seçilir | Başlangıç/bitiş kanal ve kenarları seçilir |

Tablo **aktif seviye uygulandıktan sonraki** 0/1 durumları içindir: 1 = aktif. İki kanalın da aynı sinyali seçmesi veya özel bir kuralın aynı kanalda başlayıp bitmesi kabul edilmez. 2.5.2 ve öncesinde varsayılan eski kuraldı; eski sonuçlarla karşılaştırma için **Eski kural (2.4.0 uyumlu)** seçin.

**Fiziksel anlam:** İki konum sensörü türü, kaynak konumdan ayrılma ile hedef konuma varma arasını ölçer; öncesindeki komut gecikmesini içermez. Açma komutu + kapalı konum türünde açılma, kapalı konumdan ayrılma gecikmesidir; tam açılma süresi değildir. Açma komutu + açık konum türünde kapanma, açık konumdan ayrılma gecikmesidir; kapalı konuma varış değildir. Eksik geri bildirimden toplam strok süresi çıkarılmaz.

## Gürültü nasıl işlenir?

İşlem sırası: **özgün örnek → kesin 0/1 veya histerezis → aktif seviye → kanal bazlı parazit filtresi → kenar eşleştirme**.

- **Histerezis:** Değer üst eşiğe eşit veya büyükse yüksek; alt eşiğe eşit veya küçükse düşük olur. Aradaki bantta önceki seviye korunur. İlk örnek banttaysa durum, eşiklerden biri görülene kadar bilinmez. NaN/Inf sonrasında da seviye yeniden belirlenir. Alt eşik üst eşikten küçük olmalıdır. Eşikler kaynağın ham Y birimindedir; npTDMS/DAQmx ölçeklendirmesi varsa onun sonucudur.
- **Parazit filtresi (kararlılık süresi):** Yeni durum belirlenen süre kadar sürerse kabul edilir. Süre **ms** olarak girilir; 0 = filtre kapalı. Kenarın zamanı kabul edilen durumun **ilk özgün örneğidir**; doğrulama süresi süre hesabına eklenmez. Her kanalın filtresi yükselen ve düşen kenarları için geçerlidir.
- **Kısa durumlar:** Kabul edilmez, sayılır ve sağ grafikte × ile gösterilir. Özet satırı elenen sayıyı ve en uzununu yazar (örn. `elenen kısa durum: 2 (en uzun 2 ms)`). Bunlar gerçek kısa hareketler de olabilir; elenen noktaları inceleyin.
- **Kayıt sonu:** Yeni durum yeterince uzun gözlenmemişse doğrulanmış kenar sayılmaz. Uzun bir filtre bu nedenle bitişi eksik gösterebilir.
- **Veri boşlukları:** Doldurulmaz. Boşluğun iki tarafı birleştirilerek kenar veya süre uydurulmaz.

Filtre, ilk fiziksel teması bulma algoritması değildir. Kontak 700 ms'de ilk kez düşüp 702–706 ms arasında sıçradıktan sonra 707 ms'de kalıcı olarak düşerse, 3 ms filtre bitişi **707 ms** olarak kabul eder. İlk temas ile kararlı konuma varma ayrı ölçüm tanımlarıdır. İlk teması ölçmeniz gerekiyorsa bunu ham grafikte değerlendirip elle doğrulama olarak kaydedin.

## Tanı grafikleri

Her kanal için sol sütun ham sinyali kendi biriminde, sağ sütun aktif durumun 0/1 karşılığını gösterir.

| Görünüm | Anlamı |
| --- | --- |
| Sol gri çizgi | Ham kaynak örnekleri; dijitalde tüm geçişler, analogda min/max önizleme |
| Sağ kesikli gri | Eşikleme/aktif seviye sonrası, filtre öncesi durum |
| Sağ renkli çizgi | Analizin kullandığı kabul edilmiş durum |
| Sağ × işaretleri | Filtre süresini karşılamayan durumların ilk örnekleri |
| Sol yatay kesikli çizgiler | Analog girişin alt/üst eşikleri |
| Dikey Baş./Bit. çizgileri | Seçili olayın incelenen başlangıcı ve bitişi |

Tüm grafiklerin zaman eksenleri bağlıdır. Ctrl + sağ tıkla **Seçili Olaya Sığdır** veya **Tüm Kaydı Göster** kullanılır. Dar ekranda alt kontroller sekmenin dikey kaydırma çubuğuyla erişilir.

Analog ham önizleme yaklaşık 8.000 noktalık min/max gösterimi kullanır (blok sınırları birkaç nokta ekleyebilir); her analog örneği çizmez. **Analiz ve elle ölçüm daima özgün örnekleri kullanır.** Dijital koşullandırılmış ve kabul edilmiş geçişler tam zamanlarında saklanır.

## Uyarıların anlamı

| Durum | Açıklama ve kontrol |
| --- | --- |
| Tamamlandı | Seçili kuralın başlangıç/bitiş çifti bulundu. Mekanik anlamı seçili bağlantı türüne bağlıdır. |
| Başlangıç uyumsuz | Bitiş kanalının başlangıç öncesi durumu, seçilen bitiş kenarıyla uyumlu değil. Satır açıklaması beklenen ve görülen seviyeyi yazar. Bağlantı türü, aktif seviye, önceki çevrim ve çok uzun filtreyi kontrol edin. |
| Başlatan sinyal geri döndü | Beklenen bitişten önce başlangıç kanalı önceki durumuna döndü. Gerçek komut iptali, kontak sıçraması veya yanlış kural olabilir. Tek başına vana arızası tanısı değildir. |
| Eşzamanlı kenarlar / belirsiz | Devam eden olayda bitiş ile başlatan sinyalin geri dönüşü aynı zaman damgasında. Öncelikleri çözülemez; otomatik süre üretilmez. |
| Veri boşluğu | Ölçümde NaN/Inf veya henüz belirlenmemiş eşik durumu var. |
| Süre aşıldı | Belirlenen azami bekleme içinde uygun bitiş yok. |
| Bitiş eksik | Ortak kayıt aralığında doğrulanmış bitiş yok; kayıt kısa, kural yanlış veya son durum filtre için kısa olabilir. |

Tamamlanmayan olayların otomatik süresi boş kalır ve **Kontrol edilecek olay** kartında sayılır. Aynı zaman damgasında yeni başlangıç ve uygun bitiş görülürse 0 s bulunabilir; örnekleme sınırları sıfır olmak zorunda değildir. Kayıt başında zaten aktif olan bir kanal yeni kenar sayılmaz. Süresi aşılmış veya iptal edilmiş olay, başka çevrimin kenarıyla sonradan tamamlanmaz.

## Elle doğrulama ve rapor

Başlangıç çizgisi seçili kuralın başlangıç kanalındaki, bitiş çizgisi bitiş kanalındaki en yakın özgün örneğe oturur. Farklı Fs'ler korunur. Açıklamada kanal harfi, örnek indeksi ve ham değer yazılır. Eşit uzaklıkta önceki örnek seçilir; kayıt dışına veya NaN/Inf üzerine ölçüm konulamaz.

Otomatik süre korunur; elle süre, onay/red ve not ayrı tutulur. Eksik/uyumsuz olayın elle doğrulanması otomatik durumunu "tamamlandı"ya dönüştürmez. Çizgi düzenlenince eski onay kaldırılır; **Otomatiğe Dön** elle ölçümü temizler. Reddetmek satırı silmez.

**Özet kartları:** Elle ölçümü kaydedilmiş (onaylanan veya elle doğrulanan) olayda elle süre, diğer tamamlanan olaylarda otomatik süre kullanılır; reddedilen olaylar hariçtir. σ, üç veya daha fazla olay varken gösterilir.

**CSV'ye Aktar** tüm olayları, otomatik/elle süreleri, ham örnek indekslerini/değerlerini, örnekleme sınırlarını, kanal kimliklerini, Fs kaynaklarını, bağlantı türünü ve kullanılan başlangıç/bitiş kenarlarını içerir. `settings_json` alanında giriş türü, aktif seviye, eşikler ve her kanalın filtre süresi bulunur; `a_hold_s` / `b_hold_s` sütunları kullanılan filtreyi saniye olarak verir. Eski CSV sütunları geriye uyum için korunmuştur: `open_*` A kanalını, `closed_*` B kanalını temsil eder; yeni `channel_a`, `channel_b` ve rol sütunlarını esas alın.

Ayırıcı noktalı virgül, ondalık nokta, kodlama UTF-8 BOM'dur. Zamanlar özgün eksendedir; UTC kayıtlarında Unix saniyesidir. Grafik ve tablo ortak kayıt başlangıcına göre saniye gösterir. Dosya atomik yazılır; kaynak TDMS üzerine rapor yazılması engellenir.

**Saklama sınırı:** Vana sonuç tablosu ve elle doğrulamalar `.tdmsproj` içinde saklanmaz; kalıcı çıktı CSV'dir.

## Zaman çözünürlüğü ve doğruluk

5 Hz = 200 ms/örnek, 1 kHz = 1 ms/örnek. Gerçek örnekleme hızını değiştirmek veya ondalık basamak artırmak kaydedilmemiş zaman ayrıntısını üretmez. Her kanal yalnız kendi geçerli Manuel Fs veya `wf_increment` değerini kullanır. Biri saniye, diğeri UTC ise analiz yapılmaz. Farklı cihazların saatleri otomatik hizalanmaz.

A ve B burada seçili **başlangıç/bitiş zamanları**, `A_prev` ve `B_prev` o kanallardaki önceki örnekler olmak üzere süre sınırları:

- Alt: `max(0, B_prev − A)`
- Üst: `max(0, B − A_prev)`

Bu sınırlar istatistiksel güven aralığı değildir; kabul edilen kenarların örnekleme belirsizliğini gösterir. Eşik seçimi, sensör gecikmesi, kontak sıçraması ve cihaz saat farkları ayrıca değerlendirilmelidir.

**Doğrulama (2.5.3):** `tests/test_valve_253.py`, gerçek kenar zamanları bilinen sürekli bir vana hareketinden kayıtlar üretir. Her raporlanan sürenin örnekleme sınırları içinde kaldığını ve gerçek değere en yavaş kanalın bir örnek aralığından yakın olduğunu kontrol eder. Kapsanan durumlar:

- üç bağlantı türü,
- 1000/1000, 5000/1000 ve 200/2000 Hz kanal çiftleri,
- 0/1, gürültülü 0–24 V ve 4–20 seviyeleri,
- ters aktif seviye,
- tek-iki örneklik parazitler,
- kontak sıçraması,
- gerçek kısa komut darbesi,
- diskten okunan TDMS kaynağı.

Otomatik sonucun aynı ayarlarla elle yapılan analizle birebir aynı olduğu da test edilir. Gerçek cihaz kaydı bu ortamda denenmedi.

## Paketteki sentetik örnekler

`examples/vana_5hz.tdms`, 2.4.0 örneğidir ve **Eski kural (2.4.0 uyumlu)** ile çalışır. Varsayılan *İki konum sensörü* türünde uygulama iki kanalı ters çevirmeyi önerir. Bu öneri kaydı, kayıt başında açık olan bir vana gibi okur (ilk olay kapanma). Bu nedenle bu örnekte öneriyi uygulamayın; bağlantı türünü değiştirin.

`examples/vana_gurultulu_1khz.tdms`, 1 kHz örnekleme ile kısa parazit darbelerini, gürültülü analog seviyeleri ve ters polariteyi gösterir. **Gerçek vana ölçümü değildir.** Yeniden üretmek için `python examples/create_valve_noisy_demo.py` çalıştırın.

| TDMS grubu | A / B | Bağlantı türü | Otomatik ayarın bulduğu | Beklenen açılma / kapanma |
| --- | --- | --- | --- | --- |
| KonumAnahtarlari | Acik / Kapali | İki konum sensörü | Kesin 0/1, filtre 3 ms | 80 / 100 ms |
| TersPolarite | Acik / Kapali | İki konum sensörü, A ve B **Ters (0 = aktif)** | Kesin 0/1, filtre 3 ms. Normal seçiliyse öneri iki kanalı ters çevirir. | 80 / 100 ms |
| GurultuluKomut | AcmaKomutu_V / KapaliKonum_V | Açma komutu + kapalı konum sensörü | Analog ≈0,1/4,9 V, eşik ≈1,54/3,46 V, filtre 3 ms | 80 / 100 ms |

Otomatik ayarı kapatıp filtreyi 0 ms yaparak hangi kısa darbenin süreyi bozduğunu sağ/sol grafiklerde karşılaştırabilirsiniz. Bu sayılar örneğin bilinen kurulumuna aittir; kendi kaydınız için evrensel filtre/eşik önerisi değildir.

Büyük kayıtlar bloklarla taranır. Kanal başına 200.000 geçiş, analiz başına 20.000 olay sınırı aşılırsa açık hata verilir; sonuç sessizce kırpılmaz. Çok yoğun geçişli kayıtlarda (toplam 20.000 geçişten fazla) daha seyrek filtre adayları denenir. Sorunlu gerçek cihaz kaydı ve Windows EXE bu ortamda doğrulanmadı.
